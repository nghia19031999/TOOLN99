﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace BMD2
{
    public partial class CustomMessageBox: Form
    {
        public CustomMessageBox(string message, string title, Image icon = null, Image background = null)
        {
            InitializeComponent(); // gọi tới designer

            this.Text = title;
            using (Bitmap bmp = new Bitmap("anh-mat-cuoi-3.jpg"))
            {
                IntPtr hIcon = bmp.GetHicon();
                this.Icon = Icon.FromHandle(hIcon);
            }// 🔔 Thay icon ở đây
            lblMessage.Text = message;

            //if (icon != null)
            //    pictureBoxIcon.Image = icon;

            if (background != null)
            {
                this.BackgroundImage = background;
                this.BackgroundImageLayout = ImageLayout.Stretch;
            }
        }

        public static void ShowMessage(string message, string title, string iconPath, string backgroundPath)
        {
            Image icon = File.Exists(iconPath) ? Image.FromFile(iconPath) : null;
            Image bg = File.Exists(backgroundPath) ? Image.FromFile(backgroundPath) : null;

            using (var box = new CustomMessageBox(message, title, icon, bg))
            {
                box.ShowDialog();
            }
        }
    }
}
