﻿namespace BMD2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.btn_RUN = new System.Windows.Forms.Button();
            this.dgv1 = new System.Windows.Forms.DataGridView();
            this.cStt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cUID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cPass = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c2FAvsCookie = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cMail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cPassMail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cMailKP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cCheckBM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cSelect = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.chọnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bôiĐenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bỏChọnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bôiĐenToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.xóaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dòngĐãChọnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.aDDMAILKPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nHẬNBMNEWToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tẮTBẬTSÁNGTẠOIGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cHECKBMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sHAREBMIGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rEGBM12ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rEGBM2025ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lOADALLBMVIAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nHẬNBMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loginVIAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kILLChromeDriverToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lấyCookieVIAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nHẬNBMAUTOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lOGINGMAILCHROMEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tESTWABMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bACKUPBMTHEOIDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oUTBMTHEOIDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cHECKADMINBMTHEOIDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kICHWHATAPPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cHECKINFORBMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cHECKADMINIGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uOTIGBMFBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sHARED22025ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vIADToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lOADACBMD2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.label56 = new System.Windows.Forms.Label();
            this.tb_so_luong_BM = new System.Windows.Forms.TextBox();
            this.rtb_BMDIE = new System.Windows.Forms.RichTextBox();
            this.rtb_BM_Nhan_Du = new System.Windows.Forms.RichTextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.rtbdone = new System.Windows.Forms.RichTextBox();
            this.rtbAC_FAIL = new System.Windows.Forms.RichTextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.rtb_BM_CLOSE_4_THAY_THE = new System.Windows.Forms.RichTextBox();
            this.rtb_BM_CLOSE_3_THAY_THE = new System.Windows.Forms.RichTextBox();
            this.rtb_BM_CLOSE_2_THAY_THE = new System.Windows.Forms.RichTextBox();
            this.rtb_BM_CLOSE_THAY_THE = new System.Windows.Forms.RichTextBox();
            this.rtb_BM_BACKUP3_THAY_THE = new System.Windows.Forms.RichTextBox();
            this.rtb_BM_BACKUP2_THAY_THE = new System.Windows.Forms.RichTextBox();
            this.rtb_BM_BACKUP_THAY_THE = new System.Windows.Forms.RichTextBox();
            this.rtb_BM_THAY_THE = new System.Windows.Forms.RichTextBox();
            this.cmb_ADD_Tra_Truoc = new System.Windows.Forms.ComboBox();
            this.label34 = new System.Windows.Forms.Label();
            this.gioi_han_close = new System.Windows.Forms.NumericUpDown();
            this.label32 = new System.Windows.Forms.Label();
            this.gioi_han_live = new System.Windows.Forms.NumericUpDown();
            this.label31 = new System.Windows.Forms.Label();
            this.gioi_han_1 = new System.Windows.Forms.NumericUpDown();
            this.label30 = new System.Windows.Forms.Label();
            this.delayshare = new System.Windows.Forms.NumericUpDown();
            this.label29 = new System.Windows.Forms.Label();
            this.rtb_BM_PARTNER_THAY_THE = new System.Windows.Forms.RichTextBox();
            this.sl_Nhan_BM_CLOSE1_2 = new System.Windows.Forms.NumericUpDown();
            this.sl_Nhan_BM_PARTNER = new System.Windows.Forms.NumericUpDown();
            this.sl_nhan_Bm_BM_BACKUP = new System.Windows.Forms.NumericUpDown();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.tx_So_Luong_Share_vao_bm = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.tb_so_luong_BM_PARTNER = new System.Windows.Forms.TextBox();
            this.tb_BM_Close_4 = new System.Windows.Forms.TextBox();
            this.tb_BM_Close_3 = new System.Windows.Forms.TextBox();
            this.tb_BM_Close_2 = new System.Windows.Forms.TextBox();
            this.tb_BM_Close1 = new System.Windows.Forms.TextBox();
            this.tb_BM_BACK_UP3 = new System.Windows.Forms.TextBox();
            this.tb_BM_BACK_UP2 = new System.Windows.Forms.TextBox();
            this.tb_BM_BACK_UP = new System.Windows.Forms.TextBox();
            this.tb_BM = new System.Windows.Forms.TextBox();
            this.rtb_IDBM_PARTNER = new System.Windows.Forms.RichTextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.rtb_IDBM_CLOSE_4 = new System.Windows.Forms.RichTextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.rtb_IDBM_CLOSE_3 = new System.Windows.Forms.RichTextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.rtb_IDBM_CLOSE_2 = new System.Windows.Forms.RichTextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.rtb_IDBM_CLOSE = new System.Windows.Forms.RichTextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.rtb_ID_BM_Share_BACK_UP3 = new System.Windows.Forms.RichTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.rtb_ID_BM_Share_BACK_UP2 = new System.Windows.Forms.RichTextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.rtb_ID_BM_Share_BACK_UP = new System.Windows.Forms.RichTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.rtb_ID_BM_Share = new System.Windows.Forms.RichTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tb_sl_282 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cmb_CLOSE_SHARE = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmb_User_Agent = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.label55 = new System.Windows.Forms.Label();
            this.rtb_MAIL_SHARE_CLONE = new System.Windows.Forms.RichTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmb_Share_DOI_TAC = new System.Windows.Forms.ComboBox();
            this.label57 = new System.Windows.Forms.Label();
            this.cmb_Share_BM_CLone = new System.Windows.Forms.ComboBox();
            this.label54 = new System.Windows.Forms.Label();
            this.cmb_Mui_Gio_TK_BM = new System.Windows.Forms.ComboBox();
            this.label53 = new System.Windows.Forms.Label();
            this.cmb_TEN_TK_BM = new System.Windows.Forms.ComboBox();
            this.label52 = new System.Windows.Forms.Label();
            this.cmb_Tien_Te_TK_BM = new System.Windows.Forms.ComboBox();
            this.label51 = new System.Windows.Forms.Label();
            this.delay_reg_bm = new System.Windows.Forms.NumericUpDown();
            this.for_reg_bm = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cmb_Tao_TK_BM = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cmb_REG_BM_Clone_API = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label41 = new System.Windows.Forms.Label();
            this.cmb_DONG_VAN = new System.Windows.Forms.ComboBox();
            this.cmb_ID_MAIL = new System.Windows.Forms.ComboBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.soluong_mua_Mail = new System.Windows.Forms.NumericUpDown();
            this.label38 = new System.Windows.Forms.Label();
            this.tb_so_du_DongVan = new System.Windows.Forms.TextBox();
            this.Tx_Key_API_DongVan = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.tx_MK_Dong_Vanox2 = new System.Windows.Forms.TextBox();
            this.tx_TK_Dong_Van = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dgv2_IG = new System.Windows.Forms.DataGridView();
            this.cStt2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cIG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cStatus2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cSelect2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.contextMenuStrip3 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.chọnToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.bôiĐenToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.bỏChọnToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.bôiĐenToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảToolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.xóaToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.bôiĐenToolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảToolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.dgv_mail = new System.Windows.Forms.DataGridView();
            this.cStt1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cMail1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cPassMail1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cToken = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cStatus1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cSelect1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.chọnToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.bôiĐenToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.bỏChọnToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.bôiĐenToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.xóaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.dòngĐãChọnToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảToolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabControl6 = new System.Windows.Forms.TabControl();
            this.tabPage23 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label175 = new System.Windows.Forms.Label();
            this.cmb_REG_BM_IG_API_CHROME = new System.Windows.Forms.ComboBox();
            this.tb_ID_UP = new System.Windows.Forms.TextBox();
            this.label140 = new System.Windows.Forms.Label();
            this.label139 = new System.Windows.Forms.Label();
            this.label138 = new System.Windows.Forms.Label();
            this.tb_MK_NAM = new System.Windows.Forms.TextBox();
            this.tb_TK_NAM = new System.Windows.Forms.TextBox();
            this.cmb_UP_WEB = new System.Windows.Forms.ComboBox();
            this.label137 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.cmb_REGHOTMAIL = new System.Windows.Forms.ComboBox();
            this.cmb_VN_US = new System.Windows.Forms.ComboBox();
            this.tabPage24 = new System.Windows.Forms.TabPage();
            this.label225 = new System.Windows.Forms.Label();
            this.cmb_ramdom_nuoc = new System.Windows.Forms.ComboBox();
            this.cmb_NO_RANDOM = new System.Windows.Forms.ComboBox();
            this.label215 = new System.Windows.Forms.Label();
            this.cmb_Random4_17 = new System.Windows.Forms.ComboBox();
            this.label214 = new System.Windows.Forms.Label();
            this.cmb_dinh_dang_ten = new System.Windows.Forms.ComboBox();
            this.label213 = new System.Windows.Forms.Label();
            this.tabPage25 = new System.Windows.Forms.TabPage();
            this.cmn_doc_link_hotmail_vanha = new System.Windows.Forms.ComboBox();
            this.label224 = new System.Windows.Forms.Label();
            this.tabPage26 = new System.Windows.Forms.TabPage();
            this.label228 = new System.Windows.Forms.Label();
            this.cmb_nameMACDINH = new System.Windows.Forms.ComboBox();
            this.cmb_Domain_RANDOM = new System.Windows.Forms.ComboBox();
            this.label227 = new System.Windows.Forms.Label();
            this.label226 = new System.Windows.Forms.Label();
            this.cmb_domain_moakt = new System.Windows.Forms.ComboBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.numericUpDown10 = new System.Windows.Forms.NumericUpDown();
            this.label230 = new System.Windows.Forms.Label();
            this.label200 = new System.Windows.Forms.Label();
            this.cmb_bo_DIE = new System.Windows.Forms.ComboBox();
            this.cmb_TTK_BM350 = new System.Windows.Forms.ComboBox();
            this.cmb_TTK_BM50 = new System.Windows.Forms.ComboBox();
            this.label177 = new System.Windows.Forms.Label();
            this.label176 = new System.Windows.Forms.Label();
            this.label151 = new System.Windows.Forms.Label();
            this.numericUpDown5_delay_regbmig = new System.Windows.Forms.NumericUpDown();
            this.label150 = new System.Windows.Forms.Label();
            this.num_tao_5bm = new System.Windows.Forms.NumericUpDown();
            this.cmb_Tao_5BM_IG = new System.Windows.Forms.ComboBox();
            this.label149 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.cmb_TTKQC_BM_IG = new System.Windows.Forms.ComboBox();
            this.label110 = new System.Windows.Forms.Label();
            this.cmb_REG_BM_IG1 = new System.Windows.Forms.ComboBox();
            this.label109 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.cmb_2FA_IG = new System.Windows.Forms.ComboBox();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.cmb_ON_OFF_2FAIG = new System.Windows.Forms.ComboBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.delay_doc_hotmail_1 = new System.Windows.Forms.NumericUpDown();
            this.label222 = new System.Windows.Forms.Label();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.cmb_Tao_1_5 = new System.Windows.Forms.ComboBox();
            this.label205 = new System.Windows.Forms.Label();
            this.cmb_kick_BM3_IG = new System.Windows.Forms.ComboBox();
            this.label198 = new System.Windows.Forms.Label();
            this.cmb_doc_luon_link_mail_ao = new System.Windows.Forms.ComboBox();
            this.label181 = new System.Windows.Forms.Label();
            this.btn_update_mail = new System.Windows.Forms.Button();
            this.label168 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label167 = new System.Windows.Forms.Label();
            this.n_slink_share_them = new System.Windows.Forms.NumericUpDown();
            this.label163 = new System.Windows.Forms.Label();
            this.delay_tatbatsangtao = new System.Windows.Forms.NumericUpDown();
            this.cmb_sharebmt6_50 = new System.Windows.Forms.ComboBox();
            this.label162 = new System.Windows.Forms.Label();
            this.label161 = new System.Windows.Forms.Label();
            this.cmb_sharebmt6_350 = new System.Windows.Forms.ComboBox();
            this.label160 = new System.Windows.Forms.Label();
            this.label159 = new System.Windows.Forms.Label();
            this.label158 = new System.Windows.Forms.Label();
            this.nam_rip = new System.Windows.Forms.NumericUpDown();
            this.thang_rip = new System.Windows.Forms.NumericUpDown();
            this.ngay_rip = new System.Windows.Forms.NumericUpDown();
            this.cmb_RIPIG = new System.Windows.Forms.ComboBox();
            this.label157 = new System.Windows.Forms.Label();
            this.cmb_BMT6 = new System.Windows.Forms.ComboBox();
            this.label156 = new System.Windows.Forms.Label();
            this.cmb_color350 = new System.Windows.Forms.ComboBox();
            this.label155 = new System.Windows.Forms.Label();
            this.cmb_on_off_chrome = new System.Windows.Forms.ComboBox();
            this.label154 = new System.Windows.Forms.Label();
            this.label153 = new System.Windows.Forms.Label();
            this.numericUpDown5_slcheck_bm350 = new System.Windows.Forms.NumericUpDown();
            this.cmb_chishare_bm350 = new System.Windows.Forms.ComboBox();
            this.label152 = new System.Windows.Forms.Label();
            this.cmb_LOAI_LINK = new System.Windows.Forms.ComboBox();
            this.label142 = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.rtb_hotmail_BM350 = new System.Windows.Forms.RichTextBox();
            this.label88 = new System.Windows.Forms.Label();
            this.cmb_DOC_LINK_MAX = new System.Windows.Forms.ComboBox();
            this.label87 = new System.Windows.Forms.Label();
            this.rtb_BMIII = new System.Windows.Forms.RichTextBox();
            this.label86 = new System.Windows.Forms.Label();
            this.cmb_CHECK_ADMIN = new System.Windows.Forms.ComboBox();
            this.label85 = new System.Windows.Forms.Label();
            this.delay_check_admin = new System.Windows.Forms.NumericUpDown();
            this.label84 = new System.Windows.Forms.Label();
            this.rtb_Link_BM350_IG = new System.Windows.Forms.RichTextBox();
            this.cmb_TAT_BAT_SANG_TAO = new System.Windows.Forms.ComboBox();
            this.label83 = new System.Windows.Forms.Label();
            this.cmb_AN_CHROME = new System.Windows.Forms.ComboBox();
            this.label82 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.cmb_MAIL_SHARE_BM_IG = new System.Windows.Forms.ComboBox();
            this.label80 = new System.Windows.Forms.Label();
            this.rtb_hotmail = new System.Windows.Forms.RichTextBox();
            this.cmb_Admin_BM = new System.Windows.Forms.ComboBox();
            this.label79 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.rtb_Link_BM_IG = new System.Windows.Forms.RichTextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.cmb_LOGIN_IG = new System.Windows.Forms.ComboBox();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.ndelayloop = new System.Windows.Forms.NumericUpDown();
            this.label74 = new System.Windows.Forms.Label();
            this.cmb_DUNG_DOC_LINK_BACKUP = new System.Windows.Forms.ComboBox();
            this.label73 = new System.Windows.Forms.Label();
            this.delay_link_bm_backup = new System.Windows.Forms.NumericUpDown();
            this.label72 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.rtb_MAIL_DOCLINK_BACKUP = new System.Windows.Forms.RichTextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.rtb_FAIL3 = new System.Windows.Forms.RichTextBox();
            this.rtb_linkmail3_backup = new System.Windows.Forms.RichTextBox();
            this.rtb_DONE3 = new System.Windows.Forms.RichTextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.rtb_FAIL2 = new System.Windows.Forms.RichTextBox();
            this.rtb_linkmail2_backup = new System.Windows.Forms.RichTextBox();
            this.rtb_DONE2 = new System.Windows.Forms.RichTextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.rtb_FAIL1 = new System.Windows.Forms.RichTextBox();
            this.rtb_linkmail1_backup = new System.Windows.Forms.RichTextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.rtb_DONE1 = new System.Windows.Forms.RichTextBox();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.label75 = new System.Windows.Forms.Label();
            this.cmb_HOTMAIL_GMAIL = new System.Windows.Forms.ComboBox();
            this.cmbonoffchrome = new System.Windows.Forms.ComboBox();
            this.cmb_lay_Cookie = new System.Windows.Forms.ComboBox();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.tb_IDBM_CHECK = new System.Windows.Forms.TextBox();
            this.label210 = new System.Windows.Forms.Label();
            this.delay_check_infor = new System.Windows.Forms.NumericUpDown();
            this.label209 = new System.Windows.Forms.Label();
            this.cmb_Check_Infor_BM = new System.Windows.Forms.ComboBox();
            this.label207 = new System.Windows.Forms.Label();
            this.cmb_LOAD_API_CHROME = new System.Windows.Forms.ComboBox();
            this.label192 = new System.Windows.Forms.Label();
            this.tb_EEAG_LOAD_BM = new System.Windows.Forms.TextBox();
            this.label189 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.label92 = new System.Windows.Forms.Label();
            this.sl_LOAD_TK_D2 = new System.Windows.Forms.NumericUpDown();
            this.dgv_AC = new System.Windows.Forms.DataGridView();
            this.cSttACBM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cIDACBM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cNAMEAC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cStatusAC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cLimit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cTIENTE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cNGAYTAOACBM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cSelectACBM = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.contextMenuStrip5 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.xÓAALLToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.label90 = new System.Windows.Forms.Label();
            this.delay_LOAD_BM = new System.Windows.Forms.NumericUpDown();
            this.label89 = new System.Windows.Forms.Label();
            this.SL_BM_LOAD = new System.Windows.Forms.NumericUpDown();
            this.rtb_IDBM_FILTER = new System.Windows.Forms.RichTextBox();
            this.bt_filter = new System.Windows.Forms.Button();
            this.dgv_BM = new System.Windows.Forms.DataGridView();
            this.cSTTBM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cIDVIA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cIDBM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cNAMEBM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cStatusBM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cLOAIBM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cinfor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cNgayTao = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cADMIN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cTKLIVEDIE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cSelectBM = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.contextMenuStrip4 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.chọnToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.bôiĐenToolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảToolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.bỏChọnToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.bôiĐenToolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảToolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.xóaALLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lOADTKDONGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bACKUPBMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bACKUPBMNHIEUVIAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.tb_Token = new System.Windows.Forms.TextBox();
            this.label195 = new System.Windows.Forms.Label();
            this.label174 = new System.Windows.Forms.Label();
            this.rtb_backup_fail = new System.Windows.Forms.RichTextBox();
            this.bt_doi_dinh_dang = new System.Windows.Forms.Button();
            this.label173 = new System.Windows.Forms.Label();
            this.rtb_BM_OUT = new System.Windows.Forms.RichTextBox();
            this.label172 = new System.Windows.Forms.Label();
            this.rtb_ADMIN_BM_CHECK = new System.Windows.Forms.RichTextBox();
            this.label165 = new System.Windows.Forms.Label();
            this.rtb_IDBM_Can_Tao_TK = new System.Windows.Forms.RichTextBox();
            this.label164 = new System.Windows.Forms.Label();
            this.rtb_IDBM_CAN_BACK_Up = new System.Windows.Forms.RichTextBox();
            this.label99 = new System.Windows.Forms.Label();
            this.rtb_Link_BM = new System.Windows.Forms.RichTextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.cmb_API_CHROME_BACK_UP_BM_THEO_ID = new System.Windows.Forms.ComboBox();
            this.label208 = new System.Windows.Forms.Label();
            this.label199 = new System.Windows.Forms.Label();
            this.cmb_share_ban = new System.Windows.Forms.ComboBox();
            this.label194 = new System.Windows.Forms.Label();
            this.n_Delay_TTK = new System.Windows.Forms.NumericUpDown();
            this.label193 = new System.Windows.Forms.Label();
            this.bt_Tao_TK_BM = new System.Windows.Forms.Button();
            this.numericUpDown7 = new System.Windows.Forms.NumericUpDown();
            this.cmb_loai_mail = new System.Windows.Forms.ComboBox();
            this.cmb_Admin_BM1 = new System.Windows.Forms.ComboBox();
            this.delay_doc_link = new System.Windows.Forms.NumericUpDown();
            this.so_link_backup = new System.Windows.Forms.NumericUpDown();
            this.tb_hotmail_Share_bm = new System.Windows.Forms.TextBox();
            this.label98 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.tabPage22 = new System.Windows.Forms.TabPage();
            this.label220 = new System.Windows.Forms.Label();
            this.cmb_new_create_WA = new System.Windows.Forms.ComboBox();
            this.label219 = new System.Windows.Forms.Label();
            this.cmb_delete_WA = new System.Windows.Forms.ComboBox();
            this.label212 = new System.Windows.Forms.Label();
            this.cmb_ttk_5_1_WA = new System.Windows.Forms.ComboBox();
            this.cmb_bo_check1 = new System.Windows.Forms.ComboBox();
            this.label211 = new System.Windows.Forms.Label();
            this.label206 = new System.Windows.Forms.Label();
            this.sl_BM_kick3 = new System.Windows.Forms.NumericUpDown();
            this.label204 = new System.Windows.Forms.Label();
            this.label203 = new System.Windows.Forms.Label();
            this.rtb_BM1 = new System.Windows.Forms.RichTextBox();
            this.rtb_BM3 = new System.Windows.Forms.RichTextBox();
            this.label197 = new System.Windows.Forms.Label();
            this.m_delay_ttk = new System.Windows.Forms.NumericUpDown();
            this.label196 = new System.Windows.Forms.Label();
            this.numericUpDown9 = new System.Windows.Forms.NumericUpDown();
            this.label191 = new System.Windows.Forms.Label();
            this.cmb_TTKQCBM3 = new System.Windows.Forms.ComboBox();
            this.btdoidang = new System.Windows.Forms.Button();
            this.label187 = new System.Windows.Forms.Label();
            this.numericUpDown5 = new System.Windows.Forms.NumericUpDown();
            this.tb_NAME_WHATAPP = new System.Windows.Forms.TextBox();
            this.label186 = new System.Windows.Forms.Label();
            this.delay_kick_bm3 = new System.Windows.Forms.NumericUpDown();
            this.label185 = new System.Windows.Forms.Label();
            this.label184 = new System.Windows.Forms.Label();
            this.rtb_status_kick = new System.Windows.Forms.RichTextBox();
            this.label183 = new System.Windows.Forms.Label();
            this.rtb_IDBM_KICK_BM3 = new System.Windows.Forms.RichTextBox();
            this.tb_TokenEEAG = new System.Windows.Forms.TextBox();
            this.label182 = new System.Windows.Forms.Label();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.label148 = new System.Windows.Forms.Label();
            this.bt_CLEAR_LINK = new System.Windows.Forms.Button();
            this.label147 = new System.Windows.Forms.Label();
            this.bt_CLEAR_FAIL = new System.Windows.Forms.Button();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label107 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.rtb_LINKBM_20 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_19 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_18 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_17 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_16 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_15 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_14 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_13 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_12 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_11 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_10 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_9 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_8 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_7 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_6 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_5 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_4 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_3 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_2 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_1 = new System.Windows.Forms.RichTextBox();
            this.label105 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.rtbLINK = new System.Windows.Forms.RichTextBox();
            this.rtb_Link_FAIL = new System.Windows.Forms.RichTextBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label101 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.cmb_CACH_NHAN_LINK = new System.Windows.Forms.ComboBox();
            this.cmbAPI_Auto_selenium_NhanBM = new System.Windows.Forms.ComboBox();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.tabControl4 = new System.Windows.Forms.TabControl();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.label229 = new System.Windows.Forms.Label();
            this.cmb_ALL_FILE = new System.Windows.Forms.ComboBox();
            this.label216 = new System.Windows.Forms.Label();
            this.rtb_codemail = new System.Windows.Forms.RichTextBox();
            this.cmb_file_random = new System.Windows.Forms.ComboBox();
            this.button5 = new System.Windows.Forms.Button();
            this.cmb_chi_doc_link_mail_ao = new System.Windows.Forms.ComboBox();
            this.label190 = new System.Windows.Forms.Label();
            this.label180 = new System.Windows.Forms.Label();
            this.label179 = new System.Windows.Forms.Label();
            this.rtb_mail_moakt_fail = new System.Windows.Forms.RichTextBox();
            this.rtb_mail_moakt_done = new System.Windows.Forms.RichTextBox();
            this.label178 = new System.Windows.Forms.Label();
            this.DELAY_DOC_MAIL = new System.Windows.Forms.NumericUpDown();
            this.label171 = new System.Windows.Forms.Label();
            this.cmb_loai_mail_nhan_bm_ig = new System.Windows.Forms.ComboBox();
            this.label166 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.cmb_FILE_OPEN = new System.Windows.Forms.ComboBox();
            this.button3 = new System.Windows.Forms.Button();
            this.label146 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.numericUpDown8 = new System.Windows.Forms.NumericUpDown();
            this.label223 = new System.Windows.Forms.Label();
            this.cmb_kologin_mail = new System.Windows.Forms.ComboBox();
            this.label221 = new System.Windows.Forms.Label();
            this.cmb_VIA_NHAN_VERRY = new System.Windows.Forms.ComboBox();
            this.label218 = new System.Windows.Forms.Label();
            this.num_STT_NHAN = new System.Windows.Forms.NumericUpDown();
            this.label217 = new System.Windows.Forms.Label();
            this.number_nhan_fail = new System.Windows.Forms.NumericUpDown();
            this.label202 = new System.Windows.Forms.Label();
            this.cmb_DIE_BM_CLEAR = new System.Windows.Forms.ComboBox();
            this.label201 = new System.Windows.Forms.Label();
            this.label188 = new System.Windows.Forms.Label();
            this.numericUpDown6 = new System.Windows.Forms.NumericUpDown();
            this.label141 = new System.Windows.Forms.Label();
            this.CMB_LOAI_BM_NHAN = new System.Windows.Forms.ComboBox();
            this.cmb_STOP = new System.Windows.Forms.ComboBox();
            this.label135 = new System.Windows.Forms.Label();
            this.label136 = new System.Windows.Forms.Label();
            this.cmbAPI_Auto_selenium_NhanBM_IG = new System.Windows.Forms.ComboBox();
            this.label134 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.rtb_mail_bm350_auto = new System.Windows.Forms.RichTextBox();
            this.rtb_mail_bm50_auto = new System.Windows.Forms.RichTextBox();
            this.rtb_BMIII_auto = new System.Windows.Forms.RichTextBox();
            this.label131 = new System.Windows.Forms.Label();
            this.rtb_Link_BM350_IG_auto = new System.Windows.Forms.RichTextBox();
            this.label130 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.rtb_Link_BM50_IG_auto = new System.Windows.Forms.RichTextBox();
            this.tabPage16 = new System.Windows.Forms.TabPage();
            this.tb_nhan20 = new System.Windows.Forms.TextBox();
            this.tb_20 = new System.Windows.Forms.TextBox();
            this.tb_nhan16 = new System.Windows.Forms.TextBox();
            this.tb_16 = new System.Windows.Forms.TextBox();
            this.tb_nhan12 = new System.Windows.Forms.TextBox();
            this.tb_12 = new System.Windows.Forms.TextBox();
            this.tb_nhan8 = new System.Windows.Forms.TextBox();
            this.tb_8 = new System.Windows.Forms.TextBox();
            this.tb_nhan4 = new System.Windows.Forms.TextBox();
            this.tb_4 = new System.Windows.Forms.TextBox();
            this.tb_nhan19 = new System.Windows.Forms.TextBox();
            this.tb_19 = new System.Windows.Forms.TextBox();
            this.tb_nhan15 = new System.Windows.Forms.TextBox();
            this.tb_15 = new System.Windows.Forms.TextBox();
            this.tb_nhan11 = new System.Windows.Forms.TextBox();
            this.tb_11 = new System.Windows.Forms.TextBox();
            this.tb_nhan7 = new System.Windows.Forms.TextBox();
            this.tb_7 = new System.Windows.Forms.TextBox();
            this.tb_nhan3 = new System.Windows.Forms.TextBox();
            this.tb_3 = new System.Windows.Forms.TextBox();
            this.tb_nhan18 = new System.Windows.Forms.TextBox();
            this.tb_18 = new System.Windows.Forms.TextBox();
            this.tb_nhan14 = new System.Windows.Forms.TextBox();
            this.tb_14 = new System.Windows.Forms.TextBox();
            this.tb_nhan10 = new System.Windows.Forms.TextBox();
            this.tb_10 = new System.Windows.Forms.TextBox();
            this.tb_nhan6 = new System.Windows.Forms.TextBox();
            this.tb_6 = new System.Windows.Forms.TextBox();
            this.tb_nhan2 = new System.Windows.Forms.TextBox();
            this.tb_2 = new System.Windows.Forms.TextBox();
            this.tb_nhan17 = new System.Windows.Forms.TextBox();
            this.tb_17 = new System.Windows.Forms.TextBox();
            this.tb_nhan13 = new System.Windows.Forms.TextBox();
            this.tb_13 = new System.Windows.Forms.TextBox();
            this.tb_nhan9 = new System.Windows.Forms.TextBox();
            this.tb_9 = new System.Windows.Forms.TextBox();
            this.tb_nhan5 = new System.Windows.Forms.TextBox();
            this.tb_5 = new System.Windows.Forms.TextBox();
            this.tb_nhan1 = new System.Windows.Forms.TextBox();
            this.tb_1 = new System.Windows.Forms.TextBox();
            this.label118 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.rtb_LINKBMFAIL_IG_19 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_20 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_20 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_19 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_15 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_16 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_16 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_15 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_11 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_12 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_12 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_11 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_7 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_8 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_8 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_7 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_3 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_4 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_4 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_3 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_17 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_18 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_18 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_17 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_13 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_14 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_14 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_13 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_9 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_10 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_10 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_9 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_5 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_6 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_6 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_5 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_1 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_2 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_2 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_1 = new System.Windows.Forms.RichTextBox();
            this.tabPage17 = new System.Windows.Forms.TabPage();
            this.tb_nhan40 = new System.Windows.Forms.TextBox();
            this.tb_40 = new System.Windows.Forms.TextBox();
            this.tb_nhan36 = new System.Windows.Forms.TextBox();
            this.tb_36 = new System.Windows.Forms.TextBox();
            this.tb_nhan32 = new System.Windows.Forms.TextBox();
            this.tb_32 = new System.Windows.Forms.TextBox();
            this.tb_nhan28 = new System.Windows.Forms.TextBox();
            this.tb_28 = new System.Windows.Forms.TextBox();
            this.tb_nhan24 = new System.Windows.Forms.TextBox();
            this.tb_24 = new System.Windows.Forms.TextBox();
            this.tb_nhan39 = new System.Windows.Forms.TextBox();
            this.tb_39 = new System.Windows.Forms.TextBox();
            this.tb_nhan35 = new System.Windows.Forms.TextBox();
            this.tb_35 = new System.Windows.Forms.TextBox();
            this.tb_nhan31 = new System.Windows.Forms.TextBox();
            this.tb_31 = new System.Windows.Forms.TextBox();
            this.tb_nhan27 = new System.Windows.Forms.TextBox();
            this.tb_27 = new System.Windows.Forms.TextBox();
            this.tb_nhan23 = new System.Windows.Forms.TextBox();
            this.tb_23 = new System.Windows.Forms.TextBox();
            this.tb_nhan38 = new System.Windows.Forms.TextBox();
            this.tb_38 = new System.Windows.Forms.TextBox();
            this.tb_nhan34 = new System.Windows.Forms.TextBox();
            this.tb_34 = new System.Windows.Forms.TextBox();
            this.tb_nhan30 = new System.Windows.Forms.TextBox();
            this.tb_30 = new System.Windows.Forms.TextBox();
            this.tb_nhan26 = new System.Windows.Forms.TextBox();
            this.tb_26 = new System.Windows.Forms.TextBox();
            this.tb_nhan22 = new System.Windows.Forms.TextBox();
            this.tb_22 = new System.Windows.Forms.TextBox();
            this.tb_nhan37 = new System.Windows.Forms.TextBox();
            this.tb_37 = new System.Windows.Forms.TextBox();
            this.tb_nhan33 = new System.Windows.Forms.TextBox();
            this.tb_33 = new System.Windows.Forms.TextBox();
            this.tb_nhan29 = new System.Windows.Forms.TextBox();
            this.tb_29 = new System.Windows.Forms.TextBox();
            this.tb_nhan25 = new System.Windows.Forms.TextBox();
            this.tb_25 = new System.Windows.Forms.TextBox();
            this.tb_nhan21 = new System.Windows.Forms.TextBox();
            this.tb_21 = new System.Windows.Forms.TextBox();
            this.label128 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.rtb_LINKBMFAIL_IG_39 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_40 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_40 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_39 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_35 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_36 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_36 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_35 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_31 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_32 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_32 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_31 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_27 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_28 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_28 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_27 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_23 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_24 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_24 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_23 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_37 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_38 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_38 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_37 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_33 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_34 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_34 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_33 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_29 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_30 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_30 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_29 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_25 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_26 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_26 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_25 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_21 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_22 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_22 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_21 = new System.Windows.Forms.RichTextBox();
            this.tabPage18 = new System.Windows.Forms.TabPage();
            this.label145 = new System.Windows.Forms.Label();
            this.delay_check_ig = new System.Windows.Forms.NumericUpDown();
            this.label144 = new System.Windows.Forms.Label();
            this.label143 = new System.Windows.Forms.Label();
            this.rtb_282 = new System.Windows.Forms.RichTextBox();
            this.rtb_LIVE = new System.Windows.Forms.RichTextBox();
            this.tabPage19 = new System.Windows.Forms.TabPage();
            this.tabControl5 = new System.Windows.Forms.TabControl();
            this.tabPage20 = new System.Windows.Forms.TabPage();
            this.label170 = new System.Windows.Forms.Label();
            this.label169 = new System.Windows.Forms.Label();
            this.rtb_10_link_bm350 = new System.Windows.Forms.RichTextBox();
            this.rtb_10_link_bm50 = new System.Windows.Forms.RichTextBox();
            this.tabPage21 = new System.Windows.Forms.TabPage();
            this.tabPage27 = new System.Windows.Forms.TabPage();
            this.tabControl7 = new System.Windows.Forms.TabControl();
            this.tabPage28 = new System.Windows.Forms.TabPage();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.tabControl8 = new System.Windows.Forms.TabControl();
            this.tabPage31 = new System.Windows.Forms.TabPage();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.label289 = new System.Windows.Forms.Label();
            this.numericUpDown24 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown15 = new System.Windows.Forms.NumericUpDown();
            this.label298 = new System.Windows.Forms.Label();
            this.label290 = new System.Windows.Forms.Label();
            this.numericUpDown19 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown16 = new System.Windows.Forms.NumericUpDown();
            this.label293 = new System.Windows.Forms.Label();
            this.label292 = new System.Windows.Forms.Label();
            this.numericUpDown21 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown18 = new System.Windows.Forms.NumericUpDown();
            this.label295 = new System.Windows.Forms.Label();
            this.label291 = new System.Windows.Forms.Label();
            this.numericUpDown22 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown17 = new System.Windows.Forms.NumericUpDown();
            this.label296 = new System.Windows.Forms.Label();
            this.label294 = new System.Windows.Forms.Label();
            this.numericUpDown23 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown20 = new System.Windows.Forms.NumericUpDown();
            this.label297 = new System.Windows.Forms.Label();
            this.tabPage32 = new System.Windows.Forms.TabPage();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.label316 = new System.Windows.Forms.Label();
            this.numericUpDown25 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown26 = new System.Windows.Forms.NumericUpDown();
            this.label317 = new System.Windows.Forms.Label();
            this.label318 = new System.Windows.Forms.Label();
            this.numericUpDown27 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown28 = new System.Windows.Forms.NumericUpDown();
            this.label319 = new System.Windows.Forms.Label();
            this.label320 = new System.Windows.Forms.Label();
            this.numericUpDown29 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown30 = new System.Windows.Forms.NumericUpDown();
            this.label321 = new System.Windows.Forms.Label();
            this.label322 = new System.Windows.Forms.Label();
            this.numericUpDown31 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown32 = new System.Windows.Forms.NumericUpDown();
            this.label323 = new System.Windows.Forms.Label();
            this.label324 = new System.Windows.Forms.Label();
            this.numericUpDown33 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown34 = new System.Windows.Forms.NumericUpDown();
            this.label325 = new System.Windows.Forms.Label();
            this.cmb_Doi_Ten_BM = new System.Windows.Forms.ComboBox();
            this.label288 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.cmb_NO_CLOSE_TK_D2 = new System.Windows.Forms.ComboBox();
            this.label255 = new System.Windows.Forms.Label();
            this.cmb_Logingmail_trc = new System.Windows.Forms.ComboBox();
            this.label254 = new System.Windows.Forms.Label();
            this.cmb_chi_Share_LIVE = new System.Windows.Forms.ComboBox();
            this.label253 = new System.Windows.Forms.Label();
            this.numericUpDown14 = new System.Windows.Forms.NumericUpDown();
            this.label252 = new System.Windows.Forms.Label();
            this.label251 = new System.Windows.Forms.Label();
            this.rtb_AC_DIE = new System.Windows.Forms.RichTextBox();
            this.numericUpDown13 = new System.Windows.Forms.NumericUpDown();
            this.label250 = new System.Windows.Forms.Label();
            this.label249 = new System.Windows.Forms.Label();
            this.rtb_IDBM_CLOSECL = new System.Windows.Forms.RichTextBox();
            this.label248 = new System.Windows.Forms.Label();
            this.rtb_IDBM_LIVE = new System.Windows.Forms.RichTextBox();
            this.numericUpDown12 = new System.Windows.Forms.NumericUpDown();
            this.label247 = new System.Windows.Forms.Label();
            this.numericUpDown11 = new System.Windows.Forms.NumericUpDown();
            this.label246 = new System.Windows.Forms.Label();
            this.label245 = new System.Windows.Forms.Label();
            this.rtb_AC_CLOSE = new System.Windows.Forms.RichTextBox();
            this.label244 = new System.Windows.Forms.Label();
            this.rtb_ACLIVE = new System.Windows.Forms.RichTextBox();
            this.cmb_MUI_GIO_BMCL = new System.Windows.Forms.ComboBox();
            this.label240 = new System.Windows.Forms.Label();
            this.cmb_TEN_TKBM_CL = new System.Windows.Forms.ComboBox();
            this.label241 = new System.Windows.Forms.Label();
            this.cmb_TIENTE_BM_CL = new System.Windows.Forms.ComboBox();
            this.label242 = new System.Windows.Forms.Label();
            this.cmb_TAOTK_CL = new System.Windows.Forms.ComboBox();
            this.label243 = new System.Windows.Forms.Label();
            this.label239 = new System.Windows.Forms.Label();
            this.rtb_BM350_CL = new System.Windows.Forms.RichTextBox();
            this.label238 = new System.Windows.Forms.Label();
            this.rtb_BM50_CL = new System.Windows.Forms.RichTextBox();
            this.label236 = new System.Windows.Forms.Label();
            this.delay_regbm_cl = new System.Windows.Forms.NumericUpDown();
            this.label237 = new System.Windows.Forms.Label();
            this.number_REGBMCL = new System.Windows.Forms.NumericUpDown();
            this.label235 = new System.Windows.Forms.Label();
            this.cmb_REGBMVIA = new System.Windows.Forms.ComboBox();
            this.label234 = new System.Windows.Forms.Label();
            this.cmb_share_D2VIA = new System.Windows.Forms.ComboBox();
            this.cmb_radom_ncFB = new System.Windows.Forms.ComboBox();
            this.label233 = new System.Windows.Forms.Label();
            this.cmb_VN_US_INDIA = new System.Windows.Forms.ComboBox();
            this.label232 = new System.Windows.Forms.Label();
            this.label231 = new System.Windows.Forms.Label();
            this.cmb_on2FAFB = new System.Windows.Forms.ComboBox();
            this.label44 = new System.Windows.Forms.Label();
            this.cmb_noveri = new System.Windows.Forms.ComboBox();
            this.label43 = new System.Windows.Forms.Label();
            this.cmb_IP = new System.Windows.Forms.ComboBox();
            this.tabPage29 = new System.Windows.Forms.TabPage();
            this.button6 = new System.Windows.Forms.Button();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.rtb_IDBM_LIVE8 = new System.Windows.Forms.RichTextBox();
            this.label280 = new System.Windows.Forms.Label();
            this.label281 = new System.Windows.Forms.Label();
            this.label282 = new System.Windows.Forms.Label();
            this.label283 = new System.Windows.Forms.Label();
            this.rtb_AC_CLOSE8 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBM_CLOSECL8 = new System.Windows.Forms.RichTextBox();
            this.rtb_ACLIVE8 = new System.Windows.Forms.RichTextBox();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.rtb_IDBM_LIVE6 = new System.Windows.Forms.RichTextBox();
            this.label272 = new System.Windows.Forms.Label();
            this.label273 = new System.Windows.Forms.Label();
            this.label274 = new System.Windows.Forms.Label();
            this.label275 = new System.Windows.Forms.Label();
            this.rtb_AC_CLOSE6 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBM_CLOSECL6 = new System.Windows.Forms.RichTextBox();
            this.rtb_ACLIVE6 = new System.Windows.Forms.RichTextBox();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.rtb_IDBM_LIVE7 = new System.Windows.Forms.RichTextBox();
            this.label284 = new System.Windows.Forms.Label();
            this.label285 = new System.Windows.Forms.Label();
            this.label286 = new System.Windows.Forms.Label();
            this.label287 = new System.Windows.Forms.Label();
            this.rtb_AC_CLOSE7 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBM_CLOSECL7 = new System.Windows.Forms.RichTextBox();
            this.rtb_ACLIVE7 = new System.Windows.Forms.RichTextBox();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.rtb_IDBM_LIVE3 = new System.Windows.Forms.RichTextBox();
            this.label264 = new System.Windows.Forms.Label();
            this.label265 = new System.Windows.Forms.Label();
            this.label266 = new System.Windows.Forms.Label();
            this.label267 = new System.Windows.Forms.Label();
            this.rtb_AC_CLOSE3 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBM_CLOSECL3 = new System.Windows.Forms.RichTextBox();
            this.rtb_ACLIVE3 = new System.Windows.Forms.RichTextBox();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.rtb_IDBM_LIVE5 = new System.Windows.Forms.RichTextBox();
            this.label276 = new System.Windows.Forms.Label();
            this.label277 = new System.Windows.Forms.Label();
            this.label278 = new System.Windows.Forms.Label();
            this.label279 = new System.Windows.Forms.Label();
            this.rtb_AC_CLOSE5 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBM_CLOSECL5 = new System.Windows.Forms.RichTextBox();
            this.rtb_ACLIVE5 = new System.Windows.Forms.RichTextBox();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.rtb_IDBM_LIVE4 = new System.Windows.Forms.RichTextBox();
            this.label268 = new System.Windows.Forms.Label();
            this.label269 = new System.Windows.Forms.Label();
            this.label270 = new System.Windows.Forms.Label();
            this.label271 = new System.Windows.Forms.Label();
            this.rtb_AC_CLOSE4 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBM_CLOSECL4 = new System.Windows.Forms.RichTextBox();
            this.rtb_ACLIVE4 = new System.Windows.Forms.RichTextBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.rtb_IDBM_LIVE2 = new System.Windows.Forms.RichTextBox();
            this.label260 = new System.Windows.Forms.Label();
            this.label261 = new System.Windows.Forms.Label();
            this.label262 = new System.Windows.Forms.Label();
            this.label263 = new System.Windows.Forms.Label();
            this.rtb_AC_CLOSE2 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBM_CLOSECL2 = new System.Windows.Forms.RichTextBox();
            this.rtb_ACLIVE2 = new System.Windows.Forms.RichTextBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.rtb_IDBM_LIVE1 = new System.Windows.Forms.RichTextBox();
            this.label258 = new System.Windows.Forms.Label();
            this.label257 = new System.Windows.Forms.Label();
            this.label259 = new System.Windows.Forms.Label();
            this.label256 = new System.Windows.Forms.Label();
            this.rtb_AC_CLOSE1 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBM_CLOSECL1 = new System.Windows.Forms.RichTextBox();
            this.rtb_ACLIVE1 = new System.Windows.Forms.RichTextBox();
            this.tabPage35 = new System.Windows.Forms.TabPage();
            this.groupBox35 = new System.Windows.Forms.GroupBox();
            this.rtb_IDBM_LIVE18 = new System.Windows.Forms.RichTextBox();
            this.label371 = new System.Windows.Forms.Label();
            this.label372 = new System.Windows.Forms.Label();
            this.label373 = new System.Windows.Forms.Label();
            this.label374 = new System.Windows.Forms.Label();
            this.rtb_AC_CLOSE18 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBM_CLOSECL18 = new System.Windows.Forms.RichTextBox();
            this.rtb_ACLIVE18 = new System.Windows.Forms.RichTextBox();
            this.groupBox27 = new System.Windows.Forms.GroupBox();
            this.rtb_IDBM_LIVE16 = new System.Windows.Forms.RichTextBox();
            this.label339 = new System.Windows.Forms.Label();
            this.label340 = new System.Windows.Forms.Label();
            this.label341 = new System.Windows.Forms.Label();
            this.label342 = new System.Windows.Forms.Label();
            this.rtb_AC_CLOSE16 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBM_CLOSECL16 = new System.Windows.Forms.RichTextBox();
            this.rtb_ACLIVE16 = new System.Windows.Forms.RichTextBox();
            this.groupBox36 = new System.Windows.Forms.GroupBox();
            this.rtb_IDBM_LIVE17 = new System.Windows.Forms.RichTextBox();
            this.label375 = new System.Windows.Forms.Label();
            this.label376 = new System.Windows.Forms.Label();
            this.label377 = new System.Windows.Forms.Label();
            this.label378 = new System.Windows.Forms.Label();
            this.rtb_AC_CLOSE17 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBM_CLOSECL17 = new System.Windows.Forms.RichTextBox();
            this.rtb_ACLIVE17 = new System.Windows.Forms.RichTextBox();
            this.groupBox28 = new System.Windows.Forms.GroupBox();
            this.rtb_IDBM_LIVE14 = new System.Windows.Forms.RichTextBox();
            this.label343 = new System.Windows.Forms.Label();
            this.label344 = new System.Windows.Forms.Label();
            this.label345 = new System.Windows.Forms.Label();
            this.label346 = new System.Windows.Forms.Label();
            this.rtb_AC_CLOSE14 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBM_CLOSECL14 = new System.Windows.Forms.RichTextBox();
            this.rtb_ACLIVE14 = new System.Windows.Forms.RichTextBox();
            this.groupBox29 = new System.Windows.Forms.GroupBox();
            this.rtb_IDBM_LIVE15 = new System.Windows.Forms.RichTextBox();
            this.label347 = new System.Windows.Forms.Label();
            this.label348 = new System.Windows.Forms.Label();
            this.label349 = new System.Windows.Forms.Label();
            this.label350 = new System.Windows.Forms.Label();
            this.rtb_AC_CLOSE15 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBM_CLOSECL15 = new System.Windows.Forms.RichTextBox();
            this.rtb_ACLIVE15 = new System.Windows.Forms.RichTextBox();
            this.groupBox30 = new System.Windows.Forms.GroupBox();
            this.rtb_IDBM_LIVE11 = new System.Windows.Forms.RichTextBox();
            this.label351 = new System.Windows.Forms.Label();
            this.label352 = new System.Windows.Forms.Label();
            this.label353 = new System.Windows.Forms.Label();
            this.label354 = new System.Windows.Forms.Label();
            this.rtb_AC_CLOSE11 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBM_CLOSECL11 = new System.Windows.Forms.RichTextBox();
            this.rtb_ACLIVE11 = new System.Windows.Forms.RichTextBox();
            this.groupBox31 = new System.Windows.Forms.GroupBox();
            this.rtb_IDBM_LIVE13 = new System.Windows.Forms.RichTextBox();
            this.label355 = new System.Windows.Forms.Label();
            this.label356 = new System.Windows.Forms.Label();
            this.label357 = new System.Windows.Forms.Label();
            this.label358 = new System.Windows.Forms.Label();
            this.rtb_AC_CLOSE13 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBM_CLOSECL13 = new System.Windows.Forms.RichTextBox();
            this.rtb_ACLIVE13 = new System.Windows.Forms.RichTextBox();
            this.groupBox32 = new System.Windows.Forms.GroupBox();
            this.rtb_IDBM_LIVE12 = new System.Windows.Forms.RichTextBox();
            this.label359 = new System.Windows.Forms.Label();
            this.label360 = new System.Windows.Forms.Label();
            this.label361 = new System.Windows.Forms.Label();
            this.label362 = new System.Windows.Forms.Label();
            this.rtb_AC_CLOSE12 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBM_CLOSECL12 = new System.Windows.Forms.RichTextBox();
            this.rtb_ACLIVE12 = new System.Windows.Forms.RichTextBox();
            this.groupBox33 = new System.Windows.Forms.GroupBox();
            this.rtb_IDBM_LIVE10 = new System.Windows.Forms.RichTextBox();
            this.label363 = new System.Windows.Forms.Label();
            this.label364 = new System.Windows.Forms.Label();
            this.label365 = new System.Windows.Forms.Label();
            this.label366 = new System.Windows.Forms.Label();
            this.rtb_AC_CLOSE10 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBM_CLOSECL10 = new System.Windows.Forms.RichTextBox();
            this.rtb_ACLIVE10 = new System.Windows.Forms.RichTextBox();
            this.groupBox34 = new System.Windows.Forms.GroupBox();
            this.rtb_IDBM_LIVE9 = new System.Windows.Forms.RichTextBox();
            this.label367 = new System.Windows.Forms.Label();
            this.label368 = new System.Windows.Forms.Label();
            this.label369 = new System.Windows.Forms.Label();
            this.label370 = new System.Windows.Forms.Label();
            this.rtb_AC_CLOSE9 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBM_CLOSECL9 = new System.Windows.Forms.RichTextBox();
            this.rtb_ACLIVE9 = new System.Windows.Forms.RichTextBox();
            this.tabPage30 = new System.Windows.Forms.TabPage();
            this.number_delay_nhand2 = new System.Windows.Forms.NumericUpDown();
            this.label338 = new System.Windows.Forms.Label();
            this.tabControl9 = new System.Windows.Forms.TabControl();
            this.tabPage33 = new System.Windows.Forms.TabPage();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.rtb_ACLIVE6_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label310 = new System.Windows.Forms.Label();
            this.rtb_ACLIVE5_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label311 = new System.Windows.Forms.Label();
            this.rtb_ACLIVE4_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label312 = new System.Windows.Forms.Label();
            this.rtb_IDBMLIVE6_VIA1 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBMLIVE5_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label313 = new System.Windows.Forms.Label();
            this.label314 = new System.Windows.Forms.Label();
            this.rtb_IDBMLIVE4_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label315 = new System.Windows.Forms.Label();
            this.rtb_ACLIVE3_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label307 = new System.Windows.Forms.Label();
            this.rtb_ACLIVE2_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label302 = new System.Windows.Forms.Label();
            this.rtb_ACLIVE1_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label304 = new System.Windows.Forms.Label();
            this.rtb_IDBMLIVE3_VIA1 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBMLIVE2_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label305 = new System.Windows.Forms.Label();
            this.label306 = new System.Windows.Forms.Label();
            this.rtb_IDBMLIVE_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label303 = new System.Windows.Forms.Label();
            this.tabPage34 = new System.Windows.Forms.TabPage();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.rtb_ACLIVE12_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label326 = new System.Windows.Forms.Label();
            this.rtb_ACLIVE11_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label327 = new System.Windows.Forms.Label();
            this.rtb_ACLIVE10_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label328 = new System.Windows.Forms.Label();
            this.rtb_IDBMLIVE12_VIA1 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBMLIVE11_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label329 = new System.Windows.Forms.Label();
            this.label330 = new System.Windows.Forms.Label();
            this.rtb_IDBMLIVE10_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label331 = new System.Windows.Forms.Label();
            this.rtb_ACLIVE9_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label332 = new System.Windows.Forms.Label();
            this.rtb_ACLIVE8_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label333 = new System.Windows.Forms.Label();
            this.rtb_ACLIVE7_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label334 = new System.Windows.Forms.Label();
            this.rtb_IDBMLIVE9_VIA1 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBMLIVE8_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label335 = new System.Windows.Forms.Label();
            this.label336 = new System.Windows.Forms.Label();
            this.rtb_IDBMLIVE7_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label337 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.cmb_stt_chuyen_123 = new System.Windows.Forms.ComboBox();
            this.label309 = new System.Windows.Forms.Label();
            this.cmb_VIA1 = new System.Windows.Forms.ComboBox();
            this.label308 = new System.Windows.Forms.Label();
            this.label301 = new System.Windows.Forms.Label();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.rtb_ID_AC_SELECT_FAIL = new System.Windows.Forms.RichTextBox();
            this.button8 = new System.Windows.Forms.Button();
            this.label300 = new System.Windows.Forms.Label();
            this.rtb_ID_AC_DONE = new System.Windows.Forms.RichTextBox();
            this.label299 = new System.Windows.Forms.Label();
            this.rtb_ID_AC_FAIL = new System.Windows.Forms.RichTextBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.cmb_Chuc_Nang = new System.Windows.Forms.ComboBox();
            this.label42 = new System.Windows.Forms.Label();
            this.tbsodu = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.cmbKeyCaptcha = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.cmbVIA = new System.Windows.Forms.ComboBox();
            this.cmbLogin = new System.Windows.Forms.ComboBox();
            this.btn_Stop = new System.Windows.Forms.Button();
            this.lbnew = new System.Windows.Forms.Label();
            this.labelnew = new System.Windows.Forms.Label();
            this.btUpdate = new System.Windows.Forms.Button();
            this.tb_LOAD_STT = new System.Windows.Forms.Button();
            this.bt_file_VIA = new System.Windows.Forms.Button();
            this.tabPage36 = new System.Windows.Forms.TabPage();
            this.groupBox37 = new System.Windows.Forms.GroupBox();
            this.rtb_ACLIVE18_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label379 = new System.Windows.Forms.Label();
            this.rtb_ACLIVE17_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label380 = new System.Windows.Forms.Label();
            this.rtb_ACLIVE16_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label381 = new System.Windows.Forms.Label();
            this.rtb_IDBMLIVE18_VIA1 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBMLIVE17_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label382 = new System.Windows.Forms.Label();
            this.label383 = new System.Windows.Forms.Label();
            this.rtb_IDBMLIVE16_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label384 = new System.Windows.Forms.Label();
            this.rtb_ACLIVE15_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label385 = new System.Windows.Forms.Label();
            this.rtb_ACLIVE14_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label386 = new System.Windows.Forms.Label();
            this.rtb_ACLIVE13_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label387 = new System.Windows.Forms.Label();
            this.rtb_IDBMLIVE15_VIA1 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBMLIVE14_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label388 = new System.Windows.Forms.Label();
            this.label389 = new System.Windows.Forms.Label();
            this.rtb_IDBMLIVE13_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label390 = new System.Windows.Forms.Label();
            this.tabPage37 = new System.Windows.Forms.TabPage();
            this.groupBox38 = new System.Windows.Forms.GroupBox();
            this.rtb_ACLIVE24_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label391 = new System.Windows.Forms.Label();
            this.rtb_ACLIVE23_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label392 = new System.Windows.Forms.Label();
            this.rtb_ACLIVE22_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label393 = new System.Windows.Forms.Label();
            this.rtb_IDBMLIVE24_VIA1 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBMLIVE23_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label394 = new System.Windows.Forms.Label();
            this.label395 = new System.Windows.Forms.Label();
            this.rtb_IDBMLIVE22_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label396 = new System.Windows.Forms.Label();
            this.rtb_ACLIVE21_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label397 = new System.Windows.Forms.Label();
            this.rtb_ACLIVE20_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label398 = new System.Windows.Forms.Label();
            this.rtb_ACLIVE19_VIA1 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBMLIVE21_VIA1 = new System.Windows.Forms.RichTextBox();
            this.rtb_IDBMLIVE20_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label400 = new System.Windows.Forms.Label();
            this.label401 = new System.Windows.Forms.Label();
            this.rtb_IDBMLIVE19_VIA1 = new System.Windows.Forms.RichTextBox();
            this.label399 = new System.Windows.Forms.Label();
            this.label402 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gioi_han_close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gioi_han_live)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gioi_han_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.delayshare)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sl_Nhan_BM_CLOSE1_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sl_Nhan_BM_PARTNER)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sl_nhan_Bm_BM_BACKUP)).BeginInit();
            this.tabPage7.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.delay_reg_bm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.for_reg_bm)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.soluong_mua_Mail)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv2_IG)).BeginInit();
            this.contextMenuStrip3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_mail)).BeginInit();
            this.contextMenuStrip2.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabControl6.SuspendLayout();
            this.tabPage23.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPage24.SuspendLayout();
            this.tabPage25.SuspendLayout();
            this.tabPage26.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5_delay_regbmig)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_tao_5bm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.delay_doc_hotmail_1)).BeginInit();
            this.groupBox14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.n_slink_share_them)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.delay_tatbatsangtao)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nam_rip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.thang_rip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngay_rip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5_slcheck_bm350)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.delay_check_admin)).BeginInit();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ndelayloop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.delay_link_bm_backup)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.delay_check_infor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sl_LOAD_TK_D2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_AC)).BeginInit();
            this.contextMenuStrip5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.delay_LOAD_BM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SL_BM_LOAD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_BM)).BeginInit();
            this.contextMenuStrip4.SuspendLayout();
            this.tabPage12.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.n_Delay_TTK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.delay_doc_link)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.so_link_backup)).BeginInit();
            this.tabPage22.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sl_BM_kick3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.m_delay_ttk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.delay_kick_bm3)).BeginInit();
            this.tabPage13.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.tabPage14.SuspendLayout();
            this.tabControl4.SuspendLayout();
            this.tabPage15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DELAY_DOC_MAIL)).BeginInit();
            this.groupBox12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_STT_NHAN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.number_nhan_fail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).BeginInit();
            this.tabPage16.SuspendLayout();
            this.tabPage17.SuspendLayout();
            this.tabPage18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.delay_check_ig)).BeginInit();
            this.tabPage19.SuspendLayout();
            this.tabControl5.SuspendLayout();
            this.tabPage20.SuspendLayout();
            this.tabPage27.SuspendLayout();
            this.tabControl7.SuspendLayout();
            this.tabPage28.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.tabControl8.SuspendLayout();
            this.tabPage31.SuspendLayout();
            this.groupBox24.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown20)).BeginInit();
            this.tabPage32.SuspendLayout();
            this.groupBox25.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown27)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown29)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.delay_regbm_cl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.number_REGBMCL)).BeginInit();
            this.tabPage29.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.tabPage35.SuspendLayout();
            this.groupBox35.SuspendLayout();
            this.groupBox27.SuspendLayout();
            this.groupBox36.SuspendLayout();
            this.groupBox28.SuspendLayout();
            this.groupBox29.SuspendLayout();
            this.groupBox30.SuspendLayout();
            this.groupBox31.SuspendLayout();
            this.groupBox32.SuspendLayout();
            this.groupBox33.SuspendLayout();
            this.groupBox34.SuspendLayout();
            this.tabPage30.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.number_delay_nhand2)).BeginInit();
            this.tabControl9.SuspendLayout();
            this.tabPage33.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.tabPage34.SuspendLayout();
            this.groupBox26.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.tabPage36.SuspendLayout();
            this.groupBox37.SuspendLayout();
            this.tabPage37.SuspendLayout();
            this.groupBox38.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(597, 137);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(8, 8);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btn_RUN
            // 
            this.btn_RUN.BackColor = System.Drawing.SystemColors.Highlight;
            this.btn_RUN.Location = new System.Drawing.Point(12, 12);
            this.btn_RUN.Name = "btn_RUN";
            this.btn_RUN.Size = new System.Drawing.Size(75, 49);
            this.btn_RUN.TabIndex = 1;
            this.btn_RUN.Text = "RUN";
            this.btn_RUN.UseVisualStyleBackColor = false;
            this.btn_RUN.Click += new System.EventHandler(this.btn_RUN_Click);
            // 
            // dgv1
            // 
            this.dgv1.AllowUserToAddRows = false;
            this.dgv1.AllowUserToDeleteRows = false;
            this.dgv1.AllowUserToResizeRows = false;
            this.dgv1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cStt,
            this.cUID,
            this.cPass,
            this.c2FAvsCookie,
            this.cMail,
            this.cPassMail,
            this.cMailKP,
            this.cStatus,
            this.cCheckBM,
            this.cSelect});
            this.dgv1.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv1.Location = new System.Drawing.Point(3, 3);
            this.dgv1.Name = "dgv1";
            this.dgv1.RowHeadersVisible = false;
            this.dgv1.Size = new System.Drawing.Size(1761, 682);
            this.dgv1.TabIndex = 2;
            this.dgv1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv1_CellContentClick);
            this.dgv1.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgv1_CellFormatting);
            this.dgv1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgv1_KeyDown);
            // 
            // cStt
            // 
            this.cStt.FillWeight = 30F;
            this.cStt.HeaderText = "STT";
            this.cStt.Name = "cStt";
            // 
            // cUID
            // 
            this.cUID.FillWeight = 50F;
            this.cUID.HeaderText = "UID";
            this.cUID.Name = "cUID";
            // 
            // cPass
            // 
            this.cPass.FillWeight = 50F;
            this.cPass.HeaderText = "PASS";
            this.cPass.Name = "cPass";
            // 
            // c2FAvsCookie
            // 
            this.c2FAvsCookie.FillWeight = 50F;
            this.c2FAvsCookie.HeaderText = "2FA || Cookie";
            this.c2FAvsCookie.Name = "c2FAvsCookie";
            // 
            // cMail
            // 
            this.cMail.FillWeight = 50F;
            this.cMail.HeaderText = "MAIL";
            this.cMail.Name = "cMail";
            // 
            // cPassMail
            // 
            this.cPassMail.FillWeight = 50F;
            this.cPassMail.HeaderText = "PASSMAIL";
            this.cPassMail.Name = "cPassMail";
            // 
            // cMailKP
            // 
            this.cMailKP.FillWeight = 50F;
            this.cMailKP.HeaderText = "MAILKP";
            this.cMailKP.Name = "cMailKP";
            // 
            // cStatus
            // 
            this.cStatus.FillWeight = 200F;
            this.cStatus.HeaderText = "STATUS";
            this.cStatus.Name = "cStatus";
            this.cStatus.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.cStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // cCheckBM
            // 
            this.cCheckBM.FillWeight = 200F;
            this.cCheckBM.HeaderText = "CheckBM";
            this.cCheckBM.Name = "cCheckBM";
            this.cCheckBM.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.cCheckBM.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // cSelect
            // 
            this.cSelect.FillWeight = 20F;
            this.cSelect.HeaderText = "";
            this.cSelect.Name = "cSelect";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chọnToolStripMenuItem,
            this.bỏChọnToolStripMenuItem,
            this.xóaToolStripMenuItem,
            this.aDDMAILKPToolStripMenuItem,
            this.nHẬNBMNEWToolStripMenuItem,
            this.tẮTBẬTSÁNGTẠOIGToolStripMenuItem,
            this.cHECKBMToolStripMenuItem,
            this.sHAREBMIGToolStripMenuItem,
            this.rEGBM12ToolStripMenuItem,
            this.rEGBM2025ToolStripMenuItem,
            this.lOADALLBMVIAToolStripMenuItem,
            this.nHẬNBMToolStripMenuItem,
            this.loginVIAToolStripMenuItem,
            this.kILLChromeDriverToolStripMenuItem,
            this.lấyCookieVIAToolStripMenuItem,
            this.nHẬNBMAUTOToolStripMenuItem,
            this.lOGINGMAILCHROMEToolStripMenuItem,
            this.tESTWABMToolStripMenuItem,
            this.bACKUPBMTHEOIDToolStripMenuItem,
            this.oUTBMTHEOIDToolStripMenuItem,
            this.cHECKADMINBMTHEOIDToolStripMenuItem,
            this.kICHWHATAPPToolStripMenuItem,
            this.cHECKINFORBMToolStripMenuItem,
            this.cHECKADMINIGToolStripMenuItem,
            this.uOTIGBMFBToolStripMenuItem,
            this.sHARED22025ToolStripMenuItem,
            this.vIADToolStripMenuItem,
            this.lOADACBMD2ToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(227, 620);
            // 
            // chọnToolStripMenuItem
            // 
            this.chọnToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bôiĐenToolStripMenuItem,
            this.tấtCảToolStripMenuItem});
            this.chọnToolStripMenuItem.Name = "chọnToolStripMenuItem";
            this.chọnToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.chọnToolStripMenuItem.Text = "Chọn";
            // 
            // bôiĐenToolStripMenuItem
            // 
            this.bôiĐenToolStripMenuItem.Name = "bôiĐenToolStripMenuItem";
            this.bôiĐenToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.bôiĐenToolStripMenuItem.Text = "Bôi Đen";
            this.bôiĐenToolStripMenuItem.Click += new System.EventHandler(this.bôiĐenToolStripMenuItem_Click_1);
            // 
            // tấtCảToolStripMenuItem
            // 
            this.tấtCảToolStripMenuItem.Name = "tấtCảToolStripMenuItem";
            this.tấtCảToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.tấtCảToolStripMenuItem.Text = "Tất Cả";
            this.tấtCảToolStripMenuItem.Click += new System.EventHandler(this.tấtCảToolStripMenuItem_Click_1);
            // 
            // bỏChọnToolStripMenuItem
            // 
            this.bỏChọnToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bôiĐenToolStripMenuItem1,
            this.tấtCảToolStripMenuItem1});
            this.bỏChọnToolStripMenuItem.Name = "bỏChọnToolStripMenuItem";
            this.bỏChọnToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.bỏChọnToolStripMenuItem.Text = "Bỏ Chọn";
            // 
            // bôiĐenToolStripMenuItem1
            // 
            this.bôiĐenToolStripMenuItem1.Name = "bôiĐenToolStripMenuItem1";
            this.bôiĐenToolStripMenuItem1.Size = new System.Drawing.Size(115, 22);
            this.bôiĐenToolStripMenuItem1.Text = "Bôi Đen";
            this.bôiĐenToolStripMenuItem1.Click += new System.EventHandler(this.bôiĐenToolStripMenuItem1_Click_1);
            // 
            // tấtCảToolStripMenuItem1
            // 
            this.tấtCảToolStripMenuItem1.Name = "tấtCảToolStripMenuItem1";
            this.tấtCảToolStripMenuItem1.Size = new System.Drawing.Size(115, 22);
            this.tấtCảToolStripMenuItem1.Text = "Tất Cả";
            this.tấtCảToolStripMenuItem1.Click += new System.EventHandler(this.tấtCảToolStripMenuItem1_Click_1);
            // 
            // xóaToolStripMenuItem
            // 
            this.xóaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dòngĐãChọnToolStripMenuItem,
            this.tấtCảToolStripMenuItem2});
            this.xóaToolStripMenuItem.Name = "xóaToolStripMenuItem";
            this.xóaToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.xóaToolStripMenuItem.Text = "Xóa";
            // 
            // dòngĐãChọnToolStripMenuItem
            // 
            this.dòngĐãChọnToolStripMenuItem.Name = "dòngĐãChọnToolStripMenuItem";
            this.dòngĐãChọnToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.dòngĐãChọnToolStripMenuItem.Text = "Dòng Đã Chọn";
            this.dòngĐãChọnToolStripMenuItem.Click += new System.EventHandler(this.dòngĐãChọnToolStripMenuItem_Click_1);
            // 
            // tấtCảToolStripMenuItem2
            // 
            this.tấtCảToolStripMenuItem2.Name = "tấtCảToolStripMenuItem2";
            this.tấtCảToolStripMenuItem2.Size = new System.Drawing.Size(152, 22);
            this.tấtCảToolStripMenuItem2.Text = "Tất Cả";
            this.tấtCảToolStripMenuItem2.Click += new System.EventHandler(this.tấtCảToolStripMenuItem2_Click_1);
            // 
            // aDDMAILKPToolStripMenuItem
            // 
            this.aDDMAILKPToolStripMenuItem.Name = "aDDMAILKPToolStripMenuItem";
            this.aDDMAILKPToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.aDDMAILKPToolStripMenuItem.Text = "ADD MAIL KP";
            this.aDDMAILKPToolStripMenuItem.Click += new System.EventHandler(this.aDDMAILKPToolStripMenuItem_Click);
            // 
            // nHẬNBMNEWToolStripMenuItem
            // 
            this.nHẬNBMNEWToolStripMenuItem.Name = "nHẬNBMNEWToolStripMenuItem";
            this.nHẬNBMNEWToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.nHẬNBMNEWToolStripMenuItem.Text = "NHẬN BM NEW";
            this.nHẬNBMNEWToolStripMenuItem.Click += new System.EventHandler(this.nHẬNBMNEWToolStripMenuItem_Click);
            // 
            // tẮTBẬTSÁNGTẠOIGToolStripMenuItem
            // 
            this.tẮTBẬTSÁNGTẠOIGToolStripMenuItem.Name = "tẮTBẬTSÁNGTẠOIGToolStripMenuItem";
            this.tẮTBẬTSÁNGTẠOIGToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.tẮTBẬTSÁNGTẠOIGToolStripMenuItem.Text = "TẮT BẬT SÁNG TẠO IG";
            this.tẮTBẬTSÁNGTẠOIGToolStripMenuItem.Click += new System.EventHandler(this.tẮTBẬTSÁNGTẠOIGToolStripMenuItem_Click);
            // 
            // cHECKBMToolStripMenuItem
            // 
            this.cHECKBMToolStripMenuItem.Name = "cHECKBMToolStripMenuItem";
            this.cHECKBMToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.cHECKBMToolStripMenuItem.Text = "CHECK BM";
            this.cHECKBMToolStripMenuItem.Click += new System.EventHandler(this.cHECKBMToolStripMenuItem_Click);
            // 
            // sHAREBMIGToolStripMenuItem
            // 
            this.sHAREBMIGToolStripMenuItem.Name = "sHAREBMIGToolStripMenuItem";
            this.sHAREBMIGToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.sHAREBMIGToolStripMenuItem.Text = "SHARE_BM_IG";
            this.sHAREBMIGToolStripMenuItem.Click += new System.EventHandler(this.sHAREBMIGToolStripMenuItem_Click);
            // 
            // rEGBM12ToolStripMenuItem
            // 
            this.rEGBM12ToolStripMenuItem.Name = "rEGBM12ToolStripMenuItem";
            this.rEGBM12ToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.rEGBM12ToolStripMenuItem.Text = "REG_BM_1_2_3";
            this.rEGBM12ToolStripMenuItem.Click += new System.EventHandler(this.rEGBM12ToolStripMenuItem_Click);
            // 
            // rEGBM2025ToolStripMenuItem
            // 
            this.rEGBM2025ToolStripMenuItem.Name = "rEGBM2025ToolStripMenuItem";
            this.rEGBM2025ToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.rEGBM2025ToolStripMenuItem.Text = "REG_BM_2025";
            this.rEGBM2025ToolStripMenuItem.Click += new System.EventHandler(this.rEGBM2025ToolStripMenuItem_Click);
            // 
            // lOADALLBMVIAToolStripMenuItem
            // 
            this.lOADALLBMVIAToolStripMenuItem.Name = "lOADALLBMVIAToolStripMenuItem";
            this.lOADALLBMVIAToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.lOADALLBMVIAToolStripMenuItem.Text = "LOAD_ALL_BM_VIA";
            this.lOADALLBMVIAToolStripMenuItem.Click += new System.EventHandler(this.lOADALLBMVIAToolStripMenuItem_Click);
            // 
            // nHẬNBMToolStripMenuItem
            // 
            this.nHẬNBMToolStripMenuItem.Name = "nHẬNBMToolStripMenuItem";
            this.nHẬNBMToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.nHẬNBMToolStripMenuItem.Text = "NHẬN BM";
            this.nHẬNBMToolStripMenuItem.Click += new System.EventHandler(this.nHẬNBMToolStripMenuItem_Click_1);
            // 
            // loginVIAToolStripMenuItem
            // 
            this.loginVIAToolStripMenuItem.Name = "loginVIAToolStripMenuItem";
            this.loginVIAToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.loginVIAToolStripMenuItem.Text = "Login_VIA";
            this.loginVIAToolStripMenuItem.Click += new System.EventHandler(this.loginVIAToolStripMenuItem_Click);
            // 
            // kILLChromeDriverToolStripMenuItem
            // 
            this.kILLChromeDriverToolStripMenuItem.Name = "kILLChromeDriverToolStripMenuItem";
            this.kILLChromeDriverToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.kILLChromeDriverToolStripMenuItem.Text = "KILL_Chrome_Driver";
            this.kILLChromeDriverToolStripMenuItem.Click += new System.EventHandler(this.kILLChromeDriverToolStripMenuItem_Click);
            // 
            // lấyCookieVIAToolStripMenuItem
            // 
            this.lấyCookieVIAToolStripMenuItem.Name = "lấyCookieVIAToolStripMenuItem";
            this.lấyCookieVIAToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.lấyCookieVIAToolStripMenuItem.Text = "Lấy_Cookie_VIA";
            this.lấyCookieVIAToolStripMenuItem.Click += new System.EventHandler(this.lấyCookieVIAToolStripMenuItem_Click);
            // 
            // nHẬNBMAUTOToolStripMenuItem
            // 
            this.nHẬNBMAUTOToolStripMenuItem.Name = "nHẬNBMAUTOToolStripMenuItem";
            this.nHẬNBMAUTOToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.nHẬNBMAUTOToolStripMenuItem.Text = "NHẬN BM AUTO";
            this.nHẬNBMAUTOToolStripMenuItem.Click += new System.EventHandler(this.nHẬNBMAUTOToolStripMenuItem_Click);
            // 
            // lOGINGMAILCHROMEToolStripMenuItem
            // 
            this.lOGINGMAILCHROMEToolStripMenuItem.Name = "lOGINGMAILCHROMEToolStripMenuItem";
            this.lOGINGMAILCHROMEToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.lOGINGMAILCHROMEToolStripMenuItem.Text = "LOGIN_GMAIL_CHROME";
            this.lOGINGMAILCHROMEToolStripMenuItem.Click += new System.EventHandler(this.lOGINGMAILCHROMEToolStripMenuItem_Click);
            // 
            // tESTWABMToolStripMenuItem
            // 
            this.tESTWABMToolStripMenuItem.Name = "tESTWABMToolStripMenuItem";
            this.tESTWABMToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.tESTWABMToolStripMenuItem.Text = "TEST WA BM";
            this.tESTWABMToolStripMenuItem.Click += new System.EventHandler(this.tESTWABMToolStripMenuItem_Click);
            // 
            // bACKUPBMTHEOIDToolStripMenuItem
            // 
            this.bACKUPBMTHEOIDToolStripMenuItem.Name = "bACKUPBMTHEOIDToolStripMenuItem";
            this.bACKUPBMTHEOIDToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.bACKUPBMTHEOIDToolStripMenuItem.Text = "BACK_UP_BM_THEO_ID";
            this.bACKUPBMTHEOIDToolStripMenuItem.Click += new System.EventHandler(this.bACKUPBMTHEOIDToolStripMenuItem_Click);
            // 
            // oUTBMTHEOIDToolStripMenuItem
            // 
            this.oUTBMTHEOIDToolStripMenuItem.Name = "oUTBMTHEOIDToolStripMenuItem";
            this.oUTBMTHEOIDToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.oUTBMTHEOIDToolStripMenuItem.Text = "OUT_BM_THEO_ID";
            this.oUTBMTHEOIDToolStripMenuItem.Click += new System.EventHandler(this.oUTBMTHEOIDToolStripMenuItem_Click);
            // 
            // cHECKADMINBMTHEOIDToolStripMenuItem
            // 
            this.cHECKADMINBMTHEOIDToolStripMenuItem.Name = "cHECKADMINBMTHEOIDToolStripMenuItem";
            this.cHECKADMINBMTHEOIDToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.cHECKADMINBMTHEOIDToolStripMenuItem.Text = "CHECK_ADMINBM_THEO_ID";
            this.cHECKADMINBMTHEOIDToolStripMenuItem.Click += new System.EventHandler(this.cHECKADMINBMTHEOIDToolStripMenuItem_Click);
            // 
            // kICHWHATAPPToolStripMenuItem
            // 
            this.kICHWHATAPPToolStripMenuItem.Name = "kICHWHATAPPToolStripMenuItem";
            this.kICHWHATAPPToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.kICHWHATAPPToolStripMenuItem.Text = "KICH_WHATAPP";
            this.kICHWHATAPPToolStripMenuItem.Click += new System.EventHandler(this.kICHWHATAPPToolStripMenuItem_Click);
            // 
            // cHECKINFORBMToolStripMenuItem
            // 
            this.cHECKINFORBMToolStripMenuItem.Name = "cHECKINFORBMToolStripMenuItem";
            this.cHECKINFORBMToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.cHECKINFORBMToolStripMenuItem.Text = "CHECK_INFOR_BM";
            this.cHECKINFORBMToolStripMenuItem.Click += new System.EventHandler(this.cHECKINFORBMToolStripMenuItem_Click);
            // 
            // cHECKADMINIGToolStripMenuItem
            // 
            this.cHECKADMINIGToolStripMenuItem.Name = "cHECKADMINIGToolStripMenuItem";
            this.cHECKADMINIGToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.cHECKADMINIGToolStripMenuItem.Text = "CHECK_ADMIN_IG";
            this.cHECKADMINIGToolStripMenuItem.Click += new System.EventHandler(this.cHECKADMINIGToolStripMenuItem_Click);
            // 
            // uOTIGBMFBToolStripMenuItem
            // 
            this.uOTIGBMFBToolStripMenuItem.Name = "uOTIGBMFBToolStripMenuItem";
            this.uOTIGBMFBToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.uOTIGBMFBToolStripMenuItem.Text = "UOT_IG_BM_FB";
            this.uOTIGBMFBToolStripMenuItem.Click += new System.EventHandler(this.uOTIGBMFBToolStripMenuItem_Click);
            // 
            // sHARED22025ToolStripMenuItem
            // 
            this.sHARED22025ToolStripMenuItem.Name = "sHARED22025ToolStripMenuItem";
            this.sHARED22025ToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.sHARED22025ToolStripMenuItem.Text = "SHARE_D2_2025";
            this.sHARED22025ToolStripMenuItem.Click += new System.EventHandler(this.sHARED22025ToolStripMenuItem_Click);
            // 
            // vIADToolStripMenuItem
            // 
            this.vIADToolStripMenuItem.Name = "vIADToolStripMenuItem";
            this.vIADToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.vIADToolStripMenuItem.Text = "VIA D2 2025";
            this.vIADToolStripMenuItem.Click += new System.EventHandler(this.vIADToolStripMenuItem_Click);
            // 
            // lOADACBMD2ToolStripMenuItem
            // 
            this.lOADACBMD2ToolStripMenuItem.Name = "lOADACBMD2ToolStripMenuItem";
            this.lOADACBMD2ToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.lOADACBMD2ToolStripMenuItem.Text = "LOAD AC BMD2";
            this.lOADACBMD2ToolStripMenuItem.Click += new System.EventHandler(this.lOADACBMD2ToolStripMenuItem_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Controls.Add(this.tabPage9);
            this.tabControl1.Controls.Add(this.tabPage10);
            this.tabControl1.Controls.Add(this.tabPage13);
            this.tabControl1.Controls.Add(this.tabPage14);
            this.tabControl1.Controls.Add(this.tabPage18);
            this.tabControl1.Controls.Add(this.tabPage19);
            this.tabControl1.Controls.Add(this.tabPage27);
            this.tabControl1.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(3, 117);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1775, 716);
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dgv1);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1767, 688);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Hiển Thị";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Silver;
            this.tabPage2.Controls.Add(this.tabControl2);
            this.tabPage2.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1767, 688);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "SHARE DONG 2";
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Location = new System.Drawing.Point(0, 0);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1761, 695);
            this.tabControl2.TabIndex = 75;
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.tabPage6.Controls.Add(this.label56);
            this.tabPage6.Controls.Add(this.tb_so_luong_BM);
            this.tabPage6.Controls.Add(this.rtb_BMDIE);
            this.tabPage6.Controls.Add(this.rtb_BM_Nhan_Du);
            this.tabPage6.Controls.Add(this.label28);
            this.tabPage6.Controls.Add(this.label27);
            this.tabPage6.Controls.Add(this.label25);
            this.tabPage6.Controls.Add(this.label24);
            this.tabPage6.Controls.Add(this.rtbdone);
            this.tabPage6.Controls.Add(this.rtbAC_FAIL);
            this.tabPage6.Controls.Add(this.label26);
            this.tabPage6.Controls.Add(this.label19);
            this.tabPage6.Controls.Add(this.label18);
            this.tabPage6.Controls.Add(this.rtb_BM_CLOSE_4_THAY_THE);
            this.tabPage6.Controls.Add(this.rtb_BM_CLOSE_3_THAY_THE);
            this.tabPage6.Controls.Add(this.rtb_BM_CLOSE_2_THAY_THE);
            this.tabPage6.Controls.Add(this.rtb_BM_CLOSE_THAY_THE);
            this.tabPage6.Controls.Add(this.rtb_BM_BACKUP3_THAY_THE);
            this.tabPage6.Controls.Add(this.rtb_BM_BACKUP2_THAY_THE);
            this.tabPage6.Controls.Add(this.rtb_BM_BACKUP_THAY_THE);
            this.tabPage6.Controls.Add(this.rtb_BM_THAY_THE);
            this.tabPage6.Controls.Add(this.cmb_ADD_Tra_Truoc);
            this.tabPage6.Controls.Add(this.label34);
            this.tabPage6.Controls.Add(this.gioi_han_close);
            this.tabPage6.Controls.Add(this.label32);
            this.tabPage6.Controls.Add(this.gioi_han_live);
            this.tabPage6.Controls.Add(this.label31);
            this.tabPage6.Controls.Add(this.gioi_han_1);
            this.tabPage6.Controls.Add(this.label30);
            this.tabPage6.Controls.Add(this.delayshare);
            this.tabPage6.Controls.Add(this.label29);
            this.tabPage6.Controls.Add(this.rtb_BM_PARTNER_THAY_THE);
            this.tabPage6.Controls.Add(this.sl_Nhan_BM_CLOSE1_2);
            this.tabPage6.Controls.Add(this.sl_Nhan_BM_PARTNER);
            this.tabPage6.Controls.Add(this.sl_nhan_Bm_BM_BACKUP);
            this.tabPage6.Controls.Add(this.label22);
            this.tabPage6.Controls.Add(this.label21);
            this.tabPage6.Controls.Add(this.label20);
            this.tabPage6.Controls.Add(this.tx_So_Luong_Share_vao_bm);
            this.tabPage6.Controls.Add(this.label33);
            this.tabPage6.Controls.Add(this.tb_so_luong_BM_PARTNER);
            this.tabPage6.Controls.Add(this.tb_BM_Close_4);
            this.tabPage6.Controls.Add(this.tb_BM_Close_3);
            this.tabPage6.Controls.Add(this.tb_BM_Close_2);
            this.tabPage6.Controls.Add(this.tb_BM_Close1);
            this.tabPage6.Controls.Add(this.tb_BM_BACK_UP3);
            this.tabPage6.Controls.Add(this.tb_BM_BACK_UP2);
            this.tabPage6.Controls.Add(this.tb_BM_BACK_UP);
            this.tabPage6.Controls.Add(this.tb_BM);
            this.tabPage6.Controls.Add(this.rtb_IDBM_PARTNER);
            this.tabPage6.Controls.Add(this.label23);
            this.tabPage6.Controls.Add(this.label17);
            this.tabPage6.Controls.Add(this.rtb_IDBM_CLOSE_4);
            this.tabPage6.Controls.Add(this.label13);
            this.tabPage6.Controls.Add(this.rtb_IDBM_CLOSE_3);
            this.tabPage6.Controls.Add(this.label14);
            this.tabPage6.Controls.Add(this.rtb_IDBM_CLOSE_2);
            this.tabPage6.Controls.Add(this.label15);
            this.tabPage6.Controls.Add(this.rtb_IDBM_CLOSE);
            this.tabPage6.Controls.Add(this.label16);
            this.tabPage6.Controls.Add(this.rtb_ID_BM_Share_BACK_UP3);
            this.tabPage6.Controls.Add(this.label11);
            this.tabPage6.Controls.Add(this.rtb_ID_BM_Share_BACK_UP2);
            this.tabPage6.Controls.Add(this.label12);
            this.tabPage6.Controls.Add(this.rtb_ID_BM_Share_BACK_UP);
            this.tabPage6.Controls.Add(this.label10);
            this.tabPage6.Controls.Add(this.rtb_ID_BM_Share);
            this.tabPage6.Controls.Add(this.label9);
            this.tabPage6.Controls.Add(this.tb_sl_282);
            this.tabPage6.Controls.Add(this.label8);
            this.tabPage6.Controls.Add(this.cmb_CLOSE_SHARE);
            this.tabPage6.Controls.Add(this.label3);
            this.tabPage6.Controls.Add(this.cmb_User_Agent);
            this.tabPage6.Controls.Add(this.label2);
            this.tabPage6.Location = new System.Drawing.Point(4, 24);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1753, 667);
            this.tabPage6.TabIndex = 0;
            this.tabPage6.Text = "SHARE";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(1122, 31);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(126, 15);
            this.label56.TabIndex = 123;
            this.label56.Text = "SỐ LƯỢNG BM REG:";
            // 
            // tb_so_luong_BM
            // 
            this.tb_so_luong_BM.Location = new System.Drawing.Point(1254, 28);
            this.tb_so_luong_BM.Name = "tb_so_luong_BM";
            this.tb_so_luong_BM.Size = new System.Drawing.Size(100, 21);
            this.tb_so_luong_BM.TabIndex = 122;
            // 
            // rtb_BMDIE
            // 
            this.rtb_BMDIE.Location = new System.Drawing.Point(775, 412);
            this.rtb_BMDIE.Name = "rtb_BMDIE";
            this.rtb_BMDIE.Size = new System.Drawing.Size(302, 166);
            this.rtb_BMDIE.TabIndex = 117;
            this.rtb_BMDIE.Text = "";
            // 
            // rtb_BM_Nhan_Du
            // 
            this.rtb_BM_Nhan_Du.Location = new System.Drawing.Point(775, 215);
            this.rtb_BM_Nhan_Du.Name = "rtb_BM_Nhan_Du";
            this.rtb_BM_Nhan_Du.Size = new System.Drawing.Size(302, 166);
            this.rtb_BM_Nhan_Du.TabIndex = 116;
            this.rtb_BM_Nhan_Du.Text = "";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(828, 6);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(36, 15);
            this.label28.TabIndex = 121;
            this.label28.Text = "FAIL:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(969, 6);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(46, 15);
            this.label27.TabIndex = 120;
            this.label27.Text = "DONE:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(894, 388);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(53, 15);
            this.label25.TabIndex = 119;
            this.label25.Text = "BM DIE:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(875, 196);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(88, 15);
            this.label24.TabIndex = 118;
            this.label24.Text = "BM NHẬN ĐỦ:";
            // 
            // rtbdone
            // 
            this.rtbdone.Location = new System.Drawing.Point(945, 27);
            this.rtbdone.Name = "rtbdone";
            this.rtbdone.Size = new System.Drawing.Size(148, 166);
            this.rtbdone.TabIndex = 115;
            this.rtbdone.Text = "";
            // 
            // rtbAC_FAIL
            // 
            this.rtbAC_FAIL.Location = new System.Drawing.Point(775, 27);
            this.rtbAC_FAIL.Name = "rtbAC_FAIL";
            this.rtbAC_FAIL.Size = new System.Drawing.Size(148, 166);
            this.rtbAC_FAIL.TabIndex = 114;
            this.rtbAC_FAIL.Text = "";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(445, 401);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(100, 15);
            this.label26.TabIndex = 103;
            this.label26.Text = "IDBM PARTNER:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(613, 7);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(65, 15);
            this.label19.TabIndex = 95;
            this.label19.Text = "IDCLOSE:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(467, 7);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(43, 15);
            this.label18.TabIndex = 94;
            this.label18.Text = "IDBM:";
            // 
            // rtb_BM_CLOSE_4_THAY_THE
            // 
            this.rtb_BM_CLOSE_4_THAY_THE.Location = new System.Drawing.Point(577, 236);
            this.rtb_BM_CLOSE_4_THAY_THE.Name = "rtb_BM_CLOSE_4_THAY_THE";
            this.rtb_BM_CLOSE_4_THAY_THE.Size = new System.Drawing.Size(148, 64);
            this.rtb_BM_CLOSE_4_THAY_THE.TabIndex = 93;
            this.rtb_BM_CLOSE_4_THAY_THE.Text = "";
            // 
            // rtb_BM_CLOSE_3_THAY_THE
            // 
            this.rtb_BM_CLOSE_3_THAY_THE.Location = new System.Drawing.Point(577, 167);
            this.rtb_BM_CLOSE_3_THAY_THE.Name = "rtb_BM_CLOSE_3_THAY_THE";
            this.rtb_BM_CLOSE_3_THAY_THE.Size = new System.Drawing.Size(148, 64);
            this.rtb_BM_CLOSE_3_THAY_THE.TabIndex = 92;
            this.rtb_BM_CLOSE_3_THAY_THE.Text = "";
            // 
            // rtb_BM_CLOSE_2_THAY_THE
            // 
            this.rtb_BM_CLOSE_2_THAY_THE.Location = new System.Drawing.Point(577, 97);
            this.rtb_BM_CLOSE_2_THAY_THE.Name = "rtb_BM_CLOSE_2_THAY_THE";
            this.rtb_BM_CLOSE_2_THAY_THE.Size = new System.Drawing.Size(148, 64);
            this.rtb_BM_CLOSE_2_THAY_THE.TabIndex = 91;
            this.rtb_BM_CLOSE_2_THAY_THE.Text = "";
            // 
            // rtb_BM_CLOSE_THAY_THE
            // 
            this.rtb_BM_CLOSE_THAY_THE.Location = new System.Drawing.Point(577, 28);
            this.rtb_BM_CLOSE_THAY_THE.Name = "rtb_BM_CLOSE_THAY_THE";
            this.rtb_BM_CLOSE_THAY_THE.Size = new System.Drawing.Size(148, 64);
            this.rtb_BM_CLOSE_THAY_THE.TabIndex = 90;
            this.rtb_BM_CLOSE_THAY_THE.Text = "";
            // 
            // rtb_BM_BACKUP3_THAY_THE
            // 
            this.rtb_BM_BACKUP3_THAY_THE.Location = new System.Drawing.Point(416, 236);
            this.rtb_BM_BACKUP3_THAY_THE.Name = "rtb_BM_BACKUP3_THAY_THE";
            this.rtb_BM_BACKUP3_THAY_THE.Size = new System.Drawing.Size(148, 64);
            this.rtb_BM_BACKUP3_THAY_THE.TabIndex = 89;
            this.rtb_BM_BACKUP3_THAY_THE.Text = "";
            // 
            // rtb_BM_BACKUP2_THAY_THE
            // 
            this.rtb_BM_BACKUP2_THAY_THE.Location = new System.Drawing.Point(416, 167);
            this.rtb_BM_BACKUP2_THAY_THE.Name = "rtb_BM_BACKUP2_THAY_THE";
            this.rtb_BM_BACKUP2_THAY_THE.Size = new System.Drawing.Size(148, 64);
            this.rtb_BM_BACKUP2_THAY_THE.TabIndex = 88;
            this.rtb_BM_BACKUP2_THAY_THE.Text = "";
            // 
            // rtb_BM_BACKUP_THAY_THE
            // 
            this.rtb_BM_BACKUP_THAY_THE.Location = new System.Drawing.Point(416, 97);
            this.rtb_BM_BACKUP_THAY_THE.Name = "rtb_BM_BACKUP_THAY_THE";
            this.rtb_BM_BACKUP_THAY_THE.Size = new System.Drawing.Size(148, 64);
            this.rtb_BM_BACKUP_THAY_THE.TabIndex = 87;
            this.rtb_BM_BACKUP_THAY_THE.Text = "";
            // 
            // rtb_BM_THAY_THE
            // 
            this.rtb_BM_THAY_THE.Location = new System.Drawing.Point(416, 28);
            this.rtb_BM_THAY_THE.Name = "rtb_BM_THAY_THE";
            this.rtb_BM_THAY_THE.Size = new System.Drawing.Size(148, 64);
            this.rtb_BM_THAY_THE.TabIndex = 86;
            this.rtb_BM_THAY_THE.Text = "";
            // 
            // cmb_ADD_Tra_Truoc
            // 
            this.cmb_ADD_Tra_Truoc.FormattingEnabled = true;
            this.cmb_ADD_Tra_Truoc.Location = new System.Drawing.Point(688, 432);
            this.cmb_ADD_Tra_Truoc.Name = "cmb_ADD_Tra_Truoc";
            this.cmb_ADD_Tra_Truoc.Size = new System.Drawing.Size(77, 23);
            this.cmb_ADD_Tra_Truoc.TabIndex = 113;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(570, 438);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(112, 15);
            this.label34.TabIndex = 112;
            this.label34.Text = "ADD TRẢ TRƯỚC:";
            // 
            // gioi_han_close
            // 
            this.gioi_han_close.Location = new System.Drawing.Point(665, 503);
            this.gioi_han_close.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.gioi_han_close.Name = "gioi_han_close";
            this.gioi_han_close.Size = new System.Drawing.Size(85, 21);
            this.gioi_han_close.TabIndex = 111;
            this.gioi_han_close.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(574, 505);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(93, 15);
            this.label32.TabIndex = 110;
            this.label32.Text = "Giới Hạn Close:";
            // 
            // gioi_han_live
            // 
            this.gioi_han_live.Location = new System.Drawing.Point(479, 562);
            this.gioi_han_live.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.gioi_han_live.Name = "gioi_han_live";
            this.gioi_han_live.Size = new System.Drawing.Size(85, 21);
            this.gioi_han_live.TabIndex = 109;
            this.gioi_han_live.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(396, 564);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(85, 15);
            this.label31.TabIndex = 108;
            this.label31.Text = "Giới Hạn Live:";
            // 
            // gioi_han_1
            // 
            this.gioi_han_1.Location = new System.Drawing.Point(479, 533);
            this.gioi_han_1.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.gioi_han_1.Name = "gioi_han_1";
            this.gioi_han_1.Size = new System.Drawing.Size(85, 21);
            this.gioi_han_1.TabIndex = 107;
            this.gioi_han_1.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(406, 539);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(67, 15);
            this.label30.TabIndex = 106;
            this.label30.Text = "Giới hạn 1:";
            // 
            // delayshare
            // 
            this.delayshare.Location = new System.Drawing.Point(479, 503);
            this.delayshare.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.delayshare.Name = "delayshare";
            this.delayshare.Size = new System.Drawing.Size(85, 21);
            this.delayshare.TabIndex = 105;
            this.delayshare.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(396, 505);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(77, 15);
            this.label29.TabIndex = 104;
            this.label29.Text = "Delay Share:";
            // 
            // rtb_BM_PARTNER_THAY_THE
            // 
            this.rtb_BM_PARTNER_THAY_THE.Location = new System.Drawing.Point(416, 419);
            this.rtb_BM_PARTNER_THAY_THE.Name = "rtb_BM_PARTNER_THAY_THE";
            this.rtb_BM_PARTNER_THAY_THE.Size = new System.Drawing.Size(148, 64);
            this.rtb_BM_PARTNER_THAY_THE.TabIndex = 102;
            this.rtb_BM_PARTNER_THAY_THE.Text = "";
            // 
            // sl_Nhan_BM_CLOSE1_2
            // 
            this.sl_Nhan_BM_CLOSE1_2.Location = new System.Drawing.Point(607, 341);
            this.sl_Nhan_BM_CLOSE1_2.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.sl_Nhan_BM_CLOSE1_2.Name = "sl_Nhan_BM_CLOSE1_2";
            this.sl_Nhan_BM_CLOSE1_2.Size = new System.Drawing.Size(120, 21);
            this.sl_Nhan_BM_CLOSE1_2.TabIndex = 101;
            this.sl_Nhan_BM_CLOSE1_2.Value = new decimal(new int[] {
            3000,
            0,
            0,
            0});
            // 
            // sl_Nhan_BM_PARTNER
            // 
            this.sl_Nhan_BM_PARTNER.Location = new System.Drawing.Point(607, 368);
            this.sl_Nhan_BM_PARTNER.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.sl_Nhan_BM_PARTNER.Name = "sl_Nhan_BM_PARTNER";
            this.sl_Nhan_BM_PARTNER.Size = new System.Drawing.Size(120, 21);
            this.sl_Nhan_BM_PARTNER.TabIndex = 100;
            this.sl_Nhan_BM_PARTNER.Value = new decimal(new int[] {
            1500,
            0,
            0,
            0});
            // 
            // sl_nhan_Bm_BM_BACKUP
            // 
            this.sl_nhan_Bm_BM_BACKUP.Location = new System.Drawing.Point(607, 314);
            this.sl_nhan_Bm_BM_BACKUP.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.sl_nhan_Bm_BM_BACKUP.Name = "sl_nhan_Bm_BM_BACKUP";
            this.sl_nhan_Bm_BM_BACKUP.Size = new System.Drawing.Size(120, 21);
            this.sl_nhan_Bm_BM_BACKUP.TabIndex = 99;
            this.sl_nhan_Bm_BM_BACKUP.Value = new decimal(new int[] {
            1500,
            0,
            0,
            0});
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(396, 376);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(196, 15);
            this.label22.TabIndex = 98;
            this.label22.Text = "Số Lượng Nhận Vào BM PARTNER:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(396, 348);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(183, 15);
            this.label21.TabIndex = 97;
            this.label21.Text = "Số Lượng Nhận Vào BM CLOSE:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(396, 320);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(139, 15);
            this.label20.TabIndex = 96;
            this.label20.Text = "Số Lượng Nhận Vào BM:";
            // 
            // tx_So_Luong_Share_vao_bm
            // 
            this.tx_So_Luong_Share_vao_bm.Location = new System.Drawing.Point(227, 549);
            this.tx_So_Luong_Share_vao_bm.Name = "tx_So_Luong_Share_vao_bm";
            this.tx_So_Luong_Share_vao_bm.Size = new System.Drawing.Size(92, 21);
            this.tx_So_Luong_Share_vao_bm.TabIndex = 84;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(140, 552);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(81, 15);
            this.label33.TabIndex = 85;
            this.label33.Text = "Share DONE:";
            // 
            // tb_so_luong_BM_PARTNER
            // 
            this.tb_so_luong_BM_PARTNER.Location = new System.Drawing.Point(271, 405);
            this.tb_so_luong_BM_PARTNER.Name = "tb_so_luong_BM_PARTNER";
            this.tb_so_luong_BM_PARTNER.Size = new System.Drawing.Size(100, 21);
            this.tb_so_luong_BM_PARTNER.TabIndex = 83;
            // 
            // tb_BM_Close_4
            // 
            this.tb_BM_Close_4.Location = new System.Drawing.Point(271, 356);
            this.tb_BM_Close_4.Name = "tb_BM_Close_4";
            this.tb_BM_Close_4.Size = new System.Drawing.Size(100, 21);
            this.tb_BM_Close_4.TabIndex = 82;
            // 
            // tb_BM_Close_3
            // 
            this.tb_BM_Close_3.Location = new System.Drawing.Point(271, 306);
            this.tb_BM_Close_3.Name = "tb_BM_Close_3";
            this.tb_BM_Close_3.Size = new System.Drawing.Size(100, 21);
            this.tb_BM_Close_3.TabIndex = 81;
            // 
            // tb_BM_Close_2
            // 
            this.tb_BM_Close_2.Location = new System.Drawing.Point(271, 258);
            this.tb_BM_Close_2.Name = "tb_BM_Close_2";
            this.tb_BM_Close_2.Size = new System.Drawing.Size(100, 21);
            this.tb_BM_Close_2.TabIndex = 80;
            // 
            // tb_BM_Close1
            // 
            this.tb_BM_Close1.Location = new System.Drawing.Point(271, 208);
            this.tb_BM_Close1.Name = "tb_BM_Close1";
            this.tb_BM_Close1.Size = new System.Drawing.Size(100, 21);
            this.tb_BM_Close1.TabIndex = 79;
            // 
            // tb_BM_BACK_UP3
            // 
            this.tb_BM_BACK_UP3.Location = new System.Drawing.Point(271, 159);
            this.tb_BM_BACK_UP3.Name = "tb_BM_BACK_UP3";
            this.tb_BM_BACK_UP3.Size = new System.Drawing.Size(100, 21);
            this.tb_BM_BACK_UP3.TabIndex = 78;
            // 
            // tb_BM_BACK_UP2
            // 
            this.tb_BM_BACK_UP2.Location = new System.Drawing.Point(271, 109);
            this.tb_BM_BACK_UP2.Name = "tb_BM_BACK_UP2";
            this.tb_BM_BACK_UP2.Size = new System.Drawing.Size(100, 21);
            this.tb_BM_BACK_UP2.TabIndex = 77;
            // 
            // tb_BM_BACK_UP
            // 
            this.tb_BM_BACK_UP.Location = new System.Drawing.Point(271, 61);
            this.tb_BM_BACK_UP.Name = "tb_BM_BACK_UP";
            this.tb_BM_BACK_UP.Size = new System.Drawing.Size(100, 21);
            this.tb_BM_BACK_UP.TabIndex = 76;
            // 
            // tb_BM
            // 
            this.tb_BM.Location = new System.Drawing.Point(271, 11);
            this.tb_BM.Name = "tb_BM";
            this.tb_BM.Size = new System.Drawing.Size(100, 21);
            this.tb_BM.TabIndex = 75;
            // 
            // rtb_IDBM_PARTNER
            // 
            this.rtb_IDBM_PARTNER.Location = new System.Drawing.Point(81, 396);
            this.rtb_IDBM_PARTNER.Name = "rtb_IDBM_PARTNER";
            this.rtb_IDBM_PARTNER.Size = new System.Drawing.Size(140, 40);
            this.rtb_IDBM_PARTNER.TabIndex = 74;
            this.rtb_IDBM_PARTNER.Text = "";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(7, 408);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(78, 15);
            this.label23.TabIndex = 73;
            this.label23.Text = "IDPARTNER:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(227, 14);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(36, 15);
            this.label17.TabIndex = 72;
            this.label17.Text = "STK:";
            // 
            // rtb_IDBM_CLOSE_4
            // 
            this.rtb_IDBM_CLOSE_4.Location = new System.Drawing.Point(81, 347);
            this.rtb_IDBM_CLOSE_4.Name = "rtb_IDBM_CLOSE_4";
            this.rtb_IDBM_CLOSE_4.Size = new System.Drawing.Size(140, 40);
            this.rtb_IDBM_CLOSE_4.TabIndex = 71;
            this.rtb_IDBM_CLOSE_4.Text = "";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(7, 359);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(71, 15);
            this.label13.TabIndex = 70;
            this.label13.Text = "IDCLOSE4:";
            // 
            // rtb_IDBM_CLOSE_3
            // 
            this.rtb_IDBM_CLOSE_3.Location = new System.Drawing.Point(81, 297);
            this.rtb_IDBM_CLOSE_3.Name = "rtb_IDBM_CLOSE_3";
            this.rtb_IDBM_CLOSE_3.Size = new System.Drawing.Size(140, 40);
            this.rtb_IDBM_CLOSE_3.TabIndex = 69;
            this.rtb_IDBM_CLOSE_3.Text = "";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(7, 309);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(71, 15);
            this.label14.TabIndex = 68;
            this.label14.Text = "IDCLOSE3:";
            // 
            // rtb_IDBM_CLOSE_2
            // 
            this.rtb_IDBM_CLOSE_2.Location = new System.Drawing.Point(81, 249);
            this.rtb_IDBM_CLOSE_2.Name = "rtb_IDBM_CLOSE_2";
            this.rtb_IDBM_CLOSE_2.Size = new System.Drawing.Size(140, 40);
            this.rtb_IDBM_CLOSE_2.TabIndex = 67;
            this.rtb_IDBM_CLOSE_2.Text = "";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(7, 261);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(71, 15);
            this.label15.TabIndex = 66;
            this.label15.Text = "IDCLOSE2:";
            // 
            // rtb_IDBM_CLOSE
            // 
            this.rtb_IDBM_CLOSE.Location = new System.Drawing.Point(81, 199);
            this.rtb_IDBM_CLOSE.Name = "rtb_IDBM_CLOSE";
            this.rtb_IDBM_CLOSE.Size = new System.Drawing.Size(140, 40);
            this.rtb_IDBM_CLOSE.TabIndex = 65;
            this.rtb_IDBM_CLOSE.Text = "";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(7, 211);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(71, 15);
            this.label16.TabIndex = 64;
            this.label16.Text = "IDCLOSE1:";
            // 
            // rtb_ID_BM_Share_BACK_UP3
            // 
            this.rtb_ID_BM_Share_BACK_UP3.Location = new System.Drawing.Point(81, 150);
            this.rtb_ID_BM_Share_BACK_UP3.Name = "rtb_ID_BM_Share_BACK_UP3";
            this.rtb_ID_BM_Share_BACK_UP3.Size = new System.Drawing.Size(140, 40);
            this.rtb_ID_BM_Share_BACK_UP3.TabIndex = 63;
            this.rtb_ID_BM_Share_BACK_UP3.Text = "";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(7, 162);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 15);
            this.label11.TabIndex = 62;
            this.label11.Text = "IDBM4:";
            // 
            // rtb_ID_BM_Share_BACK_UP2
            // 
            this.rtb_ID_BM_Share_BACK_UP2.Location = new System.Drawing.Point(81, 100);
            this.rtb_ID_BM_Share_BACK_UP2.Name = "rtb_ID_BM_Share_BACK_UP2";
            this.rtb_ID_BM_Share_BACK_UP2.Size = new System.Drawing.Size(140, 40);
            this.rtb_ID_BM_Share_BACK_UP2.TabIndex = 61;
            this.rtb_ID_BM_Share_BACK_UP2.Text = "";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(7, 112);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(49, 15);
            this.label12.TabIndex = 60;
            this.label12.Text = "IDBM3:";
            // 
            // rtb_ID_BM_Share_BACK_UP
            // 
            this.rtb_ID_BM_Share_BACK_UP.Location = new System.Drawing.Point(81, 52);
            this.rtb_ID_BM_Share_BACK_UP.Name = "rtb_ID_BM_Share_BACK_UP";
            this.rtb_ID_BM_Share_BACK_UP.Size = new System.Drawing.Size(140, 40);
            this.rtb_ID_BM_Share_BACK_UP.TabIndex = 59;
            this.rtb_ID_BM_Share_BACK_UP.Text = "";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 64);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(49, 15);
            this.label10.TabIndex = 58;
            this.label10.Text = "IDBM2:";
            // 
            // rtb_ID_BM_Share
            // 
            this.rtb_ID_BM_Share.Location = new System.Drawing.Point(81, 2);
            this.rtb_ID_BM_Share.Name = "rtb_ID_BM_Share";
            this.rtb_ID_BM_Share.Size = new System.Drawing.Size(140, 40);
            this.rtb_ID_BM_Share.TabIndex = 57;
            this.rtb_ID_BM_Share.Text = "";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 14);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 15);
            this.label9.TabIndex = 56;
            this.label9.Text = "IDBM1:";
            // 
            // tb_sl_282
            // 
            this.tb_sl_282.Location = new System.Drawing.Point(42, 550);
            this.tb_sl_282.Name = "tb_sl_282";
            this.tb_sl_282.Size = new System.Drawing.Size(92, 21);
            this.tb_sl_282.TabIndex = 55;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(7, 553);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 15);
            this.label8.TabIndex = 54;
            this.label8.Text = "282:";
            // 
            // cmb_CLOSE_SHARE
            // 
            this.cmb_CLOSE_SHARE.FormattingEnabled = true;
            this.cmb_CLOSE_SHARE.Location = new System.Drawing.Point(101, 515);
            this.cmb_CLOSE_SHARE.Name = "cmb_CLOSE_SHARE";
            this.cmb_CLOSE_SHARE.Size = new System.Drawing.Size(92, 23);
            this.cmb_CLOSE_SHARE.TabIndex = 53;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 518);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 15);
            this.label3.TabIndex = 52;
            this.label3.Text = "Share CLONE:";
            // 
            // cmb_User_Agent
            // 
            this.cmb_User_Agent.FormattingEnabled = true;
            this.cmb_User_Agent.Location = new System.Drawing.Point(101, 478);
            this.cmb_User_Agent.Name = "cmb_User_Agent";
            this.cmb_User_Agent.Size = new System.Drawing.Size(274, 23);
            this.cmb_User_Agent.TabIndex = 51;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 481);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 15);
            this.label2.TabIndex = 50;
            this.label2.Text = "User_Agent:";
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.tabPage7.Controls.Add(this.label55);
            this.tabPage7.Controls.Add(this.rtb_MAIL_SHARE_CLONE);
            this.tabPage7.Controls.Add(this.groupBox1);
            this.tabPage7.Location = new System.Drawing.Point(4, 24);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(1753, 667);
            this.tabPage7.TabIndex = 1;
            this.tabPage7.Text = "BM";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(318, 18);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(105, 15);
            this.label55.TabIndex = 76;
            this.label55.Text = "MAIL SHARE BM:";
            // 
            // rtb_MAIL_SHARE_CLONE
            // 
            this.rtb_MAIL_SHARE_CLONE.Location = new System.Drawing.Point(321, 36);
            this.rtb_MAIL_SHARE_CLONE.Name = "rtb_MAIL_SHARE_CLONE";
            this.rtb_MAIL_SHARE_CLONE.Size = new System.Drawing.Size(302, 166);
            this.rtb_MAIL_SHARE_CLONE.TabIndex = 75;
            this.rtb_MAIL_SHARE_CLONE.Text = "";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmb_Share_DOI_TAC);
            this.groupBox1.Controls.Add(this.label57);
            this.groupBox1.Controls.Add(this.cmb_Share_BM_CLone);
            this.groupBox1.Controls.Add(this.label54);
            this.groupBox1.Controls.Add(this.cmb_Mui_Gio_TK_BM);
            this.groupBox1.Controls.Add(this.label53);
            this.groupBox1.Controls.Add(this.cmb_TEN_TK_BM);
            this.groupBox1.Controls.Add(this.label52);
            this.groupBox1.Controls.Add(this.cmb_Tien_Te_TK_BM);
            this.groupBox1.Controls.Add(this.label51);
            this.groupBox1.Controls.Add(this.delay_reg_bm);
            this.groupBox1.Controls.Add(this.for_reg_bm);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.cmb_Tao_TK_BM);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.cmb_REG_BM_Clone_API);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new System.Drawing.Point(28, 32);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(264, 512);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "REG BM";
            // 
            // cmb_Share_DOI_TAC
            // 
            this.cmb_Share_DOI_TAC.FormattingEnabled = true;
            this.cmb_Share_DOI_TAC.Location = new System.Drawing.Point(120, 330);
            this.cmb_Share_DOI_TAC.Name = "cmb_Share_DOI_TAC";
            this.cmb_Share_DOI_TAC.Size = new System.Drawing.Size(122, 23);
            this.cmb_Share_DOI_TAC.TabIndex = 22;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(6, 333);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(108, 15);
            this.label57.TabIndex = 21;
            this.label57.Text = "SHARE PARTNER:";
            // 
            // cmb_Share_BM_CLone
            // 
            this.cmb_Share_BM_CLone.FormattingEnabled = true;
            this.cmb_Share_BM_CLone.Location = new System.Drawing.Point(86, 301);
            this.cmb_Share_BM_CLone.Name = "cmb_Share_BM_CLone";
            this.cmb_Share_BM_CLone.Size = new System.Drawing.Size(122, 23);
            this.cmb_Share_BM_CLone.TabIndex = 20;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(7, 307);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(73, 15);
            this.label54.TabIndex = 19;
            this.label54.Text = "SHARE BM:";
            // 
            // cmb_Mui_Gio_TK_BM
            // 
            this.cmb_Mui_Gio_TK_BM.FormattingEnabled = true;
            this.cmb_Mui_Gio_TK_BM.Location = new System.Drawing.Point(86, 270);
            this.cmb_Mui_Gio_TK_BM.Name = "cmb_Mui_Gio_TK_BM";
            this.cmb_Mui_Gio_TK_BM.Size = new System.Drawing.Size(122, 23);
            this.cmb_Mui_Gio_TK_BM.TabIndex = 18;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(22, 272);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(56, 15);
            this.label53.TabIndex = 17;
            this.label53.Text = "Múi Giờ:";
            // 
            // cmb_TEN_TK_BM
            // 
            this.cmb_TEN_TK_BM.FormattingEnabled = true;
            this.cmb_TEN_TK_BM.Location = new System.Drawing.Point(86, 238);
            this.cmb_TEN_TK_BM.Name = "cmb_TEN_TK_BM";
            this.cmb_TEN_TK_BM.Size = new System.Drawing.Size(122, 23);
            this.cmb_TEN_TK_BM.TabIndex = 16;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(6, 241);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(74, 15);
            this.label52.TabIndex = 15;
            this.label52.Text = "Tên TK BM:";
            // 
            // cmb_Tien_Te_TK_BM
            // 
            this.cmb_Tien_Te_TK_BM.FormattingEnabled = true;
            this.cmb_Tien_Te_TK_BM.Location = new System.Drawing.Point(86, 203);
            this.cmb_Tien_Te_TK_BM.Name = "cmb_Tien_Te_TK_BM";
            this.cmb_Tien_Te_TK_BM.Size = new System.Drawing.Size(122, 23);
            this.cmb_Tien_Te_TK_BM.TabIndex = 14;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(21, 209);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(53, 15);
            this.label51.TabIndex = 13;
            this.label51.Text = "Tiền Tệ:";
            // 
            // delay_reg_bm
            // 
            this.delay_reg_bm.Location = new System.Drawing.Point(86, 161);
            this.delay_reg_bm.Name = "delay_reg_bm";
            this.delay_reg_bm.Size = new System.Drawing.Size(120, 21);
            this.delay_reg_bm.TabIndex = 12;
            // 
            // for_reg_bm
            // 
            this.for_reg_bm.Location = new System.Drawing.Point(86, 123);
            this.for_reg_bm.Name = "for_reg_bm";
            this.for_reg_bm.Size = new System.Drawing.Size(120, 21);
            this.for_reg_bm.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(21, 165);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 15);
            this.label7.TabIndex = 10;
            this.label7.Text = "Delay:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(21, 126);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 15);
            this.label6.TabIndex = 8;
            this.label6.Text = "For:";
            // 
            // cmb_Tao_TK_BM
            // 
            this.cmb_Tao_TK_BM.FormattingEnabled = true;
            this.cmb_Tao_TK_BM.Location = new System.Drawing.Point(84, 83);
            this.cmb_Tao_TK_BM.Name = "cmb_Tao_TK_BM";
            this.cmb_Tao_TK_BM.Size = new System.Drawing.Size(122, 23);
            this.cmb_Tao_TK_BM.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(21, 86);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 15);
            this.label5.TabIndex = 6;
            this.label5.Text = "Tạo TK:";
            // 
            // cmb_REG_BM_Clone_API
            // 
            this.cmb_REG_BM_Clone_API.FormattingEnabled = true;
            this.cmb_REG_BM_Clone_API.Location = new System.Drawing.Point(84, 36);
            this.cmb_REG_BM_Clone_API.Name = "cmb_REG_BM_Clone_API";
            this.cmb_REG_BM_Clone_API.Size = new System.Drawing.Size(122, 23);
            this.cmb_REG_BM_Clone_API.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 15);
            this.label4.TabIndex = 4;
            this.label4.Text = "ON/OFF:";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Silver;
            this.tabPage3.Controls.Add(this.groupBox2);
            this.tabPage3.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage3.Location = new System.Drawing.Point(4, 24);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1767, 688);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "DongVan.Net";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label41);
            this.groupBox2.Controls.Add(this.cmb_DONG_VAN);
            this.groupBox2.Controls.Add(this.cmb_ID_MAIL);
            this.groupBox2.Controls.Add(this.label40);
            this.groupBox2.Controls.Add(this.label39);
            this.groupBox2.Controls.Add(this.soluong_mua_Mail);
            this.groupBox2.Controls.Add(this.label38);
            this.groupBox2.Controls.Add(this.tb_so_du_DongVan);
            this.groupBox2.Controls.Add(this.Tx_Key_API_DongVan);
            this.groupBox2.Controls.Add(this.label37);
            this.groupBox2.Controls.Add(this.tx_MK_Dong_Vanox2);
            this.groupBox2.Controls.Add(this.tx_TK_Dong_Van);
            this.groupBox2.Controls.Add(this.label36);
            this.groupBox2.Controls.Add(this.label35);
            this.groupBox2.Location = new System.Drawing.Point(35, 65);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(505, 229);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(300, 109);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(50, 15);
            this.label41.TabIndex = 36;
            this.label41.Text = "ON/FF :";
            // 
            // cmb_DONG_VAN
            // 
            this.cmb_DONG_VAN.FormattingEnabled = true;
            this.cmb_DONG_VAN.Location = new System.Drawing.Point(356, 106);
            this.cmb_DONG_VAN.Name = "cmb_DONG_VAN";
            this.cmb_DONG_VAN.Size = new System.Drawing.Size(121, 23);
            this.cmb_DONG_VAN.TabIndex = 35;
            // 
            // cmb_ID_MAIL
            // 
            this.cmb_ID_MAIL.FormattingEnabled = true;
            this.cmb_ID_MAIL.Location = new System.Drawing.Point(356, 74);
            this.cmb_ID_MAIL.Name = "cmb_ID_MAIL";
            this.cmb_ID_MAIL.Size = new System.Drawing.Size(121, 23);
            this.cmb_ID_MAIL.TabIndex = 19;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(327, 78);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(24, 15);
            this.label40.TabIndex = 18;
            this.label40.Text = "ID:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(262, 50);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(89, 15);
            this.label39.TabIndex = 17;
            this.label39.Text = "Số Lượng Mua:";
            // 
            // soluong_mua_Mail
            // 
            this.soluong_mua_Mail.Location = new System.Drawing.Point(357, 48);
            this.soluong_mua_Mail.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.soluong_mua_Mail.Name = "soluong_mua_Mail";
            this.soluong_mua_Mail.Size = new System.Drawing.Size(120, 21);
            this.soluong_mua_Mail.TabIndex = 16;
            this.soluong_mua_Mail.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(8, 134);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(44, 15);
            this.label38.TabIndex = 15;
            this.label38.Text = "Số Dư:";
            // 
            // tb_so_du_DongVan
            // 
            this.tb_so_du_DongVan.Location = new System.Drawing.Point(78, 131);
            this.tb_so_du_DongVan.Name = "tb_so_du_DongVan";
            this.tb_so_du_DongVan.Size = new System.Drawing.Size(149, 21);
            this.tb_so_du_DongVan.TabIndex = 14;
            // 
            // Tx_Key_API_DongVan
            // 
            this.Tx_Key_API_DongVan.Location = new System.Drawing.Point(78, 103);
            this.Tx_Key_API_DongVan.Name = "Tx_Key_API_DongVan";
            this.Tx_Key_API_DongVan.Size = new System.Drawing.Size(149, 21);
            this.Tx_Key_API_DongVan.TabIndex = 13;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(11, 109);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(53, 15);
            this.label37.TabIndex = 12;
            this.label37.Text = "Key API:";
            // 
            // tx_MK_Dong_Vanox2
            // 
            this.tx_MK_Dong_Vanox2.Location = new System.Drawing.Point(78, 74);
            this.tx_MK_Dong_Vanox2.Name = "tx_MK_Dong_Vanox2";
            this.tx_MK_Dong_Vanox2.Size = new System.Drawing.Size(149, 21);
            this.tx_MK_Dong_Vanox2.TabIndex = 11;
            // 
            // tx_TK_Dong_Van
            // 
            this.tx_TK_Dong_Van.Location = new System.Drawing.Point(78, 47);
            this.tx_TK_Dong_Van.Name = "tx_TK_Dong_Van";
            this.tx_TK_Dong_Van.Size = new System.Drawing.Size(149, 21);
            this.tx_TK_Dong_Van.TabIndex = 10;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(35, 74);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(29, 15);
            this.label36.TabIndex = 9;
            this.label36.Text = "Mk:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(35, 50);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(26, 15);
            this.label35.TabIndex = 8;
            this.label35.Text = "Tk:";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.DimGray;
            this.tabPage4.Controls.Add(this.dgv2_IG);
            this.tabPage4.Controls.Add(this.dgv_mail);
            this.tabPage4.Location = new System.Drawing.Point(4, 24);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1767, 688);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "IG_99";
            // 
            // dgv2_IG
            // 
            this.dgv2_IG.AllowUserToAddRows = false;
            this.dgv2_IG.AllowUserToDeleteRows = false;
            this.dgv2_IG.AllowUserToResizeRows = false;
            this.dgv2_IG.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv2_IG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv2_IG.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cStt2,
            this.cIG,
            this.cStatus2,
            this.cSelect2});
            this.dgv2_IG.ContextMenuStrip = this.contextMenuStrip3;
            this.dgv2_IG.Location = new System.Drawing.Point(758, 6);
            this.dgv2_IG.Name = "dgv2_IG";
            this.dgv2_IG.RowHeadersVisible = false;
            this.dgv2_IG.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgv2_IG.Size = new System.Drawing.Size(767, 596);
            this.dgv2_IG.TabIndex = 1;
            this.dgv2_IG.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgv2_IG_CellFormatting);
            // 
            // cStt2
            // 
            this.cStt2.FillWeight = 30F;
            this.cStt2.HeaderText = "STT";
            this.cStt2.Name = "cStt2";
            // 
            // cIG
            // 
            this.cIG.FillWeight = 200F;
            this.cIG.HeaderText = "IG";
            this.cIG.Name = "cIG";
            // 
            // cStatus2
            // 
            this.cStatus2.FillWeight = 200F;
            this.cStatus2.HeaderText = "STATUS";
            this.cStatus2.Name = "cStatus2";
            // 
            // cSelect2
            // 
            this.cSelect2.FillWeight = 20F;
            this.cSelect2.HeaderText = "";
            this.cSelect2.Name = "cSelect2";
            // 
            // contextMenuStrip3
            // 
            this.contextMenuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chọnToolStripMenuItem2,
            this.bỏChọnToolStripMenuItem2,
            this.xóaToolStripMenuItem2});
            this.contextMenuStrip3.Name = "contextMenuStrip3";
            this.contextMenuStrip3.Size = new System.Drawing.Size(121, 70);
            // 
            // chọnToolStripMenuItem2
            // 
            this.chọnToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bôiĐenToolStripMenuItem4,
            this.tấtCảToolStripMenuItem5});
            this.chọnToolStripMenuItem2.Name = "chọnToolStripMenuItem2";
            this.chọnToolStripMenuItem2.Size = new System.Drawing.Size(120, 22);
            this.chọnToolStripMenuItem2.Text = "Chọn";
            // 
            // bôiĐenToolStripMenuItem4
            // 
            this.bôiĐenToolStripMenuItem4.Name = "bôiĐenToolStripMenuItem4";
            this.bôiĐenToolStripMenuItem4.Size = new System.Drawing.Size(114, 22);
            this.bôiĐenToolStripMenuItem4.Text = "Bôi đen";
            this.bôiĐenToolStripMenuItem4.Click += new System.EventHandler(this.bôiĐenToolStripMenuItem4_Click);
            // 
            // tấtCảToolStripMenuItem5
            // 
            this.tấtCảToolStripMenuItem5.Name = "tấtCảToolStripMenuItem5";
            this.tấtCảToolStripMenuItem5.Size = new System.Drawing.Size(114, 22);
            this.tấtCảToolStripMenuItem5.Text = "Tất Cả";
            this.tấtCảToolStripMenuItem5.Click += new System.EventHandler(this.tấtCảToolStripMenuItem5_Click);
            // 
            // bỏChọnToolStripMenuItem2
            // 
            this.bỏChọnToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bôiĐenToolStripMenuItem5,
            this.tấtCảToolStripMenuItem6});
            this.bỏChọnToolStripMenuItem2.Name = "bỏChọnToolStripMenuItem2";
            this.bỏChọnToolStripMenuItem2.Size = new System.Drawing.Size(120, 22);
            this.bỏChọnToolStripMenuItem2.Text = "Bỏ Chọn";
            // 
            // bôiĐenToolStripMenuItem5
            // 
            this.bôiĐenToolStripMenuItem5.Name = "bôiĐenToolStripMenuItem5";
            this.bôiĐenToolStripMenuItem5.Size = new System.Drawing.Size(115, 22);
            this.bôiĐenToolStripMenuItem5.Text = "Bôi Đen";
            this.bôiĐenToolStripMenuItem5.Click += new System.EventHandler(this.bôiĐenToolStripMenuItem5_Click);
            // 
            // tấtCảToolStripMenuItem6
            // 
            this.tấtCảToolStripMenuItem6.Name = "tấtCảToolStripMenuItem6";
            this.tấtCảToolStripMenuItem6.Size = new System.Drawing.Size(115, 22);
            this.tấtCảToolStripMenuItem6.Text = "Tất Cả";
            this.tấtCảToolStripMenuItem6.Click += new System.EventHandler(this.tấtCảToolStripMenuItem6_Click);
            // 
            // xóaToolStripMenuItem2
            // 
            this.xóaToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bôiĐenToolStripMenuItem6,
            this.tấtCảToolStripMenuItem7});
            this.xóaToolStripMenuItem2.Name = "xóaToolStripMenuItem2";
            this.xóaToolStripMenuItem2.Size = new System.Drawing.Size(120, 22);
            this.xóaToolStripMenuItem2.Text = "Xóa";
            // 
            // bôiĐenToolStripMenuItem6
            // 
            this.bôiĐenToolStripMenuItem6.Name = "bôiĐenToolStripMenuItem6";
            this.bôiĐenToolStripMenuItem6.Size = new System.Drawing.Size(152, 22);
            this.bôiĐenToolStripMenuItem6.Text = "Dòng Đã Chọn";
            this.bôiĐenToolStripMenuItem6.Click += new System.EventHandler(this.bôiĐenToolStripMenuItem6_Click);
            // 
            // tấtCảToolStripMenuItem7
            // 
            this.tấtCảToolStripMenuItem7.Name = "tấtCảToolStripMenuItem7";
            this.tấtCảToolStripMenuItem7.Size = new System.Drawing.Size(152, 22);
            this.tấtCảToolStripMenuItem7.Text = "Tất Cả";
            this.tấtCảToolStripMenuItem7.Click += new System.EventHandler(this.tấtCảToolStripMenuItem7_Click);
            // 
            // dgv_mail
            // 
            this.dgv_mail.AllowUserToAddRows = false;
            this.dgv_mail.AllowUserToDeleteRows = false;
            this.dgv_mail.AllowUserToResizeRows = false;
            this.dgv_mail.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_mail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_mail.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cStt1,
            this.cMail1,
            this.cPassMail1,
            this.cToken,
            this.cStatus1,
            this.cSelect1});
            this.dgv_mail.ContextMenuStrip = this.contextMenuStrip2;
            this.dgv_mail.Location = new System.Drawing.Point(6, 6);
            this.dgv_mail.Name = "dgv_mail";
            this.dgv_mail.RowHeadersVisible = false;
            this.dgv_mail.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgv_mail.Size = new System.Drawing.Size(746, 596);
            this.dgv_mail.TabIndex = 0;
            this.dgv_mail.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_mail_CellContentClick);
            this.dgv_mail.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgv_mail_CellFormatting);
            this.dgv_mail.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgv_mail_KeyDown);
            // 
            // cStt1
            // 
            this.cStt1.FillWeight = 30F;
            this.cStt1.HeaderText = "STT";
            this.cStt1.Name = "cStt1";
            // 
            // cMail1
            // 
            this.cMail1.HeaderText = "MAIL";
            this.cMail1.Name = "cMail1";
            // 
            // cPassMail1
            // 
            this.cPassMail1.HeaderText = "PASSMAIL";
            this.cPassMail1.Name = "cPassMail1";
            // 
            // cToken
            // 
            this.cToken.HeaderText = "Token";
            this.cToken.Name = "cToken";
            // 
            // cStatus1
            // 
            this.cStatus1.FillWeight = 200F;
            this.cStatus1.HeaderText = "STATUS";
            this.cStatus1.Name = "cStatus1";
            // 
            // cSelect1
            // 
            this.cSelect1.FillWeight = 20F;
            this.cSelect1.HeaderText = "";
            this.cSelect1.Name = "cSelect1";
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chọnToolStripMenuItem1,
            this.bỏChọnToolStripMenuItem1,
            this.xóaToolStripMenuItem1});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(121, 70);
            // 
            // chọnToolStripMenuItem1
            // 
            this.chọnToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bôiĐenToolStripMenuItem2,
            this.tấtCảToolStripMenuItem3});
            this.chọnToolStripMenuItem1.Name = "chọnToolStripMenuItem1";
            this.chọnToolStripMenuItem1.Size = new System.Drawing.Size(120, 22);
            this.chọnToolStripMenuItem1.Text = "Chọn";
            // 
            // bôiĐenToolStripMenuItem2
            // 
            this.bôiĐenToolStripMenuItem2.Name = "bôiĐenToolStripMenuItem2";
            this.bôiĐenToolStripMenuItem2.Size = new System.Drawing.Size(115, 22);
            this.bôiĐenToolStripMenuItem2.Text = "Bôi Đen";
            this.bôiĐenToolStripMenuItem2.Click += new System.EventHandler(this.bôiĐenToolStripMenuItem2_Click);
            // 
            // tấtCảToolStripMenuItem3
            // 
            this.tấtCảToolStripMenuItem3.Name = "tấtCảToolStripMenuItem3";
            this.tấtCảToolStripMenuItem3.Size = new System.Drawing.Size(115, 22);
            this.tấtCảToolStripMenuItem3.Text = "Tất Cả";
            this.tấtCảToolStripMenuItem3.Click += new System.EventHandler(this.tấtCảToolStripMenuItem3_Click);
            // 
            // bỏChọnToolStripMenuItem1
            // 
            this.bỏChọnToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bôiĐenToolStripMenuItem3,
            this.tấtCảToolStripMenuItem4});
            this.bỏChọnToolStripMenuItem1.Name = "bỏChọnToolStripMenuItem1";
            this.bỏChọnToolStripMenuItem1.Size = new System.Drawing.Size(120, 22);
            this.bỏChọnToolStripMenuItem1.Text = "Bỏ Chọn";
            // 
            // bôiĐenToolStripMenuItem3
            // 
            this.bôiĐenToolStripMenuItem3.Name = "bôiĐenToolStripMenuItem3";
            this.bôiĐenToolStripMenuItem3.Size = new System.Drawing.Size(114, 22);
            this.bôiĐenToolStripMenuItem3.Text = "Bôi đen";
            this.bôiĐenToolStripMenuItem3.Click += new System.EventHandler(this.bôiĐenToolStripMenuItem3_Click);
            // 
            // tấtCảToolStripMenuItem4
            // 
            this.tấtCảToolStripMenuItem4.Name = "tấtCảToolStripMenuItem4";
            this.tấtCảToolStripMenuItem4.Size = new System.Drawing.Size(114, 22);
            this.tấtCảToolStripMenuItem4.Text = "Tất Cả";
            this.tấtCảToolStripMenuItem4.Click += new System.EventHandler(this.tấtCảToolStripMenuItem4_Click);
            // 
            // xóaToolStripMenuItem1
            // 
            this.xóaToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dòngĐãChọnToolStripMenuItem1,
            this.tấtCảToolStripMenuItem8});
            this.xóaToolStripMenuItem1.Name = "xóaToolStripMenuItem1";
            this.xóaToolStripMenuItem1.Size = new System.Drawing.Size(120, 22);
            this.xóaToolStripMenuItem1.Text = "Xóa";
            // 
            // dòngĐãChọnToolStripMenuItem1
            // 
            this.dòngĐãChọnToolStripMenuItem1.Name = "dòngĐãChọnToolStripMenuItem1";
            this.dòngĐãChọnToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.dòngĐãChọnToolStripMenuItem1.Text = "Dòng Đã Chọn";
            this.dòngĐãChọnToolStripMenuItem1.Click += new System.EventHandler(this.dòngĐãChọnToolStripMenuItem1_Click);
            // 
            // tấtCảToolStripMenuItem8
            // 
            this.tấtCảToolStripMenuItem8.Name = "tấtCảToolStripMenuItem8";
            this.tấtCảToolStripMenuItem8.Size = new System.Drawing.Size(152, 22);
            this.tấtCảToolStripMenuItem8.Text = "Tất Cả";
            this.tấtCảToolStripMenuItem8.Click += new System.EventHandler(this.tấtCảToolStripMenuItem8_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.Gray;
            this.tabPage5.Controls.Add(this.tabControl6);
            this.tabPage5.Controls.Add(this.groupBox8);
            this.tabPage5.Controls.Add(this.groupBox4);
            this.tabPage5.Location = new System.Drawing.Point(4, 24);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1767, 688);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Cài Đặt IG";
            // 
            // tabControl6
            // 
            this.tabControl6.Controls.Add(this.tabPage23);
            this.tabControl6.Controls.Add(this.tabPage24);
            this.tabControl6.Controls.Add(this.tabPage25);
            this.tabControl6.Controls.Add(this.tabPage26);
            this.tabControl6.Location = new System.Drawing.Point(6, 6);
            this.tabControl6.Name = "tabControl6";
            this.tabControl6.SelectedIndex = 0;
            this.tabControl6.Size = new System.Drawing.Size(456, 330);
            this.tabControl6.TabIndex = 30;
            // 
            // tabPage23
            // 
            this.tabPage23.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage23.Controls.Add(this.groupBox3);
            this.tabPage23.Location = new System.Drawing.Point(4, 24);
            this.tabPage23.Name = "tabPage23";
            this.tabPage23.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage23.Size = new System.Drawing.Size(448, 302);
            this.tabPage23.TabIndex = 0;
            this.tabPage23.Text = "REGIG";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label175);
            this.groupBox3.Controls.Add(this.cmb_REG_BM_IG_API_CHROME);
            this.groupBox3.Controls.Add(this.tb_ID_UP);
            this.groupBox3.Controls.Add(this.label140);
            this.groupBox3.Controls.Add(this.label139);
            this.groupBox3.Controls.Add(this.label138);
            this.groupBox3.Controls.Add(this.tb_MK_NAM);
            this.groupBox3.Controls.Add(this.tb_TK_NAM);
            this.groupBox3.Controls.Add(this.cmb_UP_WEB);
            this.groupBox3.Controls.Add(this.label137);
            this.groupBox3.Controls.Add(this.label47);
            this.groupBox3.Controls.Add(this.label48);
            this.groupBox3.Controls.Add(this.cmb_REGHOTMAIL);
            this.groupBox3.Controls.Add(this.cmb_VN_US);
            this.groupBox3.Location = new System.Drawing.Point(2, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(440, 290);
            this.groupBox3.TabIndex = 27;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "REGIG";
            // 
            // label175
            // 
            this.label175.AutoSize = true;
            this.label175.Location = new System.Drawing.Point(70, 29);
            this.label175.Name = "label175";
            this.label175.Size = new System.Drawing.Size(87, 15);
            this.label175.TabIndex = 40;
            this.label175.Text = "API/CHROME:";
            // 
            // cmb_REG_BM_IG_API_CHROME
            // 
            this.cmb_REG_BM_IG_API_CHROME.FormattingEnabled = true;
            this.cmb_REG_BM_IG_API_CHROME.Location = new System.Drawing.Point(161, 26);
            this.cmb_REG_BM_IG_API_CHROME.Name = "cmb_REG_BM_IG_API_CHROME";
            this.cmb_REG_BM_IG_API_CHROME.Size = new System.Drawing.Size(141, 23);
            this.cmb_REG_BM_IG_API_CHROME.TabIndex = 39;
            // 
            // tb_ID_UP
            // 
            this.tb_ID_UP.Location = new System.Drawing.Point(165, 219);
            this.tb_ID_UP.Name = "tb_ID_UP";
            this.tb_ID_UP.Size = new System.Drawing.Size(121, 21);
            this.tb_ID_UP.TabIndex = 38;
            // 
            // label140
            // 
            this.label140.AutoSize = true;
            this.label140.Location = new System.Drawing.Point(119, 219);
            this.label140.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(42, 15);
            this.label140.TabIndex = 37;
            this.label140.Text = "ID UP:";
            // 
            // label139
            // 
            this.label139.AutoSize = true;
            this.label139.Location = new System.Drawing.Point(130, 195);
            this.label139.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(31, 15);
            this.label139.TabIndex = 36;
            this.label139.Text = "MK:";
            // 
            // label138
            // 
            this.label138.AutoSize = true;
            this.label138.Location = new System.Drawing.Point(130, 168);
            this.label138.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(28, 15);
            this.label138.TabIndex = 35;
            this.label138.Text = "TK:";
            // 
            // tb_MK_NAM
            // 
            this.tb_MK_NAM.Location = new System.Drawing.Point(165, 192);
            this.tb_MK_NAM.Name = "tb_MK_NAM";
            this.tb_MK_NAM.Size = new System.Drawing.Size(121, 21);
            this.tb_MK_NAM.TabIndex = 34;
            // 
            // tb_TK_NAM
            // 
            this.tb_TK_NAM.Location = new System.Drawing.Point(165, 165);
            this.tb_TK_NAM.Name = "tb_TK_NAM";
            this.tb_TK_NAM.Size = new System.Drawing.Size(121, 21);
            this.tb_TK_NAM.TabIndex = 30;
            // 
            // cmb_UP_WEB
            // 
            this.cmb_UP_WEB.FormattingEnabled = true;
            this.cmb_UP_WEB.Location = new System.Drawing.Point(165, 127);
            this.cmb_UP_WEB.Name = "cmb_UP_WEB";
            this.cmb_UP_WEB.Size = new System.Drawing.Size(121, 23);
            this.cmb_UP_WEB.TabIndex = 32;
            // 
            // label137
            // 
            this.label137.AutoSize = true;
            this.label137.Location = new System.Drawing.Point(104, 130);
            this.label137.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(54, 15);
            this.label137.TabIndex = 31;
            this.label137.Text = "UP WEB:";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(1, 58);
            this.label47.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(158, 15);
            this.label47.TabIndex = 24;
            this.label47.Text = "REG_HOTMAIL_CHROME:";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(110, 96);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(47, 15);
            this.label48.TabIndex = 26;
            this.label48.Text = "VN/US:";
            // 
            // cmb_REGHOTMAIL
            // 
            this.cmb_REGHOTMAIL.FormattingEnabled = true;
            this.cmb_REGHOTMAIL.Location = new System.Drawing.Point(161, 55);
            this.cmb_REGHOTMAIL.Name = "cmb_REGHOTMAIL";
            this.cmb_REGHOTMAIL.Size = new System.Drawing.Size(141, 23);
            this.cmb_REGHOTMAIL.TabIndex = 23;
            // 
            // cmb_VN_US
            // 
            this.cmb_VN_US.FormattingEnabled = true;
            this.cmb_VN_US.Location = new System.Drawing.Point(161, 93);
            this.cmb_VN_US.Name = "cmb_VN_US";
            this.cmb_VN_US.Size = new System.Drawing.Size(141, 23);
            this.cmb_VN_US.TabIndex = 25;
            // 
            // tabPage24
            // 
            this.tabPage24.BackColor = System.Drawing.Color.Gray;
            this.tabPage24.Controls.Add(this.label225);
            this.tabPage24.Controls.Add(this.cmb_ramdom_nuoc);
            this.tabPage24.Controls.Add(this.cmb_NO_RANDOM);
            this.tabPage24.Controls.Add(this.label215);
            this.tabPage24.Controls.Add(this.cmb_Random4_17);
            this.tabPage24.Controls.Add(this.label214);
            this.tabPage24.Controls.Add(this.cmb_dinh_dang_ten);
            this.tabPage24.Controls.Add(this.label213);
            this.tabPage24.Location = new System.Drawing.Point(4, 24);
            this.tabPage24.Name = "tabPage24";
            this.tabPage24.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage24.Size = new System.Drawing.Size(448, 302);
            this.tabPage24.TabIndex = 1;
            this.tabPage24.Text = "CÀI ĐẶT TÊN REG IG";
            // 
            // label225
            // 
            this.label225.AutoSize = true;
            this.label225.Location = new System.Drawing.Point(15, 125);
            this.label225.Name = "label225";
            this.label225.Size = new System.Drawing.Size(196, 15);
            this.label225.TabIndex = 48;
            this.label225.Text = "RANDOM_VN_INDIA_THAI_HAN:";
            // 
            // cmb_ramdom_nuoc
            // 
            this.cmb_ramdom_nuoc.FormattingEnabled = true;
            this.cmb_ramdom_nuoc.Location = new System.Drawing.Point(12, 149);
            this.cmb_ramdom_nuoc.Name = "cmb_ramdom_nuoc";
            this.cmb_ramdom_nuoc.Size = new System.Drawing.Size(104, 23);
            this.cmb_ramdom_nuoc.TabIndex = 47;
            // 
            // cmb_NO_RANDOM
            // 
            this.cmb_NO_RANDOM.FormattingEnabled = true;
            this.cmb_NO_RANDOM.Location = new System.Drawing.Point(169, 88);
            this.cmb_NO_RANDOM.Name = "cmb_NO_RANDOM";
            this.cmb_NO_RANDOM.Size = new System.Drawing.Size(104, 23);
            this.cmb_NO_RANDOM.TabIndex = 46;
            // 
            // label215
            // 
            this.label215.AutoSize = true;
            this.label215.Location = new System.Drawing.Point(169, 67);
            this.label215.Name = "label215";
            this.label215.Size = new System.Drawing.Size(91, 15);
            this.label215.TabIndex = 45;
            this.label215.Text = "NO_RANDOM:";
            // 
            // cmb_Random4_17
            // 
            this.cmb_Random4_17.FormattingEnabled = true;
            this.cmb_Random4_17.Location = new System.Drawing.Point(12, 88);
            this.cmb_Random4_17.Name = "cmb_Random4_17";
            this.cmb_Random4_17.Size = new System.Drawing.Size(104, 23);
            this.cmb_Random4_17.TabIndex = 44;
            // 
            // label214
            // 
            this.label214.AutoSize = true;
            this.label214.Location = new System.Drawing.Point(9, 67);
            this.label214.Name = "label214";
            this.label214.Size = new System.Drawing.Size(96, 15);
            this.label214.TabIndex = 43;
            this.label214.Text = "RANDOM_4_17:";
            // 
            // cmb_dinh_dang_ten
            // 
            this.cmb_dinh_dang_ten.FormattingEnabled = true;
            this.cmb_dinh_dang_ten.Location = new System.Drawing.Point(12, 32);
            this.cmb_dinh_dang_ten.Name = "cmb_dinh_dang_ten";
            this.cmb_dinh_dang_ten.Size = new System.Drawing.Size(427, 23);
            this.cmb_dinh_dang_ten.TabIndex = 42;
            // 
            // label213
            // 
            this.label213.AutoSize = true;
            this.label213.Location = new System.Drawing.Point(9, 14);
            this.label213.Name = "label213";
            this.label213.Size = new System.Drawing.Size(107, 15);
            this.label213.TabIndex = 41;
            this.label213.Text = "ĐỊNH DẠNG TÊN:";
            // 
            // tabPage25
            // 
            this.tabPage25.BackColor = System.Drawing.Color.Gray;
            this.tabPage25.Controls.Add(this.cmn_doc_link_hotmail_vanha);
            this.tabPage25.Controls.Add(this.label224);
            this.tabPage25.Location = new System.Drawing.Point(4, 24);
            this.tabPage25.Name = "tabPage25";
            this.tabPage25.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage25.Size = new System.Drawing.Size(448, 302);
            this.tabPage25.TabIndex = 2;
            this.tabPage25.Text = "ĐỌC LINK ĐA LUỒNG";
            // 
            // cmn_doc_link_hotmail_vanha
            // 
            this.cmn_doc_link_hotmail_vanha.FormattingEnabled = true;
            this.cmn_doc_link_hotmail_vanha.Location = new System.Drawing.Point(180, 17);
            this.cmn_doc_link_hotmail_vanha.Name = "cmn_doc_link_hotmail_vanha";
            this.cmn_doc_link_hotmail_vanha.Size = new System.Drawing.Size(141, 23);
            this.cmn_doc_link_hotmail_vanha.TabIndex = 89;
            // 
            // label224
            // 
            this.label224.AutoSize = true;
            this.label224.Location = new System.Drawing.Point(17, 25);
            this.label224.Name = "label224";
            this.label224.Size = new System.Drawing.Size(154, 15);
            this.label224.TabIndex = 89;
            this.label224.Text = "ĐỌC LINK LẤY THEO VH:";
            // 
            // tabPage26
            // 
            this.tabPage26.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.tabPage26.Controls.Add(this.label228);
            this.tabPage26.Controls.Add(this.cmb_nameMACDINH);
            this.tabPage26.Controls.Add(this.cmb_Domain_RANDOM);
            this.tabPage26.Controls.Add(this.label227);
            this.tabPage26.Controls.Add(this.label226);
            this.tabPage26.Controls.Add(this.cmb_domain_moakt);
            this.tabPage26.ForeColor = System.Drawing.SystemColors.Desktop;
            this.tabPage26.Location = new System.Drawing.Point(4, 24);
            this.tabPage26.Name = "tabPage26";
            this.tabPage26.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage26.Size = new System.Drawing.Size(448, 302);
            this.tabPage26.TabIndex = 3;
            this.tabPage26.Text = "MAIL MOAKT";
            // 
            // label228
            // 
            this.label228.AutoSize = true;
            this.label228.Location = new System.Drawing.Point(17, 72);
            this.label228.Name = "label228";
            this.label228.Size = new System.Drawing.Size(152, 15);
            this.label228.TabIndex = 58;
            this.label228.Text = "Name_MẶC ĐỊNH_moakt :";
            // 
            // cmb_nameMACDINH
            // 
            this.cmb_nameMACDINH.FormattingEnabled = true;
            this.cmb_nameMACDINH.Location = new System.Drawing.Point(20, 93);
            this.cmb_nameMACDINH.Name = "cmb_nameMACDINH";
            this.cmb_nameMACDINH.Size = new System.Drawing.Size(159, 23);
            this.cmb_nameMACDINH.TabIndex = 57;
            // 
            // cmb_Domain_RANDOM
            // 
            this.cmb_Domain_RANDOM.FormattingEnabled = true;
            this.cmb_Domain_RANDOM.Location = new System.Drawing.Point(272, 40);
            this.cmb_Domain_RANDOM.Name = "cmb_Domain_RANDOM";
            this.cmb_Domain_RANDOM.Size = new System.Drawing.Size(159, 23);
            this.cmb_Domain_RANDOM.TabIndex = 56;
            // 
            // label227
            // 
            this.label227.AutoSize = true;
            this.label227.Location = new System.Drawing.Point(275, 19);
            this.label227.Name = "label227";
            this.label227.Size = new System.Drawing.Size(156, 15);
            this.label227.TabIndex = 55;
            this.label227.Text = "Domain_moakt_RANDOM :";
            // 
            // label226
            // 
            this.label226.AutoSize = true;
            this.label226.Location = new System.Drawing.Point(17, 19);
            this.label226.Name = "label226";
            this.label226.Size = new System.Drawing.Size(95, 15);
            this.label226.TabIndex = 54;
            this.label226.Text = "Domain_moakt :";
            // 
            // cmb_domain_moakt
            // 
            this.cmb_domain_moakt.FormattingEnabled = true;
            this.cmb_domain_moakt.Location = new System.Drawing.Point(20, 40);
            this.cmb_domain_moakt.Name = "cmb_domain_moakt";
            this.cmb_domain_moakt.Size = new System.Drawing.Size(159, 23);
            this.cmb_domain_moakt.TabIndex = 53;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.numericUpDown10);
            this.groupBox8.Controls.Add(this.label230);
            this.groupBox8.Controls.Add(this.label200);
            this.groupBox8.Controls.Add(this.cmb_bo_DIE);
            this.groupBox8.Controls.Add(this.cmb_TTK_BM350);
            this.groupBox8.Controls.Add(this.cmb_TTK_BM50);
            this.groupBox8.Controls.Add(this.label177);
            this.groupBox8.Controls.Add(this.label176);
            this.groupBox8.Controls.Add(this.label151);
            this.groupBox8.Controls.Add(this.numericUpDown5_delay_regbmig);
            this.groupBox8.Controls.Add(this.label150);
            this.groupBox8.Controls.Add(this.num_tao_5bm);
            this.groupBox8.Controls.Add(this.cmb_Tao_5BM_IG);
            this.groupBox8.Controls.Add(this.label149);
            this.groupBox8.Controls.Add(this.label120);
            this.groupBox8.Controls.Add(this.label119);
            this.groupBox8.Controls.Add(this.numericUpDown4);
            this.groupBox8.Controls.Add(this.numericUpDown3);
            this.groupBox8.Controls.Add(this.cmb_TTKQC_BM_IG);
            this.groupBox8.Controls.Add(this.label110);
            this.groupBox8.Controls.Add(this.cmb_REG_BM_IG1);
            this.groupBox8.Controls.Add(this.label109);
            this.groupBox8.Controls.Add(this.label108);
            this.groupBox8.Controls.Add(this.cmb_2FA_IG);
            this.groupBox8.Controls.Add(this.label76);
            this.groupBox8.Controls.Add(this.label77);
            this.groupBox8.Controls.Add(this.cmb_ON_OFF_2FAIG);
            this.groupBox8.Location = new System.Drawing.Point(22, 342);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(440, 340);
            this.groupBox8.TabIndex = 29;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "2FA IG";
            // 
            // numericUpDown10
            // 
            this.numericUpDown10.Location = new System.Drawing.Point(310, 182);
            this.numericUpDown10.Name = "numericUpDown10";
            this.numericUpDown10.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown10.TabIndex = 59;
            this.numericUpDown10.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // label230
            // 
            this.label230.AutoSize = true;
            this.label230.Location = new System.Drawing.Point(269, 167);
            this.label230.Name = "label230";
            this.label230.Size = new System.Drawing.Size(164, 15);
            this.label230.TabIndex = 58;
            this.label230.Text = "LUỒNG CHẠY REG BM2025:";
            // 
            // label200
            // 
            this.label200.AutoSize = true;
            this.label200.Location = new System.Drawing.Point(326, 69);
            this.label200.Name = "label200";
            this.label200.Size = new System.Drawing.Size(88, 15);
            this.label200.TabIndex = 57;
            this.label200.Text = "REG 5 BỎ DIE:";
            // 
            // cmb_bo_DIE
            // 
            this.cmb_bo_DIE.FormattingEnabled = true;
            this.cmb_bo_DIE.Location = new System.Drawing.Point(329, 95);
            this.cmb_bo_DIE.Name = "cmb_bo_DIE";
            this.cmb_bo_DIE.Size = new System.Drawing.Size(104, 23);
            this.cmb_bo_DIE.TabIndex = 56;
            // 
            // cmb_TTK_BM350
            // 
            this.cmb_TTK_BM350.FormattingEnabled = true;
            this.cmb_TTK_BM350.Location = new System.Drawing.Point(352, 239);
            this.cmb_TTK_BM350.Name = "cmb_TTK_BM350";
            this.cmb_TTK_BM350.Size = new System.Drawing.Size(81, 23);
            this.cmb_TTK_BM350.TabIndex = 55;
            // 
            // cmb_TTK_BM50
            // 
            this.cmb_TTK_BM50.FormattingEnabled = true;
            this.cmb_TTK_BM50.Location = new System.Drawing.Point(352, 209);
            this.cmb_TTK_BM50.Name = "cmb_TTK_BM50";
            this.cmb_TTK_BM50.Size = new System.Drawing.Size(81, 23);
            this.cmb_TTK_BM50.TabIndex = 54;
            // 
            // label177
            // 
            this.label177.AutoSize = true;
            this.label177.Location = new System.Drawing.Point(237, 242);
            this.label177.Name = "label177";
            this.label177.Size = new System.Drawing.Size(97, 15);
            this.label177.TabIndex = 53;
            this.label177.Text = "TẠO TKQC 350:";
            // 
            // label176
            // 
            this.label176.AutoSize = true;
            this.label176.Location = new System.Drawing.Point(237, 217);
            this.label176.Name = "label176";
            this.label176.Size = new System.Drawing.Size(113, 15);
            this.label176.TabIndex = 52;
            this.label176.Text = "TẠO TKQC BM 50:";
            // 
            // label151
            // 
            this.label151.AutoSize = true;
            this.label151.Location = new System.Drawing.Point(19, 193);
            this.label151.Name = "label151";
            this.label151.Size = new System.Drawing.Size(69, 15);
            this.label151.TabIndex = 51;
            this.label151.Text = "Delay REG:";
            // 
            // numericUpDown5_delay_regbmig
            // 
            this.numericUpDown5_delay_regbmig.Location = new System.Drawing.Point(135, 193);
            this.numericUpDown5_delay_regbmig.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown5_delay_regbmig.Name = "numericUpDown5_delay_regbmig";
            this.numericUpDown5_delay_regbmig.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown5_delay_regbmig.TabIndex = 50;
            // 
            // label150
            // 
            this.label150.AutoSize = true;
            this.label150.Location = new System.Drawing.Point(37, 167);
            this.label150.Name = "label150";
            this.label150.Size = new System.Drawing.Size(48, 15);
            this.label150.TabIndex = 49;
            this.label150.Text = "for BM:";
            // 
            // num_tao_5bm
            // 
            this.num_tao_5bm.Location = new System.Drawing.Point(135, 161);
            this.num_tao_5bm.Name = "num_tao_5bm";
            this.num_tao_5bm.Size = new System.Drawing.Size(120, 21);
            this.num_tao_5bm.TabIndex = 48;
            this.num_tao_5bm.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // cmb_Tao_5BM_IG
            // 
            this.cmb_Tao_5BM_IG.FormattingEnabled = true;
            this.cmb_Tao_5BM_IG.Location = new System.Drawing.Point(131, 95);
            this.cmb_Tao_5BM_IG.Name = "cmb_Tao_5BM_IG";
            this.cmb_Tao_5BM_IG.Size = new System.Drawing.Size(141, 23);
            this.cmb_Tao_5BM_IG.TabIndex = 47;
            // 
            // label149
            // 
            this.label149.AutoSize = true;
            this.label149.Location = new System.Drawing.Point(15, 103);
            this.label149.Name = "label149";
            this.label149.Size = new System.Drawing.Size(84, 15);
            this.label149.TabIndex = 46;
            this.label149.Text = "REG BM 1/3/5:";
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Location = new System.Drawing.Point(15, 302);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(70, 15);
            this.label120.TabIndex = 45;
            this.label120.Text = "Delay TTK:";
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Location = new System.Drawing.Point(15, 270);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(46, 15);
            this.label119.TabIndex = 44;
            this.label119.Text = "for TK:";
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.Location = new System.Drawing.Point(131, 264);
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown4.TabIndex = 43;
            this.numericUpDown4.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Location = new System.Drawing.Point(131, 302);
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown3.TabIndex = 42;
            this.numericUpDown3.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // cmb_TTKQC_BM_IG
            // 
            this.cmb_TTKQC_BM_IG.FormattingEnabled = true;
            this.cmb_TTKQC_BM_IG.Location = new System.Drawing.Point(131, 226);
            this.cmb_TTKQC_BM_IG.Name = "cmb_TTKQC_BM_IG";
            this.cmb_TTKQC_BM_IG.Size = new System.Drawing.Size(81, 23);
            this.cmb_TTKQC_BM_IG.TabIndex = 32;
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(15, 234);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(76, 15);
            this.label110.TabIndex = 31;
            this.label110.Text = "TẠO TKQC:";
            // 
            // cmb_REG_BM_IG1
            // 
            this.cmb_REG_BM_IG1.FormattingEnabled = true;
            this.cmb_REG_BM_IG1.Location = new System.Drawing.Point(131, 126);
            this.cmb_REG_BM_IG1.Name = "cmb_REG_BM_IG1";
            this.cmb_REG_BM_IG1.Size = new System.Drawing.Size(141, 23);
            this.cmb_REG_BM_IG1.TabIndex = 30;
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(15, 134);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(57, 15);
            this.label109.TabIndex = 29;
            this.label109.Text = "REG BM:";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Location = new System.Drawing.Point(15, 64);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(110, 15);
            this.label108.TabIndex = 28;
            this.label108.Text = "API/Auto selenium:";
            // 
            // cmb_2FA_IG
            // 
            this.cmb_2FA_IG.FormattingEnabled = true;
            this.cmb_2FA_IG.Location = new System.Drawing.Point(131, 61);
            this.cmb_2FA_IG.Name = "cmb_2FA_IG";
            this.cmb_2FA_IG.Size = new System.Drawing.Size(141, 23);
            this.cmb_2FA_IG.TabIndex = 27;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(15, 26);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(57, 15);
            this.label76.TabIndex = 24;
            this.label76.Text = "ON/OFF:";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(15, 85);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(0, 15);
            this.label77.TabIndex = 26;
            // 
            // cmb_ON_OFF_2FAIG
            // 
            this.cmb_ON_OFF_2FAIG.FormattingEnabled = true;
            this.cmb_ON_OFF_2FAIG.Location = new System.Drawing.Point(131, 23);
            this.cmb_ON_OFF_2FAIG.Name = "cmb_ON_OFF_2FAIG";
            this.cmb_ON_OFF_2FAIG.Size = new System.Drawing.Size(141, 23);
            this.cmb_ON_OFF_2FAIG.TabIndex = 23;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.delay_doc_hotmail_1);
            this.groupBox4.Controls.Add(this.label222);
            this.groupBox4.Controls.Add(this.groupBox14);
            this.groupBox4.Controls.Add(this.cmb_doc_luon_link_mail_ao);
            this.groupBox4.Controls.Add(this.label181);
            this.groupBox4.Controls.Add(this.btn_update_mail);
            this.groupBox4.Controls.Add(this.label168);
            this.groupBox4.Controls.Add(this.richTextBox1);
            this.groupBox4.Controls.Add(this.label167);
            this.groupBox4.Controls.Add(this.n_slink_share_them);
            this.groupBox4.Controls.Add(this.label163);
            this.groupBox4.Controls.Add(this.delay_tatbatsangtao);
            this.groupBox4.Controls.Add(this.cmb_sharebmt6_50);
            this.groupBox4.Controls.Add(this.label162);
            this.groupBox4.Controls.Add(this.label161);
            this.groupBox4.Controls.Add(this.cmb_sharebmt6_350);
            this.groupBox4.Controls.Add(this.label160);
            this.groupBox4.Controls.Add(this.label159);
            this.groupBox4.Controls.Add(this.label158);
            this.groupBox4.Controls.Add(this.nam_rip);
            this.groupBox4.Controls.Add(this.thang_rip);
            this.groupBox4.Controls.Add(this.ngay_rip);
            this.groupBox4.Controls.Add(this.cmb_RIPIG);
            this.groupBox4.Controls.Add(this.label157);
            this.groupBox4.Controls.Add(this.cmb_BMT6);
            this.groupBox4.Controls.Add(this.label156);
            this.groupBox4.Controls.Add(this.cmb_color350);
            this.groupBox4.Controls.Add(this.label155);
            this.groupBox4.Controls.Add(this.cmb_on_off_chrome);
            this.groupBox4.Controls.Add(this.label154);
            this.groupBox4.Controls.Add(this.label153);
            this.groupBox4.Controls.Add(this.numericUpDown5_slcheck_bm350);
            this.groupBox4.Controls.Add(this.cmb_chishare_bm350);
            this.groupBox4.Controls.Add(this.label152);
            this.groupBox4.Controls.Add(this.cmb_LOAI_LINK);
            this.groupBox4.Controls.Add(this.label142);
            this.groupBox4.Controls.Add(this.label133);
            this.groupBox4.Controls.Add(this.rtb_hotmail_BM350);
            this.groupBox4.Controls.Add(this.label88);
            this.groupBox4.Controls.Add(this.cmb_DOC_LINK_MAX);
            this.groupBox4.Controls.Add(this.label87);
            this.groupBox4.Controls.Add(this.rtb_BMIII);
            this.groupBox4.Controls.Add(this.label86);
            this.groupBox4.Controls.Add(this.cmb_CHECK_ADMIN);
            this.groupBox4.Controls.Add(this.label85);
            this.groupBox4.Controls.Add(this.delay_check_admin);
            this.groupBox4.Controls.Add(this.label84);
            this.groupBox4.Controls.Add(this.rtb_Link_BM350_IG);
            this.groupBox4.Controls.Add(this.cmb_TAT_BAT_SANG_TAO);
            this.groupBox4.Controls.Add(this.label83);
            this.groupBox4.Controls.Add(this.cmb_AN_CHROME);
            this.groupBox4.Controls.Add(this.label82);
            this.groupBox4.Controls.Add(this.label81);
            this.groupBox4.Controls.Add(this.cmb_MAIL_SHARE_BM_IG);
            this.groupBox4.Controls.Add(this.label80);
            this.groupBox4.Controls.Add(this.rtb_hotmail);
            this.groupBox4.Controls.Add(this.cmb_Admin_BM);
            this.groupBox4.Controls.Add(this.label79);
            this.groupBox4.Controls.Add(this.label78);
            this.groupBox4.Controls.Add(this.rtb_Link_BM_IG);
            this.groupBox4.Controls.Add(this.label49);
            this.groupBox4.Controls.Add(this.label50);
            this.groupBox4.Controls.Add(this.cmb_LOGIN_IG);
            this.groupBox4.Location = new System.Drawing.Point(481, 35);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1280, 630);
            this.groupBox4.TabIndex = 28;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "v";
            // 
            // delay_doc_hotmail_1
            // 
            this.delay_doc_hotmail_1.Location = new System.Drawing.Point(829, 205);
            this.delay_doc_hotmail_1.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.delay_doc_hotmail_1.Name = "delay_doc_hotmail_1";
            this.delay_doc_hotmail_1.Size = new System.Drawing.Size(120, 21);
            this.delay_doc_hotmail_1.TabIndex = 88;
            this.delay_doc_hotmail_1.Value = new decimal(new int[] {
            90,
            0,
            0,
            0});
            // 
            // label222
            // 
            this.label222.AutoSize = true;
            this.label222.Location = new System.Drawing.Point(716, 208);
            this.label222.Name = "label222";
            this.label222.Size = new System.Drawing.Size(109, 15);
            this.label222.TabIndex = 87;
            this.label222.Text = "delay_doc_hotmail:";
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.cmb_Tao_1_5);
            this.groupBox14.Controls.Add(this.label205);
            this.groupBox14.Controls.Add(this.cmb_kick_BM3_IG);
            this.groupBox14.Controls.Add(this.label198);
            this.groupBox14.Location = new System.Drawing.Point(1061, 376);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(200, 193);
            this.groupBox14.TabIndex = 86;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "BM3";
            // 
            // cmb_Tao_1_5
            // 
            this.cmb_Tao_1_5.FormattingEnabled = true;
            this.cmb_Tao_1_5.Location = new System.Drawing.Point(53, 83);
            this.cmb_Tao_1_5.Name = "cmb_Tao_1_5";
            this.cmb_Tao_1_5.Size = new System.Drawing.Size(141, 23);
            this.cmb_Tao_1_5.TabIndex = 87;
            // 
            // label205
            // 
            this.label205.AutoSize = true;
            this.label205.Location = new System.Drawing.Point(6, 65);
            this.label205.Name = "label205";
            this.label205.Size = new System.Drawing.Size(92, 15);
            this.label205.TabIndex = 86;
            this.label205.Text = "KICK 3 TẠO 1 :";
            // 
            // cmb_kick_BM3_IG
            // 
            this.cmb_kick_BM3_IG.FormattingEnabled = true;
            this.cmb_kick_BM3_IG.Location = new System.Drawing.Point(51, 26);
            this.cmb_kick_BM3_IG.Name = "cmb_kick_BM3_IG";
            this.cmb_kick_BM3_IG.Size = new System.Drawing.Size(141, 23);
            this.cmb_kick_BM3_IG.TabIndex = 84;
            // 
            // label198
            // 
            this.label198.AutoSize = true;
            this.label198.Location = new System.Drawing.Point(6, 29);
            this.label198.Name = "label198";
            this.label198.Size = new System.Drawing.Size(42, 15);
            this.label198.TabIndex = 85;
            this.label198.Text = "BM 3 :";
            // 
            // cmb_doc_luon_link_mail_ao
            // 
            this.cmb_doc_luon_link_mail_ao.FormattingEnabled = true;
            this.cmb_doc_luon_link_mail_ao.Location = new System.Drawing.Point(540, 205);
            this.cmb_doc_luon_link_mail_ao.Name = "cmb_doc_luon_link_mail_ao";
            this.cmb_doc_luon_link_mail_ao.Size = new System.Drawing.Size(141, 23);
            this.cmb_doc_luon_link_mail_ao.TabIndex = 83;
            // 
            // label181
            // 
            this.label181.AutoSize = true;
            this.label181.Location = new System.Drawing.Point(373, 208);
            this.label181.Name = "label181";
            this.label181.Size = new System.Drawing.Size(161, 15);
            this.label181.TabIndex = 82;
            this.label181.Text = "ĐỌC LUÔN LINK MAIL ẢO:";
            // 
            // btn_update_mail
            // 
            this.btn_update_mail.BackColor = System.Drawing.SystemColors.Highlight;
            this.btn_update_mail.Location = new System.Drawing.Point(260, 90);
            this.btn_update_mail.Name = "btn_update_mail";
            this.btn_update_mail.Size = new System.Drawing.Size(75, 28);
            this.btn_update_mail.TabIndex = 81;
            this.btn_update_mail.Text = "UPMAIL";
            this.btn_update_mail.UseVisualStyleBackColor = false;
            this.btn_update_mail.Click += new System.EventHandler(this.btn_update_mail_Click);
            // 
            // label168
            // 
            this.label168.AutoSize = true;
            this.label168.Location = new System.Drawing.Point(755, 244);
            this.label168.Name = "label168";
            this.label168.Size = new System.Drawing.Size(117, 15);
            this.label168.TabIndex = 80;
            this.label168.Text = "HOTMAIL 10 LINK :";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(758, 263);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(305, 57);
            this.richTextBox1.TabIndex = 79;
            this.richTextBox1.Text = "";
            // 
            // label167
            // 
            this.label167.AutoSize = true;
            this.label167.Location = new System.Drawing.Point(6, 120);
            this.label167.Name = "label167";
            this.label167.Size = new System.Drawing.Size(113, 15);
            this.label167.TabIndex = 78;
            this.label167.Text = "Số Link Cần Share:";
            // 
            // n_slink_share_them
            // 
            this.n_slink_share_them.Location = new System.Drawing.Point(125, 118);
            this.n_slink_share_them.Name = "n_slink_share_them";
            this.n_slink_share_them.Size = new System.Drawing.Size(120, 21);
            this.n_slink_share_them.TabIndex = 77;
            this.n_slink_share_them.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label163
            // 
            this.label163.AutoSize = true;
            this.label163.Location = new System.Drawing.Point(895, 189);
            this.label163.Name = "label163";
            this.label163.Size = new System.Drawing.Size(168, 15);
            this.label163.TabIndex = 76;
            this.label163.Text = "DELAY TAT BAT SANG TAO :";
            // 
            // delay_tatbatsangtao
            // 
            this.delay_tatbatsangtao.Location = new System.Drawing.Point(1067, 187);
            this.delay_tatbatsangtao.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.delay_tatbatsangtao.Name = "delay_tatbatsangtao";
            this.delay_tatbatsangtao.Size = new System.Drawing.Size(63, 21);
            this.delay_tatbatsangtao.TabIndex = 75;
            this.delay_tatbatsangtao.Value = new decimal(new int[] {
            300,
            0,
            0,
            0});
            // 
            // cmb_sharebmt6_50
            // 
            this.cmb_sharebmt6_50.FormattingEnabled = true;
            this.cmb_sharebmt6_50.Location = new System.Drawing.Point(1067, 156);
            this.cmb_sharebmt6_50.Name = "cmb_sharebmt6_50";
            this.cmb_sharebmt6_50.Size = new System.Drawing.Size(141, 23);
            this.cmb_sharebmt6_50.TabIndex = 74;
            // 
            // label162
            // 
            this.label162.AutoSize = true;
            this.label162.Location = new System.Drawing.Point(961, 160);
            this.label162.Name = "label162";
            this.label162.Size = new System.Drawing.Size(102, 15);
            this.label162.TabIndex = 73;
            this.label162.Text = "SHARET6/BM50 :";
            // 
            // label161
            // 
            this.label161.AutoSize = true;
            this.label161.Location = new System.Drawing.Point(955, 130);
            this.label161.Name = "label161";
            this.label161.Size = new System.Drawing.Size(108, 15);
            this.label161.TabIndex = 72;
            this.label161.Text = "SHARET6/BM350 :";
            // 
            // cmb_sharebmt6_350
            // 
            this.cmb_sharebmt6_350.FormattingEnabled = true;
            this.cmb_sharebmt6_350.Location = new System.Drawing.Point(1067, 127);
            this.cmb_sharebmt6_350.Name = "cmb_sharebmt6_350";
            this.cmb_sharebmt6_350.Size = new System.Drawing.Size(141, 23);
            this.cmb_sharebmt6_350.TabIndex = 71;
            // 
            // label160
            // 
            this.label160.AutoSize = true;
            this.label160.Location = new System.Drawing.Point(1142, 87);
            this.label160.Name = "label160";
            this.label160.Size = new System.Drawing.Size(20, 15);
            this.label160.TabIndex = 70;
            this.label160.Text = "N:";
            // 
            // label159
            // 
            this.label159.AutoSize = true;
            this.label159.Location = new System.Drawing.Point(1058, 87);
            this.label159.Name = "label159";
            this.label159.Size = new System.Drawing.Size(28, 15);
            this.label159.TabIndex = 69;
            this.label159.Text = "TH:";
            // 
            // label158
            // 
            this.label158.AutoSize = true;
            this.label158.Location = new System.Drawing.Point(979, 88);
            this.label158.Name = "label158";
            this.label158.Size = new System.Drawing.Size(29, 15);
            this.label158.TabIndex = 68;
            this.label158.Text = "NG:";
            // 
            // nam_rip
            // 
            this.nam_rip.Location = new System.Drawing.Point(1163, 84);
            this.nam_rip.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nam_rip.Name = "nam_rip";
            this.nam_rip.Size = new System.Drawing.Size(54, 21);
            this.nam_rip.TabIndex = 67;
            this.nam_rip.Value = new decimal(new int[] {
            2017,
            0,
            0,
            0});
            // 
            // thang_rip
            // 
            this.thang_rip.Location = new System.Drawing.Point(1092, 84);
            this.thang_rip.Name = "thang_rip";
            this.thang_rip.Size = new System.Drawing.Size(38, 21);
            this.thang_rip.TabIndex = 66;
            this.thang_rip.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // ngay_rip
            // 
            this.ngay_rip.Location = new System.Drawing.Point(1014, 84);
            this.ngay_rip.Name = "ngay_rip";
            this.ngay_rip.Size = new System.Drawing.Size(38, 21);
            this.ngay_rip.TabIndex = 65;
            this.ngay_rip.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // cmb_RIPIG
            // 
            this.cmb_RIPIG.FormattingEnabled = true;
            this.cmb_RIPIG.Location = new System.Drawing.Point(1067, 51);
            this.cmb_RIPIG.Name = "cmb_RIPIG";
            this.cmb_RIPIG.Size = new System.Drawing.Size(141, 23);
            this.cmb_RIPIG.TabIndex = 64;
            // 
            // label157
            // 
            this.label157.AutoSize = true;
            this.label157.Location = new System.Drawing.Point(989, 49);
            this.label157.Name = "label157";
            this.label157.Size = new System.Drawing.Size(43, 15);
            this.label157.TabIndex = 63;
            this.label157.Text = "RIPIG:";
            // 
            // cmb_BMT6
            // 
            this.cmb_BMT6.FormattingEnabled = true;
            this.cmb_BMT6.Location = new System.Drawing.Point(1067, 20);
            this.cmb_BMT6.Name = "cmb_BMT6";
            this.cmb_BMT6.Size = new System.Drawing.Size(141, 23);
            this.cmb_BMT6.TabIndex = 62;
            // 
            // label156
            // 
            this.label156.AutoSize = true;
            this.label156.Location = new System.Drawing.Point(989, 23);
            this.label156.Name = "label156";
            this.label156.Size = new System.Drawing.Size(44, 15);
            this.label156.TabIndex = 61;
            this.label156.Text = "BMT6:";
            // 
            // cmb_color350
            // 
            this.cmb_color350.FormattingEnabled = true;
            this.cmb_color350.Location = new System.Drawing.Point(808, 127);
            this.cmb_color350.Name = "cmb_color350";
            this.cmb_color350.Size = new System.Drawing.Size(141, 23);
            this.cmb_color350.TabIndex = 60;
            // 
            // label155
            // 
            this.label155.AutoSize = true;
            this.label155.Location = new System.Drawing.Point(653, 127);
            this.label155.Name = "label155";
            this.label155.Size = new System.Drawing.Size(62, 15);
            this.label155.TabIndex = 59;
            this.label155.Text = "Color 350:";
            // 
            // cmb_on_off_chrome
            // 
            this.cmb_on_off_chrome.FormattingEnabled = true;
            this.cmb_on_off_chrome.Location = new System.Drawing.Point(808, 90);
            this.cmb_on_off_chrome.Name = "cmb_on_off_chrome";
            this.cmb_on_off_chrome.Size = new System.Drawing.Size(141, 23);
            this.cmb_on_off_chrome.TabIndex = 58;
            // 
            // label154
            // 
            this.label154.AutoSize = true;
            this.label154.Location = new System.Drawing.Point(653, 93);
            this.label154.Name = "label154";
            this.label154.Size = new System.Drawing.Size(114, 15);
            this.label154.TabIndex = 57;
            this.label154.Text = "ON/OFF CHROME:";
            // 
            // label153
            // 
            this.label153.AutoSize = true;
            this.label153.Location = new System.Drawing.Point(653, 55);
            this.label153.Name = "label153";
            this.label153.Size = new System.Drawing.Size(149, 15);
            this.label153.TabIndex = 56;
            this.label153.Text = "SLCHECK ADMINBM350:";
            // 
            // numericUpDown5_slcheck_bm350
            // 
            this.numericUpDown5_slcheck_bm350.Location = new System.Drawing.Point(808, 53);
            this.numericUpDown5_slcheck_bm350.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.numericUpDown5_slcheck_bm350.Name = "numericUpDown5_slcheck_bm350";
            this.numericUpDown5_slcheck_bm350.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown5_slcheck_bm350.TabIndex = 55;
            this.numericUpDown5_slcheck_bm350.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // cmb_chishare_bm350
            // 
            this.cmb_chishare_bm350.FormattingEnabled = true;
            this.cmb_chishare_bm350.Location = new System.Drawing.Point(756, 20);
            this.cmb_chishare_bm350.Name = "cmb_chishare_bm350";
            this.cmb_chishare_bm350.Size = new System.Drawing.Size(141, 23);
            this.cmb_chishare_bm350.TabIndex = 54;
            // 
            // label152
            // 
            this.label152.AutoSize = true;
            this.label152.Location = new System.Drawing.Point(653, 23);
            this.label152.Name = "label152";
            this.label152.Size = new System.Drawing.Size(72, 15);
            this.label152.TabIndex = 53;
            this.label152.Text = "SHARE350 :";
            // 
            // cmb_LOAI_LINK
            // 
            this.cmb_LOAI_LINK.FormattingEnabled = true;
            this.cmb_LOAI_LINK.Location = new System.Drawing.Point(468, 167);
            this.cmb_LOAI_LINK.Name = "cmb_LOAI_LINK";
            this.cmb_LOAI_LINK.Size = new System.Drawing.Size(359, 23);
            this.cmb_LOAI_LINK.TabIndex = 52;
            // 
            // label142
            // 
            this.label142.AutoSize = true;
            this.label142.Location = new System.Drawing.Point(390, 167);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(72, 15);
            this.label142.TabIndex = 51;
            this.label142.Text = "LOẠI LINK:";
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.Location = new System.Drawing.Point(413, 244);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(110, 15);
            this.label133.TabIndex = 50;
            this.label133.Text = "HOTMAIL BM350 :";
            // 
            // rtb_hotmail_BM350
            // 
            this.rtb_hotmail_BM350.Location = new System.Drawing.Point(417, 263);
            this.rtb_hotmail_BM350.Name = "rtb_hotmail_BM350";
            this.rtb_hotmail_BM350.Size = new System.Drawing.Size(305, 57);
            this.rtb_hotmail_BM350.TabIndex = 49;
            this.rtb_hotmail_BM350.Text = "";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(365, 133);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(101, 15);
            this.label88.TabIndex = 48;
            this.label88.Text = "ĐỌC LINK MAX:";
            // 
            // cmb_DOC_LINK_MAX
            // 
            this.cmb_DOC_LINK_MAX.FormattingEnabled = true;
            this.cmb_DOC_LINK_MAX.Location = new System.Drawing.Point(468, 130);
            this.cmb_DOC_LINK_MAX.Name = "cmb_DOC_LINK_MAX";
            this.cmb_DOC_LINK_MAX.Size = new System.Drawing.Size(141, 23);
            this.cmb_DOC_LINK_MAX.TabIndex = 47;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(716, 344);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(101, 15);
            this.label87.TabIndex = 46;
            this.label87.Text = "LINK BM THỨ 3:";
            // 
            // rtb_BMIII
            // 
            this.rtb_BMIII.Location = new System.Drawing.Point(719, 371);
            this.rtb_BMIII.Name = "rtb_BMIII";
            this.rtb_BMIII.Size = new System.Drawing.Size(305, 195);
            this.rtb_BMIII.TabIndex = 45;
            this.rtb_BMIII.Text = "";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(365, 87);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(97, 15);
            this.label86.TabIndex = 44;
            this.label86.Text = "CHECK ADMIN:";
            // 
            // cmb_CHECK_ADMIN
            // 
            this.cmb_CHECK_ADMIN.FormattingEnabled = true;
            this.cmb_CHECK_ADMIN.Location = new System.Drawing.Point(468, 85);
            this.cmb_CHECK_ADMIN.Name = "cmb_CHECK_ADMIN";
            this.cmb_CHECK_ADMIN.Size = new System.Drawing.Size(141, 23);
            this.cmb_CHECK_ADMIN.TabIndex = 43;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(394, 23);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(157, 15);
            this.label85.TabIndex = 42;
            this.label85.Text = "Delay Check ADMIN BM(s):";
            // 
            // delay_check_admin
            // 
            this.delay_check_admin.Location = new System.Drawing.Point(468, 41);
            this.delay_check_admin.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.delay_check_admin.Name = "delay_check_admin";
            this.delay_check_admin.Size = new System.Drawing.Size(120, 21);
            this.delay_check_admin.TabIndex = 41;
            this.delay_check_admin.Value = new decimal(new int[] {
            40,
            0,
            0,
            0});
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(394, 344);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(80, 15);
            this.label84.TabIndex = 40;
            this.label84.Text = "LINK BM350:";
            // 
            // rtb_Link_BM350_IG
            // 
            this.rtb_Link_BM350_IG.Location = new System.Drawing.Point(397, 371);
            this.rtb_Link_BM350_IG.Name = "rtb_Link_BM350_IG";
            this.rtb_Link_BM350_IG.Size = new System.Drawing.Size(305, 195);
            this.rtb_Link_BM350_IG.TabIndex = 39;
            this.rtb_Link_BM350_IG.Text = "";
            // 
            // cmb_TAT_BAT_SANG_TAO
            // 
            this.cmb_TAT_BAT_SANG_TAO.FormattingEnabled = true;
            this.cmb_TAT_BAT_SANG_TAO.Location = new System.Drawing.Point(93, 205);
            this.cmb_TAT_BAT_SANG_TAO.Name = "cmb_TAT_BAT_SANG_TAO";
            this.cmb_TAT_BAT_SANG_TAO.Size = new System.Drawing.Size(141, 23);
            this.cmb_TAT_BAT_SANG_TAO.TabIndex = 38;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(6, 187);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(189, 15);
            this.label83.TabIndex = 37;
            this.label83.Text = "TẮT BẬT SÁNG TẠO TỰ ĐỘNG:";
            // 
            // cmb_AN_CHROME
            // 
            this.cmb_AN_CHROME.FormattingEnabled = true;
            this.cmb_AN_CHROME.Location = new System.Drawing.Point(93, 145);
            this.cmb_AN_CHROME.Name = "cmb_AN_CHROME";
            this.cmb_AN_CHROME.Size = new System.Drawing.Size(141, 23);
            this.cmb_AN_CHROME.TabIndex = 36;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(6, 148);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(85, 15);
            this.label82.TabIndex = 35;
            this.label82.Text = "ẨN CHROME:";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(6, 95);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(81, 15);
            this.label81.TabIndex = 34;
            this.label81.Text = "CHỌN MAIL:";
            // 
            // cmb_MAIL_SHARE_BM_IG
            // 
            this.cmb_MAIL_SHARE_BM_IG.FormattingEnabled = true;
            this.cmb_MAIL_SHARE_BM_IG.Location = new System.Drawing.Point(93, 92);
            this.cmb_MAIL_SHARE_BM_IG.Name = "cmb_MAIL_SHARE_BM_IG";
            this.cmb_MAIL_SHARE_BM_IG.Size = new System.Drawing.Size(141, 23);
            this.cmb_MAIL_SHARE_BM_IG.TabIndex = 33;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(2, 245);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(163, 15);
            this.label80.TabIndex = 32;
            this.label80.Text = "HOTMAIL BM50-BM THỨ 3:";
            // 
            // rtb_hotmail
            // 
            this.rtb_hotmail.Location = new System.Drawing.Point(69, 263);
            this.rtb_hotmail.Name = "rtb_hotmail";
            this.rtb_hotmail.Size = new System.Drawing.Size(305, 57);
            this.rtb_hotmail.TabIndex = 31;
            this.rtb_hotmail.Text = "";
            // 
            // cmb_Admin_BM
            // 
            this.cmb_Admin_BM.FormattingEnabled = true;
            this.cmb_Admin_BM.Location = new System.Drawing.Point(64, 59);
            this.cmb_Admin_BM.Name = "cmb_Admin_BM";
            this.cmb_Admin_BM.Size = new System.Drawing.Size(141, 23);
            this.cmb_Admin_BM.TabIndex = 30;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(15, 62);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(53, 15);
            this.label79.TabIndex = 29;
            this.label79.Text = "QUYỀN:";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(8, 353);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(74, 15);
            this.label78.TabIndex = 28;
            this.label78.Text = "LINK BM50:";
            // 
            // rtb_Link_BM_IG
            // 
            this.rtb_Link_BM_IG.Location = new System.Drawing.Point(69, 371);
            this.rtb_Link_BM_IG.Name = "rtb_Link_BM_IG";
            this.rtb_Link_BM_IG.Size = new System.Drawing.Size(305, 195);
            this.rtb_Link_BM_IG.TabIndex = 27;
            this.rtb_Link_BM_IG.Text = "";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(15, 27);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(50, 15);
            this.label49.TabIndex = 24;
            this.label49.Text = "LOGIN:";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(15, 85);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(0, 15);
            this.label50.TabIndex = 26;
            // 
            // cmb_LOGIN_IG
            // 
            this.cmb_LOGIN_IG.FormattingEnabled = true;
            this.cmb_LOGIN_IG.Location = new System.Drawing.Point(64, 24);
            this.cmb_LOGIN_IG.Name = "cmb_LOGIN_IG";
            this.cmb_LOGIN_IG.Size = new System.Drawing.Size(141, 23);
            this.cmb_LOGIN_IG.TabIndex = 23;
            // 
            // tabPage8
            // 
            this.tabPage8.BackColor = System.Drawing.Color.Gray;
            this.tabPage8.Controls.Add(this.ndelayloop);
            this.tabPage8.Controls.Add(this.label74);
            this.tabPage8.Controls.Add(this.cmb_DUNG_DOC_LINK_BACKUP);
            this.tabPage8.Controls.Add(this.label73);
            this.tabPage8.Controls.Add(this.delay_link_bm_backup);
            this.tabPage8.Controls.Add(this.label72);
            this.tabPage8.Controls.Add(this.label71);
            this.tabPage8.Controls.Add(this.rtb_MAIL_DOCLINK_BACKUP);
            this.tabPage8.Controls.Add(this.groupBox7);
            this.tabPage8.Controls.Add(this.groupBox6);
            this.tabPage8.Controls.Add(this.groupBox5);
            this.tabPage8.Location = new System.Drawing.Point(4, 24);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(1767, 688);
            this.tabPage8.TabIndex = 5;
            this.tabPage8.Text = "NHẬN BM NEW";
            // 
            // ndelayloop
            // 
            this.ndelayloop.Location = new System.Drawing.Point(576, 92);
            this.ndelayloop.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.ndelayloop.Name = "ndelayloop";
            this.ndelayloop.Size = new System.Drawing.Size(120, 21);
            this.ndelayloop.TabIndex = 36;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(435, 94);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(128, 15);
            this.label74.TabIndex = 35;
            this.label74.Text = "Delay Đọc Link (phút):";
            // 
            // cmb_DUNG_DOC_LINK_BACKUP
            // 
            this.cmb_DUNG_DOC_LINK_BACKUP.FormattingEnabled = true;
            this.cmb_DUNG_DOC_LINK_BACKUP.Location = new System.Drawing.Point(576, 60);
            this.cmb_DUNG_DOC_LINK_BACKUP.Name = "cmb_DUNG_DOC_LINK_BACKUP";
            this.cmb_DUNG_DOC_LINK_BACKUP.Size = new System.Drawing.Size(121, 23);
            this.cmb_DUNG_DOC_LINK_BACKUP.TabIndex = 34;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(452, 60);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(111, 15);
            this.label73.TabIndex = 33;
            this.label73.Text = "DỪNG ĐỌC LINK:";
            // 
            // delay_link_bm_backup
            // 
            this.delay_link_bm_backup.Location = new System.Drawing.Point(577, 27);
            this.delay_link_bm_backup.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.delay_link_bm_backup.Name = "delay_link_bm_backup";
            this.delay_link_bm_backup.Size = new System.Drawing.Size(120, 21);
            this.delay_link_bm_backup.TabIndex = 32;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(476, 27);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(87, 15);
            this.label72.TabIndex = 31;
            this.label72.Text = "Delay Nhận(s):";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(14, 3);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(74, 15);
            this.label71.TabIndex = 30;
            this.label71.Text = "MAIL|PASS:";
            // 
            // rtb_MAIL_DOCLINK_BACKUP
            // 
            this.rtb_MAIL_DOCLINK_BACKUP.Location = new System.Drawing.Point(17, 24);
            this.rtb_MAIL_DOCLINK_BACKUP.Name = "rtb_MAIL_DOCLINK_BACKUP";
            this.rtb_MAIL_DOCLINK_BACKUP.Size = new System.Drawing.Size(375, 139);
            this.rtb_MAIL_DOCLINK_BACKUP.TabIndex = 29;
            this.rtb_MAIL_DOCLINK_BACKUP.Text = "";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.rtb_FAIL3);
            this.groupBox7.Controls.Add(this.rtb_linkmail3_backup);
            this.groupBox7.Controls.Add(this.rtb_DONE3);
            this.groupBox7.Controls.Add(this.label64);
            this.groupBox7.Controls.Add(this.label65);
            this.groupBox7.Controls.Add(this.label66);
            this.groupBox7.Location = new System.Drawing.Point(1144, 178);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(557, 435);
            this.groupBox7.TabIndex = 28;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "MAIL3";
            // 
            // rtb_FAIL3
            // 
            this.rtb_FAIL3.Location = new System.Drawing.Point(364, 44);
            this.rtb_FAIL3.Name = "rtb_FAIL3";
            this.rtb_FAIL3.Size = new System.Drawing.Size(173, 385);
            this.rtb_FAIL3.TabIndex = 32;
            this.rtb_FAIL3.Text = "";
            // 
            // rtb_linkmail3_backup
            // 
            this.rtb_linkmail3_backup.Location = new System.Drawing.Point(185, 44);
            this.rtb_linkmail3_backup.Name = "rtb_linkmail3_backup";
            this.rtb_linkmail3_backup.Size = new System.Drawing.Size(173, 385);
            this.rtb_linkmail3_backup.TabIndex = 31;
            this.rtb_linkmail3_backup.Text = "";
            // 
            // rtb_DONE3
            // 
            this.rtb_DONE3.Location = new System.Drawing.Point(6, 44);
            this.rtb_DONE3.Name = "rtb_DONE3";
            this.rtb_DONE3.Size = new System.Drawing.Size(173, 385);
            this.rtb_DONE3.TabIndex = 30;
            this.rtb_DONE3.Text = "";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(421, 26);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(74, 15);
            this.label64.TabIndex = 26;
            this.label64.Text = "LINK3 FAIL:";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(236, 26);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(79, 15);
            this.label65.TabIndex = 27;
            this.label65.Text = "LINK MAIL3:";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(68, 26);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(84, 15);
            this.label66.TabIndex = 25;
            this.label66.Text = "LINK3 DONE:";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.rtb_FAIL2);
            this.groupBox6.Controls.Add(this.rtb_linkmail2_backup);
            this.groupBox6.Controls.Add(this.rtb_DONE2);
            this.groupBox6.Controls.Add(this.label61);
            this.groupBox6.Controls.Add(this.label62);
            this.groupBox6.Controls.Add(this.label63);
            this.groupBox6.Location = new System.Drawing.Point(581, 178);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(557, 435);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "MAIL2";
            // 
            // rtb_FAIL2
            // 
            this.rtb_FAIL2.Location = new System.Drawing.Point(373, 44);
            this.rtb_FAIL2.Name = "rtb_FAIL2";
            this.rtb_FAIL2.Size = new System.Drawing.Size(173, 385);
            this.rtb_FAIL2.TabIndex = 32;
            this.rtb_FAIL2.Text = "";
            // 
            // rtb_linkmail2_backup
            // 
            this.rtb_linkmail2_backup.Location = new System.Drawing.Point(194, 44);
            this.rtb_linkmail2_backup.Name = "rtb_linkmail2_backup";
            this.rtb_linkmail2_backup.Size = new System.Drawing.Size(173, 385);
            this.rtb_linkmail2_backup.TabIndex = 31;
            this.rtb_linkmail2_backup.Text = "";
            // 
            // rtb_DONE2
            // 
            this.rtb_DONE2.Location = new System.Drawing.Point(15, 44);
            this.rtb_DONE2.Name = "rtb_DONE2";
            this.rtb_DONE2.Size = new System.Drawing.Size(173, 385);
            this.rtb_DONE2.TabIndex = 30;
            this.rtb_DONE2.Text = "";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(421, 26);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(74, 15);
            this.label61.TabIndex = 26;
            this.label61.Text = "LINK2 FAIL:";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(236, 26);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(79, 15);
            this.label62.TabIndex = 27;
            this.label62.Text = "LINK MAIL2:";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(68, 26);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(84, 15);
            this.label63.TabIndex = 25;
            this.label63.Text = "LINK2 DONE:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.rtb_FAIL1);
            this.groupBox5.Controls.Add(this.rtb_linkmail1_backup);
            this.groupBox5.Controls.Add(this.label59);
            this.groupBox5.Controls.Add(this.label60);
            this.groupBox5.Controls.Add(this.label58);
            this.groupBox5.Controls.Add(this.rtb_DONE1);
            this.groupBox5.Location = new System.Drawing.Point(17, 178);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(557, 435);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "MAIL1";
            // 
            // rtb_FAIL1
            // 
            this.rtb_FAIL1.Location = new System.Drawing.Point(373, 44);
            this.rtb_FAIL1.Name = "rtb_FAIL1";
            this.rtb_FAIL1.Size = new System.Drawing.Size(173, 385);
            this.rtb_FAIL1.TabIndex = 29;
            this.rtb_FAIL1.Text = "";
            // 
            // rtb_linkmail1_backup
            // 
            this.rtb_linkmail1_backup.Location = new System.Drawing.Point(194, 44);
            this.rtb_linkmail1_backup.Name = "rtb_linkmail1_backup";
            this.rtb_linkmail1_backup.Size = new System.Drawing.Size(173, 385);
            this.rtb_linkmail1_backup.TabIndex = 28;
            this.rtb_linkmail1_backup.Text = "";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(421, 26);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(74, 15);
            this.label59.TabIndex = 26;
            this.label59.Text = "LINK1 FAIL:";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(236, 26);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(79, 15);
            this.label60.TabIndex = 27;
            this.label60.Text = "LINK MAIL1:";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(68, 26);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(84, 15);
            this.label58.TabIndex = 25;
            this.label58.Text = "LINK1 DONE:";
            // 
            // rtb_DONE1
            // 
            this.rtb_DONE1.Location = new System.Drawing.Point(15, 44);
            this.rtb_DONE1.Name = "rtb_DONE1";
            this.rtb_DONE1.Size = new System.Drawing.Size(173, 385);
            this.rtb_DONE1.TabIndex = 0;
            this.rtb_DONE1.Text = "";
            // 
            // tabPage9
            // 
            this.tabPage9.BackColor = System.Drawing.Color.Gray;
            this.tabPage9.Controls.Add(this.label75);
            this.tabPage9.Controls.Add(this.cmb_HOTMAIL_GMAIL);
            this.tabPage9.Controls.Add(this.cmbonoffchrome);
            this.tabPage9.Controls.Add(this.cmb_lay_Cookie);
            this.tabPage9.Controls.Add(this.label69);
            this.tabPage9.Controls.Add(this.label70);
            this.tabPage9.Location = new System.Drawing.Point(4, 24);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(1767, 688);
            this.tabPage9.TabIndex = 6;
            this.tabPage9.Text = "CÀI ĐẶT CHUNG";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(376, 43);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(110, 15);
            this.label75.TabIndex = 38;
            this.label75.Text = "HOTMAIL/GMAIL:";
            // 
            // cmb_HOTMAIL_GMAIL
            // 
            this.cmb_HOTMAIL_GMAIL.FormattingEnabled = true;
            this.cmb_HOTMAIL_GMAIL.Location = new System.Drawing.Point(492, 37);
            this.cmb_HOTMAIL_GMAIL.Name = "cmb_HOTMAIL_GMAIL";
            this.cmb_HOTMAIL_GMAIL.Size = new System.Drawing.Size(121, 23);
            this.cmb_HOTMAIL_GMAIL.TabIndex = 37;
            // 
            // cmbonoffchrome
            // 
            this.cmbonoffchrome.FormattingEnabled = true;
            this.cmbonoffchrome.Location = new System.Drawing.Point(129, 68);
            this.cmbonoffchrome.Name = "cmbonoffchrome";
            this.cmbonoffchrome.Size = new System.Drawing.Size(121, 23);
            this.cmbonoffchrome.TabIndex = 36;
            // 
            // cmb_lay_Cookie
            // 
            this.cmb_lay_Cookie.FormattingEnabled = true;
            this.cmb_lay_Cookie.Location = new System.Drawing.Point(129, 43);
            this.cmb_lay_Cookie.Name = "cmb_lay_Cookie";
            this.cmb_lay_Cookie.Size = new System.Drawing.Size(121, 23);
            this.cmb_lay_Cookie.TabIndex = 35;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(14, 72);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(114, 15);
            this.label69.TabIndex = 34;
            this.label69.Text = "ON/OFF CHROME:";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(40, 45);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(86, 15);
            this.label70.TabIndex = 33;
            this.label70.Text = "LẤY COOKIE:";
            // 
            // tabPage10
            // 
            this.tabPage10.BackColor = System.Drawing.Color.Gray;
            this.tabPage10.Controls.Add(this.tabControl3);
            this.tabPage10.Location = new System.Drawing.Point(4, 24);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage10.Size = new System.Drawing.Size(1767, 688);
            this.tabPage10.TabIndex = 7;
            this.tabPage10.Text = "LOAD BM";
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage11);
            this.tabControl3.Controls.Add(this.tabPage12);
            this.tabControl3.Controls.Add(this.tabPage22);
            this.tabControl3.Location = new System.Drawing.Point(0, 0);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(1748, 684);
            this.tabControl3.TabIndex = 0;
            // 
            // tabPage11
            // 
            this.tabPage11.BackColor = System.Drawing.Color.Gray;
            this.tabPage11.Controls.Add(this.tb_IDBM_CHECK);
            this.tabPage11.Controls.Add(this.label210);
            this.tabPage11.Controls.Add(this.delay_check_infor);
            this.tabPage11.Controls.Add(this.label209);
            this.tabPage11.Controls.Add(this.cmb_Check_Infor_BM);
            this.tabPage11.Controls.Add(this.label207);
            this.tabPage11.Controls.Add(this.cmb_LOAD_API_CHROME);
            this.tabPage11.Controls.Add(this.label192);
            this.tabPage11.Controls.Add(this.tb_EEAG_LOAD_BM);
            this.tabPage11.Controls.Add(this.label189);
            this.tabPage11.Controls.Add(this.label91);
            this.tabPage11.Controls.Add(this.numericUpDown2);
            this.tabPage11.Controls.Add(this.label92);
            this.tabPage11.Controls.Add(this.sl_LOAD_TK_D2);
            this.tabPage11.Controls.Add(this.dgv_AC);
            this.tabPage11.Controls.Add(this.label90);
            this.tabPage11.Controls.Add(this.delay_LOAD_BM);
            this.tabPage11.Controls.Add(this.label89);
            this.tabPage11.Controls.Add(this.SL_BM_LOAD);
            this.tabPage11.Controls.Add(this.rtb_IDBM_FILTER);
            this.tabPage11.Controls.Add(this.bt_filter);
            this.tabPage11.Controls.Add(this.dgv_BM);
            this.tabPage11.Location = new System.Drawing.Point(4, 24);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(1740, 656);
            this.tabPage11.TabIndex = 0;
            this.tabPage11.Text = "HIỂN THỊ";
            // 
            // tb_IDBM_CHECK
            // 
            this.tb_IDBM_CHECK.Location = new System.Drawing.Point(1314, 54);
            this.tb_IDBM_CHECK.Name = "tb_IDBM_CHECK";
            this.tb_IDBM_CHECK.Size = new System.Drawing.Size(317, 21);
            this.tb_IDBM_CHECK.TabIndex = 51;
            // 
            // label210
            // 
            this.label210.AutoSize = true;
            this.label210.Location = new System.Drawing.Point(1208, 54);
            this.label210.Name = "label210";
            this.label210.Size = new System.Drawing.Size(92, 15);
            this.label210.TabIndex = 50;
            this.label210.Text = "IDBM_CHECK:";
            // 
            // delay_check_infor
            // 
            this.delay_check_infor.Location = new System.Drawing.Point(814, 30);
            this.delay_check_infor.Name = "delay_check_infor";
            this.delay_check_infor.Size = new System.Drawing.Size(120, 21);
            this.delay_check_infor.TabIndex = 49;
            this.delay_check_infor.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label209
            // 
            this.label209.AutoSize = true;
            this.label209.Location = new System.Drawing.Point(571, 41);
            this.label209.Name = "label209";
            this.label209.Size = new System.Drawing.Size(114, 15);
            this.label209.TabIndex = 48;
            this.label209.Text = "Check_INFOR_BM:";
            // 
            // cmb_Check_Infor_BM
            // 
            this.cmb_Check_Infor_BM.FormattingEnabled = true;
            this.cmb_Check_Infor_BM.Location = new System.Drawing.Point(693, 38);
            this.cmb_Check_Infor_BM.Name = "cmb_Check_Infor_BM";
            this.cmb_Check_Infor_BM.Size = new System.Drawing.Size(91, 23);
            this.cmb_Check_Infor_BM.TabIndex = 47;
            // 
            // label207
            // 
            this.label207.AutoSize = true;
            this.label207.Location = new System.Drawing.Point(571, 12);
            this.label207.Name = "label207";
            this.label207.Size = new System.Drawing.Size(123, 15);
            this.label207.TabIndex = 36;
            this.label207.Text = "CHỨC NĂNG LOAD:";
            // 
            // cmb_LOAD_API_CHROME
            // 
            this.cmb_LOAD_API_CHROME.FormattingEnabled = true;
            this.cmb_LOAD_API_CHROME.Location = new System.Drawing.Point(693, 9);
            this.cmb_LOAD_API_CHROME.Name = "cmb_LOAD_API_CHROME";
            this.cmb_LOAD_API_CHROME.Size = new System.Drawing.Size(91, 23);
            this.cmb_LOAD_API_CHROME.TabIndex = 46;
            // 
            // label192
            // 
            this.label192.AutoSize = true;
            this.label192.Location = new System.Drawing.Point(811, 12);
            this.label192.Name = "label192";
            this.label192.Size = new System.Drawing.Size(120, 15);
            this.label192.TabIndex = 45;
            this.label192.Text = "Delay LOAD INFOR:";
            // 
            // tb_EEAG_LOAD_BM
            // 
            this.tb_EEAG_LOAD_BM.Location = new System.Drawing.Point(1314, 26);
            this.tb_EEAG_LOAD_BM.Name = "tb_EEAG_LOAD_BM";
            this.tb_EEAG_LOAD_BM.Size = new System.Drawing.Size(317, 21);
            this.tb_EEAG_LOAD_BM.TabIndex = 43;
            // 
            // label189
            // 
            this.label189.AutoSize = true;
            this.label189.Location = new System.Drawing.Point(1208, 29);
            this.label189.Name = "label189";
            this.label189.Size = new System.Drawing.Size(81, 15);
            this.label189.TabIndex = 42;
            this.label189.Text = "Token_EEAG:";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(907, 54);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(151, 15);
            this.label91.TabIndex = 37;
            this.label91.Text = "Delay LOAD TK DÒNG 2 :";
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(1064, 54);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown2.TabIndex = 36;
            this.numericUpDown2.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(993, 9);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(170, 15);
            this.label92.TabIndex = 35;
            this.label92.Text = "SỐ LƯỢNG TK LOAD/1 LẦN:";
            // 
            // sl_LOAD_TK_D2
            // 
            this.sl_LOAD_TK_D2.Location = new System.Drawing.Point(1064, 27);
            this.sl_LOAD_TK_D2.Name = "sl_LOAD_TK_D2";
            this.sl_LOAD_TK_D2.Size = new System.Drawing.Size(120, 21);
            this.sl_LOAD_TK_D2.TabIndex = 34;
            this.sl_LOAD_TK_D2.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // dgv_AC
            // 
            this.dgv_AC.AllowUserToAddRows = false;
            this.dgv_AC.AllowUserToDeleteRows = false;
            this.dgv_AC.AllowUserToResizeRows = false;
            this.dgv_AC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_AC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_AC.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cSttACBM,
            this.cIDACBM,
            this.cNAMEAC,
            this.cStatusAC,
            this.cLimit,
            this.cTIENTE,
            this.cNGAYTAOACBM,
            this.cSelectACBM});
            this.dgv_AC.ContextMenuStrip = this.contextMenuStrip5;
            this.dgv_AC.Location = new System.Drawing.Point(969, 81);
            this.dgv_AC.Name = "dgv_AC";
            this.dgv_AC.RowHeadersVisible = false;
            this.dgv_AC.Size = new System.Drawing.Size(765, 569);
            this.dgv_AC.TabIndex = 33;
            this.dgv_AC.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgv_AC_CellFormatting);
            // 
            // cSttACBM
            // 
            this.cSttACBM.FillWeight = 30F;
            this.cSttACBM.HeaderText = "STT";
            this.cSttACBM.Name = "cSttACBM";
            // 
            // cIDACBM
            // 
            this.cIDACBM.HeaderText = "ID AC";
            this.cIDACBM.Name = "cIDACBM";
            // 
            // cNAMEAC
            // 
            this.cNAMEAC.HeaderText = "NAME AC";
            this.cNAMEAC.Name = "cNAMEAC";
            // 
            // cStatusAC
            // 
            this.cStatusAC.FillWeight = 50F;
            this.cStatusAC.HeaderText = "STATUS";
            this.cStatusAC.Name = "cStatusAC";
            // 
            // cLimit
            // 
            this.cLimit.FillWeight = 50F;
            this.cLimit.HeaderText = "Limit";
            this.cLimit.Name = "cLimit";
            // 
            // cTIENTE
            // 
            this.cTIENTE.FillWeight = 50F;
            this.cTIENTE.HeaderText = "Tiền Tệ";
            this.cTIENTE.Name = "cTIENTE";
            this.cTIENTE.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.cTIENTE.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // cNGAYTAOACBM
            // 
            this.cNGAYTAOACBM.HeaderText = "Ngày Tạo";
            this.cNGAYTAOACBM.Name = "cNGAYTAOACBM";
            // 
            // cSelectACBM
            // 
            this.cSelectACBM.FillWeight = 20F;
            this.cSelectACBM.HeaderText = "";
            this.cSelectACBM.Name = "cSelectACBM";
            // 
            // contextMenuStrip5
            // 
            this.contextMenuStrip5.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.xÓAALLToolStripMenuItem1});
            this.contextMenuStrip5.Name = "contextMenuStrip5";
            this.contextMenuStrip5.Size = new System.Drawing.Size(122, 26);
            // 
            // xÓAALLToolStripMenuItem1
            // 
            this.xÓAALLToolStripMenuItem1.Name = "xÓAALLToolStripMenuItem1";
            this.xÓAALLToolStripMenuItem1.Size = new System.Drawing.Size(121, 22);
            this.xÓAALLToolStripMenuItem1.Text = "XÓA ALL";
            this.xÓAALLToolStripMenuItem1.Click += new System.EventHandler(this.xÓAALLToolStripMenuItem1_Click);
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(332, 56);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(101, 15);
            this.label90.TabIndex = 32;
            this.label90.Text = "Delay LOAD BM:";
            // 
            // delay_LOAD_BM
            // 
            this.delay_LOAD_BM.Location = new System.Drawing.Point(436, 54);
            this.delay_LOAD_BM.Name = "delay_LOAD_BM";
            this.delay_LOAD_BM.Size = new System.Drawing.Size(120, 21);
            this.delay_LOAD_BM.TabIndex = 31;
            this.delay_LOAD_BM.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(365, 9);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(172, 15);
            this.label89.TabIndex = 30;
            this.label89.Text = "SỐ LƯỢNG BM LOAD/1 LẦN:";
            // 
            // SL_BM_LOAD
            // 
            this.SL_BM_LOAD.Location = new System.Drawing.Point(436, 27);
            this.SL_BM_LOAD.Name = "SL_BM_LOAD";
            this.SL_BM_LOAD.Size = new System.Drawing.Size(120, 21);
            this.SL_BM_LOAD.TabIndex = 6;
            this.SL_BM_LOAD.Value = new decimal(new int[] {
            40,
            0,
            0,
            0});
            // 
            // rtb_IDBM_FILTER
            // 
            this.rtb_IDBM_FILTER.Location = new System.Drawing.Point(152, 9);
            this.rtb_IDBM_FILTER.Name = "rtb_IDBM_FILTER";
            this.rtb_IDBM_FILTER.Size = new System.Drawing.Size(162, 60);
            this.rtb_IDBM_FILTER.TabIndex = 5;
            this.rtb_IDBM_FILTER.Text = "";
            // 
            // bt_filter
            // 
            this.bt_filter.Location = new System.Drawing.Point(16, 23);
            this.bt_filter.Name = "bt_filter";
            this.bt_filter.Size = new System.Drawing.Size(130, 31);
            this.bt_filter.TabIndex = 4;
            this.bt_filter.Text = "FILTER";
            this.bt_filter.UseVisualStyleBackColor = true;
            this.bt_filter.Click += new System.EventHandler(this.bt_filter_Click);
            // 
            // dgv_BM
            // 
            this.dgv_BM.AllowUserToAddRows = false;
            this.dgv_BM.AllowUserToDeleteRows = false;
            this.dgv_BM.AllowUserToResizeRows = false;
            this.dgv_BM.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_BM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_BM.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cSTTBM,
            this.cIDVIA,
            this.cIDBM,
            this.cNAMEBM,
            this.cStatusBM,
            this.cLOAIBM,
            this.cinfor,
            this.cNgayTao,
            this.cADMIN,
            this.cTKLIVEDIE,
            this.cSelectBM});
            this.dgv_BM.ContextMenuStrip = this.contextMenuStrip4;
            this.dgv_BM.Location = new System.Drawing.Point(1, 81);
            this.dgv_BM.Name = "dgv_BM";
            this.dgv_BM.RowHeadersVisible = false;
            this.dgv_BM.Size = new System.Drawing.Size(962, 569);
            this.dgv_BM.TabIndex = 3;
            this.dgv_BM.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_BM_CellContentClick);
            this.dgv_BM.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgv_BM_CellFormatting);
            // 
            // cSTTBM
            // 
            this.cSTTBM.FillWeight = 25.93909F;
            this.cSTTBM.HeaderText = "STT";
            this.cSTTBM.Name = "cSTTBM";
            // 
            // cIDVIA
            // 
            this.cIDVIA.FillWeight = 86.46362F;
            this.cIDVIA.HeaderText = "ID VIA";
            this.cIDVIA.Name = "cIDVIA";
            // 
            // cIDBM
            // 
            this.cIDBM.FillWeight = 86.46362F;
            this.cIDBM.HeaderText = "ID BM";
            this.cIDBM.Name = "cIDBM";
            // 
            // cNAMEBM
            // 
            this.cNAMEBM.FillWeight = 43.23181F;
            this.cNAMEBM.HeaderText = "NAMEBM";
            this.cNAMEBM.Name = "cNAMEBM";
            // 
            // cStatusBM
            // 
            this.cStatusBM.FillWeight = 43.23181F;
            this.cStatusBM.HeaderText = "STATUS";
            this.cStatusBM.Name = "cStatusBM";
            // 
            // cLOAIBM
            // 
            this.cLOAIBM.FillWeight = 43.23181F;
            this.cLOAIBM.HeaderText = "Loại BM";
            this.cLOAIBM.Name = "cLOAIBM";
            // 
            // cinfor
            // 
            this.cinfor.FillWeight = 30F;
            this.cinfor.HeaderText = "Business_Info";
            this.cinfor.Name = "cinfor";
            // 
            // cNgayTao
            // 
            this.cNgayTao.FillWeight = 86.46362F;
            this.cNgayTao.HeaderText = "Ngày Tạo";
            this.cNgayTao.Name = "cNgayTao";
            // 
            // cADMIN
            // 
            this.cADMIN.FillWeight = 25.93909F;
            this.cADMIN.HeaderText = "ADMIN";
            this.cADMIN.Name = "cADMIN";
            this.cADMIN.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.cADMIN.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // cTKLIVEDIE
            // 
            this.cTKLIVEDIE.FillWeight = 86.46362F;
            this.cTKLIVEDIE.HeaderText = "TKLIVE || TKDIE";
            this.cTKLIVEDIE.Name = "cTKLIVEDIE";
            this.cTKLIVEDIE.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.cTKLIVEDIE.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // cSelectBM
            // 
            this.cSelectBM.FillWeight = 17.29272F;
            this.cSelectBM.HeaderText = "";
            this.cSelectBM.Name = "cSelectBM";
            // 
            // contextMenuStrip4
            // 
            this.contextMenuStrip4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chọnToolStripMenuItem3,
            this.bỏChọnToolStripMenuItem3,
            this.xóaALLToolStripMenuItem,
            this.lOADTKDONGToolStripMenuItem,
            this.bACKUPBMToolStripMenuItem,
            this.bACKUPBMNHIEUVIAToolStripMenuItem});
            this.contextMenuStrip4.Name = "contextMenuStrip4";
            this.contextMenuStrip4.Size = new System.Drawing.Size(203, 136);
            // 
            // chọnToolStripMenuItem3
            // 
            this.chọnToolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bôiĐenToolStripMenuItem7,
            this.tấtCảToolStripMenuItem9});
            this.chọnToolStripMenuItem3.Name = "chọnToolStripMenuItem3";
            this.chọnToolStripMenuItem3.Size = new System.Drawing.Size(202, 22);
            this.chọnToolStripMenuItem3.Text = "Chọn";
            // 
            // bôiĐenToolStripMenuItem7
            // 
            this.bôiĐenToolStripMenuItem7.Name = "bôiĐenToolStripMenuItem7";
            this.bôiĐenToolStripMenuItem7.Size = new System.Drawing.Size(115, 22);
            this.bôiĐenToolStripMenuItem7.Text = "Bôi Đen";
            this.bôiĐenToolStripMenuItem7.Click += new System.EventHandler(this.bôiĐenToolStripMenuItem7_Click);
            // 
            // tấtCảToolStripMenuItem9
            // 
            this.tấtCảToolStripMenuItem9.Name = "tấtCảToolStripMenuItem9";
            this.tấtCảToolStripMenuItem9.Size = new System.Drawing.Size(115, 22);
            this.tấtCảToolStripMenuItem9.Text = "Tất Cả";
            this.tấtCảToolStripMenuItem9.Click += new System.EventHandler(this.tấtCảToolStripMenuItem9_Click);
            // 
            // bỏChọnToolStripMenuItem3
            // 
            this.bỏChọnToolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bôiĐenToolStripMenuItem8,
            this.tấtCảToolStripMenuItem10});
            this.bỏChọnToolStripMenuItem3.Name = "bỏChọnToolStripMenuItem3";
            this.bỏChọnToolStripMenuItem3.Size = new System.Drawing.Size(202, 22);
            this.bỏChọnToolStripMenuItem3.Text = "Bỏ Chọn";
            // 
            // bôiĐenToolStripMenuItem8
            // 
            this.bôiĐenToolStripMenuItem8.Name = "bôiĐenToolStripMenuItem8";
            this.bôiĐenToolStripMenuItem8.Size = new System.Drawing.Size(115, 22);
            this.bôiĐenToolStripMenuItem8.Text = "Bôi Đen";
            this.bôiĐenToolStripMenuItem8.Click += new System.EventHandler(this.bôiĐenToolStripMenuItem8_Click);
            // 
            // tấtCảToolStripMenuItem10
            // 
            this.tấtCảToolStripMenuItem10.Name = "tấtCảToolStripMenuItem10";
            this.tấtCảToolStripMenuItem10.Size = new System.Drawing.Size(115, 22);
            this.tấtCảToolStripMenuItem10.Text = "Tất Cả";
            this.tấtCảToolStripMenuItem10.Click += new System.EventHandler(this.tấtCảToolStripMenuItem10_Click);
            // 
            // xóaALLToolStripMenuItem
            // 
            this.xóaALLToolStripMenuItem.Name = "xóaALLToolStripMenuItem";
            this.xóaALLToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.xóaALLToolStripMenuItem.Text = "Xóa ALL";
            this.xóaALLToolStripMenuItem.Click += new System.EventHandler(this.xóaALLToolStripMenuItem_Click);
            // 
            // lOADTKDONGToolStripMenuItem
            // 
            this.lOADTKDONGToolStripMenuItem.Name = "lOADTKDONGToolStripMenuItem";
            this.lOADTKDONGToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.lOADTKDONGToolStripMenuItem.Text = "LOAD TK DONG 2 BM";
            this.lOADTKDONGToolStripMenuItem.Click += new System.EventHandler(this.lOADTKDONGToolStripMenuItem_Click);
            // 
            // bACKUPBMToolStripMenuItem
            // 
            this.bACKUPBMToolStripMenuItem.Name = "bACKUPBMToolStripMenuItem";
            this.bACKUPBMToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.bACKUPBMToolStripMenuItem.Text = "BACK UP BM";
            this.bACKUPBMToolStripMenuItem.Click += new System.EventHandler(this.bACKUPBMToolStripMenuItem_Click);
            // 
            // bACKUPBMNHIEUVIAToolStripMenuItem
            // 
            this.bACKUPBMNHIEUVIAToolStripMenuItem.Name = "bACKUPBMNHIEUVIAToolStripMenuItem";
            this.bACKUPBMNHIEUVIAToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.bACKUPBMNHIEUVIAToolStripMenuItem.Text = "BACK UP BM NHIEU VIA";
            this.bACKUPBMNHIEUVIAToolStripMenuItem.Click += new System.EventHandler(this.bACKUPBMNHIEUVIAToolStripMenuItem_Click);
            // 
            // tabPage12
            // 
            this.tabPage12.BackColor = System.Drawing.Color.Gray;
            this.tabPage12.Controls.Add(this.tb_Token);
            this.tabPage12.Controls.Add(this.label195);
            this.tabPage12.Controls.Add(this.label174);
            this.tabPage12.Controls.Add(this.rtb_backup_fail);
            this.tabPage12.Controls.Add(this.bt_doi_dinh_dang);
            this.tabPage12.Controls.Add(this.label173);
            this.tabPage12.Controls.Add(this.rtb_BM_OUT);
            this.tabPage12.Controls.Add(this.label172);
            this.tabPage12.Controls.Add(this.rtb_ADMIN_BM_CHECK);
            this.tabPage12.Controls.Add(this.label165);
            this.tabPage12.Controls.Add(this.rtb_IDBM_Can_Tao_TK);
            this.tabPage12.Controls.Add(this.label164);
            this.tabPage12.Controls.Add(this.rtb_IDBM_CAN_BACK_Up);
            this.tabPage12.Controls.Add(this.label99);
            this.tabPage12.Controls.Add(this.rtb_Link_BM);
            this.tabPage12.Controls.Add(this.groupBox9);
            this.tabPage12.Location = new System.Drawing.Point(4, 24);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage12.Size = new System.Drawing.Size(1740, 656);
            this.tabPage12.TabIndex = 1;
            this.tabPage12.Text = "CÀI ĐẶT LINK BM";
            // 
            // tb_Token
            // 
            this.tb_Token.Location = new System.Drawing.Point(204, 398);
            this.tb_Token.Name = "tb_Token";
            this.tb_Token.Size = new System.Drawing.Size(317, 21);
            this.tb_Token.TabIndex = 52;
            // 
            // label195
            // 
            this.label195.AutoSize = true;
            this.label195.Location = new System.Drawing.Point(98, 401);
            this.label195.Name = "label195";
            this.label195.Size = new System.Drawing.Size(81, 15);
            this.label195.TabIndex = 51;
            this.label195.Text = "Token_EEAG:";
            // 
            // label174
            // 
            this.label174.AutoSize = true;
            this.label174.Location = new System.Drawing.Point(1003, 355);
            this.label174.Name = "label174";
            this.label174.Size = new System.Drawing.Size(268, 15);
            this.label174.TabIndex = 50;
            this.label174.Text = "IDBM Cần Back Up/OUT/CHECK_ADMIN FAIL!:";
            // 
            // rtb_backup_fail
            // 
            this.rtb_backup_fail.Location = new System.Drawing.Point(1006, 373);
            this.rtb_backup_fail.Name = "rtb_backup_fail";
            this.rtb_backup_fail.Size = new System.Drawing.Size(212, 266);
            this.rtb_backup_fail.TabIndex = 49;
            this.rtb_backup_fail.Text = "";
            // 
            // bt_doi_dinh_dang
            // 
            this.bt_doi_dinh_dang.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.bt_doi_dinh_dang.Location = new System.Drawing.Point(978, 6);
            this.bt_doi_dinh_dang.Name = "bt_doi_dinh_dang";
            this.bt_doi_dinh_dang.Size = new System.Drawing.Size(135, 35);
            this.bt_doi_dinh_dang.TabIndex = 48;
            this.bt_doi_dinh_dang.Text = "ĐỔI ĐỊNH DẠNG";
            this.bt_doi_dinh_dang.UseVisualStyleBackColor = false;
            this.bt_doi_dinh_dang.Click += new System.EventHandler(this.bt_doi_dinh_dang_Click);
            // 
            // label173
            // 
            this.label173.AutoSize = true;
            this.label173.Location = new System.Drawing.Point(1514, 355);
            this.label173.Name = "label173";
            this.label173.Size = new System.Drawing.Size(133, 15);
            this.label173.TabIndex = 47;
            this.label173.Text = "CHECK BM CẦN OUT:";
            // 
            // rtb_BM_OUT
            // 
            this.rtb_BM_OUT.Location = new System.Drawing.Point(1476, 373);
            this.rtb_BM_OUT.Name = "rtb_BM_OUT";
            this.rtb_BM_OUT.Size = new System.Drawing.Size(212, 266);
            this.rtb_BM_OUT.TabIndex = 46;
            this.rtb_BM_OUT.Text = "";
            // 
            // label172
            // 
            this.label172.AutoSize = true;
            this.label172.Location = new System.Drawing.Point(1473, 57);
            this.label172.Name = "label172";
            this.label172.Size = new System.Drawing.Size(207, 15);
            this.label172.TabIndex = 45;
            this.label172.Text = "CHECK ADMIN IDBM CẦN CHECK:";
            // 
            // rtb_ADMIN_BM_CHECK
            // 
            this.rtb_ADMIN_BM_CHECK.Location = new System.Drawing.Point(1476, 75);
            this.rtb_ADMIN_BM_CHECK.Name = "rtb_ADMIN_BM_CHECK";
            this.rtb_ADMIN_BM_CHECK.Size = new System.Drawing.Size(212, 266);
            this.rtb_ADMIN_BM_CHECK.TabIndex = 44;
            this.rtb_ADMIN_BM_CHECK.Text = "";
            // 
            // label165
            // 
            this.label165.AutoSize = true;
            this.label165.Location = new System.Drawing.Point(1288, 57);
            this.label165.Name = "label165";
            this.label165.Size = new System.Drawing.Size(111, 15);
            this.label165.TabIndex = 43;
            this.label165.Text = "IDBM Cần Tạo TK:";
            // 
            // rtb_IDBM_Can_Tao_TK
            // 
            this.rtb_IDBM_Can_Tao_TK.Location = new System.Drawing.Point(1243, 75);
            this.rtb_IDBM_Can_Tao_TK.Name = "rtb_IDBM_Can_Tao_TK";
            this.rtb_IDBM_Can_Tao_TK.Size = new System.Drawing.Size(212, 266);
            this.rtb_IDBM_Can_Tao_TK.TabIndex = 42;
            this.rtb_IDBM_Can_Tao_TK.Text = "";
            // 
            // label164
            // 
            this.label164.AutoSize = true;
            this.label164.Location = new System.Drawing.Point(1003, 57);
            this.label164.Name = "label164";
            this.label164.Size = new System.Drawing.Size(236, 15);
            this.label164.TabIndex = 41;
            this.label164.Text = "IDBM Cần Back Up/OUT/CHECK_ADMIN:";
            // 
            // rtb_IDBM_CAN_BACK_Up
            // 
            this.rtb_IDBM_CAN_BACK_Up.Location = new System.Drawing.Point(1006, 75);
            this.rtb_IDBM_CAN_BACK_Up.Name = "rtb_IDBM_CAN_BACK_Up";
            this.rtb_IDBM_CAN_BACK_Up.Size = new System.Drawing.Size(212, 266);
            this.rtb_IDBM_CAN_BACK_Up.TabIndex = 40;
            this.rtb_IDBM_CAN_BACK_Up.Text = "";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(583, 57);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(86, 15);
            this.label99.TabIndex = 39;
            this.label99.Text = "LINK SHARE :";
            // 
            // rtb_Link_BM
            // 
            this.rtb_Link_BM.Location = new System.Drawing.Point(586, 75);
            this.rtb_Link_BM.Name = "rtb_Link_BM";
            this.rtb_Link_BM.Size = new System.Drawing.Size(358, 266);
            this.rtb_Link_BM.TabIndex = 1;
            this.rtb_Link_BM.Text = "";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.cmb_API_CHROME_BACK_UP_BM_THEO_ID);
            this.groupBox9.Controls.Add(this.label208);
            this.groupBox9.Controls.Add(this.label199);
            this.groupBox9.Controls.Add(this.cmb_share_ban);
            this.groupBox9.Controls.Add(this.label194);
            this.groupBox9.Controls.Add(this.n_Delay_TTK);
            this.groupBox9.Controls.Add(this.label193);
            this.groupBox9.Controls.Add(this.bt_Tao_TK_BM);
            this.groupBox9.Controls.Add(this.numericUpDown7);
            this.groupBox9.Controls.Add(this.cmb_loai_mail);
            this.groupBox9.Controls.Add(this.cmb_Admin_BM1);
            this.groupBox9.Controls.Add(this.delay_doc_link);
            this.groupBox9.Controls.Add(this.so_link_backup);
            this.groupBox9.Controls.Add(this.tb_hotmail_Share_bm);
            this.groupBox9.Controls.Add(this.label98);
            this.groupBox9.Controls.Add(this.label97);
            this.groupBox9.Controls.Add(this.label95);
            this.groupBox9.Controls.Add(this.label96);
            this.groupBox9.Controls.Add(this.label94);
            this.groupBox9.Controls.Add(this.label93);
            this.groupBox9.Location = new System.Drawing.Point(82, 63);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(464, 435);
            this.groupBox9.TabIndex = 0;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "SHARE BM";
            // 
            // cmb_API_CHROME_BACK_UP_BM_THEO_ID
            // 
            this.cmb_API_CHROME_BACK_UP_BM_THEO_ID.FormattingEnabled = true;
            this.cmb_API_CHROME_BACK_UP_BM_THEO_ID.Location = new System.Drawing.Point(122, 386);
            this.cmb_API_CHROME_BACK_UP_BM_THEO_ID.Name = "cmb_API_CHROME_BACK_UP_BM_THEO_ID";
            this.cmb_API_CHROME_BACK_UP_BM_THEO_ID.Size = new System.Drawing.Size(107, 23);
            this.cmb_API_CHROME_BACK_UP_BM_THEO_ID.TabIndex = 56;
            // 
            // label208
            // 
            this.label208.AutoSize = true;
            this.label208.Location = new System.Drawing.Point(16, 368);
            this.label208.Name = "label208";
            this.label208.Size = new System.Drawing.Size(273, 15);
            this.label208.TabIndex = 53;
            this.label208.Text = "API/CHROME OUT/CHECK/KICK3/BACKUP_ID:";
            // 
            // label199
            // 
            this.label199.AutoSize = true;
            this.label199.Location = new System.Drawing.Point(6, 217);
            this.label199.Name = "label199";
            this.label199.Size = new System.Drawing.Size(79, 15);
            this.label199.TabIndex = 55;
            this.label199.Text = "SHARE BÁN:";
            // 
            // cmb_share_ban
            // 
            this.cmb_share_ban.FormattingEnabled = true;
            this.cmb_share_ban.Location = new System.Drawing.Point(201, 209);
            this.cmb_share_ban.Name = "cmb_share_ban";
            this.cmb_share_ban.Size = new System.Drawing.Size(180, 23);
            this.cmb_share_ban.TabIndex = 53;
            // 
            // label194
            // 
            this.label194.AutoSize = true;
            this.label194.Location = new System.Drawing.Point(181, 276);
            this.label194.Name = "label194";
            this.label194.Size = new System.Drawing.Size(48, 15);
            this.label194.TabIndex = 54;
            this.label194.Text = "DELAY:";
            // 
            // n_Delay_TTK
            // 
            this.n_Delay_TTK.Location = new System.Drawing.Point(235, 274);
            this.n_Delay_TTK.Name = "n_Delay_TTK";
            this.n_Delay_TTK.Size = new System.Drawing.Size(120, 21);
            this.n_Delay_TTK.TabIndex = 53;
            // 
            // label193
            // 
            this.label193.AutoSize = true;
            this.label193.Location = new System.Drawing.Point(164, 249);
            this.label193.Name = "label193";
            this.label193.Size = new System.Drawing.Size(65, 15);
            this.label193.TabIndex = 52;
            this.label193.Text = "STK TẠO:";
            // 
            // bt_Tao_TK_BM
            // 
            this.bt_Tao_TK_BM.BackColor = System.Drawing.Color.LawnGreen;
            this.bt_Tao_TK_BM.Location = new System.Drawing.Point(9, 241);
            this.bt_Tao_TK_BM.Name = "bt_Tao_TK_BM";
            this.bt_Tao_TK_BM.Size = new System.Drawing.Size(130, 31);
            this.bt_Tao_TK_BM.TabIndex = 51;
            this.bt_Tao_TK_BM.Text = "TAO TK BM";
            this.bt_Tao_TK_BM.UseVisualStyleBackColor = false;
            this.bt_Tao_TK_BM.Click += new System.EventHandler(this.bt_Tao_TK_BM_Click_1);
            // 
            // numericUpDown7
            // 
            this.numericUpDown7.Location = new System.Drawing.Point(235, 247);
            this.numericUpDown7.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown7.Name = "numericUpDown7";
            this.numericUpDown7.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown7.TabIndex = 49;
            this.numericUpDown7.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // cmb_loai_mail
            // 
            this.cmb_loai_mail.FormattingEnabled = true;
            this.cmb_loai_mail.Location = new System.Drawing.Point(201, 149);
            this.cmb_loai_mail.Name = "cmb_loai_mail";
            this.cmb_loai_mail.Size = new System.Drawing.Size(180, 23);
            this.cmb_loai_mail.TabIndex = 48;
            // 
            // cmb_Admin_BM1
            // 
            this.cmb_Admin_BM1.FormattingEnabled = true;
            this.cmb_Admin_BM1.Location = new System.Drawing.Point(201, 116);
            this.cmb_Admin_BM1.Name = "cmb_Admin_BM1";
            this.cmb_Admin_BM1.Size = new System.Drawing.Size(180, 23);
            this.cmb_Admin_BM1.TabIndex = 47;
            // 
            // delay_doc_link
            // 
            this.delay_doc_link.Location = new System.Drawing.Point(201, 182);
            this.delay_doc_link.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.delay_doc_link.Name = "delay_doc_link";
            this.delay_doc_link.Size = new System.Drawing.Size(120, 21);
            this.delay_doc_link.TabIndex = 46;
            // 
            // so_link_backup
            // 
            this.so_link_backup.Location = new System.Drawing.Point(201, 87);
            this.so_link_backup.Name = "so_link_backup";
            this.so_link_backup.Size = new System.Drawing.Size(120, 21);
            this.so_link_backup.TabIndex = 45;
            // 
            // tb_hotmail_Share_bm
            // 
            this.tb_hotmail_Share_bm.Location = new System.Drawing.Point(201, 60);
            this.tb_hotmail_Share_bm.Name = "tb_hotmail_Share_bm";
            this.tb_hotmail_Share_bm.Size = new System.Drawing.Size(180, 21);
            this.tb_hotmail_Share_bm.TabIndex = 44;
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(220, 17);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(74, 15);
            this.label98.TabIndex = 43;
            this.label98.Text = "MAIL|PASS:";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(6, 188);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(48, 15);
            this.label97.TabIndex = 42;
            this.label97.Text = "DELAY:";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(6, 161);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(73, 15);
            this.label95.TabIndex = 41;
            this.label95.Text = "LOẠI MAIL:";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(6, 123);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(78, 15);
            this.label96.TabIndex = 40;
            this.label96.Text = "QUYỀN BM :";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(6, 95);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(133, 15);
            this.label94.TabIndex = 39;
            this.label94.Text = "SỐ LINK CẦN SHARE:";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(6, 66);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(113, 15);
            this.label93.TabIndex = 38;
            this.label93.Text = "HOTMAIL SHARE :";
            // 
            // tabPage22
            // 
            this.tabPage22.BackColor = System.Drawing.Color.Gray;
            this.tabPage22.Controls.Add(this.label220);
            this.tabPage22.Controls.Add(this.cmb_new_create_WA);
            this.tabPage22.Controls.Add(this.label219);
            this.tabPage22.Controls.Add(this.cmb_delete_WA);
            this.tabPage22.Controls.Add(this.label212);
            this.tabPage22.Controls.Add(this.cmb_ttk_5_1_WA);
            this.tabPage22.Controls.Add(this.cmb_bo_check1);
            this.tabPage22.Controls.Add(this.label211);
            this.tabPage22.Controls.Add(this.label206);
            this.tabPage22.Controls.Add(this.sl_BM_kick3);
            this.tabPage22.Controls.Add(this.label204);
            this.tabPage22.Controls.Add(this.label203);
            this.tabPage22.Controls.Add(this.rtb_BM1);
            this.tabPage22.Controls.Add(this.rtb_BM3);
            this.tabPage22.Controls.Add(this.label197);
            this.tabPage22.Controls.Add(this.m_delay_ttk);
            this.tabPage22.Controls.Add(this.label196);
            this.tabPage22.Controls.Add(this.numericUpDown9);
            this.tabPage22.Controls.Add(this.label191);
            this.tabPage22.Controls.Add(this.cmb_TTKQCBM3);
            this.tabPage22.Controls.Add(this.btdoidang);
            this.tabPage22.Controls.Add(this.label187);
            this.tabPage22.Controls.Add(this.numericUpDown5);
            this.tabPage22.Controls.Add(this.tb_NAME_WHATAPP);
            this.tabPage22.Controls.Add(this.label186);
            this.tabPage22.Controls.Add(this.delay_kick_bm3);
            this.tabPage22.Controls.Add(this.label185);
            this.tabPage22.Controls.Add(this.label184);
            this.tabPage22.Controls.Add(this.rtb_status_kick);
            this.tabPage22.Controls.Add(this.label183);
            this.tabPage22.Controls.Add(this.rtb_IDBM_KICK_BM3);
            this.tabPage22.Controls.Add(this.tb_TokenEEAG);
            this.tabPage22.Controls.Add(this.label182);
            this.tabPage22.Location = new System.Drawing.Point(4, 24);
            this.tabPage22.Name = "tabPage22";
            this.tabPage22.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage22.Size = new System.Drawing.Size(1740, 656);
            this.tabPage22.TabIndex = 2;
            this.tabPage22.Text = "KICK BM3";
            // 
            // label220
            // 
            this.label220.AutoSize = true;
            this.label220.Location = new System.Drawing.Point(771, 255);
            this.label220.Name = "label220";
            this.label220.Size = new System.Drawing.Size(96, 15);
            this.label220.TabIndex = 73;
            this.label220.Text = "TẠO WHATAPP:";
            // 
            // cmb_new_create_WA
            // 
            this.cmb_new_create_WA.FormattingEnabled = true;
            this.cmb_new_create_WA.Location = new System.Drawing.Point(821, 276);
            this.cmb_new_create_WA.Name = "cmb_new_create_WA";
            this.cmb_new_create_WA.Size = new System.Drawing.Size(121, 23);
            this.cmb_new_create_WA.TabIndex = 72;
            // 
            // label219
            // 
            this.label219.AutoSize = true;
            this.label219.Location = new System.Drawing.Point(771, 206);
            this.label219.Name = "label219";
            this.label219.Size = new System.Drawing.Size(115, 15);
            this.label219.TabIndex = 71;
            this.label219.Text = "DELETE WHATAPP:";
            // 
            // cmb_delete_WA
            // 
            this.cmb_delete_WA.FormattingEnabled = true;
            this.cmb_delete_WA.Location = new System.Drawing.Point(821, 229);
            this.cmb_delete_WA.Name = "cmb_delete_WA";
            this.cmb_delete_WA.Size = new System.Drawing.Size(121, 23);
            this.cmb_delete_WA.TabIndex = 70;
            // 
            // label212
            // 
            this.label212.AutoSize = true;
            this.label212.Location = new System.Drawing.Point(777, 162);
            this.label212.Name = "label212";
            this.label212.Size = new System.Drawing.Size(76, 15);
            this.label212.TabIndex = 69;
            this.label212.Text = "TẠO TK 5-1:";
            // 
            // cmb_ttk_5_1_WA
            // 
            this.cmb_ttk_5_1_WA.FormattingEnabled = true;
            this.cmb_ttk_5_1_WA.Location = new System.Drawing.Point(821, 180);
            this.cmb_ttk_5_1_WA.Name = "cmb_ttk_5_1_WA";
            this.cmb_ttk_5_1_WA.Size = new System.Drawing.Size(121, 23);
            this.cmb_ttk_5_1_WA.TabIndex = 68;
            // 
            // cmb_bo_check1
            // 
            this.cmb_bo_check1.FormattingEnabled = true;
            this.cmb_bo_check1.Location = new System.Drawing.Point(821, 127);
            this.cmb_bo_check1.Name = "cmb_bo_check1";
            this.cmb_bo_check1.Size = new System.Drawing.Size(121, 23);
            this.cmb_bo_check1.TabIndex = 67;
            // 
            // label211
            // 
            this.label211.AutoSize = true;
            this.label211.Location = new System.Drawing.Point(777, 109);
            this.label211.Name = "label211";
            this.label211.Size = new System.Drawing.Size(103, 15);
            this.label211.TabIndex = 66;
            this.label211.Text = "BỎ CHECK BM3:";
            // 
            // label206
            // 
            this.label206.AutoSize = true;
            this.label206.Location = new System.Drawing.Point(1060, 14);
            this.label206.Name = "label206";
            this.label206.Size = new System.Drawing.Size(133, 15);
            this.label206.TabIndex = 64;
            this.label206.Text = "SỐ LƯỢNG BM KICK:";
            // 
            // sl_BM_kick3
            // 
            this.sl_BM_kick3.Location = new System.Drawing.Point(1199, 11);
            this.sl_BM_kick3.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.sl_BM_kick3.Name = "sl_BM_kick3";
            this.sl_BM_kick3.Size = new System.Drawing.Size(120, 21);
            this.sl_BM_kick3.TabIndex = 63;
            this.sl_BM_kick3.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label204
            // 
            this.label204.AutoSize = true;
            this.label204.Location = new System.Drawing.Point(1189, 91);
            this.label204.Name = "label204";
            this.label204.Size = new System.Drawing.Size(36, 15);
            this.label204.TabIndex = 62;
            this.label204.Text = "BM1:";
            // 
            // label203
            // 
            this.label203.AutoSize = true;
            this.label203.Location = new System.Drawing.Point(975, 91);
            this.label203.Name = "label203";
            this.label203.Size = new System.Drawing.Size(36, 15);
            this.label203.TabIndex = 61;
            this.label203.Text = "BM3:";
            // 
            // rtb_BM1
            // 
            this.rtb_BM1.Location = new System.Drawing.Point(1192, 112);
            this.rtb_BM1.Name = "rtb_BM1";
            this.rtb_BM1.Size = new System.Drawing.Size(195, 266);
            this.rtb_BM1.TabIndex = 60;
            this.rtb_BM1.Text = "";
            // 
            // rtb_BM3
            // 
            this.rtb_BM3.Location = new System.Drawing.Point(978, 112);
            this.rtb_BM3.Name = "rtb_BM3";
            this.rtb_BM3.Size = new System.Drawing.Size(195, 266);
            this.rtb_BM3.TabIndex = 59;
            this.rtb_BM3.Text = "";
            // 
            // label197
            // 
            this.label197.AutoSize = true;
            this.label197.Location = new System.Drawing.Point(775, 81);
            this.label197.Name = "label197";
            this.label197.Size = new System.Drawing.Size(42, 15);
            this.label197.TabIndex = 58;
            this.label197.Text = "Delay:";
            // 
            // m_delay_ttk
            // 
            this.m_delay_ttk.Location = new System.Drawing.Point(831, 76);
            this.m_delay_ttk.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.m_delay_ttk.Name = "m_delay_ttk";
            this.m_delay_ttk.Size = new System.Drawing.Size(120, 21);
            this.m_delay_ttk.TabIndex = 57;
            // 
            // label196
            // 
            this.label196.AutoSize = true;
            this.label196.Location = new System.Drawing.Point(777, 52);
            this.label196.Name = "label196";
            this.label196.Size = new System.Drawing.Size(36, 15);
            this.label196.TabIndex = 56;
            this.label196.Text = "STK:";
            // 
            // numericUpDown9
            // 
            this.numericUpDown9.Location = new System.Drawing.Point(831, 49);
            this.numericUpDown9.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.numericUpDown9.Name = "numericUpDown9";
            this.numericUpDown9.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown9.TabIndex = 55;
            this.numericUpDown9.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label191
            // 
            this.label191.AutoSize = true;
            this.label191.Location = new System.Drawing.Point(775, 17);
            this.label191.Name = "label191";
            this.label191.Size = new System.Drawing.Size(55, 15);
            this.label191.TabIndex = 54;
            this.label191.Text = "TTKQC:";
            // 
            // cmb_TTKQCBM3
            // 
            this.cmb_TTKQCBM3.FormattingEnabled = true;
            this.cmb_TTKQCBM3.Location = new System.Drawing.Point(831, 12);
            this.cmb_TTKQCBM3.Name = "cmb_TTKQCBM3";
            this.cmb_TTKQCBM3.Size = new System.Drawing.Size(121, 23);
            this.cmb_TTKQCBM3.TabIndex = 53;
            // 
            // btdoidang
            // 
            this.btdoidang.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btdoidang.Location = new System.Drawing.Point(164, 71);
            this.btdoidang.Name = "btdoidang";
            this.btdoidang.Size = new System.Drawing.Size(135, 35);
            this.btdoidang.TabIndex = 52;
            this.btdoidang.Text = "ĐỔI ĐỊNH DẠNG";
            this.btdoidang.UseVisualStyleBackColor = false;
            this.btdoidang.Click += new System.EventHandler(this.btdoidang_Click);
            // 
            // label187
            // 
            this.label187.AutoSize = true;
            this.label187.Location = new System.Drawing.Point(524, 20);
            this.label187.Name = "label187";
            this.label187.Size = new System.Drawing.Size(50, 15);
            this.label187.TabIndex = 51;
            this.label187.Text = "STLTK:";
            // 
            // numericUpDown5
            // 
            this.numericUpDown5.Location = new System.Drawing.Point(586, 14);
            this.numericUpDown5.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.numericUpDown5.Name = "numericUpDown5";
            this.numericUpDown5.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown5.TabIndex = 50;
            this.numericUpDown5.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // tb_NAME_WHATAPP
            // 
            this.tb_NAME_WHATAPP.Location = new System.Drawing.Point(164, 17);
            this.tb_NAME_WHATAPP.Name = "tb_NAME_WHATAPP";
            this.tb_NAME_WHATAPP.Size = new System.Drawing.Size(317, 21);
            this.tb_NAME_WHATAPP.TabIndex = 49;
            // 
            // label186
            // 
            this.label186.AutoSize = true;
            this.label186.Location = new System.Drawing.Point(57, 20);
            this.label186.Name = "label186";
            this.label186.Size = new System.Drawing.Size(105, 15);
            this.label186.TabIndex = 48;
            this.label186.Text = "NAME WHATAPP:";
            // 
            // delay_kick_bm3
            // 
            this.delay_kick_bm3.Location = new System.Drawing.Point(586, 47);
            this.delay_kick_bm3.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.delay_kick_bm3.Name = "delay_kick_bm3";
            this.delay_kick_bm3.Size = new System.Drawing.Size(120, 21);
            this.delay_kick_bm3.TabIndex = 47;
            this.delay_kick_bm3.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // label185
            // 
            this.label185.AutoSize = true;
            this.label185.Location = new System.Drawing.Point(524, 49);
            this.label185.Name = "label185";
            this.label185.Size = new System.Drawing.Size(42, 15);
            this.label185.TabIndex = 46;
            this.label185.Text = "Delay:";
            // 
            // label184
            // 
            this.label184.AutoSize = true;
            this.label184.Location = new System.Drawing.Point(391, 94);
            this.label184.Name = "label184";
            this.label184.Size = new System.Drawing.Size(94, 15);
            this.label184.TabIndex = 45;
            this.label184.Text = "STATUS_KICK:";
            // 
            // rtb_status_kick
            // 
            this.rtb_status_kick.Location = new System.Drawing.Point(394, 112);
            this.rtb_status_kick.Name = "rtb_status_kick";
            this.rtb_status_kick.Size = new System.Drawing.Size(363, 266);
            this.rtb_status_kick.TabIndex = 44;
            this.rtb_status_kick.Text = "";
            // 
            // label183
            // 
            this.label183.AutoSize = true;
            this.label183.Location = new System.Drawing.Point(58, 94);
            this.label183.Name = "label183";
            this.label183.Size = new System.Drawing.Size(80, 15);
            this.label183.TabIndex = 43;
            this.label183.Text = "IDBM_KICK:";
            // 
            // rtb_IDBM_KICK_BM3
            // 
            this.rtb_IDBM_KICK_BM3.Location = new System.Drawing.Point(164, 112);
            this.rtb_IDBM_KICK_BM3.Name = "rtb_IDBM_KICK_BM3";
            this.rtb_IDBM_KICK_BM3.Size = new System.Drawing.Size(200, 266);
            this.rtb_IDBM_KICK_BM3.TabIndex = 42;
            this.rtb_IDBM_KICK_BM3.Text = "";
            // 
            // tb_TokenEEAG
            // 
            this.tb_TokenEEAG.Location = new System.Drawing.Point(164, 46);
            this.tb_TokenEEAG.Name = "tb_TokenEEAG";
            this.tb_TokenEEAG.Size = new System.Drawing.Size(317, 21);
            this.tb_TokenEEAG.TabIndex = 41;
            // 
            // label182
            // 
            this.label182.AutoSize = true;
            this.label182.Location = new System.Drawing.Point(58, 49);
            this.label182.Name = "label182";
            this.label182.Size = new System.Drawing.Size(81, 15);
            this.label182.TabIndex = 40;
            this.label182.Text = "Token_EEAG:";
            // 
            // tabPage13
            // 
            this.tabPage13.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.tabPage13.Controls.Add(this.label148);
            this.tabPage13.Controls.Add(this.bt_CLEAR_LINK);
            this.tabPage13.Controls.Add(this.label147);
            this.tabPage13.Controls.Add(this.bt_CLEAR_FAIL);
            this.tabPage13.Controls.Add(this.groupBox11);
            this.tabPage13.Controls.Add(this.label103);
            this.tabPage13.Controls.Add(this.label102);
            this.tabPage13.Controls.Add(this.rtbLINK);
            this.tabPage13.Controls.Add(this.rtb_Link_FAIL);
            this.tabPage13.Controls.Add(this.groupBox10);
            this.tabPage13.Location = new System.Drawing.Point(4, 24);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage13.Size = new System.Drawing.Size(1767, 688);
            this.tabPage13.TabIndex = 8;
            this.tabPage13.Text = "NHẬN LINK BM";
            // 
            // label148
            // 
            this.label148.AutoSize = true;
            this.label148.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label148.Location = new System.Drawing.Point(155, 316);
            this.label148.Name = "label148";
            this.label148.Size = new System.Drawing.Size(132, 15);
            this.label148.TabIndex = 204;
            this.label148.Text = "XÓA HẾT LINK NHẬN ";
            // 
            // bt_CLEAR_LINK
            // 
            this.bt_CLEAR_LINK.BackColor = System.Drawing.Color.LimeGreen;
            this.bt_CLEAR_LINK.Location = new System.Drawing.Point(55, 299);
            this.bt_CLEAR_LINK.Name = "bt_CLEAR_LINK";
            this.bt_CLEAR_LINK.Size = new System.Drawing.Size(75, 49);
            this.bt_CLEAR_LINK.TabIndex = 203;
            this.bt_CLEAR_LINK.Text = "CLEAR";
            this.bt_CLEAR_LINK.UseVisualStyleBackColor = false;
            this.bt_CLEAR_LINK.Click += new System.EventHandler(this.bt_CLEAR_LINK_Click);
            // 
            // label147
            // 
            this.label147.AutoSize = true;
            this.label147.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label147.Location = new System.Drawing.Point(155, 261);
            this.label147.Name = "label147";
            this.label147.Size = new System.Drawing.Size(157, 15);
            this.label147.TabIndex = 202;
            this.label147.Text = "XÓA HẾT LINK NHẬN FAIL";
            // 
            // bt_CLEAR_FAIL
            // 
            this.bt_CLEAR_FAIL.BackColor = System.Drawing.Color.Red;
            this.bt_CLEAR_FAIL.Location = new System.Drawing.Point(55, 244);
            this.bt_CLEAR_FAIL.Name = "bt_CLEAR_FAIL";
            this.bt_CLEAR_FAIL.Size = new System.Drawing.Size(75, 49);
            this.bt_CLEAR_FAIL.TabIndex = 201;
            this.bt_CLEAR_FAIL.Text = "CLEAR";
            this.bt_CLEAR_FAIL.UseVisualStyleBackColor = false;
            this.bt_CLEAR_FAIL.Click += new System.EventHandler(this.bt_CLEAR_FAIL_Click);
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label107);
            this.groupBox11.Controls.Add(this.label106);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_20);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_19);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_18);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_17);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_16);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_15);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_14);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_13);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_12);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_11);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_10);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_9);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_8);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_7);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_6);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_5);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_4);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_3);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_2);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_1);
            this.groupBox11.Controls.Add(this.label105);
            this.groupBox11.Controls.Add(this.label104);
            this.groupBox11.Location = new System.Drawing.Point(909, 23);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(822, 661);
            this.groupBox11.TabIndex = 43;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "1 VIA NHẬN NHIỀU LINK";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(644, 31);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(131, 15);
            this.label107.TabIndex = 66;
            this.label107.Text = "ACCOUNT 4,8,12,16,20";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(454, 34);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(130, 15);
            this.label106.TabIndex = 65;
            this.label106.Text = "ACCOUNT 3,7,11,15,19";
            // 
            // rtb_LINKBM_20
            // 
            this.rtb_LINKBM_20.Location = new System.Drawing.Point(616, 536);
            this.rtb_LINKBM_20.Name = "rtb_LINKBM_20";
            this.rtb_LINKBM_20.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_20.TabIndex = 64;
            this.rtb_LINKBM_20.Text = "";
            // 
            // rtb_LINKBM_19
            // 
            this.rtb_LINKBM_19.Location = new System.Drawing.Point(415, 536);
            this.rtb_LINKBM_19.Name = "rtb_LINKBM_19";
            this.rtb_LINKBM_19.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_19.TabIndex = 63;
            this.rtb_LINKBM_19.Text = "";
            // 
            // rtb_LINKBM_18
            // 
            this.rtb_LINKBM_18.Location = new System.Drawing.Point(214, 536);
            this.rtb_LINKBM_18.Name = "rtb_LINKBM_18";
            this.rtb_LINKBM_18.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_18.TabIndex = 62;
            this.rtb_LINKBM_18.Text = "";
            // 
            // rtb_LINKBM_17
            // 
            this.rtb_LINKBM_17.Location = new System.Drawing.Point(12, 536);
            this.rtb_LINKBM_17.Name = "rtb_LINKBM_17";
            this.rtb_LINKBM_17.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_17.TabIndex = 61;
            this.rtb_LINKBM_17.Text = "";
            // 
            // rtb_LINKBM_16
            // 
            this.rtb_LINKBM_16.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.rtb_LINKBM_16.Location = new System.Drawing.Point(616, 417);
            this.rtb_LINKBM_16.Name = "rtb_LINKBM_16";
            this.rtb_LINKBM_16.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_16.TabIndex = 60;
            this.rtb_LINKBM_16.Text = "";
            // 
            // rtb_LINKBM_15
            // 
            this.rtb_LINKBM_15.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.rtb_LINKBM_15.Location = new System.Drawing.Point(415, 417);
            this.rtb_LINKBM_15.Name = "rtb_LINKBM_15";
            this.rtb_LINKBM_15.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_15.TabIndex = 59;
            this.rtb_LINKBM_15.Text = "";
            // 
            // rtb_LINKBM_14
            // 
            this.rtb_LINKBM_14.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.rtb_LINKBM_14.Location = new System.Drawing.Point(214, 417);
            this.rtb_LINKBM_14.Name = "rtb_LINKBM_14";
            this.rtb_LINKBM_14.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_14.TabIndex = 58;
            this.rtb_LINKBM_14.Text = "";
            // 
            // rtb_LINKBM_13
            // 
            this.rtb_LINKBM_13.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.rtb_LINKBM_13.Location = new System.Drawing.Point(12, 417);
            this.rtb_LINKBM_13.Name = "rtb_LINKBM_13";
            this.rtb_LINKBM_13.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_13.TabIndex = 57;
            this.rtb_LINKBM_13.Text = "";
            // 
            // rtb_LINKBM_12
            // 
            this.rtb_LINKBM_12.Location = new System.Drawing.Point(616, 298);
            this.rtb_LINKBM_12.Name = "rtb_LINKBM_12";
            this.rtb_LINKBM_12.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_12.TabIndex = 56;
            this.rtb_LINKBM_12.Text = "";
            // 
            // rtb_LINKBM_11
            // 
            this.rtb_LINKBM_11.Location = new System.Drawing.Point(415, 298);
            this.rtb_LINKBM_11.Name = "rtb_LINKBM_11";
            this.rtb_LINKBM_11.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_11.TabIndex = 55;
            this.rtb_LINKBM_11.Text = "";
            // 
            // rtb_LINKBM_10
            // 
            this.rtb_LINKBM_10.Location = new System.Drawing.Point(214, 298);
            this.rtb_LINKBM_10.Name = "rtb_LINKBM_10";
            this.rtb_LINKBM_10.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_10.TabIndex = 54;
            this.rtb_LINKBM_10.Text = "";
            // 
            // rtb_LINKBM_9
            // 
            this.rtb_LINKBM_9.Location = new System.Drawing.Point(12, 298);
            this.rtb_LINKBM_9.Name = "rtb_LINKBM_9";
            this.rtb_LINKBM_9.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_9.TabIndex = 53;
            this.rtb_LINKBM_9.Text = "";
            // 
            // rtb_LINKBM_8
            // 
            this.rtb_LINKBM_8.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.rtb_LINKBM_8.Location = new System.Drawing.Point(616, 179);
            this.rtb_LINKBM_8.Name = "rtb_LINKBM_8";
            this.rtb_LINKBM_8.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_8.TabIndex = 52;
            this.rtb_LINKBM_8.Text = "";
            // 
            // rtb_LINKBM_7
            // 
            this.rtb_LINKBM_7.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.rtb_LINKBM_7.Location = new System.Drawing.Point(415, 179);
            this.rtb_LINKBM_7.Name = "rtb_LINKBM_7";
            this.rtb_LINKBM_7.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_7.TabIndex = 51;
            this.rtb_LINKBM_7.Text = "";
            // 
            // rtb_LINKBM_6
            // 
            this.rtb_LINKBM_6.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.rtb_LINKBM_6.Location = new System.Drawing.Point(214, 179);
            this.rtb_LINKBM_6.Name = "rtb_LINKBM_6";
            this.rtb_LINKBM_6.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_6.TabIndex = 50;
            this.rtb_LINKBM_6.Text = "";
            // 
            // rtb_LINKBM_5
            // 
            this.rtb_LINKBM_5.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.rtb_LINKBM_5.Location = new System.Drawing.Point(12, 179);
            this.rtb_LINKBM_5.Name = "rtb_LINKBM_5";
            this.rtb_LINKBM_5.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_5.TabIndex = 49;
            this.rtb_LINKBM_5.Text = "";
            // 
            // rtb_LINKBM_4
            // 
            this.rtb_LINKBM_4.Location = new System.Drawing.Point(616, 60);
            this.rtb_LINKBM_4.Name = "rtb_LINKBM_4";
            this.rtb_LINKBM_4.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_4.TabIndex = 48;
            this.rtb_LINKBM_4.Text = "";
            // 
            // rtb_LINKBM_3
            // 
            this.rtb_LINKBM_3.Location = new System.Drawing.Point(415, 60);
            this.rtb_LINKBM_3.Name = "rtb_LINKBM_3";
            this.rtb_LINKBM_3.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_3.TabIndex = 47;
            this.rtb_LINKBM_3.Text = "";
            // 
            // rtb_LINKBM_2
            // 
            this.rtb_LINKBM_2.Location = new System.Drawing.Point(214, 60);
            this.rtb_LINKBM_2.Name = "rtb_LINKBM_2";
            this.rtb_LINKBM_2.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_2.TabIndex = 46;
            this.rtb_LINKBM_2.Text = "";
            // 
            // rtb_LINKBM_1
            // 
            this.rtb_LINKBM_1.Location = new System.Drawing.Point(12, 60);
            this.rtb_LINKBM_1.Name = "rtb_LINKBM_1";
            this.rtb_LINKBM_1.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_1.TabIndex = 45;
            this.rtb_LINKBM_1.Text = "";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(243, 31);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(131, 15);
            this.label105.TabIndex = 43;
            this.label105.Text = "ACCOUNT 2,6,10,14,18";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(40, 31);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(125, 15);
            this.label104.TabIndex = 42;
            this.label104.Text = "ACCOUNT 1,5,9,13,17";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(666, 54);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(105, 15);
            this.label103.TabIndex = 42;
            this.label103.Text = "LINK    UID|LINK:";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(428, 54);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(137, 15);
            this.label102.TabIndex = 41;
            this.label102.Text = "LINK    UID|LINK FAIL!:";
            // 
            // rtbLINK
            // 
            this.rtbLINK.Location = new System.Drawing.Point(621, 83);
            this.rtbLINK.Name = "rtbLINK";
            this.rtbLINK.Size = new System.Drawing.Size(227, 493);
            this.rtbLINK.TabIndex = 2;
            this.rtbLINK.Text = "";
            // 
            // rtb_Link_FAIL
            // 
            this.rtb_Link_FAIL.Location = new System.Drawing.Point(379, 83);
            this.rtb_Link_FAIL.Name = "rtb_Link_FAIL";
            this.rtb_Link_FAIL.Size = new System.Drawing.Size(227, 493);
            this.rtb_Link_FAIL.TabIndex = 1;
            this.rtb_Link_FAIL.Text = "";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label101);
            this.groupBox10.Controls.Add(this.label100);
            this.groupBox10.Controls.Add(this.cmb_CACH_NHAN_LINK);
            this.groupBox10.Controls.Add(this.cmbAPI_Auto_selenium_NhanBM);
            this.groupBox10.Location = new System.Drawing.Point(44, 23);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(307, 173);
            this.groupBox10.TabIndex = 0;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "NHẬN BM";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(8, 63);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(78, 15);
            this.label101.TabIndex = 40;
            this.label101.Text = "NHẬN LINK:";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(8, 34);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(110, 15);
            this.label100.TabIndex = 39;
            this.label100.Text = "API/Auto selenium:";
            // 
            // cmb_CACH_NHAN_LINK
            // 
            this.cmb_CACH_NHAN_LINK.FormattingEnabled = true;
            this.cmb_CACH_NHAN_LINK.Location = new System.Drawing.Point(141, 60);
            this.cmb_CACH_NHAN_LINK.Name = "cmb_CACH_NHAN_LINK";
            this.cmb_CACH_NHAN_LINK.Size = new System.Drawing.Size(139, 23);
            this.cmb_CACH_NHAN_LINK.TabIndex = 1;
            // 
            // cmbAPI_Auto_selenium_NhanBM
            // 
            this.cmbAPI_Auto_selenium_NhanBM.FormattingEnabled = true;
            this.cmbAPI_Auto_selenium_NhanBM.Location = new System.Drawing.Point(141, 31);
            this.cmbAPI_Auto_selenium_NhanBM.Name = "cmbAPI_Auto_selenium_NhanBM";
            this.cmbAPI_Auto_selenium_NhanBM.Size = new System.Drawing.Size(139, 23);
            this.cmbAPI_Auto_selenium_NhanBM.TabIndex = 0;
            // 
            // tabPage14
            // 
            this.tabPage14.BackColor = System.Drawing.Color.Gray;
            this.tabPage14.Controls.Add(this.tabControl4);
            this.tabPage14.Location = new System.Drawing.Point(4, 24);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage14.Size = new System.Drawing.Size(1767, 688);
            this.tabPage14.TabIndex = 9;
            this.tabPage14.Text = "NHẬN BM AUTO";
            // 
            // tabControl4
            // 
            this.tabControl4.Controls.Add(this.tabPage15);
            this.tabControl4.Controls.Add(this.tabPage16);
            this.tabControl4.Controls.Add(this.tabPage17);
            this.tabControl4.Location = new System.Drawing.Point(0, 3);
            this.tabControl4.Name = "tabControl4";
            this.tabControl4.SelectedIndex = 0;
            this.tabControl4.Size = new System.Drawing.Size(1764, 689);
            this.tabControl4.TabIndex = 99;
            // 
            // tabPage15
            // 
            this.tabPage15.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage15.Controls.Add(this.label229);
            this.tabPage15.Controls.Add(this.cmb_ALL_FILE);
            this.tabPage15.Controls.Add(this.label216);
            this.tabPage15.Controls.Add(this.rtb_codemail);
            this.tabPage15.Controls.Add(this.cmb_file_random);
            this.tabPage15.Controls.Add(this.button5);
            this.tabPage15.Controls.Add(this.cmb_chi_doc_link_mail_ao);
            this.tabPage15.Controls.Add(this.label190);
            this.tabPage15.Controls.Add(this.label180);
            this.tabPage15.Controls.Add(this.label179);
            this.tabPage15.Controls.Add(this.rtb_mail_moakt_fail);
            this.tabPage15.Controls.Add(this.rtb_mail_moakt_done);
            this.tabPage15.Controls.Add(this.label178);
            this.tabPage15.Controls.Add(this.DELAY_DOC_MAIL);
            this.tabPage15.Controls.Add(this.label171);
            this.tabPage15.Controls.Add(this.cmb_loai_mail_nhan_bm_ig);
            this.tabPage15.Controls.Add(this.label166);
            this.tabPage15.Controls.Add(this.button4);
            this.tabPage15.Controls.Add(this.cmb_FILE_OPEN);
            this.tabPage15.Controls.Add(this.button3);
            this.tabPage15.Controls.Add(this.label146);
            this.tabPage15.Controls.Add(this.button2);
            this.tabPage15.Controls.Add(this.groupBox12);
            this.tabPage15.Controls.Add(this.label134);
            this.tabPage15.Controls.Add(this.label132);
            this.tabPage15.Controls.Add(this.rtb_mail_bm350_auto);
            this.tabPage15.Controls.Add(this.rtb_mail_bm50_auto);
            this.tabPage15.Controls.Add(this.rtb_BMIII_auto);
            this.tabPage15.Controls.Add(this.label131);
            this.tabPage15.Controls.Add(this.rtb_Link_BM350_IG_auto);
            this.tabPage15.Controls.Add(this.label130);
            this.tabPage15.Controls.Add(this.label129);
            this.tabPage15.Controls.Add(this.rtb_Link_BM50_IG_auto);
            this.tabPage15.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tabPage15.Location = new System.Drawing.Point(4, 24);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage15.Size = new System.Drawing.Size(1756, 661);
            this.tabPage15.TabIndex = 0;
            this.tabPage15.Text = "Hiển Thị";
            // 
            // label229
            // 
            this.label229.AutoSize = true;
            this.label229.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label229.Location = new System.Drawing.Point(1456, 521);
            this.label229.Name = "label229";
            this.label229.Size = new System.Drawing.Size(60, 15);
            this.label229.TabIndex = 227;
            this.label229.Text = "ALL FAIL:";
            // 
            // cmb_ALL_FILE
            // 
            this.cmb_ALL_FILE.FormattingEnabled = true;
            this.cmb_ALL_FILE.Location = new System.Drawing.Point(1453, 550);
            this.cmb_ALL_FILE.Name = "cmb_ALL_FILE";
            this.cmb_ALL_FILE.Size = new System.Drawing.Size(192, 23);
            this.cmb_ALL_FILE.TabIndex = 219;
            // 
            // label216
            // 
            this.label216.AutoSize = true;
            this.label216.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label216.Location = new System.Drawing.Point(8, 417);
            this.label216.Name = "label216";
            this.label216.Size = new System.Drawing.Size(79, 15);
            this.label216.TabIndex = 218;
            this.label216.Text = "CODE MAIL:";
            // 
            // rtb_codemail
            // 
            this.rtb_codemail.Location = new System.Drawing.Point(11, 446);
            this.rtb_codemail.Name = "rtb_codemail";
            this.rtb_codemail.Size = new System.Drawing.Size(134, 177);
            this.rtb_codemail.TabIndex = 217;
            this.rtb_codemail.Text = "";
            // 
            // cmb_file_random
            // 
            this.cmb_file_random.FormattingEnabled = true;
            this.cmb_file_random.Location = new System.Drawing.Point(1453, 485);
            this.cmb_file_random.Name = "cmb_file_random";
            this.cmb_file_random.Size = new System.Drawing.Size(192, 23);
            this.cmb_file_random.TabIndex = 216;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Fuchsia;
            this.button5.Location = new System.Drawing.Point(1365, 471);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 49);
            this.button5.TabIndex = 215;
            this.button5.Text = "RANDOM";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // cmb_chi_doc_link_mail_ao
            // 
            this.cmb_chi_doc_link_mail_ao.FormattingEnabled = true;
            this.cmb_chi_doc_link_mail_ao.Location = new System.Drawing.Point(9, 374);
            this.cmb_chi_doc_link_mail_ao.Name = "cmb_chi_doc_link_mail_ao";
            this.cmb_chi_doc_link_mail_ao.Size = new System.Drawing.Size(136, 23);
            this.cmb_chi_doc_link_mail_ao.TabIndex = 214;
            // 
            // label190
            // 
            this.label190.AutoSize = true;
            this.label190.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label190.Location = new System.Drawing.Point(8, 356);
            this.label190.Name = "label190";
            this.label190.Size = new System.Drawing.Size(149, 15);
            this.label190.TabIndex = 213;
            this.label190.Text = "CHỉ ĐỌC LINK MAIL ẢO:";
            // 
            // label180
            // 
            this.label180.AutoSize = true;
            this.label180.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label180.Location = new System.Drawing.Point(6, 142);
            this.label180.Name = "label180";
            this.label180.Size = new System.Drawing.Size(107, 15);
            this.label180.TabIndex = 212;
            this.label180.Text = "mail đăng ký done:";
            // 
            // label179
            // 
            this.label179.AutoSize = true;
            this.label179.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label179.Location = new System.Drawing.Point(6, 248);
            this.label179.Name = "label179";
            this.label179.Size = new System.Drawing.Size(100, 15);
            this.label179.TabIndex = 211;
            this.label179.Text = "mail đăng ký fail:";
            // 
            // rtb_mail_moakt_fail
            // 
            this.rtb_mail_moakt_fail.Location = new System.Drawing.Point(9, 266);
            this.rtb_mail_moakt_fail.Name = "rtb_mail_moakt_fail";
            this.rtb_mail_moakt_fail.Size = new System.Drawing.Size(136, 72);
            this.rtb_mail_moakt_fail.TabIndex = 210;
            this.rtb_mail_moakt_fail.Text = "";
            // 
            // rtb_mail_moakt_done
            // 
            this.rtb_mail_moakt_done.Location = new System.Drawing.Point(6, 160);
            this.rtb_mail_moakt_done.Name = "rtb_mail_moakt_done";
            this.rtb_mail_moakt_done.Size = new System.Drawing.Size(139, 72);
            this.rtb_mail_moakt_done.TabIndex = 209;
            this.rtb_mail_moakt_done.Text = "";
            // 
            // label178
            // 
            this.label178.AutoSize = true;
            this.label178.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label178.Location = new System.Drawing.Point(6, 66);
            this.label178.Name = "label178";
            this.label178.Size = new System.Drawing.Size(119, 15);
            this.label178.TabIndex = 208;
            this.label178.Text = "DELAY_DOC_MAIL:";
            // 
            // DELAY_DOC_MAIL
            // 
            this.DELAY_DOC_MAIL.Location = new System.Drawing.Point(9, 85);
            this.DELAY_DOC_MAIL.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.DELAY_DOC_MAIL.Name = "DELAY_DOC_MAIL";
            this.DELAY_DOC_MAIL.Size = new System.Drawing.Size(107, 21);
            this.DELAY_DOC_MAIL.TabIndex = 207;
            this.DELAY_DOC_MAIL.Value = new decimal(new int[] {
            90,
            0,
            0,
            0});
            // 
            // label171
            // 
            this.label171.AutoSize = true;
            this.label171.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label171.Location = new System.Drawing.Point(6, 13);
            this.label171.Name = "label171";
            this.label171.Size = new System.Drawing.Size(73, 15);
            this.label171.TabIndex = 206;
            this.label171.Text = "LOẠI MAIL:";
            // 
            // cmb_loai_mail_nhan_bm_ig
            // 
            this.cmb_loai_mail_nhan_bm_ig.FormattingEnabled = true;
            this.cmb_loai_mail_nhan_bm_ig.Location = new System.Drawing.Point(6, 40);
            this.cmb_loai_mail_nhan_bm_ig.Name = "cmb_loai_mail_nhan_bm_ig";
            this.cmb_loai_mail_nhan_bm_ig.Size = new System.Drawing.Size(110, 23);
            this.cmb_loai_mail_nhan_bm_ig.TabIndex = 205;
            // 
            // label166
            // 
            this.label166.AutoSize = true;
            this.label166.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label166.Location = new System.Drawing.Point(1456, 418);
            this.label166.Name = "label166";
            this.label166.Size = new System.Drawing.Size(167, 15);
            this.label166.TabIndex = 204;
            this.label166.Text = "XÓA HẾT LINK ĐANG NHẬN";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.LimeGreen;
            this.button4.Location = new System.Drawing.Point(1365, 401);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 49);
            this.button4.TabIndex = 203;
            this.button4.Text = "CLEAR";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // cmb_FILE_OPEN
            // 
            this.cmb_FILE_OPEN.FormattingEnabled = true;
            this.cmb_FILE_OPEN.Location = new System.Drawing.Point(1050, 88);
            this.cmb_FILE_OPEN.Name = "cmb_FILE_OPEN";
            this.cmb_FILE_OPEN.Size = new System.Drawing.Size(192, 23);
            this.cmb_FILE_OPEN.TabIndex = 202;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.DarkTurquoise;
            this.button3.Location = new System.Drawing.Point(947, 74);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 49);
            this.button3.TabIndex = 201;
            this.button3.Text = "MỞ FILE";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label146
            // 
            this.label146.AutoSize = true;
            this.label146.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label146.Location = new System.Drawing.Point(1047, 41);
            this.label146.Name = "label146";
            this.label146.Size = new System.Drawing.Size(157, 15);
            this.label146.TabIndex = 200;
            this.label146.Text = "XÓA HẾT LINK NHẬN FAIL";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Red;
            this.button2.Location = new System.Drawing.Point(947, 24);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 49);
            this.button2.TabIndex = 199;
            this.button2.Text = "CLEAR";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.numericUpDown8);
            this.groupBox12.Controls.Add(this.label223);
            this.groupBox12.Controls.Add(this.cmb_kologin_mail);
            this.groupBox12.Controls.Add(this.label221);
            this.groupBox12.Controls.Add(this.cmb_VIA_NHAN_VERRY);
            this.groupBox12.Controls.Add(this.label218);
            this.groupBox12.Controls.Add(this.num_STT_NHAN);
            this.groupBox12.Controls.Add(this.label217);
            this.groupBox12.Controls.Add(this.number_nhan_fail);
            this.groupBox12.Controls.Add(this.label202);
            this.groupBox12.Controls.Add(this.cmb_DIE_BM_CLEAR);
            this.groupBox12.Controls.Add(this.label201);
            this.groupBox12.Controls.Add(this.label188);
            this.groupBox12.Controls.Add(this.numericUpDown6);
            this.groupBox12.Controls.Add(this.label141);
            this.groupBox12.Controls.Add(this.CMB_LOAI_BM_NHAN);
            this.groupBox12.Controls.Add(this.cmb_STOP);
            this.groupBox12.Controls.Add(this.label135);
            this.groupBox12.Controls.Add(this.label136);
            this.groupBox12.Controls.Add(this.cmbAPI_Auto_selenium_NhanBM_IG);
            this.groupBox12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox12.Location = new System.Drawing.Point(1365, 13);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(307, 384);
            this.groupBox12.TabIndex = 198;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "NHẬN BM";
            // 
            // numericUpDown8
            // 
            this.numericUpDown8.Location = new System.Drawing.Point(141, 318);
            this.numericUpDown8.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.numericUpDown8.Name = "numericUpDown8";
            this.numericUpDown8.Size = new System.Drawing.Size(107, 21);
            this.numericUpDown8.TabIndex = 226;
            this.numericUpDown8.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // label223
            // 
            this.label223.AutoSize = true;
            this.label223.Location = new System.Drawing.Point(8, 322);
            this.label223.Name = "label223";
            this.label223.Size = new System.Drawing.Size(114, 15);
            this.label223.TabIndex = 225;
            this.label223.Text = "delay_entercodefail:";
            // 
            // cmb_kologin_mail
            // 
            this.cmb_kologin_mail.FormattingEnabled = true;
            this.cmb_kologin_mail.Location = new System.Drawing.Point(141, 289);
            this.cmb_kologin_mail.Name = "cmb_kologin_mail";
            this.cmb_kologin_mail.Size = new System.Drawing.Size(139, 23);
            this.cmb_kologin_mail.TabIndex = 224;
            // 
            // label221
            // 
            this.label221.AutoSize = true;
            this.label221.Location = new System.Drawing.Point(8, 296);
            this.label221.Name = "label221";
            this.label221.Size = new System.Drawing.Size(105, 15);
            this.label221.TabIndex = 223;
            this.label221.Text = "KO LOGIN MAIL:";
            // 
            // cmb_VIA_NHAN_VERRY
            // 
            this.cmb_VIA_NHAN_VERRY.FormattingEnabled = true;
            this.cmb_VIA_NHAN_VERRY.Location = new System.Drawing.Point(141, 260);
            this.cmb_VIA_NHAN_VERRY.Name = "cmb_VIA_NHAN_VERRY";
            this.cmb_VIA_NHAN_VERRY.Size = new System.Drawing.Size(139, 23);
            this.cmb_VIA_NHAN_VERRY.TabIndex = 222;
            // 
            // label218
            // 
            this.label218.AutoSize = true;
            this.label218.Location = new System.Drawing.Point(8, 267);
            this.label218.Name = "label218";
            this.label218.Size = new System.Drawing.Size(71, 15);
            this.label218.TabIndex = 221;
            this.label218.Text = "VIA VERRY:";
            // 
            // num_STT_NHAN
            // 
            this.num_STT_NHAN.Location = new System.Drawing.Point(141, 233);
            this.num_STT_NHAN.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.num_STT_NHAN.Name = "num_STT_NHAN";
            this.num_STT_NHAN.Size = new System.Drawing.Size(107, 21);
            this.num_STT_NHAN.TabIndex = 220;
            // 
            // label217
            // 
            this.label217.AutoSize = true;
            this.label217.Location = new System.Drawing.Point(8, 235);
            this.label217.Name = "label217";
            this.label217.Size = new System.Drawing.Size(69, 15);
            this.label217.TabIndex = 219;
            this.label217.Text = "STT NHẬN";
            // 
            // number_nhan_fail
            // 
            this.number_nhan_fail.Location = new System.Drawing.Point(141, 202);
            this.number_nhan_fail.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.number_nhan_fail.Name = "number_nhan_fail";
            this.number_nhan_fail.Size = new System.Drawing.Size(107, 21);
            this.number_nhan_fail.TabIndex = 218;
            this.number_nhan_fail.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label202
            // 
            this.label202.AutoSize = true;
            this.label202.Location = new System.Drawing.Point(8, 204);
            this.label202.Name = "label202";
            this.label202.Size = new System.Drawing.Size(133, 15);
            this.label202.TabIndex = 217;
            this.label202.Text = "GIỚI HẠN NHẬN FAIL:";
            // 
            // cmb_DIE_BM_CLEAR
            // 
            this.cmb_DIE_BM_CLEAR.FormattingEnabled = true;
            this.cmb_DIE_BM_CLEAR.Location = new System.Drawing.Point(141, 173);
            this.cmb_DIE_BM_CLEAR.Name = "cmb_DIE_BM_CLEAR";
            this.cmb_DIE_BM_CLEAR.Size = new System.Drawing.Size(139, 23);
            this.cmb_DIE_BM_CLEAR.TabIndex = 216;
            // 
            // label201
            // 
            this.label201.AutoSize = true;
            this.label201.Location = new System.Drawing.Point(8, 176);
            this.label201.Name = "label201";
            this.label201.Size = new System.Drawing.Size(95, 15);
            this.label201.TabIndex = 215;
            this.label201.Text = "BM DIE CLEAR:";
            // 
            // label188
            // 
            this.label188.AutoSize = true;
            this.label188.Location = new System.Drawing.Point(8, 145);
            this.label188.Name = "label188";
            this.label188.Size = new System.Drawing.Size(93, 15);
            this.label188.TabIndex = 213;
            this.label188.Text = "Delay nhan API:";
            // 
            // numericUpDown6
            // 
            this.numericUpDown6.Location = new System.Drawing.Point(141, 139);
            this.numericUpDown6.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.numericUpDown6.Name = "numericUpDown6";
            this.numericUpDown6.Size = new System.Drawing.Size(107, 21);
            this.numericUpDown6.TabIndex = 214;
            this.numericUpDown6.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.Location = new System.Drawing.Point(8, 113);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(100, 15);
            this.label141.TabIndex = 43;
            this.label141.Text = "LOẠI BM NHẬN:";
            // 
            // CMB_LOAI_BM_NHAN
            // 
            this.CMB_LOAI_BM_NHAN.FormattingEnabled = true;
            this.CMB_LOAI_BM_NHAN.Location = new System.Drawing.Point(141, 110);
            this.CMB_LOAI_BM_NHAN.Name = "CMB_LOAI_BM_NHAN";
            this.CMB_LOAI_BM_NHAN.Size = new System.Drawing.Size(139, 23);
            this.CMB_LOAI_BM_NHAN.TabIndex = 42;
            // 
            // cmb_STOP
            // 
            this.cmb_STOP.FormattingEnabled = true;
            this.cmb_STOP.Location = new System.Drawing.Point(141, 70);
            this.cmb_STOP.Name = "cmb_STOP";
            this.cmb_STOP.Size = new System.Drawing.Size(139, 23);
            this.cmb_STOP.TabIndex = 41;
            // 
            // label135
            // 
            this.label135.AutoSize = true;
            this.label135.Location = new System.Drawing.Point(8, 78);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(44, 15);
            this.label135.TabIndex = 40;
            this.label135.Text = "STOP:";
            // 
            // label136
            // 
            this.label136.AutoSize = true;
            this.label136.Location = new System.Drawing.Point(8, 34);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(110, 15);
            this.label136.TabIndex = 39;
            this.label136.Text = "API/Auto selenium:";
            // 
            // cmbAPI_Auto_selenium_NhanBM_IG
            // 
            this.cmbAPI_Auto_selenium_NhanBM_IG.FormattingEnabled = true;
            this.cmbAPI_Auto_selenium_NhanBM_IG.Location = new System.Drawing.Point(141, 31);
            this.cmbAPI_Auto_selenium_NhanBM_IG.Name = "cmbAPI_Auto_selenium_NhanBM_IG";
            this.cmbAPI_Auto_selenium_NhanBM_IG.Size = new System.Drawing.Size(139, 23);
            this.cmbAPI_Auto_selenium_NhanBM_IG.TabIndex = 0;
            // 
            // label134
            // 
            this.label134.AutoSize = true;
            this.label134.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label134.Location = new System.Drawing.Point(520, 13);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(80, 15);
            this.label134.TabIndex = 197;
            this.label134.Text = "MAIL BM350:";
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label132.Location = new System.Drawing.Point(134, 13);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(74, 15);
            this.label132.TabIndex = 195;
            this.label132.Text = "MAIL BM50:";
            // 
            // rtb_mail_bm350_auto
            // 
            this.rtb_mail_bm350_auto.Location = new System.Drawing.Point(586, 40);
            this.rtb_mail_bm350_auto.Name = "rtb_mail_bm350_auto";
            this.rtb_mail_bm350_auto.Size = new System.Drawing.Size(280, 72);
            this.rtb_mail_bm350_auto.TabIndex = 194;
            this.rtb_mail_bm350_auto.Text = "";
            // 
            // rtb_mail_bm50_auto
            // 
            this.rtb_mail_bm50_auto.Location = new System.Drawing.Point(170, 40);
            this.rtb_mail_bm50_auto.Name = "rtb_mail_bm50_auto";
            this.rtb_mail_bm50_auto.Size = new System.Drawing.Size(280, 72);
            this.rtb_mail_bm50_auto.TabIndex = 193;
            this.rtb_mail_bm50_auto.Text = "";
            // 
            // rtb_BMIII_auto
            // 
            this.rtb_BMIII_auto.Location = new System.Drawing.Point(1020, 160);
            this.rtb_BMIII_auto.Name = "rtb_BMIII_auto";
            this.rtb_BMIII_auto.Size = new System.Drawing.Size(280, 442);
            this.rtb_BMIII_auto.TabIndex = 192;
            this.rtb_BMIII_auto.Text = "";
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label131.Location = new System.Drawing.Point(954, 131);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(79, 15);
            this.label131.TabIndex = 191;
            this.label131.Text = "LINK THỨ 3:";
            // 
            // rtb_Link_BM350_IG_auto
            // 
            this.rtb_Link_BM350_IG_auto.Location = new System.Drawing.Point(586, 160);
            this.rtb_Link_BM350_IG_auto.Name = "rtb_Link_BM350_IG_auto";
            this.rtb_Link_BM350_IG_auto.Size = new System.Drawing.Size(280, 442);
            this.rtb_Link_BM350_IG_auto.TabIndex = 190;
            this.rtb_Link_BM350_IG_auto.Text = "";
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label130.Location = new System.Drawing.Point(520, 131);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(80, 15);
            this.label130.TabIndex = 189;
            this.label130.Text = "LINK BM350:";
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label129.Location = new System.Drawing.Point(134, 131);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(74, 15);
            this.label129.TabIndex = 188;
            this.label129.Text = "LINK BM50:";
            // 
            // rtb_Link_BM50_IG_auto
            // 
            this.rtb_Link_BM50_IG_auto.Location = new System.Drawing.Point(170, 160);
            this.rtb_Link_BM50_IG_auto.Name = "rtb_Link_BM50_IG_auto";
            this.rtb_Link_BM50_IG_auto.Size = new System.Drawing.Size(280, 442);
            this.rtb_Link_BM50_IG_auto.TabIndex = 0;
            this.rtb_Link_BM50_IG_auto.Text = "";
            // 
            // tabPage16
            // 
            this.tabPage16.BackColor = System.Drawing.Color.Gray;
            this.tabPage16.Controls.Add(this.tb_nhan20);
            this.tabPage16.Controls.Add(this.tb_20);
            this.tabPage16.Controls.Add(this.tb_nhan16);
            this.tabPage16.Controls.Add(this.tb_16);
            this.tabPage16.Controls.Add(this.tb_nhan12);
            this.tabPage16.Controls.Add(this.tb_12);
            this.tabPage16.Controls.Add(this.tb_nhan8);
            this.tabPage16.Controls.Add(this.tb_8);
            this.tabPage16.Controls.Add(this.tb_nhan4);
            this.tabPage16.Controls.Add(this.tb_4);
            this.tabPage16.Controls.Add(this.tb_nhan19);
            this.tabPage16.Controls.Add(this.tb_19);
            this.tabPage16.Controls.Add(this.tb_nhan15);
            this.tabPage16.Controls.Add(this.tb_15);
            this.tabPage16.Controls.Add(this.tb_nhan11);
            this.tabPage16.Controls.Add(this.tb_11);
            this.tabPage16.Controls.Add(this.tb_nhan7);
            this.tabPage16.Controls.Add(this.tb_7);
            this.tabPage16.Controls.Add(this.tb_nhan3);
            this.tabPage16.Controls.Add(this.tb_3);
            this.tabPage16.Controls.Add(this.tb_nhan18);
            this.tabPage16.Controls.Add(this.tb_18);
            this.tabPage16.Controls.Add(this.tb_nhan14);
            this.tabPage16.Controls.Add(this.tb_14);
            this.tabPage16.Controls.Add(this.tb_nhan10);
            this.tabPage16.Controls.Add(this.tb_10);
            this.tabPage16.Controls.Add(this.tb_nhan6);
            this.tabPage16.Controls.Add(this.tb_6);
            this.tabPage16.Controls.Add(this.tb_nhan2);
            this.tabPage16.Controls.Add(this.tb_2);
            this.tabPage16.Controls.Add(this.tb_nhan17);
            this.tabPage16.Controls.Add(this.tb_17);
            this.tabPage16.Controls.Add(this.tb_nhan13);
            this.tabPage16.Controls.Add(this.tb_13);
            this.tabPage16.Controls.Add(this.tb_nhan9);
            this.tabPage16.Controls.Add(this.tb_9);
            this.tabPage16.Controls.Add(this.tb_nhan5);
            this.tabPage16.Controls.Add(this.tb_5);
            this.tabPage16.Controls.Add(this.tb_nhan1);
            this.tabPage16.Controls.Add(this.tb_1);
            this.tabPage16.Controls.Add(this.label118);
            this.tabPage16.Controls.Add(this.label117);
            this.tabPage16.Controls.Add(this.label116);
            this.tabPage16.Controls.Add(this.label115);
            this.tabPage16.Controls.Add(this.label114);
            this.tabPage16.Controls.Add(this.label113);
            this.tabPage16.Controls.Add(this.label112);
            this.tabPage16.Controls.Add(this.label111);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_19);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_20);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_20);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_19);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_15);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_16);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_16);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_15);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_11);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_12);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_12);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_11);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_7);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_8);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_8);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_7);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_3);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_4);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_4);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_3);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_17);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_18);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_18);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_17);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_13);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_14);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_14);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_13);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_9);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_10);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_10);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_9);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_5);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_6);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_6);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_5);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_1);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_2);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_2);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_1);
            this.tabPage16.Location = new System.Drawing.Point(4, 24);
            this.tabPage16.Name = "tabPage16";
            this.tabPage16.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage16.Size = new System.Drawing.Size(1756, 661);
            this.tabPage16.TabIndex = 1;
            this.tabPage16.Text = "VIA NHẬN BM 1-20";
            // 
            // tb_nhan20
            // 
            this.tb_nhan20.Location = new System.Drawing.Point(1314, 589);
            this.tb_nhan20.Name = "tb_nhan20";
            this.tb_nhan20.Size = new System.Drawing.Size(32, 21);
            this.tb_nhan20.TabIndex = 234;
            // 
            // tb_20
            // 
            this.tb_20.Location = new System.Drawing.Point(1315, 562);
            this.tb_20.Name = "tb_20";
            this.tb_20.Size = new System.Drawing.Size(31, 21);
            this.tb_20.TabIndex = 233;
            // 
            // tb_nhan16
            // 
            this.tb_nhan16.Location = new System.Drawing.Point(1315, 462);
            this.tb_nhan16.Name = "tb_nhan16";
            this.tb_nhan16.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan16.TabIndex = 232;
            // 
            // tb_16
            // 
            this.tb_16.Location = new System.Drawing.Point(1316, 435);
            this.tb_16.Name = "tb_16";
            this.tb_16.Size = new System.Drawing.Size(30, 21);
            this.tb_16.TabIndex = 231;
            // 
            // tb_nhan12
            // 
            this.tb_nhan12.Location = new System.Drawing.Point(1316, 347);
            this.tb_nhan12.Name = "tb_nhan12";
            this.tb_nhan12.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan12.TabIndex = 230;
            // 
            // tb_12
            // 
            this.tb_12.Location = new System.Drawing.Point(1317, 320);
            this.tb_12.Name = "tb_12";
            this.tb_12.Size = new System.Drawing.Size(30, 21);
            this.tb_12.TabIndex = 229;
            // 
            // tb_nhan8
            // 
            this.tb_nhan8.Location = new System.Drawing.Point(1316, 223);
            this.tb_nhan8.Name = "tb_nhan8";
            this.tb_nhan8.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan8.TabIndex = 228;
            // 
            // tb_8
            // 
            this.tb_8.Location = new System.Drawing.Point(1317, 196);
            this.tb_8.Name = "tb_8";
            this.tb_8.Size = new System.Drawing.Size(30, 21);
            this.tb_8.TabIndex = 227;
            // 
            // tb_nhan4
            // 
            this.tb_nhan4.Location = new System.Drawing.Point(1316, 89);
            this.tb_nhan4.Name = "tb_nhan4";
            this.tb_nhan4.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan4.TabIndex = 226;
            // 
            // tb_4
            // 
            this.tb_4.Location = new System.Drawing.Point(1317, 62);
            this.tb_4.Name = "tb_4";
            this.tb_4.Size = new System.Drawing.Size(30, 21);
            this.tb_4.TabIndex = 225;
            // 
            // tb_nhan19
            // 
            this.tb_nhan19.Location = new System.Drawing.Point(877, 589);
            this.tb_nhan19.Name = "tb_nhan19";
            this.tb_nhan19.Size = new System.Drawing.Size(32, 21);
            this.tb_nhan19.TabIndex = 224;
            // 
            // tb_19
            // 
            this.tb_19.Location = new System.Drawing.Point(878, 562);
            this.tb_19.Name = "tb_19";
            this.tb_19.Size = new System.Drawing.Size(31, 21);
            this.tb_19.TabIndex = 223;
            // 
            // tb_nhan15
            // 
            this.tb_nhan15.Location = new System.Drawing.Point(878, 462);
            this.tb_nhan15.Name = "tb_nhan15";
            this.tb_nhan15.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan15.TabIndex = 222;
            // 
            // tb_15
            // 
            this.tb_15.Location = new System.Drawing.Point(879, 435);
            this.tb_15.Name = "tb_15";
            this.tb_15.Size = new System.Drawing.Size(30, 21);
            this.tb_15.TabIndex = 221;
            // 
            // tb_nhan11
            // 
            this.tb_nhan11.Location = new System.Drawing.Point(879, 347);
            this.tb_nhan11.Name = "tb_nhan11";
            this.tb_nhan11.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan11.TabIndex = 220;
            // 
            // tb_11
            // 
            this.tb_11.Location = new System.Drawing.Point(880, 320);
            this.tb_11.Name = "tb_11";
            this.tb_11.Size = new System.Drawing.Size(30, 21);
            this.tb_11.TabIndex = 219;
            // 
            // tb_nhan7
            // 
            this.tb_nhan7.Location = new System.Drawing.Point(879, 223);
            this.tb_nhan7.Name = "tb_nhan7";
            this.tb_nhan7.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan7.TabIndex = 218;
            // 
            // tb_7
            // 
            this.tb_7.Location = new System.Drawing.Point(880, 196);
            this.tb_7.Name = "tb_7";
            this.tb_7.Size = new System.Drawing.Size(30, 21);
            this.tb_7.TabIndex = 217;
            // 
            // tb_nhan3
            // 
            this.tb_nhan3.Location = new System.Drawing.Point(879, 89);
            this.tb_nhan3.Name = "tb_nhan3";
            this.tb_nhan3.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan3.TabIndex = 216;
            // 
            // tb_3
            // 
            this.tb_3.Location = new System.Drawing.Point(880, 62);
            this.tb_3.Name = "tb_3";
            this.tb_3.Size = new System.Drawing.Size(30, 21);
            this.tb_3.TabIndex = 215;
            // 
            // tb_nhan18
            // 
            this.tb_nhan18.Location = new System.Drawing.Point(444, 589);
            this.tb_nhan18.Name = "tb_nhan18";
            this.tb_nhan18.Size = new System.Drawing.Size(32, 21);
            this.tb_nhan18.TabIndex = 214;
            // 
            // tb_18
            // 
            this.tb_18.Location = new System.Drawing.Point(445, 562);
            this.tb_18.Name = "tb_18";
            this.tb_18.Size = new System.Drawing.Size(31, 21);
            this.tb_18.TabIndex = 213;
            // 
            // tb_nhan14
            // 
            this.tb_nhan14.Location = new System.Drawing.Point(445, 462);
            this.tb_nhan14.Name = "tb_nhan14";
            this.tb_nhan14.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan14.TabIndex = 212;
            // 
            // tb_14
            // 
            this.tb_14.Location = new System.Drawing.Point(446, 435);
            this.tb_14.Name = "tb_14";
            this.tb_14.Size = new System.Drawing.Size(30, 21);
            this.tb_14.TabIndex = 211;
            // 
            // tb_nhan10
            // 
            this.tb_nhan10.Location = new System.Drawing.Point(446, 347);
            this.tb_nhan10.Name = "tb_nhan10";
            this.tb_nhan10.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan10.TabIndex = 210;
            // 
            // tb_10
            // 
            this.tb_10.Location = new System.Drawing.Point(447, 320);
            this.tb_10.Name = "tb_10";
            this.tb_10.Size = new System.Drawing.Size(30, 21);
            this.tb_10.TabIndex = 209;
            // 
            // tb_nhan6
            // 
            this.tb_nhan6.Location = new System.Drawing.Point(446, 223);
            this.tb_nhan6.Name = "tb_nhan6";
            this.tb_nhan6.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan6.TabIndex = 208;
            // 
            // tb_6
            // 
            this.tb_6.Location = new System.Drawing.Point(447, 196);
            this.tb_6.Name = "tb_6";
            this.tb_6.Size = new System.Drawing.Size(30, 21);
            this.tb_6.TabIndex = 207;
            // 
            // tb_nhan2
            // 
            this.tb_nhan2.Location = new System.Drawing.Point(446, 89);
            this.tb_nhan2.Name = "tb_nhan2";
            this.tb_nhan2.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan2.TabIndex = 206;
            // 
            // tb_2
            // 
            this.tb_2.Location = new System.Drawing.Point(447, 62);
            this.tb_2.Name = "tb_2";
            this.tb_2.Size = new System.Drawing.Size(30, 21);
            this.tb_2.TabIndex = 205;
            // 
            // tb_nhan17
            // 
            this.tb_nhan17.Location = new System.Drawing.Point(5, 589);
            this.tb_nhan17.Name = "tb_nhan17";
            this.tb_nhan17.Size = new System.Drawing.Size(32, 21);
            this.tb_nhan17.TabIndex = 204;
            // 
            // tb_17
            // 
            this.tb_17.Location = new System.Drawing.Point(6, 562);
            this.tb_17.Name = "tb_17";
            this.tb_17.Size = new System.Drawing.Size(31, 21);
            this.tb_17.TabIndex = 203;
            // 
            // tb_nhan13
            // 
            this.tb_nhan13.Location = new System.Drawing.Point(6, 462);
            this.tb_nhan13.Name = "tb_nhan13";
            this.tb_nhan13.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan13.TabIndex = 202;
            // 
            // tb_13
            // 
            this.tb_13.Location = new System.Drawing.Point(7, 435);
            this.tb_13.Name = "tb_13";
            this.tb_13.Size = new System.Drawing.Size(30, 21);
            this.tb_13.TabIndex = 201;
            // 
            // tb_nhan9
            // 
            this.tb_nhan9.Location = new System.Drawing.Point(7, 347);
            this.tb_nhan9.Name = "tb_nhan9";
            this.tb_nhan9.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan9.TabIndex = 200;
            // 
            // tb_9
            // 
            this.tb_9.Location = new System.Drawing.Point(8, 320);
            this.tb_9.Name = "tb_9";
            this.tb_9.Size = new System.Drawing.Size(30, 21);
            this.tb_9.TabIndex = 199;
            // 
            // tb_nhan5
            // 
            this.tb_nhan5.Location = new System.Drawing.Point(7, 223);
            this.tb_nhan5.Name = "tb_nhan5";
            this.tb_nhan5.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan5.TabIndex = 198;
            // 
            // tb_5
            // 
            this.tb_5.Location = new System.Drawing.Point(8, 196);
            this.tb_5.Name = "tb_5";
            this.tb_5.Size = new System.Drawing.Size(30, 21);
            this.tb_5.TabIndex = 197;
            // 
            // tb_nhan1
            // 
            this.tb_nhan1.Location = new System.Drawing.Point(7, 89);
            this.tb_nhan1.Name = "tb_nhan1";
            this.tb_nhan1.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan1.TabIndex = 196;
            // 
            // tb_1
            // 
            this.tb_1.Location = new System.Drawing.Point(8, 62);
            this.tb_1.Name = "tb_1";
            this.tb_1.Size = new System.Drawing.Size(30, 21);
            this.tb_1.TabIndex = 195;
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Location = new System.Drawing.Point(1584, 20);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(126, 15);
            this.label118.TabIndex = 194;
            this.label118.Text = "LINK FAIL 4,8,12,16,20";
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Location = new System.Drawing.Point(1143, 20);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(125, 15);
            this.label117.TabIndex = 193;
            this.label117.Text = "LINK FAIL 3,7,11,15,19";
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Location = new System.Drawing.Point(710, 20);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(126, 15);
            this.label116.TabIndex = 192;
            this.label116.Text = "LINK FAIL 2,6,10,14,18";
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Location = new System.Drawing.Point(275, 20);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(120, 15);
            this.label115.TabIndex = 191;
            this.label115.Text = "LINK FAIL 1,5,9,13,17";
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Location = new System.Drawing.Point(1346, 20);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(131, 15);
            this.label114.TabIndex = 190;
            this.label114.Text = "ACCOUNT 4,8,12,16,20";
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Location = new System.Drawing.Point(912, 20);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(130, 15);
            this.label113.TabIndex = 189;
            this.label113.Text = "ACCOUNT 3,7,11,15,19";
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Location = new System.Drawing.Point(503, 20);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(131, 15);
            this.label112.TabIndex = 188;
            this.label112.Text = "ACCOUNT 2,6,10,14,18";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(64, 20);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(125, 15);
            this.label111.TabIndex = 187;
            this.label111.Text = "ACCOUNT 1,5,9,13,17";
            // 
            // rtb_LINKBMFAIL_IG_19
            // 
            this.rtb_LINKBMFAIL_IG_19.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_19.Location = new System.Drawing.Point(1116, 527);
            this.rtb_LINKBMFAIL_IG_19.Name = "rtb_LINKBMFAIL_IG_19";
            this.rtb_LINKBMFAIL_IG_19.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_19.TabIndex = 186;
            this.rtb_LINKBMFAIL_IG_19.Text = "";
            // 
            // rtb_LINKBM_IG_20
            // 
            this.rtb_LINKBM_IG_20.Location = new System.Drawing.Point(1349, 527);
            this.rtb_LINKBM_IG_20.Name = "rtb_LINKBM_IG_20";
            this.rtb_LINKBM_IG_20.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_20.TabIndex = 185;
            this.rtb_LINKBM_IG_20.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_20
            // 
            this.rtb_LINKBMFAIL_IG_20.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_20.Location = new System.Drawing.Point(1553, 527);
            this.rtb_LINKBMFAIL_IG_20.Name = "rtb_LINKBMFAIL_IG_20";
            this.rtb_LINKBMFAIL_IG_20.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_20.TabIndex = 184;
            this.rtb_LINKBMFAIL_IG_20.Text = "";
            // 
            // rtb_LINKBM_IG_19
            // 
            this.rtb_LINKBM_IG_19.Location = new System.Drawing.Point(915, 527);
            this.rtb_LINKBM_IG_19.Name = "rtb_LINKBM_IG_19";
            this.rtb_LINKBM_IG_19.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_19.TabIndex = 183;
            this.rtb_LINKBM_IG_19.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_15
            // 
            this.rtb_LINKBMFAIL_IG_15.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_15.Location = new System.Drawing.Point(1116, 408);
            this.rtb_LINKBMFAIL_IG_15.Name = "rtb_LINKBMFAIL_IG_15";
            this.rtb_LINKBMFAIL_IG_15.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_15.TabIndex = 182;
            this.rtb_LINKBMFAIL_IG_15.Text = "";
            // 
            // rtb_LINKBM_IG_16
            // 
            this.rtb_LINKBM_IG_16.Location = new System.Drawing.Point(1349, 408);
            this.rtb_LINKBM_IG_16.Name = "rtb_LINKBM_IG_16";
            this.rtb_LINKBM_IG_16.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_16.TabIndex = 181;
            this.rtb_LINKBM_IG_16.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_16
            // 
            this.rtb_LINKBMFAIL_IG_16.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_16.Location = new System.Drawing.Point(1553, 408);
            this.rtb_LINKBMFAIL_IG_16.Name = "rtb_LINKBMFAIL_IG_16";
            this.rtb_LINKBMFAIL_IG_16.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_16.TabIndex = 180;
            this.rtb_LINKBMFAIL_IG_16.Text = "";
            // 
            // rtb_LINKBM_IG_15
            // 
            this.rtb_LINKBM_IG_15.Location = new System.Drawing.Point(915, 408);
            this.rtb_LINKBM_IG_15.Name = "rtb_LINKBM_IG_15";
            this.rtb_LINKBM_IG_15.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_15.TabIndex = 179;
            this.rtb_LINKBM_IG_15.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_11
            // 
            this.rtb_LINKBMFAIL_IG_11.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_11.Location = new System.Drawing.Point(1116, 289);
            this.rtb_LINKBMFAIL_IG_11.Name = "rtb_LINKBMFAIL_IG_11";
            this.rtb_LINKBMFAIL_IG_11.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_11.TabIndex = 178;
            this.rtb_LINKBMFAIL_IG_11.Text = "";
            // 
            // rtb_LINKBM_IG_12
            // 
            this.rtb_LINKBM_IG_12.Location = new System.Drawing.Point(1349, 289);
            this.rtb_LINKBM_IG_12.Name = "rtb_LINKBM_IG_12";
            this.rtb_LINKBM_IG_12.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_12.TabIndex = 177;
            this.rtb_LINKBM_IG_12.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_12
            // 
            this.rtb_LINKBMFAIL_IG_12.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_12.Location = new System.Drawing.Point(1553, 289);
            this.rtb_LINKBMFAIL_IG_12.Name = "rtb_LINKBMFAIL_IG_12";
            this.rtb_LINKBMFAIL_IG_12.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_12.TabIndex = 176;
            this.rtb_LINKBMFAIL_IG_12.Text = "";
            // 
            // rtb_LINKBM_IG_11
            // 
            this.rtb_LINKBM_IG_11.Location = new System.Drawing.Point(915, 289);
            this.rtb_LINKBM_IG_11.Name = "rtb_LINKBM_IG_11";
            this.rtb_LINKBM_IG_11.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_11.TabIndex = 175;
            this.rtb_LINKBM_IG_11.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_7
            // 
            this.rtb_LINKBMFAIL_IG_7.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_7.Location = new System.Drawing.Point(1116, 170);
            this.rtb_LINKBMFAIL_IG_7.Name = "rtb_LINKBMFAIL_IG_7";
            this.rtb_LINKBMFAIL_IG_7.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_7.TabIndex = 174;
            this.rtb_LINKBMFAIL_IG_7.Text = "";
            // 
            // rtb_LINKBM_IG_8
            // 
            this.rtb_LINKBM_IG_8.Location = new System.Drawing.Point(1349, 170);
            this.rtb_LINKBM_IG_8.Name = "rtb_LINKBM_IG_8";
            this.rtb_LINKBM_IG_8.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_8.TabIndex = 173;
            this.rtb_LINKBM_IG_8.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_8
            // 
            this.rtb_LINKBMFAIL_IG_8.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_8.Location = new System.Drawing.Point(1553, 170);
            this.rtb_LINKBMFAIL_IG_8.Name = "rtb_LINKBMFAIL_IG_8";
            this.rtb_LINKBMFAIL_IG_8.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_8.TabIndex = 172;
            this.rtb_LINKBMFAIL_IG_8.Text = "";
            // 
            // rtb_LINKBM_IG_7
            // 
            this.rtb_LINKBM_IG_7.Location = new System.Drawing.Point(915, 170);
            this.rtb_LINKBM_IG_7.Name = "rtb_LINKBM_IG_7";
            this.rtb_LINKBM_IG_7.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_7.TabIndex = 171;
            this.rtb_LINKBM_IG_7.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_3
            // 
            this.rtb_LINKBMFAIL_IG_3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_3.Location = new System.Drawing.Point(1116, 51);
            this.rtb_LINKBMFAIL_IG_3.Name = "rtb_LINKBMFAIL_IG_3";
            this.rtb_LINKBMFAIL_IG_3.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_3.TabIndex = 170;
            this.rtb_LINKBMFAIL_IG_3.Text = "";
            // 
            // rtb_LINKBM_IG_4
            // 
            this.rtb_LINKBM_IG_4.Location = new System.Drawing.Point(1349, 51);
            this.rtb_LINKBM_IG_4.Name = "rtb_LINKBM_IG_4";
            this.rtb_LINKBM_IG_4.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_4.TabIndex = 169;
            this.rtb_LINKBM_IG_4.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_4
            // 
            this.rtb_LINKBMFAIL_IG_4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_4.Location = new System.Drawing.Point(1553, 51);
            this.rtb_LINKBMFAIL_IG_4.Name = "rtb_LINKBMFAIL_IG_4";
            this.rtb_LINKBMFAIL_IG_4.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_4.TabIndex = 168;
            this.rtb_LINKBMFAIL_IG_4.Text = "";
            // 
            // rtb_LINKBM_IG_3
            // 
            this.rtb_LINKBM_IG_3.Location = new System.Drawing.Point(915, 51);
            this.rtb_LINKBM_IG_3.Name = "rtb_LINKBM_IG_3";
            this.rtb_LINKBM_IG_3.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_3.TabIndex = 167;
            this.rtb_LINKBM_IG_3.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_17
            // 
            this.rtb_LINKBMFAIL_IG_17.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_17.Location = new System.Drawing.Point(245, 527);
            this.rtb_LINKBMFAIL_IG_17.Name = "rtb_LINKBMFAIL_IG_17";
            this.rtb_LINKBMFAIL_IG_17.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_17.TabIndex = 166;
            this.rtb_LINKBMFAIL_IG_17.Text = "";
            // 
            // rtb_LINKBM_IG_18
            // 
            this.rtb_LINKBM_IG_18.Location = new System.Drawing.Point(478, 527);
            this.rtb_LINKBM_IG_18.Name = "rtb_LINKBM_IG_18";
            this.rtb_LINKBM_IG_18.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_18.TabIndex = 165;
            this.rtb_LINKBM_IG_18.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_18
            // 
            this.rtb_LINKBMFAIL_IG_18.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_18.Location = new System.Drawing.Point(679, 527);
            this.rtb_LINKBMFAIL_IG_18.Name = "rtb_LINKBMFAIL_IG_18";
            this.rtb_LINKBMFAIL_IG_18.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_18.TabIndex = 164;
            this.rtb_LINKBMFAIL_IG_18.Text = "";
            // 
            // rtb_LINKBM_IG_17
            // 
            this.rtb_LINKBM_IG_17.Location = new System.Drawing.Point(44, 527);
            this.rtb_LINKBM_IG_17.Name = "rtb_LINKBM_IG_17";
            this.rtb_LINKBM_IG_17.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_17.TabIndex = 163;
            this.rtb_LINKBM_IG_17.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_13
            // 
            this.rtb_LINKBMFAIL_IG_13.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_13.Location = new System.Drawing.Point(245, 408);
            this.rtb_LINKBMFAIL_IG_13.Name = "rtb_LINKBMFAIL_IG_13";
            this.rtb_LINKBMFAIL_IG_13.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_13.TabIndex = 162;
            this.rtb_LINKBMFAIL_IG_13.Text = "";
            // 
            // rtb_LINKBM_IG_14
            // 
            this.rtb_LINKBM_IG_14.Location = new System.Drawing.Point(478, 408);
            this.rtb_LINKBM_IG_14.Name = "rtb_LINKBM_IG_14";
            this.rtb_LINKBM_IG_14.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_14.TabIndex = 161;
            this.rtb_LINKBM_IG_14.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_14
            // 
            this.rtb_LINKBMFAIL_IG_14.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_14.Location = new System.Drawing.Point(679, 408);
            this.rtb_LINKBMFAIL_IG_14.Name = "rtb_LINKBMFAIL_IG_14";
            this.rtb_LINKBMFAIL_IG_14.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_14.TabIndex = 160;
            this.rtb_LINKBMFAIL_IG_14.Text = "";
            // 
            // rtb_LINKBM_IG_13
            // 
            this.rtb_LINKBM_IG_13.Location = new System.Drawing.Point(44, 408);
            this.rtb_LINKBM_IG_13.Name = "rtb_LINKBM_IG_13";
            this.rtb_LINKBM_IG_13.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_13.TabIndex = 159;
            this.rtb_LINKBM_IG_13.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_9
            // 
            this.rtb_LINKBMFAIL_IG_9.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_9.Location = new System.Drawing.Point(245, 289);
            this.rtb_LINKBMFAIL_IG_9.Name = "rtb_LINKBMFAIL_IG_9";
            this.rtb_LINKBMFAIL_IG_9.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_9.TabIndex = 158;
            this.rtb_LINKBMFAIL_IG_9.Text = "";
            // 
            // rtb_LINKBM_IG_10
            // 
            this.rtb_LINKBM_IG_10.Location = new System.Drawing.Point(478, 289);
            this.rtb_LINKBM_IG_10.Name = "rtb_LINKBM_IG_10";
            this.rtb_LINKBM_IG_10.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_10.TabIndex = 157;
            this.rtb_LINKBM_IG_10.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_10
            // 
            this.rtb_LINKBMFAIL_IG_10.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_10.Location = new System.Drawing.Point(679, 289);
            this.rtb_LINKBMFAIL_IG_10.Name = "rtb_LINKBMFAIL_IG_10";
            this.rtb_LINKBMFAIL_IG_10.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_10.TabIndex = 156;
            this.rtb_LINKBMFAIL_IG_10.Text = "";
            // 
            // rtb_LINKBM_IG_9
            // 
            this.rtb_LINKBM_IG_9.Location = new System.Drawing.Point(44, 289);
            this.rtb_LINKBM_IG_9.Name = "rtb_LINKBM_IG_9";
            this.rtb_LINKBM_IG_9.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_9.TabIndex = 155;
            this.rtb_LINKBM_IG_9.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_5
            // 
            this.rtb_LINKBMFAIL_IG_5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_5.Location = new System.Drawing.Point(245, 170);
            this.rtb_LINKBMFAIL_IG_5.Name = "rtb_LINKBMFAIL_IG_5";
            this.rtb_LINKBMFAIL_IG_5.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_5.TabIndex = 154;
            this.rtb_LINKBMFAIL_IG_5.Text = "";
            // 
            // rtb_LINKBM_IG_6
            // 
            this.rtb_LINKBM_IG_6.Location = new System.Drawing.Point(478, 170);
            this.rtb_LINKBM_IG_6.Name = "rtb_LINKBM_IG_6";
            this.rtb_LINKBM_IG_6.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_6.TabIndex = 153;
            this.rtb_LINKBM_IG_6.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_6
            // 
            this.rtb_LINKBMFAIL_IG_6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_6.Location = new System.Drawing.Point(679, 170);
            this.rtb_LINKBMFAIL_IG_6.Name = "rtb_LINKBMFAIL_IG_6";
            this.rtb_LINKBMFAIL_IG_6.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_6.TabIndex = 152;
            this.rtb_LINKBMFAIL_IG_6.Text = "";
            // 
            // rtb_LINKBM_IG_5
            // 
            this.rtb_LINKBM_IG_5.Location = new System.Drawing.Point(44, 170);
            this.rtb_LINKBM_IG_5.Name = "rtb_LINKBM_IG_5";
            this.rtb_LINKBM_IG_5.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_5.TabIndex = 151;
            this.rtb_LINKBM_IG_5.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_1
            // 
            this.rtb_LINKBMFAIL_IG_1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_1.Location = new System.Drawing.Point(245, 51);
            this.rtb_LINKBMFAIL_IG_1.Name = "rtb_LINKBMFAIL_IG_1";
            this.rtb_LINKBMFAIL_IG_1.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_1.TabIndex = 150;
            this.rtb_LINKBMFAIL_IG_1.Text = "";
            // 
            // rtb_LINKBM_IG_2
            // 
            this.rtb_LINKBM_IG_2.Location = new System.Drawing.Point(478, 51);
            this.rtb_LINKBM_IG_2.Name = "rtb_LINKBM_IG_2";
            this.rtb_LINKBM_IG_2.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_2.TabIndex = 149;
            this.rtb_LINKBM_IG_2.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_2
            // 
            this.rtb_LINKBMFAIL_IG_2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_2.Location = new System.Drawing.Point(679, 51);
            this.rtb_LINKBMFAIL_IG_2.Name = "rtb_LINKBMFAIL_IG_2";
            this.rtb_LINKBMFAIL_IG_2.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_2.TabIndex = 148;
            this.rtb_LINKBMFAIL_IG_2.Text = "";
            // 
            // rtb_LINKBM_IG_1
            // 
            this.rtb_LINKBM_IG_1.Location = new System.Drawing.Point(44, 51);
            this.rtb_LINKBM_IG_1.Name = "rtb_LINKBM_IG_1";
            this.rtb_LINKBM_IG_1.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_1.TabIndex = 147;
            this.rtb_LINKBM_IG_1.Text = "";
            // 
            // tabPage17
            // 
            this.tabPage17.BackColor = System.Drawing.Color.Gray;
            this.tabPage17.Controls.Add(this.tb_nhan40);
            this.tabPage17.Controls.Add(this.tb_40);
            this.tabPage17.Controls.Add(this.tb_nhan36);
            this.tabPage17.Controls.Add(this.tb_36);
            this.tabPage17.Controls.Add(this.tb_nhan32);
            this.tabPage17.Controls.Add(this.tb_32);
            this.tabPage17.Controls.Add(this.tb_nhan28);
            this.tabPage17.Controls.Add(this.tb_28);
            this.tabPage17.Controls.Add(this.tb_nhan24);
            this.tabPage17.Controls.Add(this.tb_24);
            this.tabPage17.Controls.Add(this.tb_nhan39);
            this.tabPage17.Controls.Add(this.tb_39);
            this.tabPage17.Controls.Add(this.tb_nhan35);
            this.tabPage17.Controls.Add(this.tb_35);
            this.tabPage17.Controls.Add(this.tb_nhan31);
            this.tabPage17.Controls.Add(this.tb_31);
            this.tabPage17.Controls.Add(this.tb_nhan27);
            this.tabPage17.Controls.Add(this.tb_27);
            this.tabPage17.Controls.Add(this.tb_nhan23);
            this.tabPage17.Controls.Add(this.tb_23);
            this.tabPage17.Controls.Add(this.tb_nhan38);
            this.tabPage17.Controls.Add(this.tb_38);
            this.tabPage17.Controls.Add(this.tb_nhan34);
            this.tabPage17.Controls.Add(this.tb_34);
            this.tabPage17.Controls.Add(this.tb_nhan30);
            this.tabPage17.Controls.Add(this.tb_30);
            this.tabPage17.Controls.Add(this.tb_nhan26);
            this.tabPage17.Controls.Add(this.tb_26);
            this.tabPage17.Controls.Add(this.tb_nhan22);
            this.tabPage17.Controls.Add(this.tb_22);
            this.tabPage17.Controls.Add(this.tb_nhan37);
            this.tabPage17.Controls.Add(this.tb_37);
            this.tabPage17.Controls.Add(this.tb_nhan33);
            this.tabPage17.Controls.Add(this.tb_33);
            this.tabPage17.Controls.Add(this.tb_nhan29);
            this.tabPage17.Controls.Add(this.tb_29);
            this.tabPage17.Controls.Add(this.tb_nhan25);
            this.tabPage17.Controls.Add(this.tb_25);
            this.tabPage17.Controls.Add(this.tb_nhan21);
            this.tabPage17.Controls.Add(this.tb_21);
            this.tabPage17.Controls.Add(this.label128);
            this.tabPage17.Controls.Add(this.label121);
            this.tabPage17.Controls.Add(this.label122);
            this.tabPage17.Controls.Add(this.label123);
            this.tabPage17.Controls.Add(this.label124);
            this.tabPage17.Controls.Add(this.label125);
            this.tabPage17.Controls.Add(this.label126);
            this.tabPage17.Controls.Add(this.label127);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_39);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_40);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_40);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_39);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_35);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_36);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_36);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_35);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_31);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_32);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_32);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_31);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_27);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_28);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_28);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_27);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_23);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_24);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_24);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_23);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_37);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_38);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_38);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_37);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_33);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_34);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_34);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_33);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_29);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_30);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_30);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_29);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_25);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_26);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_26);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_25);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_21);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_22);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_22);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_21);
            this.tabPage17.Location = new System.Drawing.Point(4, 24);
            this.tabPage17.Name = "tabPage17";
            this.tabPage17.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage17.Size = new System.Drawing.Size(1756, 661);
            this.tabPage17.TabIndex = 2;
            this.tabPage17.Text = "VIA NHẬN BM 21-40";
            // 
            // tb_nhan40
            // 
            this.tb_nhan40.Location = new System.Drawing.Point(1312, 600);
            this.tb_nhan40.Name = "tb_nhan40";
            this.tb_nhan40.Size = new System.Drawing.Size(32, 21);
            this.tb_nhan40.TabIndex = 281;
            // 
            // tb_40
            // 
            this.tb_40.Location = new System.Drawing.Point(1313, 573);
            this.tb_40.Name = "tb_40";
            this.tb_40.Size = new System.Drawing.Size(31, 21);
            this.tb_40.TabIndex = 280;
            // 
            // tb_nhan36
            // 
            this.tb_nhan36.Location = new System.Drawing.Point(1313, 473);
            this.tb_nhan36.Name = "tb_nhan36";
            this.tb_nhan36.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan36.TabIndex = 279;
            // 
            // tb_36
            // 
            this.tb_36.Location = new System.Drawing.Point(1314, 446);
            this.tb_36.Name = "tb_36";
            this.tb_36.Size = new System.Drawing.Size(30, 21);
            this.tb_36.TabIndex = 278;
            // 
            // tb_nhan32
            // 
            this.tb_nhan32.Location = new System.Drawing.Point(1314, 358);
            this.tb_nhan32.Name = "tb_nhan32";
            this.tb_nhan32.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan32.TabIndex = 277;
            // 
            // tb_32
            // 
            this.tb_32.Location = new System.Drawing.Point(1315, 331);
            this.tb_32.Name = "tb_32";
            this.tb_32.Size = new System.Drawing.Size(30, 21);
            this.tb_32.TabIndex = 276;
            // 
            // tb_nhan28
            // 
            this.tb_nhan28.Location = new System.Drawing.Point(1314, 234);
            this.tb_nhan28.Name = "tb_nhan28";
            this.tb_nhan28.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan28.TabIndex = 275;
            // 
            // tb_28
            // 
            this.tb_28.Location = new System.Drawing.Point(1315, 207);
            this.tb_28.Name = "tb_28";
            this.tb_28.Size = new System.Drawing.Size(30, 21);
            this.tb_28.TabIndex = 274;
            // 
            // tb_nhan24
            // 
            this.tb_nhan24.Location = new System.Drawing.Point(1314, 100);
            this.tb_nhan24.Name = "tb_nhan24";
            this.tb_nhan24.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan24.TabIndex = 273;
            // 
            // tb_24
            // 
            this.tb_24.Location = new System.Drawing.Point(1315, 73);
            this.tb_24.Name = "tb_24";
            this.tb_24.Size = new System.Drawing.Size(30, 21);
            this.tb_24.TabIndex = 272;
            // 
            // tb_nhan39
            // 
            this.tb_nhan39.Location = new System.Drawing.Point(877, 600);
            this.tb_nhan39.Name = "tb_nhan39";
            this.tb_nhan39.Size = new System.Drawing.Size(32, 21);
            this.tb_nhan39.TabIndex = 271;
            // 
            // tb_39
            // 
            this.tb_39.Location = new System.Drawing.Point(878, 573);
            this.tb_39.Name = "tb_39";
            this.tb_39.Size = new System.Drawing.Size(31, 21);
            this.tb_39.TabIndex = 270;
            // 
            // tb_nhan35
            // 
            this.tb_nhan35.Location = new System.Drawing.Point(878, 473);
            this.tb_nhan35.Name = "tb_nhan35";
            this.tb_nhan35.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan35.TabIndex = 269;
            // 
            // tb_35
            // 
            this.tb_35.Location = new System.Drawing.Point(879, 446);
            this.tb_35.Name = "tb_35";
            this.tb_35.Size = new System.Drawing.Size(30, 21);
            this.tb_35.TabIndex = 268;
            // 
            // tb_nhan31
            // 
            this.tb_nhan31.Location = new System.Drawing.Point(879, 358);
            this.tb_nhan31.Name = "tb_nhan31";
            this.tb_nhan31.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan31.TabIndex = 267;
            // 
            // tb_31
            // 
            this.tb_31.Location = new System.Drawing.Point(880, 331);
            this.tb_31.Name = "tb_31";
            this.tb_31.Size = new System.Drawing.Size(30, 21);
            this.tb_31.TabIndex = 266;
            // 
            // tb_nhan27
            // 
            this.tb_nhan27.Location = new System.Drawing.Point(879, 234);
            this.tb_nhan27.Name = "tb_nhan27";
            this.tb_nhan27.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan27.TabIndex = 265;
            // 
            // tb_27
            // 
            this.tb_27.Location = new System.Drawing.Point(880, 207);
            this.tb_27.Name = "tb_27";
            this.tb_27.Size = new System.Drawing.Size(30, 21);
            this.tb_27.TabIndex = 264;
            // 
            // tb_nhan23
            // 
            this.tb_nhan23.Location = new System.Drawing.Point(879, 100);
            this.tb_nhan23.Name = "tb_nhan23";
            this.tb_nhan23.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan23.TabIndex = 263;
            // 
            // tb_23
            // 
            this.tb_23.Location = new System.Drawing.Point(880, 73);
            this.tb_23.Name = "tb_23";
            this.tb_23.Size = new System.Drawing.Size(30, 21);
            this.tb_23.TabIndex = 262;
            // 
            // tb_nhan38
            // 
            this.tb_nhan38.Location = new System.Drawing.Point(439, 600);
            this.tb_nhan38.Name = "tb_nhan38";
            this.tb_nhan38.Size = new System.Drawing.Size(32, 21);
            this.tb_nhan38.TabIndex = 261;
            // 
            // tb_38
            // 
            this.tb_38.Location = new System.Drawing.Point(440, 573);
            this.tb_38.Name = "tb_38";
            this.tb_38.Size = new System.Drawing.Size(31, 21);
            this.tb_38.TabIndex = 260;
            // 
            // tb_nhan34
            // 
            this.tb_nhan34.Location = new System.Drawing.Point(440, 473);
            this.tb_nhan34.Name = "tb_nhan34";
            this.tb_nhan34.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan34.TabIndex = 259;
            // 
            // tb_34
            // 
            this.tb_34.Location = new System.Drawing.Point(441, 446);
            this.tb_34.Name = "tb_34";
            this.tb_34.Size = new System.Drawing.Size(30, 21);
            this.tb_34.TabIndex = 258;
            // 
            // tb_nhan30
            // 
            this.tb_nhan30.Location = new System.Drawing.Point(441, 358);
            this.tb_nhan30.Name = "tb_nhan30";
            this.tb_nhan30.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan30.TabIndex = 257;
            // 
            // tb_30
            // 
            this.tb_30.Location = new System.Drawing.Point(442, 331);
            this.tb_30.Name = "tb_30";
            this.tb_30.Size = new System.Drawing.Size(30, 21);
            this.tb_30.TabIndex = 256;
            // 
            // tb_nhan26
            // 
            this.tb_nhan26.Location = new System.Drawing.Point(441, 234);
            this.tb_nhan26.Name = "tb_nhan26";
            this.tb_nhan26.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan26.TabIndex = 255;
            // 
            // tb_26
            // 
            this.tb_26.Location = new System.Drawing.Point(442, 207);
            this.tb_26.Name = "tb_26";
            this.tb_26.Size = new System.Drawing.Size(30, 21);
            this.tb_26.TabIndex = 254;
            // 
            // tb_nhan22
            // 
            this.tb_nhan22.Location = new System.Drawing.Point(441, 100);
            this.tb_nhan22.Name = "tb_nhan22";
            this.tb_nhan22.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan22.TabIndex = 253;
            // 
            // tb_22
            // 
            this.tb_22.Location = new System.Drawing.Point(442, 73);
            this.tb_22.Name = "tb_22";
            this.tb_22.Size = new System.Drawing.Size(30, 21);
            this.tb_22.TabIndex = 252;
            // 
            // tb_nhan37
            // 
            this.tb_nhan37.Location = new System.Drawing.Point(3, 600);
            this.tb_nhan37.Name = "tb_nhan37";
            this.tb_nhan37.Size = new System.Drawing.Size(32, 21);
            this.tb_nhan37.TabIndex = 251;
            // 
            // tb_37
            // 
            this.tb_37.Location = new System.Drawing.Point(4, 573);
            this.tb_37.Name = "tb_37";
            this.tb_37.Size = new System.Drawing.Size(31, 21);
            this.tb_37.TabIndex = 250;
            // 
            // tb_nhan33
            // 
            this.tb_nhan33.Location = new System.Drawing.Point(4, 473);
            this.tb_nhan33.Name = "tb_nhan33";
            this.tb_nhan33.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan33.TabIndex = 249;
            // 
            // tb_33
            // 
            this.tb_33.Location = new System.Drawing.Point(5, 446);
            this.tb_33.Name = "tb_33";
            this.tb_33.Size = new System.Drawing.Size(30, 21);
            this.tb_33.TabIndex = 248;
            // 
            // tb_nhan29
            // 
            this.tb_nhan29.Location = new System.Drawing.Point(5, 358);
            this.tb_nhan29.Name = "tb_nhan29";
            this.tb_nhan29.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan29.TabIndex = 247;
            // 
            // tb_29
            // 
            this.tb_29.Location = new System.Drawing.Point(6, 331);
            this.tb_29.Name = "tb_29";
            this.tb_29.Size = new System.Drawing.Size(30, 21);
            this.tb_29.TabIndex = 246;
            // 
            // tb_nhan25
            // 
            this.tb_nhan25.Location = new System.Drawing.Point(5, 234);
            this.tb_nhan25.Name = "tb_nhan25";
            this.tb_nhan25.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan25.TabIndex = 245;
            // 
            // tb_25
            // 
            this.tb_25.Location = new System.Drawing.Point(6, 207);
            this.tb_25.Name = "tb_25";
            this.tb_25.Size = new System.Drawing.Size(30, 21);
            this.tb_25.TabIndex = 244;
            // 
            // tb_nhan21
            // 
            this.tb_nhan21.Location = new System.Drawing.Point(5, 100);
            this.tb_nhan21.Name = "tb_nhan21";
            this.tb_nhan21.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan21.TabIndex = 243;
            // 
            // tb_21
            // 
            this.tb_21.Location = new System.Drawing.Point(6, 73);
            this.tb_21.Name = "tb_21";
            this.tb_21.Size = new System.Drawing.Size(30, 21);
            this.tb_21.TabIndex = 242;
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Location = new System.Drawing.Point(1581, 20);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(138, 15);
            this.label128.TabIndex = 241;
            this.label128.Text = "LINK FAIL 24,28,32,36,40";
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Location = new System.Drawing.Point(1141, 20);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(138, 15);
            this.label121.TabIndex = 240;
            this.label121.Text = "LINK FAIL 23,27,31,35,39";
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Location = new System.Drawing.Point(710, 20);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(138, 15);
            this.label122.TabIndex = 239;
            this.label122.Text = "LINK FAIL 22,26,30,34,38";
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Location = new System.Drawing.Point(271, 20);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(138, 15);
            this.label123.TabIndex = 238;
            this.label123.Text = "LINK FAIL 21,25,29,33,37";
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Location = new System.Drawing.Point(1377, 20);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(143, 15);
            this.label124.TabIndex = 237;
            this.label124.Text = "ACCOUNT 24,28,32,36,40";
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Location = new System.Drawing.Point(935, 20);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(143, 15);
            this.label125.TabIndex = 236;
            this.label125.Text = "ACCOUNT 23,27,31,35,39";
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Location = new System.Drawing.Point(506, 20);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(143, 15);
            this.label126.TabIndex = 235;
            this.label126.Text = "ACCOUNT 22,26,30,34,38";
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Location = new System.Drawing.Point(60, 20);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(143, 15);
            this.label127.TabIndex = 234;
            this.label127.Text = "ACCOUNT 21,25,29,33,37";
            // 
            // rtb_LINKBMFAIL_IG_39
            // 
            this.rtb_LINKBMFAIL_IG_39.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_39.Location = new System.Drawing.Point(1114, 527);
            this.rtb_LINKBMFAIL_IG_39.Name = "rtb_LINKBMFAIL_IG_39";
            this.rtb_LINKBMFAIL_IG_39.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_39.TabIndex = 233;
            this.rtb_LINKBMFAIL_IG_39.Text = "";
            // 
            // rtb_LINKBM_IG_40
            // 
            this.rtb_LINKBM_IG_40.Location = new System.Drawing.Point(1349, 527);
            this.rtb_LINKBM_IG_40.Name = "rtb_LINKBM_IG_40";
            this.rtb_LINKBM_IG_40.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_40.TabIndex = 232;
            this.rtb_LINKBM_IG_40.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_40
            // 
            this.rtb_LINKBMFAIL_IG_40.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_40.Location = new System.Drawing.Point(1553, 527);
            this.rtb_LINKBMFAIL_IG_40.Name = "rtb_LINKBMFAIL_IG_40";
            this.rtb_LINKBMFAIL_IG_40.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_40.TabIndex = 231;
            this.rtb_LINKBMFAIL_IG_40.Text = "";
            // 
            // rtb_LINKBM_IG_39
            // 
            this.rtb_LINKBM_IG_39.Location = new System.Drawing.Point(913, 527);
            this.rtb_LINKBM_IG_39.Name = "rtb_LINKBM_IG_39";
            this.rtb_LINKBM_IG_39.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_39.TabIndex = 230;
            this.rtb_LINKBM_IG_39.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_35
            // 
            this.rtb_LINKBMFAIL_IG_35.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_35.Location = new System.Drawing.Point(1114, 408);
            this.rtb_LINKBMFAIL_IG_35.Name = "rtb_LINKBMFAIL_IG_35";
            this.rtb_LINKBMFAIL_IG_35.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_35.TabIndex = 229;
            this.rtb_LINKBMFAIL_IG_35.Text = "";
            // 
            // rtb_LINKBM_IG_36
            // 
            this.rtb_LINKBM_IG_36.Location = new System.Drawing.Point(1349, 408);
            this.rtb_LINKBM_IG_36.Name = "rtb_LINKBM_IG_36";
            this.rtb_LINKBM_IG_36.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_36.TabIndex = 228;
            this.rtb_LINKBM_IG_36.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_36
            // 
            this.rtb_LINKBMFAIL_IG_36.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_36.Location = new System.Drawing.Point(1553, 408);
            this.rtb_LINKBMFAIL_IG_36.Name = "rtb_LINKBMFAIL_IG_36";
            this.rtb_LINKBMFAIL_IG_36.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_36.TabIndex = 227;
            this.rtb_LINKBMFAIL_IG_36.Text = "";
            // 
            // rtb_LINKBM_IG_35
            // 
            this.rtb_LINKBM_IG_35.Location = new System.Drawing.Point(913, 408);
            this.rtb_LINKBM_IG_35.Name = "rtb_LINKBM_IG_35";
            this.rtb_LINKBM_IG_35.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_35.TabIndex = 226;
            this.rtb_LINKBM_IG_35.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_31
            // 
            this.rtb_LINKBMFAIL_IG_31.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_31.Location = new System.Drawing.Point(1114, 289);
            this.rtb_LINKBMFAIL_IG_31.Name = "rtb_LINKBMFAIL_IG_31";
            this.rtb_LINKBMFAIL_IG_31.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_31.TabIndex = 225;
            this.rtb_LINKBMFAIL_IG_31.Text = "";
            // 
            // rtb_LINKBM_IG_32
            // 
            this.rtb_LINKBM_IG_32.Location = new System.Drawing.Point(1349, 289);
            this.rtb_LINKBM_IG_32.Name = "rtb_LINKBM_IG_32";
            this.rtb_LINKBM_IG_32.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_32.TabIndex = 224;
            this.rtb_LINKBM_IG_32.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_32
            // 
            this.rtb_LINKBMFAIL_IG_32.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_32.Location = new System.Drawing.Point(1553, 289);
            this.rtb_LINKBMFAIL_IG_32.Name = "rtb_LINKBMFAIL_IG_32";
            this.rtb_LINKBMFAIL_IG_32.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_32.TabIndex = 223;
            this.rtb_LINKBMFAIL_IG_32.Text = "";
            // 
            // rtb_LINKBM_IG_31
            // 
            this.rtb_LINKBM_IG_31.Location = new System.Drawing.Point(913, 289);
            this.rtb_LINKBM_IG_31.Name = "rtb_LINKBM_IG_31";
            this.rtb_LINKBM_IG_31.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_31.TabIndex = 222;
            this.rtb_LINKBM_IG_31.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_27
            // 
            this.rtb_LINKBMFAIL_IG_27.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_27.Location = new System.Drawing.Point(1114, 170);
            this.rtb_LINKBMFAIL_IG_27.Name = "rtb_LINKBMFAIL_IG_27";
            this.rtb_LINKBMFAIL_IG_27.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_27.TabIndex = 221;
            this.rtb_LINKBMFAIL_IG_27.Text = "";
            // 
            // rtb_LINKBM_IG_28
            // 
            this.rtb_LINKBM_IG_28.Location = new System.Drawing.Point(1349, 170);
            this.rtb_LINKBM_IG_28.Name = "rtb_LINKBM_IG_28";
            this.rtb_LINKBM_IG_28.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_28.TabIndex = 220;
            this.rtb_LINKBM_IG_28.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_28
            // 
            this.rtb_LINKBMFAIL_IG_28.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_28.Location = new System.Drawing.Point(1553, 170);
            this.rtb_LINKBMFAIL_IG_28.Name = "rtb_LINKBMFAIL_IG_28";
            this.rtb_LINKBMFAIL_IG_28.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_28.TabIndex = 219;
            this.rtb_LINKBMFAIL_IG_28.Text = "";
            // 
            // rtb_LINKBM_IG_27
            // 
            this.rtb_LINKBM_IG_27.Location = new System.Drawing.Point(913, 170);
            this.rtb_LINKBM_IG_27.Name = "rtb_LINKBM_IG_27";
            this.rtb_LINKBM_IG_27.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_27.TabIndex = 218;
            this.rtb_LINKBM_IG_27.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_23
            // 
            this.rtb_LINKBMFAIL_IG_23.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_23.Location = new System.Drawing.Point(1114, 51);
            this.rtb_LINKBMFAIL_IG_23.Name = "rtb_LINKBMFAIL_IG_23";
            this.rtb_LINKBMFAIL_IG_23.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_23.TabIndex = 217;
            this.rtb_LINKBMFAIL_IG_23.Text = "";
            // 
            // rtb_LINKBM_IG_24
            // 
            this.rtb_LINKBM_IG_24.Location = new System.Drawing.Point(1349, 51);
            this.rtb_LINKBM_IG_24.Name = "rtb_LINKBM_IG_24";
            this.rtb_LINKBM_IG_24.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_24.TabIndex = 216;
            this.rtb_LINKBM_IG_24.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_24
            // 
            this.rtb_LINKBMFAIL_IG_24.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_24.Location = new System.Drawing.Point(1553, 51);
            this.rtb_LINKBMFAIL_IG_24.Name = "rtb_LINKBMFAIL_IG_24";
            this.rtb_LINKBMFAIL_IG_24.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_24.TabIndex = 215;
            this.rtb_LINKBMFAIL_IG_24.Text = "";
            // 
            // rtb_LINKBM_IG_23
            // 
            this.rtb_LINKBM_IG_23.Location = new System.Drawing.Point(913, 51);
            this.rtb_LINKBM_IG_23.Name = "rtb_LINKBM_IG_23";
            this.rtb_LINKBM_IG_23.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_23.TabIndex = 214;
            this.rtb_LINKBM_IG_23.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_37
            // 
            this.rtb_LINKBMFAIL_IG_37.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_37.Location = new System.Drawing.Point(241, 527);
            this.rtb_LINKBMFAIL_IG_37.Name = "rtb_LINKBMFAIL_IG_37";
            this.rtb_LINKBMFAIL_IG_37.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_37.TabIndex = 213;
            this.rtb_LINKBMFAIL_IG_37.Text = "";
            // 
            // rtb_LINKBM_IG_38
            // 
            this.rtb_LINKBM_IG_38.Location = new System.Drawing.Point(478, 527);
            this.rtb_LINKBM_IG_38.Name = "rtb_LINKBM_IG_38";
            this.rtb_LINKBM_IG_38.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_38.TabIndex = 212;
            this.rtb_LINKBM_IG_38.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_38
            // 
            this.rtb_LINKBMFAIL_IG_38.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_38.Location = new System.Drawing.Point(679, 527);
            this.rtb_LINKBMFAIL_IG_38.Name = "rtb_LINKBMFAIL_IG_38";
            this.rtb_LINKBMFAIL_IG_38.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_38.TabIndex = 211;
            this.rtb_LINKBMFAIL_IG_38.Text = "";
            // 
            // rtb_LINKBM_IG_37
            // 
            this.rtb_LINKBM_IG_37.Location = new System.Drawing.Point(40, 527);
            this.rtb_LINKBM_IG_37.Name = "rtb_LINKBM_IG_37";
            this.rtb_LINKBM_IG_37.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_37.TabIndex = 210;
            this.rtb_LINKBM_IG_37.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_33
            // 
            this.rtb_LINKBMFAIL_IG_33.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_33.Location = new System.Drawing.Point(241, 408);
            this.rtb_LINKBMFAIL_IG_33.Name = "rtb_LINKBMFAIL_IG_33";
            this.rtb_LINKBMFAIL_IG_33.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_33.TabIndex = 209;
            this.rtb_LINKBMFAIL_IG_33.Text = "";
            // 
            // rtb_LINKBM_IG_34
            // 
            this.rtb_LINKBM_IG_34.Location = new System.Drawing.Point(478, 408);
            this.rtb_LINKBM_IG_34.Name = "rtb_LINKBM_IG_34";
            this.rtb_LINKBM_IG_34.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_34.TabIndex = 208;
            this.rtb_LINKBM_IG_34.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_34
            // 
            this.rtb_LINKBMFAIL_IG_34.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_34.Location = new System.Drawing.Point(679, 408);
            this.rtb_LINKBMFAIL_IG_34.Name = "rtb_LINKBMFAIL_IG_34";
            this.rtb_LINKBMFAIL_IG_34.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_34.TabIndex = 207;
            this.rtb_LINKBMFAIL_IG_34.Text = "";
            // 
            // rtb_LINKBM_IG_33
            // 
            this.rtb_LINKBM_IG_33.Location = new System.Drawing.Point(40, 408);
            this.rtb_LINKBM_IG_33.Name = "rtb_LINKBM_IG_33";
            this.rtb_LINKBM_IG_33.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_33.TabIndex = 206;
            this.rtb_LINKBM_IG_33.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_29
            // 
            this.rtb_LINKBMFAIL_IG_29.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_29.Location = new System.Drawing.Point(241, 289);
            this.rtb_LINKBMFAIL_IG_29.Name = "rtb_LINKBMFAIL_IG_29";
            this.rtb_LINKBMFAIL_IG_29.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_29.TabIndex = 205;
            this.rtb_LINKBMFAIL_IG_29.Text = "";
            // 
            // rtb_LINKBM_IG_30
            // 
            this.rtb_LINKBM_IG_30.Location = new System.Drawing.Point(478, 289);
            this.rtb_LINKBM_IG_30.Name = "rtb_LINKBM_IG_30";
            this.rtb_LINKBM_IG_30.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_30.TabIndex = 204;
            this.rtb_LINKBM_IG_30.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_30
            // 
            this.rtb_LINKBMFAIL_IG_30.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_30.Location = new System.Drawing.Point(679, 289);
            this.rtb_LINKBMFAIL_IG_30.Name = "rtb_LINKBMFAIL_IG_30";
            this.rtb_LINKBMFAIL_IG_30.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_30.TabIndex = 203;
            this.rtb_LINKBMFAIL_IG_30.Text = "";
            // 
            // rtb_LINKBM_IG_29
            // 
            this.rtb_LINKBM_IG_29.Location = new System.Drawing.Point(40, 289);
            this.rtb_LINKBM_IG_29.Name = "rtb_LINKBM_IG_29";
            this.rtb_LINKBM_IG_29.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_29.TabIndex = 202;
            this.rtb_LINKBM_IG_29.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_25
            // 
            this.rtb_LINKBMFAIL_IG_25.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_25.Location = new System.Drawing.Point(241, 170);
            this.rtb_LINKBMFAIL_IG_25.Name = "rtb_LINKBMFAIL_IG_25";
            this.rtb_LINKBMFAIL_IG_25.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_25.TabIndex = 201;
            this.rtb_LINKBMFAIL_IG_25.Text = "";
            // 
            // rtb_LINKBM_IG_26
            // 
            this.rtb_LINKBM_IG_26.Location = new System.Drawing.Point(478, 170);
            this.rtb_LINKBM_IG_26.Name = "rtb_LINKBM_IG_26";
            this.rtb_LINKBM_IG_26.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_26.TabIndex = 200;
            this.rtb_LINKBM_IG_26.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_26
            // 
            this.rtb_LINKBMFAIL_IG_26.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_26.Location = new System.Drawing.Point(679, 170);
            this.rtb_LINKBMFAIL_IG_26.Name = "rtb_LINKBMFAIL_IG_26";
            this.rtb_LINKBMFAIL_IG_26.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_26.TabIndex = 199;
            this.rtb_LINKBMFAIL_IG_26.Text = "";
            // 
            // rtb_LINKBM_IG_25
            // 
            this.rtb_LINKBM_IG_25.Location = new System.Drawing.Point(40, 170);
            this.rtb_LINKBM_IG_25.Name = "rtb_LINKBM_IG_25";
            this.rtb_LINKBM_IG_25.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_25.TabIndex = 198;
            this.rtb_LINKBM_IG_25.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_21
            // 
            this.rtb_LINKBMFAIL_IG_21.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_21.Location = new System.Drawing.Point(241, 51);
            this.rtb_LINKBMFAIL_IG_21.Name = "rtb_LINKBMFAIL_IG_21";
            this.rtb_LINKBMFAIL_IG_21.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_21.TabIndex = 197;
            this.rtb_LINKBMFAIL_IG_21.Text = "";
            // 
            // rtb_LINKBM_IG_22
            // 
            this.rtb_LINKBM_IG_22.Location = new System.Drawing.Point(478, 51);
            this.rtb_LINKBM_IG_22.Name = "rtb_LINKBM_IG_22";
            this.rtb_LINKBM_IG_22.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_22.TabIndex = 196;
            this.rtb_LINKBM_IG_22.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_22
            // 
            this.rtb_LINKBMFAIL_IG_22.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_22.Location = new System.Drawing.Point(679, 51);
            this.rtb_LINKBMFAIL_IG_22.Name = "rtb_LINKBMFAIL_IG_22";
            this.rtb_LINKBMFAIL_IG_22.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_22.TabIndex = 195;
            this.rtb_LINKBMFAIL_IG_22.Text = "";
            // 
            // rtb_LINKBM_IG_21
            // 
            this.rtb_LINKBM_IG_21.Location = new System.Drawing.Point(40, 51);
            this.rtb_LINKBM_IG_21.Name = "rtb_LINKBM_IG_21";
            this.rtb_LINKBM_IG_21.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_21.TabIndex = 194;
            this.rtb_LINKBM_IG_21.Text = "";
            // 
            // tabPage18
            // 
            this.tabPage18.BackColor = System.Drawing.Color.Gray;
            this.tabPage18.Controls.Add(this.label145);
            this.tabPage18.Controls.Add(this.delay_check_ig);
            this.tabPage18.Controls.Add(this.label144);
            this.tabPage18.Controls.Add(this.label143);
            this.tabPage18.Controls.Add(this.rtb_282);
            this.tabPage18.Controls.Add(this.rtb_LIVE);
            this.tabPage18.Location = new System.Drawing.Point(4, 24);
            this.tabPage18.Name = "tabPage18";
            this.tabPage18.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage18.Size = new System.Drawing.Size(1767, 688);
            this.tabPage18.TabIndex = 10;
            this.tabPage18.Text = "CHECK LIVE DIE";
            // 
            // label145
            // 
            this.label145.AutoSize = true;
            this.label145.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label145.Location = new System.Drawing.Point(32, 242);
            this.label145.Name = "label145";
            this.label145.Size = new System.Drawing.Size(48, 15);
            this.label145.TabIndex = 201;
            this.label145.Text = "DELAY:";
            // 
            // delay_check_ig
            // 
            this.delay_check_ig.Location = new System.Drawing.Point(35, 271);
            this.delay_check_ig.Name = "delay_check_ig";
            this.delay_check_ig.Size = new System.Drawing.Size(120, 21);
            this.delay_check_ig.TabIndex = 200;
            this.delay_check_ig.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label144
            // 
            this.label144.AutoSize = true;
            this.label144.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label144.Location = new System.Drawing.Point(32, 19);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(37, 15);
            this.label144.TabIndex = 199;
            this.label144.Text = "LIVE:";
            // 
            // label143
            // 
            this.label143.AutoSize = true;
            this.label143.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label143.Location = new System.Drawing.Point(483, 19);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(29, 15);
            this.label143.TabIndex = 198;
            this.label143.Text = "282:";
            // 
            // rtb_282
            // 
            this.rtb_282.Location = new System.Drawing.Point(485, 53);
            this.rtb_282.Name = "rtb_282";
            this.rtb_282.Size = new System.Drawing.Size(391, 177);
            this.rtb_282.TabIndex = 2;
            this.rtb_282.Text = "";
            // 
            // rtb_LIVE
            // 
            this.rtb_LIVE.Location = new System.Drawing.Point(35, 53);
            this.rtb_LIVE.Name = "rtb_LIVE";
            this.rtb_LIVE.Size = new System.Drawing.Size(391, 177);
            this.rtb_LIVE.TabIndex = 1;
            this.rtb_LIVE.Text = "";
            // 
            // tabPage19
            // 
            this.tabPage19.BackColor = System.Drawing.Color.Gray;
            this.tabPage19.Controls.Add(this.tabControl5);
            this.tabPage19.Location = new System.Drawing.Point(4, 24);
            this.tabPage19.Name = "tabPage19";
            this.tabPage19.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage19.Size = new System.Drawing.Size(1767, 688);
            this.tabPage19.TabIndex = 11;
            this.tabPage19.Text = "IG NHAN BM";
            // 
            // tabControl5
            // 
            this.tabControl5.Controls.Add(this.tabPage20);
            this.tabControl5.Controls.Add(this.tabPage21);
            this.tabControl5.Location = new System.Drawing.Point(0, 6);
            this.tabControl5.Name = "tabControl5";
            this.tabControl5.SelectedIndex = 0;
            this.tabControl5.Size = new System.Drawing.Size(1764, 679);
            this.tabControl5.TabIndex = 0;
            // 
            // tabPage20
            // 
            this.tabPage20.BackColor = System.Drawing.Color.Gray;
            this.tabPage20.Controls.Add(this.label170);
            this.tabPage20.Controls.Add(this.label169);
            this.tabPage20.Controls.Add(this.rtb_10_link_bm350);
            this.tabPage20.Controls.Add(this.rtb_10_link_bm50);
            this.tabPage20.Location = new System.Drawing.Point(4, 24);
            this.tabPage20.Name = "tabPage20";
            this.tabPage20.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage20.Size = new System.Drawing.Size(1756, 651);
            this.tabPage20.TabIndex = 0;
            this.tabPage20.Text = "Cài Đặt";
            // 
            // label170
            // 
            this.label170.AutoSize = true;
            this.label170.Location = new System.Drawing.Point(334, 70);
            this.label170.Name = "label170";
            this.label170.Size = new System.Drawing.Size(48, 15);
            this.label170.TabIndex = 34;
            this.label170.Text = "BM350:";
            // 
            // label169
            // 
            this.label169.AutoSize = true;
            this.label169.Location = new System.Drawing.Point(31, 70);
            this.label169.Name = "label169";
            this.label169.Size = new System.Drawing.Size(42, 15);
            this.label169.TabIndex = 33;
            this.label169.Text = "BM50:";
            // 
            // rtb_10_link_bm350
            // 
            this.rtb_10_link_bm350.Location = new System.Drawing.Point(327, 102);
            this.rtb_10_link_bm350.Name = "rtb_10_link_bm350";
            this.rtb_10_link_bm350.Size = new System.Drawing.Size(267, 195);
            this.rtb_10_link_bm350.TabIndex = 29;
            this.rtb_10_link_bm350.Text = "";
            // 
            // rtb_10_link_bm50
            // 
            this.rtb_10_link_bm50.Location = new System.Drawing.Point(34, 102);
            this.rtb_10_link_bm50.Name = "rtb_10_link_bm50";
            this.rtb_10_link_bm50.Size = new System.Drawing.Size(267, 195);
            this.rtb_10_link_bm50.TabIndex = 28;
            this.rtb_10_link_bm50.Text = "";
            // 
            // tabPage21
            // 
            this.tabPage21.BackColor = System.Drawing.Color.Gray;
            this.tabPage21.Location = new System.Drawing.Point(4, 24);
            this.tabPage21.Name = "tabPage21";
            this.tabPage21.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage21.Size = new System.Drawing.Size(1756, 651);
            this.tabPage21.TabIndex = 1;
            this.tabPage21.Text = "NHẬN 1-10";
            // 
            // tabPage27
            // 
            this.tabPage27.BackColor = System.Drawing.Color.Gray;
            this.tabPage27.Controls.Add(this.tabControl7);
            this.tabPage27.Location = new System.Drawing.Point(4, 24);
            this.tabPage27.Name = "tabPage27";
            this.tabPage27.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage27.Size = new System.Drawing.Size(1767, 688);
            this.tabPage27.TabIndex = 12;
            this.tabPage27.Text = "CL FB";
            // 
            // tabControl7
            // 
            this.tabControl7.Controls.Add(this.tabPage28);
            this.tabControl7.Controls.Add(this.tabPage29);
            this.tabControl7.Controls.Add(this.tabPage35);
            this.tabControl7.Controls.Add(this.tabPage30);
            this.tabControl7.Location = new System.Drawing.Point(0, 3);
            this.tabControl7.Name = "tabControl7";
            this.tabControl7.SelectedIndex = 0;
            this.tabControl7.Size = new System.Drawing.Size(1771, 685);
            this.tabControl7.TabIndex = 40;
            // 
            // tabPage28
            // 
            this.tabPage28.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage28.Controls.Add(this.groupBox13);
            this.tabPage28.Location = new System.Drawing.Point(4, 24);
            this.tabPage28.Name = "tabPage28";
            this.tabPage28.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage28.Size = new System.Drawing.Size(1763, 657);
            this.tabPage28.TabIndex = 0;
            this.tabPage28.Text = "Hiển Thị";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.tabControl8);
            this.groupBox13.Controls.Add(this.cmb_Doi_Ten_BM);
            this.groupBox13.Controls.Add(this.label288);
            this.groupBox13.Controls.Add(this.button7);
            this.groupBox13.Controls.Add(this.cmb_NO_CLOSE_TK_D2);
            this.groupBox13.Controls.Add(this.label255);
            this.groupBox13.Controls.Add(this.cmb_Logingmail_trc);
            this.groupBox13.Controls.Add(this.label254);
            this.groupBox13.Controls.Add(this.cmb_chi_Share_LIVE);
            this.groupBox13.Controls.Add(this.label253);
            this.groupBox13.Controls.Add(this.numericUpDown14);
            this.groupBox13.Controls.Add(this.label252);
            this.groupBox13.Controls.Add(this.label251);
            this.groupBox13.Controls.Add(this.rtb_AC_DIE);
            this.groupBox13.Controls.Add(this.numericUpDown13);
            this.groupBox13.Controls.Add(this.label250);
            this.groupBox13.Controls.Add(this.label249);
            this.groupBox13.Controls.Add(this.rtb_IDBM_CLOSECL);
            this.groupBox13.Controls.Add(this.label248);
            this.groupBox13.Controls.Add(this.rtb_IDBM_LIVE);
            this.groupBox13.Controls.Add(this.numericUpDown12);
            this.groupBox13.Controls.Add(this.label247);
            this.groupBox13.Controls.Add(this.numericUpDown11);
            this.groupBox13.Controls.Add(this.label246);
            this.groupBox13.Controls.Add(this.label245);
            this.groupBox13.Controls.Add(this.rtb_AC_CLOSE);
            this.groupBox13.Controls.Add(this.label244);
            this.groupBox13.Controls.Add(this.rtb_ACLIVE);
            this.groupBox13.Controls.Add(this.cmb_MUI_GIO_BMCL);
            this.groupBox13.Controls.Add(this.label240);
            this.groupBox13.Controls.Add(this.cmb_TEN_TKBM_CL);
            this.groupBox13.Controls.Add(this.label241);
            this.groupBox13.Controls.Add(this.cmb_TIENTE_BM_CL);
            this.groupBox13.Controls.Add(this.label242);
            this.groupBox13.Controls.Add(this.cmb_TAOTK_CL);
            this.groupBox13.Controls.Add(this.label243);
            this.groupBox13.Controls.Add(this.label239);
            this.groupBox13.Controls.Add(this.rtb_BM350_CL);
            this.groupBox13.Controls.Add(this.label238);
            this.groupBox13.Controls.Add(this.rtb_BM50_CL);
            this.groupBox13.Controls.Add(this.label236);
            this.groupBox13.Controls.Add(this.delay_regbm_cl);
            this.groupBox13.Controls.Add(this.label237);
            this.groupBox13.Controls.Add(this.number_REGBMCL);
            this.groupBox13.Controls.Add(this.label235);
            this.groupBox13.Controls.Add(this.cmb_REGBMVIA);
            this.groupBox13.Controls.Add(this.label234);
            this.groupBox13.Controls.Add(this.cmb_share_D2VIA);
            this.groupBox13.Controls.Add(this.cmb_radom_ncFB);
            this.groupBox13.Controls.Add(this.label233);
            this.groupBox13.Controls.Add(this.cmb_VN_US_INDIA);
            this.groupBox13.Controls.Add(this.label232);
            this.groupBox13.Controls.Add(this.label231);
            this.groupBox13.Controls.Add(this.cmb_on2FAFB);
            this.groupBox13.Controls.Add(this.label44);
            this.groupBox13.Controls.Add(this.cmb_noveri);
            this.groupBox13.Controls.Add(this.label43);
            this.groupBox13.Controls.Add(this.cmb_IP);
            this.groupBox13.Location = new System.Drawing.Point(3, 6);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(1704, 659);
            this.groupBox13.TabIndex = 39;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "REG CL";
            // 
            // tabControl8
            // 
            this.tabControl8.Controls.Add(this.tabPage31);
            this.tabControl8.Controls.Add(this.tabPage32);
            this.tabControl8.Location = new System.Drawing.Point(240, 316);
            this.tabControl8.Name = "tabControl8";
            this.tabControl8.SelectedIndex = 0;
            this.tabControl8.Size = new System.Drawing.Size(346, 308);
            this.tabControl8.TabIndex = 116;
            // 
            // tabPage31
            // 
            this.tabPage31.BackColor = System.Drawing.Color.DimGray;
            this.tabPage31.Controls.Add(this.groupBox24);
            this.tabPage31.Location = new System.Drawing.Point(4, 24);
            this.tabPage31.Name = "tabPage31";
            this.tabPage31.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage31.Size = new System.Drawing.Size(338, 280);
            this.tabPage31.TabIndex = 0;
            this.tabPage31.Text = "BM1-10";
            // 
            // groupBox24
            // 
            this.groupBox24.Controls.Add(this.label289);
            this.groupBox24.Controls.Add(this.numericUpDown24);
            this.groupBox24.Controls.Add(this.numericUpDown15);
            this.groupBox24.Controls.Add(this.label298);
            this.groupBox24.Controls.Add(this.label290);
            this.groupBox24.Controls.Add(this.numericUpDown19);
            this.groupBox24.Controls.Add(this.numericUpDown16);
            this.groupBox24.Controls.Add(this.label293);
            this.groupBox24.Controls.Add(this.label292);
            this.groupBox24.Controls.Add(this.numericUpDown21);
            this.groupBox24.Controls.Add(this.numericUpDown18);
            this.groupBox24.Controls.Add(this.label295);
            this.groupBox24.Controls.Add(this.label291);
            this.groupBox24.Controls.Add(this.numericUpDown22);
            this.groupBox24.Controls.Add(this.numericUpDown17);
            this.groupBox24.Controls.Add(this.label296);
            this.groupBox24.Controls.Add(this.label294);
            this.groupBox24.Controls.Add(this.numericUpDown23);
            this.groupBox24.Controls.Add(this.numericUpDown20);
            this.groupBox24.Controls.Add(this.label297);
            this.groupBox24.Location = new System.Drawing.Point(3, 3);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Size = new System.Drawing.Size(323, 266);
            this.groupBox24.TabIndex = 115;
            this.groupBox24.TabStop = false;
            this.groupBox24.Text = "Time delay 1-10";
            // 
            // label289
            // 
            this.label289.AutoSize = true;
            this.label289.Location = new System.Drawing.Point(6, 32);
            this.label289.Name = "label289";
            this.label289.Size = new System.Drawing.Size(180, 15);
            this.label289.TabIndex = 95;
            this.label289.Text = "Delay Chấp Nhận  BM1 FAIL(s): ";
            // 
            // numericUpDown24
            // 
            this.numericUpDown24.Location = new System.Drawing.Point(190, 226);
            this.numericUpDown24.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown24.Name = "numericUpDown24";
            this.numericUpDown24.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown24.TabIndex = 114;
            this.numericUpDown24.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numericUpDown15
            // 
            this.numericUpDown15.Location = new System.Drawing.Point(190, 30);
            this.numericUpDown15.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown15.Name = "numericUpDown15";
            this.numericUpDown15.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown15.TabIndex = 96;
            this.numericUpDown15.Value = new decimal(new int[] {
            40,
            0,
            0,
            0});
            // 
            // label298
            // 
            this.label298.AutoSize = true;
            this.label298.Location = new System.Drawing.Point(6, 228);
            this.label298.Name = "label298";
            this.label298.Size = new System.Drawing.Size(186, 15);
            this.label298.TabIndex = 113;
            this.label298.Text = "Delay Chấp Nhận  BM10 FAIL(s): ";
            // 
            // label290
            // 
            this.label290.AutoSize = true;
            this.label290.Location = new System.Drawing.Point(6, 54);
            this.label290.Name = "label290";
            this.label290.Size = new System.Drawing.Size(180, 15);
            this.label290.TabIndex = 97;
            this.label290.Text = "Delay Chấp Nhận  BM2 FAIL(s): ";
            // 
            // numericUpDown19
            // 
            this.numericUpDown19.Location = new System.Drawing.Point(190, 204);
            this.numericUpDown19.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown19.Name = "numericUpDown19";
            this.numericUpDown19.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown19.TabIndex = 112;
            this.numericUpDown19.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numericUpDown16
            // 
            this.numericUpDown16.Location = new System.Drawing.Point(190, 52);
            this.numericUpDown16.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown16.Name = "numericUpDown16";
            this.numericUpDown16.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown16.TabIndex = 98;
            this.numericUpDown16.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            // 
            // label293
            // 
            this.label293.AutoSize = true;
            this.label293.Location = new System.Drawing.Point(6, 206);
            this.label293.Name = "label293";
            this.label293.Size = new System.Drawing.Size(180, 15);
            this.label293.TabIndex = 111;
            this.label293.Text = "Delay Chấp Nhận  BM9 FAIL(s): ";
            // 
            // label292
            // 
            this.label292.AutoSize = true;
            this.label292.Location = new System.Drawing.Point(6, 75);
            this.label292.Name = "label292";
            this.label292.Size = new System.Drawing.Size(180, 15);
            this.label292.TabIndex = 99;
            this.label292.Text = "Delay Chấp Nhận  BM3 FAIL(s): ";
            // 
            // numericUpDown21
            // 
            this.numericUpDown21.Location = new System.Drawing.Point(190, 182);
            this.numericUpDown21.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown21.Name = "numericUpDown21";
            this.numericUpDown21.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown21.TabIndex = 110;
            this.numericUpDown21.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // numericUpDown18
            // 
            this.numericUpDown18.Location = new System.Drawing.Point(190, 73);
            this.numericUpDown18.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown18.Name = "numericUpDown18";
            this.numericUpDown18.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown18.TabIndex = 100;
            this.numericUpDown18.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            // 
            // label295
            // 
            this.label295.AutoSize = true;
            this.label295.Location = new System.Drawing.Point(6, 184);
            this.label295.Name = "label295";
            this.label295.Size = new System.Drawing.Size(180, 15);
            this.label295.TabIndex = 109;
            this.label295.Text = "Delay Chấp Nhận  BM8 FAIL(s): ";
            // 
            // label291
            // 
            this.label291.AutoSize = true;
            this.label291.Location = new System.Drawing.Point(6, 97);
            this.label291.Name = "label291";
            this.label291.Size = new System.Drawing.Size(180, 15);
            this.label291.TabIndex = 101;
            this.label291.Text = "Delay Chấp Nhận  BM4 FAIL(s): ";
            // 
            // numericUpDown22
            // 
            this.numericUpDown22.Location = new System.Drawing.Point(190, 160);
            this.numericUpDown22.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown22.Name = "numericUpDown22";
            this.numericUpDown22.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown22.TabIndex = 108;
            this.numericUpDown22.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // numericUpDown17
            // 
            this.numericUpDown17.Location = new System.Drawing.Point(190, 95);
            this.numericUpDown17.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown17.Name = "numericUpDown17";
            this.numericUpDown17.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown17.TabIndex = 102;
            this.numericUpDown17.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label296
            // 
            this.label296.AutoSize = true;
            this.label296.Location = new System.Drawing.Point(6, 162);
            this.label296.Name = "label296";
            this.label296.Size = new System.Drawing.Size(180, 15);
            this.label296.TabIndex = 107;
            this.label296.Text = "Delay Chấp Nhận  BM7 FAIL(s): ";
            // 
            // label294
            // 
            this.label294.AutoSize = true;
            this.label294.Location = new System.Drawing.Point(6, 119);
            this.label294.Name = "label294";
            this.label294.Size = new System.Drawing.Size(180, 15);
            this.label294.TabIndex = 103;
            this.label294.Text = "Delay Chấp Nhận  BM5 FAIL(s): ";
            // 
            // numericUpDown23
            // 
            this.numericUpDown23.Location = new System.Drawing.Point(190, 139);
            this.numericUpDown23.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown23.Name = "numericUpDown23";
            this.numericUpDown23.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown23.TabIndex = 106;
            this.numericUpDown23.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // numericUpDown20
            // 
            this.numericUpDown20.Location = new System.Drawing.Point(190, 117);
            this.numericUpDown20.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown20.Name = "numericUpDown20";
            this.numericUpDown20.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown20.TabIndex = 104;
            this.numericUpDown20.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label297
            // 
            this.label297.AutoSize = true;
            this.label297.Location = new System.Drawing.Point(6, 141);
            this.label297.Name = "label297";
            this.label297.Size = new System.Drawing.Size(180, 15);
            this.label297.TabIndex = 105;
            this.label297.Text = "Delay Chấp Nhận  BM6 FAIL(s): ";
            // 
            // tabPage32
            // 
            this.tabPage32.BackColor = System.Drawing.Color.DimGray;
            this.tabPage32.Controls.Add(this.groupBox25);
            this.tabPage32.Location = new System.Drawing.Point(4, 24);
            this.tabPage32.Name = "tabPage32";
            this.tabPage32.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage32.Size = new System.Drawing.Size(338, 280);
            this.tabPage32.TabIndex = 1;
            this.tabPage32.Text = "BM11-20";
            // 
            // groupBox25
            // 
            this.groupBox25.Controls.Add(this.label316);
            this.groupBox25.Controls.Add(this.numericUpDown25);
            this.groupBox25.Controls.Add(this.numericUpDown26);
            this.groupBox25.Controls.Add(this.label317);
            this.groupBox25.Controls.Add(this.label318);
            this.groupBox25.Controls.Add(this.numericUpDown27);
            this.groupBox25.Controls.Add(this.numericUpDown28);
            this.groupBox25.Controls.Add(this.label319);
            this.groupBox25.Controls.Add(this.label320);
            this.groupBox25.Controls.Add(this.numericUpDown29);
            this.groupBox25.Controls.Add(this.numericUpDown30);
            this.groupBox25.Controls.Add(this.label321);
            this.groupBox25.Controls.Add(this.label322);
            this.groupBox25.Controls.Add(this.numericUpDown31);
            this.groupBox25.Controls.Add(this.numericUpDown32);
            this.groupBox25.Controls.Add(this.label323);
            this.groupBox25.Controls.Add(this.label324);
            this.groupBox25.Controls.Add(this.numericUpDown33);
            this.groupBox25.Controls.Add(this.numericUpDown34);
            this.groupBox25.Controls.Add(this.label325);
            this.groupBox25.Location = new System.Drawing.Point(6, 8);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Size = new System.Drawing.Size(323, 266);
            this.groupBox25.TabIndex = 116;
            this.groupBox25.TabStop = false;
            this.groupBox25.Text = "Time delay 11-20";
            // 
            // label316
            // 
            this.label316.AutoSize = true;
            this.label316.Location = new System.Drawing.Point(6, 32);
            this.label316.Name = "label316";
            this.label316.Size = new System.Drawing.Size(185, 15);
            this.label316.TabIndex = 95;
            this.label316.Text = "Delay Chấp Nhận  BM11 FAIL(s): ";
            // 
            // numericUpDown25
            // 
            this.numericUpDown25.Location = new System.Drawing.Point(190, 226);
            this.numericUpDown25.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown25.Name = "numericUpDown25";
            this.numericUpDown25.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown25.TabIndex = 114;
            this.numericUpDown25.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numericUpDown26
            // 
            this.numericUpDown26.Location = new System.Drawing.Point(190, 30);
            this.numericUpDown26.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown26.Name = "numericUpDown26";
            this.numericUpDown26.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown26.TabIndex = 96;
            this.numericUpDown26.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label317
            // 
            this.label317.AutoSize = true;
            this.label317.Location = new System.Drawing.Point(6, 228);
            this.label317.Name = "label317";
            this.label317.Size = new System.Drawing.Size(186, 15);
            this.label317.TabIndex = 113;
            this.label317.Text = "Delay Chấp Nhận  BM20 FAIL(s): ";
            // 
            // label318
            // 
            this.label318.AutoSize = true;
            this.label318.Location = new System.Drawing.Point(6, 54);
            this.label318.Name = "label318";
            this.label318.Size = new System.Drawing.Size(186, 15);
            this.label318.TabIndex = 97;
            this.label318.Text = "Delay Chấp Nhận  BM12 FAIL(s): ";
            // 
            // numericUpDown27
            // 
            this.numericUpDown27.Location = new System.Drawing.Point(190, 204);
            this.numericUpDown27.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown27.Name = "numericUpDown27";
            this.numericUpDown27.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown27.TabIndex = 112;
            this.numericUpDown27.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numericUpDown28
            // 
            this.numericUpDown28.Location = new System.Drawing.Point(190, 52);
            this.numericUpDown28.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown28.Name = "numericUpDown28";
            this.numericUpDown28.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown28.TabIndex = 98;
            this.numericUpDown28.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label319
            // 
            this.label319.AutoSize = true;
            this.label319.Location = new System.Drawing.Point(6, 206);
            this.label319.Name = "label319";
            this.label319.Size = new System.Drawing.Size(186, 15);
            this.label319.TabIndex = 111;
            this.label319.Text = "Delay Chấp Nhận  BM19 FAIL(s): ";
            // 
            // label320
            // 
            this.label320.AutoSize = true;
            this.label320.Location = new System.Drawing.Point(6, 75);
            this.label320.Name = "label320";
            this.label320.Size = new System.Drawing.Size(186, 15);
            this.label320.TabIndex = 99;
            this.label320.Text = "Delay Chấp Nhận  BM13 FAIL(s): ";
            // 
            // numericUpDown29
            // 
            this.numericUpDown29.Location = new System.Drawing.Point(190, 182);
            this.numericUpDown29.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown29.Name = "numericUpDown29";
            this.numericUpDown29.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown29.TabIndex = 110;
            this.numericUpDown29.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numericUpDown30
            // 
            this.numericUpDown30.Location = new System.Drawing.Point(190, 73);
            this.numericUpDown30.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown30.Name = "numericUpDown30";
            this.numericUpDown30.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown30.TabIndex = 100;
            this.numericUpDown30.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label321
            // 
            this.label321.AutoSize = true;
            this.label321.Location = new System.Drawing.Point(6, 184);
            this.label321.Name = "label321";
            this.label321.Size = new System.Drawing.Size(186, 15);
            this.label321.TabIndex = 109;
            this.label321.Text = "Delay Chấp Nhận  BM18 FAIL(s): ";
            // 
            // label322
            // 
            this.label322.AutoSize = true;
            this.label322.Location = new System.Drawing.Point(6, 97);
            this.label322.Name = "label322";
            this.label322.Size = new System.Drawing.Size(186, 15);
            this.label322.TabIndex = 101;
            this.label322.Text = "Delay Chấp Nhận  BM14 FAIL(s): ";
            // 
            // numericUpDown31
            // 
            this.numericUpDown31.Location = new System.Drawing.Point(190, 160);
            this.numericUpDown31.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown31.Name = "numericUpDown31";
            this.numericUpDown31.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown31.TabIndex = 108;
            this.numericUpDown31.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numericUpDown32
            // 
            this.numericUpDown32.Location = new System.Drawing.Point(190, 95);
            this.numericUpDown32.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown32.Name = "numericUpDown32";
            this.numericUpDown32.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown32.TabIndex = 102;
            this.numericUpDown32.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label323
            // 
            this.label323.AutoSize = true;
            this.label323.Location = new System.Drawing.Point(6, 162);
            this.label323.Name = "label323";
            this.label323.Size = new System.Drawing.Size(186, 15);
            this.label323.TabIndex = 107;
            this.label323.Text = "Delay Chấp Nhận  BM17 FAIL(s): ";
            // 
            // label324
            // 
            this.label324.AutoSize = true;
            this.label324.Location = new System.Drawing.Point(6, 119);
            this.label324.Name = "label324";
            this.label324.Size = new System.Drawing.Size(186, 15);
            this.label324.TabIndex = 103;
            this.label324.Text = "Delay Chấp Nhận  BM15 FAIL(s): ";
            // 
            // numericUpDown33
            // 
            this.numericUpDown33.Location = new System.Drawing.Point(190, 139);
            this.numericUpDown33.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown33.Name = "numericUpDown33";
            this.numericUpDown33.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown33.TabIndex = 106;
            this.numericUpDown33.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // numericUpDown34
            // 
            this.numericUpDown34.Location = new System.Drawing.Point(190, 117);
            this.numericUpDown34.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown34.Name = "numericUpDown34";
            this.numericUpDown34.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown34.TabIndex = 104;
            this.numericUpDown34.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label325
            // 
            this.label325.AutoSize = true;
            this.label325.Location = new System.Drawing.Point(6, 141);
            this.label325.Name = "label325";
            this.label325.Size = new System.Drawing.Size(186, 15);
            this.label325.TabIndex = 105;
            this.label325.Text = "Delay Chấp Nhận  BM16 FAIL(s): ";
            // 
            // cmb_Doi_Ten_BM
            // 
            this.cmb_Doi_Ten_BM.FormattingEnabled = true;
            this.cmb_Doi_Ten_BM.Location = new System.Drawing.Point(421, 286);
            this.cmb_Doi_Ten_BM.Name = "cmb_Doi_Ten_BM";
            this.cmb_Doi_Ten_BM.Size = new System.Drawing.Size(121, 23);
            this.cmb_Doi_Ten_BM.TabIndex = 94;
            // 
            // label288
            // 
            this.label288.AutoSize = true;
            this.label288.Location = new System.Drawing.Point(265, 289);
            this.label288.Name = "label288";
            this.label288.Size = new System.Drawing.Size(141, 15);
            this.label288.TabIndex = 93;
            this.label288.Text = "ĐỔI TÊN BM CÓ ID TK:";
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button7.Location = new System.Drawing.Point(1197, 316);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 49);
            this.button7.TabIndex = 38;
            this.button7.Text = "DETELE ID ";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // cmb_NO_CLOSE_TK_D2
            // 
            this.cmb_NO_CLOSE_TK_D2.FormattingEnabled = true;
            this.cmb_NO_CLOSE_TK_D2.Location = new System.Drawing.Point(110, 395);
            this.cmb_NO_CLOSE_TK_D2.Name = "cmb_NO_CLOSE_TK_D2";
            this.cmb_NO_CLOSE_TK_D2.Size = new System.Drawing.Size(122, 23);
            this.cmb_NO_CLOSE_TK_D2.TabIndex = 92;
            // 
            // label255
            // 
            this.label255.AutoSize = true;
            this.label255.Location = new System.Drawing.Point(12, 377);
            this.label255.Name = "label255";
            this.label255.Size = new System.Drawing.Size(111, 15);
            this.label255.TabIndex = 91;
            this.label255.Text = "NO CLOSE AC D2:";
            // 
            // cmb_Logingmail_trc
            // 
            this.cmb_Logingmail_trc.FormattingEnabled = true;
            this.cmb_Logingmail_trc.Location = new System.Drawing.Point(112, 351);
            this.cmb_Logingmail_trc.Name = "cmb_Logingmail_trc";
            this.cmb_Logingmail_trc.Size = new System.Drawing.Size(122, 23);
            this.cmb_Logingmail_trc.TabIndex = 90;
            // 
            // label254
            // 
            this.label254.AutoSize = true;
            this.label254.Location = new System.Drawing.Point(8, 333);
            this.label254.Name = "label254";
            this.label254.Size = new System.Drawing.Size(139, 15);
            this.label254.TabIndex = 89;
            this.label254.Text = "LOGIN GMAIL TRƯỚC:";
            // 
            // cmb_chi_Share_LIVE
            // 
            this.cmb_chi_Share_LIVE.FormattingEnabled = true;
            this.cmb_chi_Share_LIVE.Location = new System.Drawing.Point(1557, 14);
            this.cmb_chi_Share_LIVE.Name = "cmb_chi_Share_LIVE";
            this.cmb_chi_Share_LIVE.Size = new System.Drawing.Size(121, 23);
            this.cmb_chi_Share_LIVE.TabIndex = 88;
            // 
            // label253
            // 
            this.label253.AutoSize = true;
            this.label253.Location = new System.Drawing.Point(1446, 17);
            this.label253.Name = "label253";
            this.label253.Size = new System.Drawing.Size(105, 15);
            this.label253.TabIndex = 87;
            this.label253.Text = "CHỈ SHARE LIVE:";
            // 
            // numericUpDown14
            // 
            this.numericUpDown14.Location = new System.Drawing.Point(422, 259);
            this.numericUpDown14.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown14.Name = "numericUpDown14";
            this.numericUpDown14.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown14.TabIndex = 86;
            this.numericUpDown14.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label252
            // 
            this.label252.AutoSize = true;
            this.label252.Location = new System.Drawing.Point(311, 263);
            this.label252.Name = "label252";
            this.label252.Size = new System.Drawing.Size(95, 15);
            this.label252.TabIndex = 85;
            this.label252.Text = "STK 1 BM ADD:";
            // 
            // label251
            // 
            this.label251.AutoSize = true;
            this.label251.Location = new System.Drawing.Point(1444, 157);
            this.label251.Name = "label251";
            this.label251.Size = new System.Drawing.Size(51, 15);
            this.label251.TabIndex = 84;
            this.label251.Text = "AC DIE:";
            // 
            // rtb_AC_DIE
            // 
            this.rtb_AC_DIE.Location = new System.Drawing.Point(1447, 172);
            this.rtb_AC_DIE.Name = "rtb_AC_DIE";
            this.rtb_AC_DIE.Size = new System.Drawing.Size(231, 281);
            this.rtb_AC_DIE.TabIndex = 83;
            this.rtb_AC_DIE.Text = "";
            // 
            // numericUpDown13
            // 
            this.numericUpDown13.Location = new System.Drawing.Point(422, 232);
            this.numericUpDown13.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown13.Name = "numericUpDown13";
            this.numericUpDown13.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown13.TabIndex = 82;
            this.numericUpDown13.Value = new decimal(new int[] {
            180,
            0,
            0,
            0});
            // 
            // label250
            // 
            this.label250.AutoSize = true;
            this.label250.Location = new System.Drawing.Point(296, 234);
            this.label250.Name = "label250";
            this.label250.Size = new System.Drawing.Size(118, 15);
            this.label250.TabIndex = 81;
            this.label250.Text = "Delay Chấp Nhận(s):";
            // 
            // label249
            // 
            this.label249.AutoSize = true;
            this.label249.Location = new System.Drawing.Point(1185, 164);
            this.label249.Name = "label249";
            this.label249.Size = new System.Drawing.Size(87, 15);
            this.label249.TabIndex = 80;
            this.label249.Text = "IDBM CLOSE:";
            // 
            // rtb_IDBM_CLOSECL
            // 
            this.rtb_IDBM_CLOSECL.Location = new System.Drawing.Point(1188, 182);
            this.rtb_IDBM_CLOSECL.Name = "rtb_IDBM_CLOSECL";
            this.rtb_IDBM_CLOSECL.Size = new System.Drawing.Size(231, 116);
            this.rtb_IDBM_CLOSECL.TabIndex = 79;
            this.rtb_IDBM_CLOSECL.Text = "";
            // 
            // label248
            // 
            this.label248.AutoSize = true;
            this.label248.Location = new System.Drawing.Point(1185, 17);
            this.label248.Name = "label248";
            this.label248.Size = new System.Drawing.Size(72, 15);
            this.label248.TabIndex = 78;
            this.label248.Text = "IDBM LIVE:";
            // 
            // rtb_IDBM_LIVE
            // 
            this.rtb_IDBM_LIVE.Location = new System.Drawing.Point(1188, 35);
            this.rtb_IDBM_LIVE.Name = "rtb_IDBM_LIVE";
            this.rtb_IDBM_LIVE.Size = new System.Drawing.Size(231, 116);
            this.rtb_IDBM_LIVE.TabIndex = 77;
            this.rtb_IDBM_LIVE.Text = "";
            // 
            // numericUpDown12
            // 
            this.numericUpDown12.Location = new System.Drawing.Point(422, 205);
            this.numericUpDown12.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown12.Name = "numericUpDown12";
            this.numericUpDown12.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown12.TabIndex = 76;
            // 
            // label247
            // 
            this.label247.AutoSize = true;
            this.label247.Location = new System.Drawing.Point(324, 207);
            this.label247.Name = "label247";
            this.label247.Size = new System.Drawing.Size(91, 15);
            this.label247.TabIndex = 75;
            this.label247.Text = "Delay CLose(s):";
            // 
            // numericUpDown11
            // 
            this.numericUpDown11.Location = new System.Drawing.Point(422, 173);
            this.numericUpDown11.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown11.Name = "numericUpDown11";
            this.numericUpDown11.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown11.TabIndex = 74;
            this.numericUpDown11.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // label246
            // 
            this.label246.AutoSize = true;
            this.label246.Location = new System.Drawing.Point(252, 177);
            this.label246.Name = "label246";
            this.label246.Size = new System.Drawing.Size(164, 15);
            this.label246.TabIndex = 73;
            this.label246.Text = "LUỒNG CHẠY REG BM2025:";
            // 
            // label245
            // 
            this.label245.AutoSize = true;
            this.label245.Location = new System.Drawing.Point(864, 157);
            this.label245.Name = "label245";
            this.label245.Size = new System.Drawing.Size(72, 15);
            this.label245.TabIndex = 72;
            this.label245.Text = "AC CLOSE:";
            // 
            // rtb_AC_CLOSE
            // 
            this.rtb_AC_CLOSE.Location = new System.Drawing.Point(867, 182);
            this.rtb_AC_CLOSE.Name = "rtb_AC_CLOSE";
            this.rtb_AC_CLOSE.Size = new System.Drawing.Size(231, 281);
            this.rtb_AC_CLOSE.TabIndex = 71;
            this.rtb_AC_CLOSE.Text = "";
            // 
            // label244
            // 
            this.label244.AutoSize = true;
            this.label244.Location = new System.Drawing.Point(607, 157);
            this.label244.Name = "label244";
            this.label244.Size = new System.Drawing.Size(57, 15);
            this.label244.TabIndex = 70;
            this.label244.Text = "AC LIVE:";
            // 
            // rtb_ACLIVE
            // 
            this.rtb_ACLIVE.Location = new System.Drawing.Point(610, 182);
            this.rtb_ACLIVE.Name = "rtb_ACLIVE";
            this.rtb_ACLIVE.Size = new System.Drawing.Size(231, 281);
            this.rtb_ACLIVE.TabIndex = 69;
            this.rtb_ACLIVE.Text = "";
            // 
            // cmb_MUI_GIO_BMCL
            // 
            this.cmb_MUI_GIO_BMCL.FormattingEnabled = true;
            this.cmb_MUI_GIO_BMCL.Location = new System.Drawing.Point(112, 307);
            this.cmb_MUI_GIO_BMCL.Name = "cmb_MUI_GIO_BMCL";
            this.cmb_MUI_GIO_BMCL.Size = new System.Drawing.Size(122, 23);
            this.cmb_MUI_GIO_BMCL.TabIndex = 68;
            // 
            // label240
            // 
            this.label240.AutoSize = true;
            this.label240.Location = new System.Drawing.Point(48, 309);
            this.label240.Name = "label240";
            this.label240.Size = new System.Drawing.Size(56, 15);
            this.label240.TabIndex = 67;
            this.label240.Text = "Múi Giờ:";
            // 
            // cmb_TEN_TKBM_CL
            // 
            this.cmb_TEN_TKBM_CL.FormattingEnabled = true;
            this.cmb_TEN_TKBM_CL.Location = new System.Drawing.Point(112, 275);
            this.cmb_TEN_TKBM_CL.Name = "cmb_TEN_TKBM_CL";
            this.cmb_TEN_TKBM_CL.Size = new System.Drawing.Size(122, 23);
            this.cmb_TEN_TKBM_CL.TabIndex = 66;
            // 
            // label241
            // 
            this.label241.AutoSize = true;
            this.label241.Location = new System.Drawing.Point(32, 278);
            this.label241.Name = "label241";
            this.label241.Size = new System.Drawing.Size(74, 15);
            this.label241.TabIndex = 65;
            this.label241.Text = "Tên TK BM:";
            // 
            // cmb_TIENTE_BM_CL
            // 
            this.cmb_TIENTE_BM_CL.FormattingEnabled = true;
            this.cmb_TIENTE_BM_CL.Location = new System.Drawing.Point(112, 240);
            this.cmb_TIENTE_BM_CL.Name = "cmb_TIENTE_BM_CL";
            this.cmb_TIENTE_BM_CL.Size = new System.Drawing.Size(122, 23);
            this.cmb_TIENTE_BM_CL.TabIndex = 64;
            // 
            // label242
            // 
            this.label242.AutoSize = true;
            this.label242.Location = new System.Drawing.Point(47, 246);
            this.label242.Name = "label242";
            this.label242.Size = new System.Drawing.Size(53, 15);
            this.label242.TabIndex = 63;
            this.label242.Text = "Tiền Tệ:";
            // 
            // cmb_TAOTK_CL
            // 
            this.cmb_TAOTK_CL.FormattingEnabled = true;
            this.cmb_TAOTK_CL.Location = new System.Drawing.Point(112, 211);
            this.cmb_TAOTK_CL.Name = "cmb_TAOTK_CL";
            this.cmb_TAOTK_CL.Size = new System.Drawing.Size(122, 23);
            this.cmb_TAOTK_CL.TabIndex = 62;
            // 
            // label243
            // 
            this.label243.AutoSize = true;
            this.label243.Location = new System.Drawing.Point(49, 214);
            this.label243.Name = "label243";
            this.label243.Size = new System.Drawing.Size(51, 15);
            this.label243.TabIndex = 61;
            this.label243.Text = "Tạo TK:";
            // 
            // label239
            // 
            this.label239.AutoSize = true;
            this.label239.Location = new System.Drawing.Point(864, 17);
            this.label239.Name = "label239";
            this.label239.Size = new System.Drawing.Size(80, 15);
            this.label239.TabIndex = 60;
            this.label239.Text = "MAIL BM350:";
            // 
            // rtb_BM350_CL
            // 
            this.rtb_BM350_CL.Location = new System.Drawing.Point(867, 38);
            this.rtb_BM350_CL.Name = "rtb_BM350_CL";
            this.rtb_BM350_CL.Size = new System.Drawing.Size(231, 116);
            this.rtb_BM350_CL.TabIndex = 59;
            this.rtb_BM350_CL.Text = "";
            // 
            // label238
            // 
            this.label238.AutoSize = true;
            this.label238.Location = new System.Drawing.Point(607, 17);
            this.label238.Name = "label238";
            this.label238.Size = new System.Drawing.Size(74, 15);
            this.label238.TabIndex = 58;
            this.label238.Text = "MAIL BM50:";
            // 
            // rtb_BM50_CL
            // 
            this.rtb_BM50_CL.Location = new System.Drawing.Point(610, 38);
            this.rtb_BM50_CL.Name = "rtb_BM50_CL";
            this.rtb_BM50_CL.Size = new System.Drawing.Size(231, 116);
            this.rtb_BM50_CL.TabIndex = 57;
            this.rtb_BM50_CL.Text = "";
            // 
            // label236
            // 
            this.label236.AutoSize = true;
            this.label236.Location = new System.Drawing.Point(306, 136);
            this.label236.Name = "label236";
            this.label236.Size = new System.Drawing.Size(69, 15);
            this.label236.TabIndex = 56;
            this.label236.Text = "Delay REG:";
            // 
            // delay_regbm_cl
            // 
            this.delay_regbm_cl.Location = new System.Drawing.Point(422, 136);
            this.delay_regbm_cl.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.delay_regbm_cl.Name = "delay_regbm_cl";
            this.delay_regbm_cl.Size = new System.Drawing.Size(120, 21);
            this.delay_regbm_cl.TabIndex = 55;
            // 
            // label237
            // 
            this.label237.AutoSize = true;
            this.label237.Location = new System.Drawing.Point(324, 110);
            this.label237.Name = "label237";
            this.label237.Size = new System.Drawing.Size(48, 15);
            this.label237.TabIndex = 54;
            this.label237.Text = "for BM:";
            // 
            // number_REGBMCL
            // 
            this.number_REGBMCL.Location = new System.Drawing.Point(422, 104);
            this.number_REGBMCL.Name = "number_REGBMCL";
            this.number_REGBMCL.Size = new System.Drawing.Size(120, 21);
            this.number_REGBMCL.TabIndex = 53;
            this.number_REGBMCL.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label235
            // 
            this.label235.AutoSize = true;
            this.label235.Location = new System.Drawing.Point(359, 71);
            this.label235.Name = "label235";
            this.label235.Size = new System.Drawing.Size(57, 15);
            this.label235.TabIndex = 52;
            this.label235.Text = "REG BM:";
            // 
            // cmb_REGBMVIA
            // 
            this.cmb_REGBMVIA.FormattingEnabled = true;
            this.cmb_REGBMVIA.Location = new System.Drawing.Point(422, 68);
            this.cmb_REGBMVIA.Name = "cmb_REGBMVIA";
            this.cmb_REGBMVIA.Size = new System.Drawing.Size(121, 23);
            this.cmb_REGBMVIA.TabIndex = 51;
            // 
            // label234
            // 
            this.label234.AutoSize = true;
            this.label234.Location = new System.Drawing.Point(316, 38);
            this.label234.Name = "label234";
            this.label234.Size = new System.Drawing.Size(100, 15);
            this.label234.TabIndex = 50;
            this.label234.Text = "SHARE DONG 2:";
            // 
            // cmb_share_D2VIA
            // 
            this.cmb_share_D2VIA.FormattingEnabled = true;
            this.cmb_share_D2VIA.Location = new System.Drawing.Point(422, 35);
            this.cmb_share_D2VIA.Name = "cmb_share_D2VIA";
            this.cmb_share_D2VIA.Size = new System.Drawing.Size(121, 23);
            this.cmb_share_D2VIA.TabIndex = 49;
            // 
            // cmb_radom_ncFB
            // 
            this.cmb_radom_ncFB.FormattingEnabled = true;
            this.cmb_radom_ncFB.Location = new System.Drawing.Point(114, 169);
            this.cmb_radom_ncFB.Name = "cmb_radom_ncFB";
            this.cmb_radom_ncFB.Size = new System.Drawing.Size(121, 23);
            this.cmb_radom_ncFB.TabIndex = 48;
            // 
            // label233
            // 
            this.label233.AutoSize = true;
            this.label233.Location = new System.Drawing.Point(6, 175);
            this.label233.Name = "label233";
            this.label233.Size = new System.Drawing.Size(90, 15);
            this.label233.TabIndex = 47;
            this.label233.Text = "RANDOM NC :";
            // 
            // cmb_VN_US_INDIA
            // 
            this.cmb_VN_US_INDIA.FormattingEnabled = true;
            this.cmb_VN_US_INDIA.Location = new System.Drawing.Point(114, 136);
            this.cmb_VN_US_INDIA.Name = "cmb_VN_US_INDIA";
            this.cmb_VN_US_INDIA.Size = new System.Drawing.Size(121, 23);
            this.cmb_VN_US_INDIA.TabIndex = 46;
            // 
            // label232
            // 
            this.label232.AutoSize = true;
            this.label232.Location = new System.Drawing.Point(8, 139);
            this.label232.Name = "label232";
            this.label232.Size = new System.Drawing.Size(99, 15);
            this.label232.TabIndex = 45;
            this.label232.Text = "VN_US_INDIA.. :";
            // 
            // label231
            // 
            this.label231.AutoSize = true;
            this.label231.Location = new System.Drawing.Point(8, 104);
            this.label231.Name = "label231";
            this.label231.Size = new System.Drawing.Size(88, 15);
            this.label231.TabIndex = 44;
            this.label231.Text = "ON / OFF 2FA :";
            // 
            // cmb_on2FAFB
            // 
            this.cmb_on2FAFB.FormattingEnabled = true;
            this.cmb_on2FAFB.Location = new System.Drawing.Point(114, 101);
            this.cmb_on2FAFB.Name = "cmb_on2FAFB";
            this.cmb_on2FAFB.Size = new System.Drawing.Size(121, 23);
            this.cmb_on2FAFB.TabIndex = 43;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(30, 71);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(63, 15);
            this.label44.TabIndex = 42;
            this.label44.Text = "NO VERI :";
            // 
            // cmb_noveri
            // 
            this.cmb_noveri.FormattingEnabled = true;
            this.cmb_noveri.Location = new System.Drawing.Point(114, 68);
            this.cmb_noveri.Name = "cmb_noveri";
            this.cmb_noveri.Size = new System.Drawing.Size(121, 23);
            this.cmb_noveri.TabIndex = 41;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(71, 38);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(22, 15);
            this.label43.TabIndex = 40;
            this.label43.Text = "IP:";
            // 
            // cmb_IP
            // 
            this.cmb_IP.FormattingEnabled = true;
            this.cmb_IP.Location = new System.Drawing.Point(113, 35);
            this.cmb_IP.Name = "cmb_IP";
            this.cmb_IP.Size = new System.Drawing.Size(121, 23);
            this.cmb_IP.TabIndex = 39;
            // 
            // tabPage29
            // 
            this.tabPage29.BackColor = System.Drawing.Color.Silver;
            this.tabPage29.Controls.Add(this.button6);
            this.tabPage29.Controls.Add(this.groupBox21);
            this.tabPage29.Controls.Add(this.groupBox19);
            this.tabPage29.Controls.Add(this.groupBox22);
            this.tabPage29.Controls.Add(this.groupBox17);
            this.tabPage29.Controls.Add(this.groupBox20);
            this.tabPage29.Controls.Add(this.groupBox18);
            this.tabPage29.Controls.Add(this.groupBox16);
            this.tabPage29.Controls.Add(this.groupBox15);
            this.tabPage29.Location = new System.Drawing.Point(4, 24);
            this.tabPage29.Name = "tabPage29";
            this.tabPage29.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage29.Size = new System.Drawing.Size(1763, 657);
            this.tabPage29.TabIndex = 1;
            this.tabPage29.Text = "VIA 1 - 8";
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button6.Location = new System.Drawing.Point(1521, 16);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 49);
            this.button6.TabIndex = 38;
            this.button6.Text = "DELETE ID";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.rtb_IDBM_LIVE8);
            this.groupBox21.Controls.Add(this.label280);
            this.groupBox21.Controls.Add(this.label281);
            this.groupBox21.Controls.Add(this.label282);
            this.groupBox21.Controls.Add(this.label283);
            this.groupBox21.Controls.Add(this.rtb_AC_CLOSE8);
            this.groupBox21.Controls.Add(this.rtb_IDBM_CLOSECL8);
            this.groupBox21.Controls.Add(this.rtb_ACLIVE8);
            this.groupBox21.Location = new System.Drawing.Point(1080, 330);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(352, 320);
            this.groupBox21.TabIndex = 95;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "VIA 8";
            // 
            // rtb_IDBM_LIVE8
            // 
            this.rtb_IDBM_LIVE8.Location = new System.Drawing.Point(31, 45);
            this.rtb_IDBM_LIVE8.Name = "rtb_IDBM_LIVE8";
            this.rtb_IDBM_LIVE8.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_LIVE8.TabIndex = 81;
            this.rtb_IDBM_LIVE8.Text = "";
            // 
            // label280
            // 
            this.label280.AutoSize = true;
            this.label280.Location = new System.Drawing.Point(219, 164);
            this.label280.Name = "label280";
            this.label280.Size = new System.Drawing.Size(72, 15);
            this.label280.TabIndex = 89;
            this.label280.Text = "AC CLOSE:";
            // 
            // label281
            // 
            this.label281.AutoSize = true;
            this.label281.Location = new System.Drawing.Point(64, 27);
            this.label281.Name = "label281";
            this.label281.Size = new System.Drawing.Size(72, 15);
            this.label281.TabIndex = 82;
            this.label281.Text = "IDBM LIVE:";
            // 
            // label282
            // 
            this.label282.AutoSize = true;
            this.label282.Location = new System.Drawing.Point(64, 164);
            this.label282.Name = "label282";
            this.label282.Size = new System.Drawing.Size(57, 15);
            this.label282.TabIndex = 88;
            this.label282.Text = "AC LIVE:";
            // 
            // label283
            // 
            this.label283.AutoSize = true;
            this.label283.Location = new System.Drawing.Point(219, 27);
            this.label283.Name = "label283";
            this.label283.Size = new System.Drawing.Size(87, 15);
            this.label283.TabIndex = 84;
            this.label283.Text = "IDBM CLOSE:";
            // 
            // rtb_AC_CLOSE8
            // 
            this.rtb_AC_CLOSE8.Location = new System.Drawing.Point(182, 183);
            this.rtb_AC_CLOSE8.Name = "rtb_AC_CLOSE8";
            this.rtb_AC_CLOSE8.Size = new System.Drawing.Size(145, 116);
            this.rtb_AC_CLOSE8.TabIndex = 87;
            this.rtb_AC_CLOSE8.Text = "";
            // 
            // rtb_IDBM_CLOSECL8
            // 
            this.rtb_IDBM_CLOSECL8.Location = new System.Drawing.Point(182, 45);
            this.rtb_IDBM_CLOSECL8.Name = "rtb_IDBM_CLOSECL8";
            this.rtb_IDBM_CLOSECL8.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_CLOSECL8.TabIndex = 85;
            this.rtb_IDBM_CLOSECL8.Text = "";
            // 
            // rtb_ACLIVE8
            // 
            this.rtb_ACLIVE8.Location = new System.Drawing.Point(31, 183);
            this.rtb_ACLIVE8.Name = "rtb_ACLIVE8";
            this.rtb_ACLIVE8.Size = new System.Drawing.Size(145, 116);
            this.rtb_ACLIVE8.TabIndex = 86;
            this.rtb_ACLIVE8.Text = "";
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.rtb_IDBM_LIVE6);
            this.groupBox19.Controls.Add(this.label272);
            this.groupBox19.Controls.Add(this.label273);
            this.groupBox19.Controls.Add(this.label274);
            this.groupBox19.Controls.Add(this.label275);
            this.groupBox19.Controls.Add(this.rtb_AC_CLOSE6);
            this.groupBox19.Controls.Add(this.rtb_IDBM_CLOSECL6);
            this.groupBox19.Controls.Add(this.rtb_ACLIVE6);
            this.groupBox19.Location = new System.Drawing.Point(364, 330);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(352, 320);
            this.groupBox19.TabIndex = 93;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "VIA 6";
            // 
            // rtb_IDBM_LIVE6
            // 
            this.rtb_IDBM_LIVE6.Location = new System.Drawing.Point(31, 45);
            this.rtb_IDBM_LIVE6.Name = "rtb_IDBM_LIVE6";
            this.rtb_IDBM_LIVE6.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_LIVE6.TabIndex = 81;
            this.rtb_IDBM_LIVE6.Text = "";
            // 
            // label272
            // 
            this.label272.AutoSize = true;
            this.label272.Location = new System.Drawing.Point(219, 164);
            this.label272.Name = "label272";
            this.label272.Size = new System.Drawing.Size(72, 15);
            this.label272.TabIndex = 89;
            this.label272.Text = "AC CLOSE:";
            // 
            // label273
            // 
            this.label273.AutoSize = true;
            this.label273.Location = new System.Drawing.Point(64, 27);
            this.label273.Name = "label273";
            this.label273.Size = new System.Drawing.Size(72, 15);
            this.label273.TabIndex = 82;
            this.label273.Text = "IDBM LIVE:";
            // 
            // label274
            // 
            this.label274.AutoSize = true;
            this.label274.Location = new System.Drawing.Point(64, 164);
            this.label274.Name = "label274";
            this.label274.Size = new System.Drawing.Size(57, 15);
            this.label274.TabIndex = 88;
            this.label274.Text = "AC LIVE:";
            // 
            // label275
            // 
            this.label275.AutoSize = true;
            this.label275.Location = new System.Drawing.Point(219, 27);
            this.label275.Name = "label275";
            this.label275.Size = new System.Drawing.Size(87, 15);
            this.label275.TabIndex = 84;
            this.label275.Text = "IDBM CLOSE:";
            // 
            // rtb_AC_CLOSE6
            // 
            this.rtb_AC_CLOSE6.Location = new System.Drawing.Point(182, 183);
            this.rtb_AC_CLOSE6.Name = "rtb_AC_CLOSE6";
            this.rtb_AC_CLOSE6.Size = new System.Drawing.Size(145, 116);
            this.rtb_AC_CLOSE6.TabIndex = 87;
            this.rtb_AC_CLOSE6.Text = "";
            // 
            // rtb_IDBM_CLOSECL6
            // 
            this.rtb_IDBM_CLOSECL6.Location = new System.Drawing.Point(182, 45);
            this.rtb_IDBM_CLOSECL6.Name = "rtb_IDBM_CLOSECL6";
            this.rtb_IDBM_CLOSECL6.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_CLOSECL6.TabIndex = 85;
            this.rtb_IDBM_CLOSECL6.Text = "";
            // 
            // rtb_ACLIVE6
            // 
            this.rtb_ACLIVE6.Location = new System.Drawing.Point(31, 183);
            this.rtb_ACLIVE6.Name = "rtb_ACLIVE6";
            this.rtb_ACLIVE6.Size = new System.Drawing.Size(145, 116);
            this.rtb_ACLIVE6.TabIndex = 86;
            this.rtb_ACLIVE6.Text = "";
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.rtb_IDBM_LIVE7);
            this.groupBox22.Controls.Add(this.label284);
            this.groupBox22.Controls.Add(this.label285);
            this.groupBox22.Controls.Add(this.label286);
            this.groupBox22.Controls.Add(this.label287);
            this.groupBox22.Controls.Add(this.rtb_AC_CLOSE7);
            this.groupBox22.Controls.Add(this.rtb_IDBM_CLOSECL7);
            this.groupBox22.Controls.Add(this.rtb_ACLIVE7);
            this.groupBox22.Location = new System.Drawing.Point(722, 330);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(352, 320);
            this.groupBox22.TabIndex = 94;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "VIA 7";
            // 
            // rtb_IDBM_LIVE7
            // 
            this.rtb_IDBM_LIVE7.Location = new System.Drawing.Point(31, 45);
            this.rtb_IDBM_LIVE7.Name = "rtb_IDBM_LIVE7";
            this.rtb_IDBM_LIVE7.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_LIVE7.TabIndex = 81;
            this.rtb_IDBM_LIVE7.Text = "";
            // 
            // label284
            // 
            this.label284.AutoSize = true;
            this.label284.Location = new System.Drawing.Point(219, 164);
            this.label284.Name = "label284";
            this.label284.Size = new System.Drawing.Size(72, 15);
            this.label284.TabIndex = 89;
            this.label284.Text = "AC CLOSE:";
            // 
            // label285
            // 
            this.label285.AutoSize = true;
            this.label285.Location = new System.Drawing.Point(64, 27);
            this.label285.Name = "label285";
            this.label285.Size = new System.Drawing.Size(72, 15);
            this.label285.TabIndex = 82;
            this.label285.Text = "IDBM LIVE:";
            // 
            // label286
            // 
            this.label286.AutoSize = true;
            this.label286.Location = new System.Drawing.Point(64, 164);
            this.label286.Name = "label286";
            this.label286.Size = new System.Drawing.Size(57, 15);
            this.label286.TabIndex = 88;
            this.label286.Text = "AC LIVE:";
            // 
            // label287
            // 
            this.label287.AutoSize = true;
            this.label287.Location = new System.Drawing.Point(219, 27);
            this.label287.Name = "label287";
            this.label287.Size = new System.Drawing.Size(87, 15);
            this.label287.TabIndex = 84;
            this.label287.Text = "IDBM CLOSE:";
            // 
            // rtb_AC_CLOSE7
            // 
            this.rtb_AC_CLOSE7.Location = new System.Drawing.Point(182, 183);
            this.rtb_AC_CLOSE7.Name = "rtb_AC_CLOSE7";
            this.rtb_AC_CLOSE7.Size = new System.Drawing.Size(145, 116);
            this.rtb_AC_CLOSE7.TabIndex = 87;
            this.rtb_AC_CLOSE7.Text = "";
            // 
            // rtb_IDBM_CLOSECL7
            // 
            this.rtb_IDBM_CLOSECL7.Location = new System.Drawing.Point(182, 45);
            this.rtb_IDBM_CLOSECL7.Name = "rtb_IDBM_CLOSECL7";
            this.rtb_IDBM_CLOSECL7.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_CLOSECL7.TabIndex = 85;
            this.rtb_IDBM_CLOSECL7.Text = "";
            // 
            // rtb_ACLIVE7
            // 
            this.rtb_ACLIVE7.Location = new System.Drawing.Point(31, 183);
            this.rtb_ACLIVE7.Name = "rtb_ACLIVE7";
            this.rtb_ACLIVE7.Size = new System.Drawing.Size(145, 116);
            this.rtb_ACLIVE7.TabIndex = 86;
            this.rtb_ACLIVE7.Text = "";
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.rtb_IDBM_LIVE3);
            this.groupBox17.Controls.Add(this.label264);
            this.groupBox17.Controls.Add(this.label265);
            this.groupBox17.Controls.Add(this.label266);
            this.groupBox17.Controls.Add(this.label267);
            this.groupBox17.Controls.Add(this.rtb_AC_CLOSE3);
            this.groupBox17.Controls.Add(this.rtb_IDBM_CLOSECL3);
            this.groupBox17.Controls.Add(this.rtb_ACLIVE3);
            this.groupBox17.Location = new System.Drawing.Point(722, 6);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(352, 320);
            this.groupBox17.TabIndex = 92;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "VIA 3";
            // 
            // rtb_IDBM_LIVE3
            // 
            this.rtb_IDBM_LIVE3.Location = new System.Drawing.Point(31, 45);
            this.rtb_IDBM_LIVE3.Name = "rtb_IDBM_LIVE3";
            this.rtb_IDBM_LIVE3.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_LIVE3.TabIndex = 81;
            this.rtb_IDBM_LIVE3.Text = "";
            // 
            // label264
            // 
            this.label264.AutoSize = true;
            this.label264.Location = new System.Drawing.Point(219, 164);
            this.label264.Name = "label264";
            this.label264.Size = new System.Drawing.Size(72, 15);
            this.label264.TabIndex = 89;
            this.label264.Text = "AC CLOSE:";
            // 
            // label265
            // 
            this.label265.AutoSize = true;
            this.label265.Location = new System.Drawing.Point(64, 27);
            this.label265.Name = "label265";
            this.label265.Size = new System.Drawing.Size(72, 15);
            this.label265.TabIndex = 82;
            this.label265.Text = "IDBM LIVE:";
            // 
            // label266
            // 
            this.label266.AutoSize = true;
            this.label266.Location = new System.Drawing.Point(64, 164);
            this.label266.Name = "label266";
            this.label266.Size = new System.Drawing.Size(57, 15);
            this.label266.TabIndex = 88;
            this.label266.Text = "AC LIVE:";
            // 
            // label267
            // 
            this.label267.AutoSize = true;
            this.label267.Location = new System.Drawing.Point(219, 27);
            this.label267.Name = "label267";
            this.label267.Size = new System.Drawing.Size(87, 15);
            this.label267.TabIndex = 84;
            this.label267.Text = "IDBM CLOSE:";
            // 
            // rtb_AC_CLOSE3
            // 
            this.rtb_AC_CLOSE3.Location = new System.Drawing.Point(182, 183);
            this.rtb_AC_CLOSE3.Name = "rtb_AC_CLOSE3";
            this.rtb_AC_CLOSE3.Size = new System.Drawing.Size(145, 116);
            this.rtb_AC_CLOSE3.TabIndex = 87;
            this.rtb_AC_CLOSE3.Text = "";
            // 
            // rtb_IDBM_CLOSECL3
            // 
            this.rtb_IDBM_CLOSECL3.Location = new System.Drawing.Point(182, 45);
            this.rtb_IDBM_CLOSECL3.Name = "rtb_IDBM_CLOSECL3";
            this.rtb_IDBM_CLOSECL3.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_CLOSECL3.TabIndex = 85;
            this.rtb_IDBM_CLOSECL3.Text = "";
            // 
            // rtb_ACLIVE3
            // 
            this.rtb_ACLIVE3.Location = new System.Drawing.Point(31, 183);
            this.rtb_ACLIVE3.Name = "rtb_ACLIVE3";
            this.rtb_ACLIVE3.Size = new System.Drawing.Size(145, 116);
            this.rtb_ACLIVE3.TabIndex = 86;
            this.rtb_ACLIVE3.Text = "";
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.rtb_IDBM_LIVE5);
            this.groupBox20.Controls.Add(this.label276);
            this.groupBox20.Controls.Add(this.label277);
            this.groupBox20.Controls.Add(this.label278);
            this.groupBox20.Controls.Add(this.label279);
            this.groupBox20.Controls.Add(this.rtb_AC_CLOSE5);
            this.groupBox20.Controls.Add(this.rtb_IDBM_CLOSECL5);
            this.groupBox20.Controls.Add(this.rtb_ACLIVE5);
            this.groupBox20.Location = new System.Drawing.Point(9, 330);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(352, 320);
            this.groupBox20.TabIndex = 92;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "VIA 5";
            // 
            // rtb_IDBM_LIVE5
            // 
            this.rtb_IDBM_LIVE5.Location = new System.Drawing.Point(31, 45);
            this.rtb_IDBM_LIVE5.Name = "rtb_IDBM_LIVE5";
            this.rtb_IDBM_LIVE5.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_LIVE5.TabIndex = 81;
            this.rtb_IDBM_LIVE5.Text = "";
            // 
            // label276
            // 
            this.label276.AutoSize = true;
            this.label276.Location = new System.Drawing.Point(219, 164);
            this.label276.Name = "label276";
            this.label276.Size = new System.Drawing.Size(72, 15);
            this.label276.TabIndex = 89;
            this.label276.Text = "AC CLOSE:";
            // 
            // label277
            // 
            this.label277.AutoSize = true;
            this.label277.Location = new System.Drawing.Point(64, 27);
            this.label277.Name = "label277";
            this.label277.Size = new System.Drawing.Size(72, 15);
            this.label277.TabIndex = 82;
            this.label277.Text = "IDBM LIVE:";
            // 
            // label278
            // 
            this.label278.AutoSize = true;
            this.label278.Location = new System.Drawing.Point(64, 164);
            this.label278.Name = "label278";
            this.label278.Size = new System.Drawing.Size(57, 15);
            this.label278.TabIndex = 88;
            this.label278.Text = "AC LIVE:";
            // 
            // label279
            // 
            this.label279.AutoSize = true;
            this.label279.Location = new System.Drawing.Point(219, 27);
            this.label279.Name = "label279";
            this.label279.Size = new System.Drawing.Size(87, 15);
            this.label279.TabIndex = 84;
            this.label279.Text = "IDBM CLOSE:";
            // 
            // rtb_AC_CLOSE5
            // 
            this.rtb_AC_CLOSE5.Location = new System.Drawing.Point(182, 183);
            this.rtb_AC_CLOSE5.Name = "rtb_AC_CLOSE5";
            this.rtb_AC_CLOSE5.Size = new System.Drawing.Size(145, 116);
            this.rtb_AC_CLOSE5.TabIndex = 87;
            this.rtb_AC_CLOSE5.Text = "";
            // 
            // rtb_IDBM_CLOSECL5
            // 
            this.rtb_IDBM_CLOSECL5.Location = new System.Drawing.Point(182, 45);
            this.rtb_IDBM_CLOSECL5.Name = "rtb_IDBM_CLOSECL5";
            this.rtb_IDBM_CLOSECL5.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_CLOSECL5.TabIndex = 85;
            this.rtb_IDBM_CLOSECL5.Text = "";
            // 
            // rtb_ACLIVE5
            // 
            this.rtb_ACLIVE5.Location = new System.Drawing.Point(31, 183);
            this.rtb_ACLIVE5.Name = "rtb_ACLIVE5";
            this.rtb_ACLIVE5.Size = new System.Drawing.Size(145, 116);
            this.rtb_ACLIVE5.TabIndex = 86;
            this.rtb_ACLIVE5.Text = "";
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.rtb_IDBM_LIVE4);
            this.groupBox18.Controls.Add(this.label268);
            this.groupBox18.Controls.Add(this.label269);
            this.groupBox18.Controls.Add(this.label270);
            this.groupBox18.Controls.Add(this.label271);
            this.groupBox18.Controls.Add(this.rtb_AC_CLOSE4);
            this.groupBox18.Controls.Add(this.rtb_IDBM_CLOSECL4);
            this.groupBox18.Controls.Add(this.rtb_ACLIVE4);
            this.groupBox18.Location = new System.Drawing.Point(1080, 6);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(352, 320);
            this.groupBox18.TabIndex = 92;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "VIA 4";
            // 
            // rtb_IDBM_LIVE4
            // 
            this.rtb_IDBM_LIVE4.Location = new System.Drawing.Point(31, 45);
            this.rtb_IDBM_LIVE4.Name = "rtb_IDBM_LIVE4";
            this.rtb_IDBM_LIVE4.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_LIVE4.TabIndex = 81;
            this.rtb_IDBM_LIVE4.Text = "";
            // 
            // label268
            // 
            this.label268.AutoSize = true;
            this.label268.Location = new System.Drawing.Point(219, 164);
            this.label268.Name = "label268";
            this.label268.Size = new System.Drawing.Size(72, 15);
            this.label268.TabIndex = 89;
            this.label268.Text = "AC CLOSE:";
            // 
            // label269
            // 
            this.label269.AutoSize = true;
            this.label269.Location = new System.Drawing.Point(64, 27);
            this.label269.Name = "label269";
            this.label269.Size = new System.Drawing.Size(72, 15);
            this.label269.TabIndex = 82;
            this.label269.Text = "IDBM LIVE:";
            // 
            // label270
            // 
            this.label270.AutoSize = true;
            this.label270.Location = new System.Drawing.Point(64, 164);
            this.label270.Name = "label270";
            this.label270.Size = new System.Drawing.Size(57, 15);
            this.label270.TabIndex = 88;
            this.label270.Text = "AC LIVE:";
            // 
            // label271
            // 
            this.label271.AutoSize = true;
            this.label271.Location = new System.Drawing.Point(219, 27);
            this.label271.Name = "label271";
            this.label271.Size = new System.Drawing.Size(87, 15);
            this.label271.TabIndex = 84;
            this.label271.Text = "IDBM CLOSE:";
            // 
            // rtb_AC_CLOSE4
            // 
            this.rtb_AC_CLOSE4.Location = new System.Drawing.Point(182, 183);
            this.rtb_AC_CLOSE4.Name = "rtb_AC_CLOSE4";
            this.rtb_AC_CLOSE4.Size = new System.Drawing.Size(145, 116);
            this.rtb_AC_CLOSE4.TabIndex = 87;
            this.rtb_AC_CLOSE4.Text = "";
            // 
            // rtb_IDBM_CLOSECL4
            // 
            this.rtb_IDBM_CLOSECL4.Location = new System.Drawing.Point(182, 45);
            this.rtb_IDBM_CLOSECL4.Name = "rtb_IDBM_CLOSECL4";
            this.rtb_IDBM_CLOSECL4.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_CLOSECL4.TabIndex = 85;
            this.rtb_IDBM_CLOSECL4.Text = "";
            // 
            // rtb_ACLIVE4
            // 
            this.rtb_ACLIVE4.Location = new System.Drawing.Point(31, 183);
            this.rtb_ACLIVE4.Name = "rtb_ACLIVE4";
            this.rtb_ACLIVE4.Size = new System.Drawing.Size(145, 116);
            this.rtb_ACLIVE4.TabIndex = 86;
            this.rtb_ACLIVE4.Text = "";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.rtb_IDBM_LIVE2);
            this.groupBox16.Controls.Add(this.label260);
            this.groupBox16.Controls.Add(this.label261);
            this.groupBox16.Controls.Add(this.label262);
            this.groupBox16.Controls.Add(this.label263);
            this.groupBox16.Controls.Add(this.rtb_AC_CLOSE2);
            this.groupBox16.Controls.Add(this.rtb_IDBM_CLOSECL2);
            this.groupBox16.Controls.Add(this.rtb_ACLIVE2);
            this.groupBox16.Location = new System.Drawing.Point(364, 6);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(352, 320);
            this.groupBox16.TabIndex = 91;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "VIA 2";
            // 
            // rtb_IDBM_LIVE2
            // 
            this.rtb_IDBM_LIVE2.Location = new System.Drawing.Point(31, 45);
            this.rtb_IDBM_LIVE2.Name = "rtb_IDBM_LIVE2";
            this.rtb_IDBM_LIVE2.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_LIVE2.TabIndex = 81;
            this.rtb_IDBM_LIVE2.Text = "";
            // 
            // label260
            // 
            this.label260.AutoSize = true;
            this.label260.Location = new System.Drawing.Point(219, 164);
            this.label260.Name = "label260";
            this.label260.Size = new System.Drawing.Size(72, 15);
            this.label260.TabIndex = 89;
            this.label260.Text = "AC CLOSE:";
            // 
            // label261
            // 
            this.label261.AutoSize = true;
            this.label261.Location = new System.Drawing.Point(64, 27);
            this.label261.Name = "label261";
            this.label261.Size = new System.Drawing.Size(72, 15);
            this.label261.TabIndex = 82;
            this.label261.Text = "IDBM LIVE:";
            // 
            // label262
            // 
            this.label262.AutoSize = true;
            this.label262.Location = new System.Drawing.Point(64, 164);
            this.label262.Name = "label262";
            this.label262.Size = new System.Drawing.Size(57, 15);
            this.label262.TabIndex = 88;
            this.label262.Text = "AC LIVE:";
            // 
            // label263
            // 
            this.label263.AutoSize = true;
            this.label263.Location = new System.Drawing.Point(219, 27);
            this.label263.Name = "label263";
            this.label263.Size = new System.Drawing.Size(87, 15);
            this.label263.TabIndex = 84;
            this.label263.Text = "IDBM CLOSE:";
            // 
            // rtb_AC_CLOSE2
            // 
            this.rtb_AC_CLOSE2.Location = new System.Drawing.Point(182, 183);
            this.rtb_AC_CLOSE2.Name = "rtb_AC_CLOSE2";
            this.rtb_AC_CLOSE2.Size = new System.Drawing.Size(145, 116);
            this.rtb_AC_CLOSE2.TabIndex = 87;
            this.rtb_AC_CLOSE2.Text = "";
            // 
            // rtb_IDBM_CLOSECL2
            // 
            this.rtb_IDBM_CLOSECL2.Location = new System.Drawing.Point(182, 45);
            this.rtb_IDBM_CLOSECL2.Name = "rtb_IDBM_CLOSECL2";
            this.rtb_IDBM_CLOSECL2.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_CLOSECL2.TabIndex = 85;
            this.rtb_IDBM_CLOSECL2.Text = "";
            // 
            // rtb_ACLIVE2
            // 
            this.rtb_ACLIVE2.Location = new System.Drawing.Point(31, 183);
            this.rtb_ACLIVE2.Name = "rtb_ACLIVE2";
            this.rtb_ACLIVE2.Size = new System.Drawing.Size(145, 116);
            this.rtb_ACLIVE2.TabIndex = 86;
            this.rtb_ACLIVE2.Text = "";
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.rtb_IDBM_LIVE1);
            this.groupBox15.Controls.Add(this.label258);
            this.groupBox15.Controls.Add(this.label257);
            this.groupBox15.Controls.Add(this.label259);
            this.groupBox15.Controls.Add(this.label256);
            this.groupBox15.Controls.Add(this.rtb_AC_CLOSE1);
            this.groupBox15.Controls.Add(this.rtb_IDBM_CLOSECL1);
            this.groupBox15.Controls.Add(this.rtb_ACLIVE1);
            this.groupBox15.Location = new System.Drawing.Point(9, 6);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(352, 320);
            this.groupBox15.TabIndex = 90;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "VIA 1";
            // 
            // rtb_IDBM_LIVE1
            // 
            this.rtb_IDBM_LIVE1.Location = new System.Drawing.Point(31, 45);
            this.rtb_IDBM_LIVE1.Name = "rtb_IDBM_LIVE1";
            this.rtb_IDBM_LIVE1.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_LIVE1.TabIndex = 81;
            this.rtb_IDBM_LIVE1.Text = "";
            // 
            // label258
            // 
            this.label258.AutoSize = true;
            this.label258.Location = new System.Drawing.Point(219, 164);
            this.label258.Name = "label258";
            this.label258.Size = new System.Drawing.Size(72, 15);
            this.label258.TabIndex = 89;
            this.label258.Text = "AC CLOSE:";
            // 
            // label257
            // 
            this.label257.AutoSize = true;
            this.label257.Location = new System.Drawing.Point(64, 27);
            this.label257.Name = "label257";
            this.label257.Size = new System.Drawing.Size(72, 15);
            this.label257.TabIndex = 82;
            this.label257.Text = "IDBM LIVE:";
            // 
            // label259
            // 
            this.label259.AutoSize = true;
            this.label259.Location = new System.Drawing.Point(64, 164);
            this.label259.Name = "label259";
            this.label259.Size = new System.Drawing.Size(57, 15);
            this.label259.TabIndex = 88;
            this.label259.Text = "AC LIVE:";
            // 
            // label256
            // 
            this.label256.AutoSize = true;
            this.label256.Location = new System.Drawing.Point(219, 27);
            this.label256.Name = "label256";
            this.label256.Size = new System.Drawing.Size(87, 15);
            this.label256.TabIndex = 84;
            this.label256.Text = "IDBM CLOSE:";
            // 
            // rtb_AC_CLOSE1
            // 
            this.rtb_AC_CLOSE1.Location = new System.Drawing.Point(182, 183);
            this.rtb_AC_CLOSE1.Name = "rtb_AC_CLOSE1";
            this.rtb_AC_CLOSE1.Size = new System.Drawing.Size(145, 116);
            this.rtb_AC_CLOSE1.TabIndex = 87;
            this.rtb_AC_CLOSE1.Text = "";
            // 
            // rtb_IDBM_CLOSECL1
            // 
            this.rtb_IDBM_CLOSECL1.Location = new System.Drawing.Point(182, 45);
            this.rtb_IDBM_CLOSECL1.Name = "rtb_IDBM_CLOSECL1";
            this.rtb_IDBM_CLOSECL1.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_CLOSECL1.TabIndex = 85;
            this.rtb_IDBM_CLOSECL1.Text = "";
            // 
            // rtb_ACLIVE1
            // 
            this.rtb_ACLIVE1.Location = new System.Drawing.Point(31, 183);
            this.rtb_ACLIVE1.Name = "rtb_ACLIVE1";
            this.rtb_ACLIVE1.Size = new System.Drawing.Size(145, 116);
            this.rtb_ACLIVE1.TabIndex = 86;
            this.rtb_ACLIVE1.Text = "";
            // 
            // tabPage35
            // 
            this.tabPage35.BackColor = System.Drawing.Color.DimGray;
            this.tabPage35.Controls.Add(this.groupBox35);
            this.tabPage35.Controls.Add(this.groupBox27);
            this.tabPage35.Controls.Add(this.groupBox36);
            this.tabPage35.Controls.Add(this.groupBox28);
            this.tabPage35.Controls.Add(this.groupBox29);
            this.tabPage35.Controls.Add(this.groupBox30);
            this.tabPage35.Controls.Add(this.groupBox31);
            this.tabPage35.Controls.Add(this.groupBox32);
            this.tabPage35.Controls.Add(this.groupBox33);
            this.tabPage35.Controls.Add(this.groupBox34);
            this.tabPage35.Location = new System.Drawing.Point(4, 24);
            this.tabPage35.Name = "tabPage35";
            this.tabPage35.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage35.Size = new System.Drawing.Size(1763, 657);
            this.tabPage35.TabIndex = 3;
            this.tabPage35.Text = "VIA 9 - 18";
            // 
            // groupBox35
            // 
            this.groupBox35.Controls.Add(this.rtb_IDBM_LIVE18);
            this.groupBox35.Controls.Add(this.label371);
            this.groupBox35.Controls.Add(this.label372);
            this.groupBox35.Controls.Add(this.label373);
            this.groupBox35.Controls.Add(this.label374);
            this.groupBox35.Controls.Add(this.rtb_AC_CLOSE18);
            this.groupBox35.Controls.Add(this.rtb_IDBM_CLOSECL18);
            this.groupBox35.Controls.Add(this.rtb_ACLIVE18);
            this.groupBox35.Location = new System.Drawing.Point(1435, 330);
            this.groupBox35.Name = "groupBox35";
            this.groupBox35.Size = new System.Drawing.Size(352, 320);
            this.groupBox35.TabIndex = 101;
            this.groupBox35.TabStop = false;
            this.groupBox35.Text = "VIA 18";
            // 
            // rtb_IDBM_LIVE18
            // 
            this.rtb_IDBM_LIVE18.Location = new System.Drawing.Point(31, 45);
            this.rtb_IDBM_LIVE18.Name = "rtb_IDBM_LIVE18";
            this.rtb_IDBM_LIVE18.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_LIVE18.TabIndex = 81;
            this.rtb_IDBM_LIVE18.Text = "";
            // 
            // label371
            // 
            this.label371.AutoSize = true;
            this.label371.Location = new System.Drawing.Point(219, 164);
            this.label371.Name = "label371";
            this.label371.Size = new System.Drawing.Size(72, 15);
            this.label371.TabIndex = 89;
            this.label371.Text = "AC CLOSE:";
            // 
            // label372
            // 
            this.label372.AutoSize = true;
            this.label372.Location = new System.Drawing.Point(64, 27);
            this.label372.Name = "label372";
            this.label372.Size = new System.Drawing.Size(72, 15);
            this.label372.TabIndex = 82;
            this.label372.Text = "IDBM LIVE:";
            // 
            // label373
            // 
            this.label373.AutoSize = true;
            this.label373.Location = new System.Drawing.Point(64, 164);
            this.label373.Name = "label373";
            this.label373.Size = new System.Drawing.Size(57, 15);
            this.label373.TabIndex = 88;
            this.label373.Text = "AC LIVE:";
            // 
            // label374
            // 
            this.label374.AutoSize = true;
            this.label374.Location = new System.Drawing.Point(219, 27);
            this.label374.Name = "label374";
            this.label374.Size = new System.Drawing.Size(87, 15);
            this.label374.TabIndex = 84;
            this.label374.Text = "IDBM CLOSE:";
            // 
            // rtb_AC_CLOSE18
            // 
            this.rtb_AC_CLOSE18.Location = new System.Drawing.Point(182, 183);
            this.rtb_AC_CLOSE18.Name = "rtb_AC_CLOSE18";
            this.rtb_AC_CLOSE18.Size = new System.Drawing.Size(145, 116);
            this.rtb_AC_CLOSE18.TabIndex = 87;
            this.rtb_AC_CLOSE18.Text = "";
            // 
            // rtb_IDBM_CLOSECL18
            // 
            this.rtb_IDBM_CLOSECL18.Location = new System.Drawing.Point(182, 45);
            this.rtb_IDBM_CLOSECL18.Name = "rtb_IDBM_CLOSECL18";
            this.rtb_IDBM_CLOSECL18.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_CLOSECL18.TabIndex = 85;
            this.rtb_IDBM_CLOSECL18.Text = "";
            // 
            // rtb_ACLIVE18
            // 
            this.rtb_ACLIVE18.Location = new System.Drawing.Point(31, 183);
            this.rtb_ACLIVE18.Name = "rtb_ACLIVE18";
            this.rtb_ACLIVE18.Size = new System.Drawing.Size(145, 116);
            this.rtb_ACLIVE18.TabIndex = 86;
            this.rtb_ACLIVE18.Text = "";
            // 
            // groupBox27
            // 
            this.groupBox27.Controls.Add(this.rtb_IDBM_LIVE16);
            this.groupBox27.Controls.Add(this.label339);
            this.groupBox27.Controls.Add(this.label340);
            this.groupBox27.Controls.Add(this.label341);
            this.groupBox27.Controls.Add(this.label342);
            this.groupBox27.Controls.Add(this.rtb_AC_CLOSE16);
            this.groupBox27.Controls.Add(this.rtb_IDBM_CLOSECL16);
            this.groupBox27.Controls.Add(this.rtb_ACLIVE16);
            this.groupBox27.Location = new System.Drawing.Point(719, 330);
            this.groupBox27.Name = "groupBox27";
            this.groupBox27.Size = new System.Drawing.Size(352, 320);
            this.groupBox27.TabIndex = 103;
            this.groupBox27.TabStop = false;
            this.groupBox27.Text = "VIA 16";
            // 
            // rtb_IDBM_LIVE16
            // 
            this.rtb_IDBM_LIVE16.Location = new System.Drawing.Point(31, 45);
            this.rtb_IDBM_LIVE16.Name = "rtb_IDBM_LIVE16";
            this.rtb_IDBM_LIVE16.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_LIVE16.TabIndex = 81;
            this.rtb_IDBM_LIVE16.Text = "";
            // 
            // label339
            // 
            this.label339.AutoSize = true;
            this.label339.Location = new System.Drawing.Point(219, 164);
            this.label339.Name = "label339";
            this.label339.Size = new System.Drawing.Size(72, 15);
            this.label339.TabIndex = 89;
            this.label339.Text = "AC CLOSE:";
            // 
            // label340
            // 
            this.label340.AutoSize = true;
            this.label340.Location = new System.Drawing.Point(64, 27);
            this.label340.Name = "label340";
            this.label340.Size = new System.Drawing.Size(72, 15);
            this.label340.TabIndex = 82;
            this.label340.Text = "IDBM LIVE:";
            // 
            // label341
            // 
            this.label341.AutoSize = true;
            this.label341.Location = new System.Drawing.Point(64, 164);
            this.label341.Name = "label341";
            this.label341.Size = new System.Drawing.Size(57, 15);
            this.label341.TabIndex = 88;
            this.label341.Text = "AC LIVE:";
            // 
            // label342
            // 
            this.label342.AutoSize = true;
            this.label342.Location = new System.Drawing.Point(219, 27);
            this.label342.Name = "label342";
            this.label342.Size = new System.Drawing.Size(87, 15);
            this.label342.TabIndex = 84;
            this.label342.Text = "IDBM CLOSE:";
            // 
            // rtb_AC_CLOSE16
            // 
            this.rtb_AC_CLOSE16.Location = new System.Drawing.Point(182, 183);
            this.rtb_AC_CLOSE16.Name = "rtb_AC_CLOSE16";
            this.rtb_AC_CLOSE16.Size = new System.Drawing.Size(145, 116);
            this.rtb_AC_CLOSE16.TabIndex = 87;
            this.rtb_AC_CLOSE16.Text = "";
            // 
            // rtb_IDBM_CLOSECL16
            // 
            this.rtb_IDBM_CLOSECL16.Location = new System.Drawing.Point(182, 45);
            this.rtb_IDBM_CLOSECL16.Name = "rtb_IDBM_CLOSECL16";
            this.rtb_IDBM_CLOSECL16.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_CLOSECL16.TabIndex = 85;
            this.rtb_IDBM_CLOSECL16.Text = "";
            // 
            // rtb_ACLIVE16
            // 
            this.rtb_ACLIVE16.Location = new System.Drawing.Point(31, 183);
            this.rtb_ACLIVE16.Name = "rtb_ACLIVE16";
            this.rtb_ACLIVE16.Size = new System.Drawing.Size(145, 116);
            this.rtb_ACLIVE16.TabIndex = 86;
            this.rtb_ACLIVE16.Text = "";
            // 
            // groupBox36
            // 
            this.groupBox36.Controls.Add(this.rtb_IDBM_LIVE17);
            this.groupBox36.Controls.Add(this.label375);
            this.groupBox36.Controls.Add(this.label376);
            this.groupBox36.Controls.Add(this.label377);
            this.groupBox36.Controls.Add(this.label378);
            this.groupBox36.Controls.Add(this.rtb_AC_CLOSE17);
            this.groupBox36.Controls.Add(this.rtb_IDBM_CLOSECL17);
            this.groupBox36.Controls.Add(this.rtb_ACLIVE17);
            this.groupBox36.Location = new System.Drawing.Point(1077, 330);
            this.groupBox36.Name = "groupBox36";
            this.groupBox36.Size = new System.Drawing.Size(352, 320);
            this.groupBox36.TabIndex = 102;
            this.groupBox36.TabStop = false;
            this.groupBox36.Text = "VIA 17";
            // 
            // rtb_IDBM_LIVE17
            // 
            this.rtb_IDBM_LIVE17.Location = new System.Drawing.Point(31, 45);
            this.rtb_IDBM_LIVE17.Name = "rtb_IDBM_LIVE17";
            this.rtb_IDBM_LIVE17.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_LIVE17.TabIndex = 81;
            this.rtb_IDBM_LIVE17.Text = "";
            // 
            // label375
            // 
            this.label375.AutoSize = true;
            this.label375.Location = new System.Drawing.Point(219, 164);
            this.label375.Name = "label375";
            this.label375.Size = new System.Drawing.Size(72, 15);
            this.label375.TabIndex = 89;
            this.label375.Text = "AC CLOSE:";
            // 
            // label376
            // 
            this.label376.AutoSize = true;
            this.label376.Location = new System.Drawing.Point(64, 27);
            this.label376.Name = "label376";
            this.label376.Size = new System.Drawing.Size(72, 15);
            this.label376.TabIndex = 82;
            this.label376.Text = "IDBM LIVE:";
            // 
            // label377
            // 
            this.label377.AutoSize = true;
            this.label377.Location = new System.Drawing.Point(64, 164);
            this.label377.Name = "label377";
            this.label377.Size = new System.Drawing.Size(57, 15);
            this.label377.TabIndex = 88;
            this.label377.Text = "AC LIVE:";
            // 
            // label378
            // 
            this.label378.AutoSize = true;
            this.label378.Location = new System.Drawing.Point(219, 27);
            this.label378.Name = "label378";
            this.label378.Size = new System.Drawing.Size(87, 15);
            this.label378.TabIndex = 84;
            this.label378.Text = "IDBM CLOSE:";
            // 
            // rtb_AC_CLOSE17
            // 
            this.rtb_AC_CLOSE17.Location = new System.Drawing.Point(182, 183);
            this.rtb_AC_CLOSE17.Name = "rtb_AC_CLOSE17";
            this.rtb_AC_CLOSE17.Size = new System.Drawing.Size(145, 116);
            this.rtb_AC_CLOSE17.TabIndex = 87;
            this.rtb_AC_CLOSE17.Text = "";
            // 
            // rtb_IDBM_CLOSECL17
            // 
            this.rtb_IDBM_CLOSECL17.Location = new System.Drawing.Point(182, 45);
            this.rtb_IDBM_CLOSECL17.Name = "rtb_IDBM_CLOSECL17";
            this.rtb_IDBM_CLOSECL17.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_CLOSECL17.TabIndex = 85;
            this.rtb_IDBM_CLOSECL17.Text = "";
            // 
            // rtb_ACLIVE17
            // 
            this.rtb_ACLIVE17.Location = new System.Drawing.Point(31, 183);
            this.rtb_ACLIVE17.Name = "rtb_ACLIVE17";
            this.rtb_ACLIVE17.Size = new System.Drawing.Size(145, 116);
            this.rtb_ACLIVE17.TabIndex = 86;
            this.rtb_ACLIVE17.Text = "";
            // 
            // groupBox28
            // 
            this.groupBox28.Controls.Add(this.rtb_IDBM_LIVE14);
            this.groupBox28.Controls.Add(this.label343);
            this.groupBox28.Controls.Add(this.label344);
            this.groupBox28.Controls.Add(this.label345);
            this.groupBox28.Controls.Add(this.label346);
            this.groupBox28.Controls.Add(this.rtb_AC_CLOSE14);
            this.groupBox28.Controls.Add(this.rtb_IDBM_CLOSECL14);
            this.groupBox28.Controls.Add(this.rtb_ACLIVE14);
            this.groupBox28.Location = new System.Drawing.Point(6, 330);
            this.groupBox28.Name = "groupBox28";
            this.groupBox28.Size = new System.Drawing.Size(352, 320);
            this.groupBox28.TabIndex = 101;
            this.groupBox28.TabStop = false;
            this.groupBox28.Text = "VIA 14";
            // 
            // rtb_IDBM_LIVE14
            // 
            this.rtb_IDBM_LIVE14.Location = new System.Drawing.Point(31, 45);
            this.rtb_IDBM_LIVE14.Name = "rtb_IDBM_LIVE14";
            this.rtb_IDBM_LIVE14.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_LIVE14.TabIndex = 81;
            this.rtb_IDBM_LIVE14.Text = "";
            // 
            // label343
            // 
            this.label343.AutoSize = true;
            this.label343.Location = new System.Drawing.Point(219, 164);
            this.label343.Name = "label343";
            this.label343.Size = new System.Drawing.Size(72, 15);
            this.label343.TabIndex = 89;
            this.label343.Text = "AC CLOSE:";
            // 
            // label344
            // 
            this.label344.AutoSize = true;
            this.label344.Location = new System.Drawing.Point(64, 27);
            this.label344.Name = "label344";
            this.label344.Size = new System.Drawing.Size(72, 15);
            this.label344.TabIndex = 82;
            this.label344.Text = "IDBM LIVE:";
            // 
            // label345
            // 
            this.label345.AutoSize = true;
            this.label345.Location = new System.Drawing.Point(64, 164);
            this.label345.Name = "label345";
            this.label345.Size = new System.Drawing.Size(57, 15);
            this.label345.TabIndex = 88;
            this.label345.Text = "AC LIVE:";
            // 
            // label346
            // 
            this.label346.AutoSize = true;
            this.label346.Location = new System.Drawing.Point(219, 27);
            this.label346.Name = "label346";
            this.label346.Size = new System.Drawing.Size(87, 15);
            this.label346.TabIndex = 84;
            this.label346.Text = "IDBM CLOSE:";
            // 
            // rtb_AC_CLOSE14
            // 
            this.rtb_AC_CLOSE14.Location = new System.Drawing.Point(182, 183);
            this.rtb_AC_CLOSE14.Name = "rtb_AC_CLOSE14";
            this.rtb_AC_CLOSE14.Size = new System.Drawing.Size(145, 116);
            this.rtb_AC_CLOSE14.TabIndex = 87;
            this.rtb_AC_CLOSE14.Text = "";
            // 
            // rtb_IDBM_CLOSECL14
            // 
            this.rtb_IDBM_CLOSECL14.Location = new System.Drawing.Point(182, 45);
            this.rtb_IDBM_CLOSECL14.Name = "rtb_IDBM_CLOSECL14";
            this.rtb_IDBM_CLOSECL14.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_CLOSECL14.TabIndex = 85;
            this.rtb_IDBM_CLOSECL14.Text = "";
            // 
            // rtb_ACLIVE14
            // 
            this.rtb_ACLIVE14.Location = new System.Drawing.Point(31, 183);
            this.rtb_ACLIVE14.Name = "rtb_ACLIVE14";
            this.rtb_ACLIVE14.Size = new System.Drawing.Size(145, 116);
            this.rtb_ACLIVE14.TabIndex = 86;
            this.rtb_ACLIVE14.Text = "";
            // 
            // groupBox29
            // 
            this.groupBox29.Controls.Add(this.rtb_IDBM_LIVE15);
            this.groupBox29.Controls.Add(this.label347);
            this.groupBox29.Controls.Add(this.label348);
            this.groupBox29.Controls.Add(this.label349);
            this.groupBox29.Controls.Add(this.label350);
            this.groupBox29.Controls.Add(this.rtb_AC_CLOSE15);
            this.groupBox29.Controls.Add(this.rtb_IDBM_CLOSECL15);
            this.groupBox29.Controls.Add(this.rtb_ACLIVE15);
            this.groupBox29.Location = new System.Drawing.Point(361, 330);
            this.groupBox29.Name = "groupBox29";
            this.groupBox29.Size = new System.Drawing.Size(352, 320);
            this.groupBox29.TabIndex = 102;
            this.groupBox29.TabStop = false;
            this.groupBox29.Text = "VIA 15";
            // 
            // rtb_IDBM_LIVE15
            // 
            this.rtb_IDBM_LIVE15.Location = new System.Drawing.Point(31, 45);
            this.rtb_IDBM_LIVE15.Name = "rtb_IDBM_LIVE15";
            this.rtb_IDBM_LIVE15.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_LIVE15.TabIndex = 81;
            this.rtb_IDBM_LIVE15.Text = "";
            // 
            // label347
            // 
            this.label347.AutoSize = true;
            this.label347.Location = new System.Drawing.Point(219, 164);
            this.label347.Name = "label347";
            this.label347.Size = new System.Drawing.Size(72, 15);
            this.label347.TabIndex = 89;
            this.label347.Text = "AC CLOSE:";
            // 
            // label348
            // 
            this.label348.AutoSize = true;
            this.label348.Location = new System.Drawing.Point(64, 27);
            this.label348.Name = "label348";
            this.label348.Size = new System.Drawing.Size(72, 15);
            this.label348.TabIndex = 82;
            this.label348.Text = "IDBM LIVE:";
            // 
            // label349
            // 
            this.label349.AutoSize = true;
            this.label349.Location = new System.Drawing.Point(64, 164);
            this.label349.Name = "label349";
            this.label349.Size = new System.Drawing.Size(57, 15);
            this.label349.TabIndex = 88;
            this.label349.Text = "AC LIVE:";
            // 
            // label350
            // 
            this.label350.AutoSize = true;
            this.label350.Location = new System.Drawing.Point(219, 27);
            this.label350.Name = "label350";
            this.label350.Size = new System.Drawing.Size(87, 15);
            this.label350.TabIndex = 84;
            this.label350.Text = "IDBM CLOSE:";
            // 
            // rtb_AC_CLOSE15
            // 
            this.rtb_AC_CLOSE15.Location = new System.Drawing.Point(182, 183);
            this.rtb_AC_CLOSE15.Name = "rtb_AC_CLOSE15";
            this.rtb_AC_CLOSE15.Size = new System.Drawing.Size(145, 116);
            this.rtb_AC_CLOSE15.TabIndex = 87;
            this.rtb_AC_CLOSE15.Text = "";
            // 
            // rtb_IDBM_CLOSECL15
            // 
            this.rtb_IDBM_CLOSECL15.Location = new System.Drawing.Point(182, 45);
            this.rtb_IDBM_CLOSECL15.Name = "rtb_IDBM_CLOSECL15";
            this.rtb_IDBM_CLOSECL15.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_CLOSECL15.TabIndex = 85;
            this.rtb_IDBM_CLOSECL15.Text = "";
            // 
            // rtb_ACLIVE15
            // 
            this.rtb_ACLIVE15.Location = new System.Drawing.Point(31, 183);
            this.rtb_ACLIVE15.Name = "rtb_ACLIVE15";
            this.rtb_ACLIVE15.Size = new System.Drawing.Size(145, 116);
            this.rtb_ACLIVE15.TabIndex = 86;
            this.rtb_ACLIVE15.Text = "";
            // 
            // groupBox30
            // 
            this.groupBox30.Controls.Add(this.rtb_IDBM_LIVE11);
            this.groupBox30.Controls.Add(this.label351);
            this.groupBox30.Controls.Add(this.label352);
            this.groupBox30.Controls.Add(this.label353);
            this.groupBox30.Controls.Add(this.label354);
            this.groupBox30.Controls.Add(this.rtb_AC_CLOSE11);
            this.groupBox30.Controls.Add(this.rtb_IDBM_CLOSECL11);
            this.groupBox30.Controls.Add(this.rtb_ACLIVE11);
            this.groupBox30.Location = new System.Drawing.Point(719, 6);
            this.groupBox30.Name = "groupBox30";
            this.groupBox30.Size = new System.Drawing.Size(352, 320);
            this.groupBox30.TabIndex = 98;
            this.groupBox30.TabStop = false;
            this.groupBox30.Text = "VIA 11";
            // 
            // rtb_IDBM_LIVE11
            // 
            this.rtb_IDBM_LIVE11.Location = new System.Drawing.Point(31, 45);
            this.rtb_IDBM_LIVE11.Name = "rtb_IDBM_LIVE11";
            this.rtb_IDBM_LIVE11.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_LIVE11.TabIndex = 81;
            this.rtb_IDBM_LIVE11.Text = "";
            // 
            // label351
            // 
            this.label351.AutoSize = true;
            this.label351.Location = new System.Drawing.Point(219, 164);
            this.label351.Name = "label351";
            this.label351.Size = new System.Drawing.Size(72, 15);
            this.label351.TabIndex = 89;
            this.label351.Text = "AC CLOSE:";
            // 
            // label352
            // 
            this.label352.AutoSize = true;
            this.label352.Location = new System.Drawing.Point(64, 27);
            this.label352.Name = "label352";
            this.label352.Size = new System.Drawing.Size(72, 15);
            this.label352.TabIndex = 82;
            this.label352.Text = "IDBM LIVE:";
            // 
            // label353
            // 
            this.label353.AutoSize = true;
            this.label353.Location = new System.Drawing.Point(64, 164);
            this.label353.Name = "label353";
            this.label353.Size = new System.Drawing.Size(57, 15);
            this.label353.TabIndex = 88;
            this.label353.Text = "AC LIVE:";
            // 
            // label354
            // 
            this.label354.AutoSize = true;
            this.label354.Location = new System.Drawing.Point(219, 27);
            this.label354.Name = "label354";
            this.label354.Size = new System.Drawing.Size(87, 15);
            this.label354.TabIndex = 84;
            this.label354.Text = "IDBM CLOSE:";
            // 
            // rtb_AC_CLOSE11
            // 
            this.rtb_AC_CLOSE11.Location = new System.Drawing.Point(182, 183);
            this.rtb_AC_CLOSE11.Name = "rtb_AC_CLOSE11";
            this.rtb_AC_CLOSE11.Size = new System.Drawing.Size(145, 116);
            this.rtb_AC_CLOSE11.TabIndex = 87;
            this.rtb_AC_CLOSE11.Text = "";
            // 
            // rtb_IDBM_CLOSECL11
            // 
            this.rtb_IDBM_CLOSECL11.Location = new System.Drawing.Point(182, 45);
            this.rtb_IDBM_CLOSECL11.Name = "rtb_IDBM_CLOSECL11";
            this.rtb_IDBM_CLOSECL11.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_CLOSECL11.TabIndex = 85;
            this.rtb_IDBM_CLOSECL11.Text = "";
            // 
            // rtb_ACLIVE11
            // 
            this.rtb_ACLIVE11.Location = new System.Drawing.Point(31, 183);
            this.rtb_ACLIVE11.Name = "rtb_ACLIVE11";
            this.rtb_ACLIVE11.Size = new System.Drawing.Size(145, 116);
            this.rtb_ACLIVE11.TabIndex = 86;
            this.rtb_ACLIVE11.Text = "";
            // 
            // groupBox31
            // 
            this.groupBox31.Controls.Add(this.rtb_IDBM_LIVE13);
            this.groupBox31.Controls.Add(this.label355);
            this.groupBox31.Controls.Add(this.label356);
            this.groupBox31.Controls.Add(this.label357);
            this.groupBox31.Controls.Add(this.label358);
            this.groupBox31.Controls.Add(this.rtb_AC_CLOSE13);
            this.groupBox31.Controls.Add(this.rtb_IDBM_CLOSECL13);
            this.groupBox31.Controls.Add(this.rtb_ACLIVE13);
            this.groupBox31.Location = new System.Drawing.Point(1435, 6);
            this.groupBox31.Name = "groupBox31";
            this.groupBox31.Size = new System.Drawing.Size(352, 320);
            this.groupBox31.TabIndex = 99;
            this.groupBox31.TabStop = false;
            this.groupBox31.Text = "VIA 13";
            // 
            // rtb_IDBM_LIVE13
            // 
            this.rtb_IDBM_LIVE13.Location = new System.Drawing.Point(31, 45);
            this.rtb_IDBM_LIVE13.Name = "rtb_IDBM_LIVE13";
            this.rtb_IDBM_LIVE13.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_LIVE13.TabIndex = 81;
            this.rtb_IDBM_LIVE13.Text = "";
            // 
            // label355
            // 
            this.label355.AutoSize = true;
            this.label355.Location = new System.Drawing.Point(219, 164);
            this.label355.Name = "label355";
            this.label355.Size = new System.Drawing.Size(72, 15);
            this.label355.TabIndex = 89;
            this.label355.Text = "AC CLOSE:";
            // 
            // label356
            // 
            this.label356.AutoSize = true;
            this.label356.Location = new System.Drawing.Point(64, 27);
            this.label356.Name = "label356";
            this.label356.Size = new System.Drawing.Size(72, 15);
            this.label356.TabIndex = 82;
            this.label356.Text = "IDBM LIVE:";
            // 
            // label357
            // 
            this.label357.AutoSize = true;
            this.label357.Location = new System.Drawing.Point(64, 164);
            this.label357.Name = "label357";
            this.label357.Size = new System.Drawing.Size(57, 15);
            this.label357.TabIndex = 88;
            this.label357.Text = "AC LIVE:";
            // 
            // label358
            // 
            this.label358.AutoSize = true;
            this.label358.Location = new System.Drawing.Point(219, 27);
            this.label358.Name = "label358";
            this.label358.Size = new System.Drawing.Size(87, 15);
            this.label358.TabIndex = 84;
            this.label358.Text = "IDBM CLOSE:";
            // 
            // rtb_AC_CLOSE13
            // 
            this.rtb_AC_CLOSE13.Location = new System.Drawing.Point(182, 183);
            this.rtb_AC_CLOSE13.Name = "rtb_AC_CLOSE13";
            this.rtb_AC_CLOSE13.Size = new System.Drawing.Size(145, 116);
            this.rtb_AC_CLOSE13.TabIndex = 87;
            this.rtb_AC_CLOSE13.Text = "";
            // 
            // rtb_IDBM_CLOSECL13
            // 
            this.rtb_IDBM_CLOSECL13.Location = new System.Drawing.Point(182, 45);
            this.rtb_IDBM_CLOSECL13.Name = "rtb_IDBM_CLOSECL13";
            this.rtb_IDBM_CLOSECL13.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_CLOSECL13.TabIndex = 85;
            this.rtb_IDBM_CLOSECL13.Text = "";
            // 
            // rtb_ACLIVE13
            // 
            this.rtb_ACLIVE13.Location = new System.Drawing.Point(31, 183);
            this.rtb_ACLIVE13.Name = "rtb_ACLIVE13";
            this.rtb_ACLIVE13.Size = new System.Drawing.Size(145, 116);
            this.rtb_ACLIVE13.TabIndex = 86;
            this.rtb_ACLIVE13.Text = "";
            // 
            // groupBox32
            // 
            this.groupBox32.Controls.Add(this.rtb_IDBM_LIVE12);
            this.groupBox32.Controls.Add(this.label359);
            this.groupBox32.Controls.Add(this.label360);
            this.groupBox32.Controls.Add(this.label361);
            this.groupBox32.Controls.Add(this.label362);
            this.groupBox32.Controls.Add(this.rtb_AC_CLOSE12);
            this.groupBox32.Controls.Add(this.rtb_IDBM_CLOSECL12);
            this.groupBox32.Controls.Add(this.rtb_ACLIVE12);
            this.groupBox32.Location = new System.Drawing.Point(1077, 6);
            this.groupBox32.Name = "groupBox32";
            this.groupBox32.Size = new System.Drawing.Size(352, 320);
            this.groupBox32.TabIndex = 100;
            this.groupBox32.TabStop = false;
            this.groupBox32.Text = "VIA 12";
            // 
            // rtb_IDBM_LIVE12
            // 
            this.rtb_IDBM_LIVE12.Location = new System.Drawing.Point(31, 45);
            this.rtb_IDBM_LIVE12.Name = "rtb_IDBM_LIVE12";
            this.rtb_IDBM_LIVE12.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_LIVE12.TabIndex = 81;
            this.rtb_IDBM_LIVE12.Text = "";
            // 
            // label359
            // 
            this.label359.AutoSize = true;
            this.label359.Location = new System.Drawing.Point(219, 164);
            this.label359.Name = "label359";
            this.label359.Size = new System.Drawing.Size(72, 15);
            this.label359.TabIndex = 89;
            this.label359.Text = "AC CLOSE:";
            // 
            // label360
            // 
            this.label360.AutoSize = true;
            this.label360.Location = new System.Drawing.Point(64, 27);
            this.label360.Name = "label360";
            this.label360.Size = new System.Drawing.Size(72, 15);
            this.label360.TabIndex = 82;
            this.label360.Text = "IDBM LIVE:";
            // 
            // label361
            // 
            this.label361.AutoSize = true;
            this.label361.Location = new System.Drawing.Point(64, 164);
            this.label361.Name = "label361";
            this.label361.Size = new System.Drawing.Size(57, 15);
            this.label361.TabIndex = 88;
            this.label361.Text = "AC LIVE:";
            // 
            // label362
            // 
            this.label362.AutoSize = true;
            this.label362.Location = new System.Drawing.Point(219, 27);
            this.label362.Name = "label362";
            this.label362.Size = new System.Drawing.Size(87, 15);
            this.label362.TabIndex = 84;
            this.label362.Text = "IDBM CLOSE:";
            // 
            // rtb_AC_CLOSE12
            // 
            this.rtb_AC_CLOSE12.Location = new System.Drawing.Point(182, 183);
            this.rtb_AC_CLOSE12.Name = "rtb_AC_CLOSE12";
            this.rtb_AC_CLOSE12.Size = new System.Drawing.Size(145, 116);
            this.rtb_AC_CLOSE12.TabIndex = 87;
            this.rtb_AC_CLOSE12.Text = "";
            // 
            // rtb_IDBM_CLOSECL12
            // 
            this.rtb_IDBM_CLOSECL12.Location = new System.Drawing.Point(182, 45);
            this.rtb_IDBM_CLOSECL12.Name = "rtb_IDBM_CLOSECL12";
            this.rtb_IDBM_CLOSECL12.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_CLOSECL12.TabIndex = 85;
            this.rtb_IDBM_CLOSECL12.Text = "";
            // 
            // rtb_ACLIVE12
            // 
            this.rtb_ACLIVE12.Location = new System.Drawing.Point(31, 183);
            this.rtb_ACLIVE12.Name = "rtb_ACLIVE12";
            this.rtb_ACLIVE12.Size = new System.Drawing.Size(145, 116);
            this.rtb_ACLIVE12.TabIndex = 86;
            this.rtb_ACLIVE12.Text = "";
            // 
            // groupBox33
            // 
            this.groupBox33.Controls.Add(this.rtb_IDBM_LIVE10);
            this.groupBox33.Controls.Add(this.label363);
            this.groupBox33.Controls.Add(this.label364);
            this.groupBox33.Controls.Add(this.label365);
            this.groupBox33.Controls.Add(this.label366);
            this.groupBox33.Controls.Add(this.rtb_AC_CLOSE10);
            this.groupBox33.Controls.Add(this.rtb_IDBM_CLOSECL10);
            this.groupBox33.Controls.Add(this.rtb_ACLIVE10);
            this.groupBox33.Location = new System.Drawing.Point(361, 6);
            this.groupBox33.Name = "groupBox33";
            this.groupBox33.Size = new System.Drawing.Size(352, 320);
            this.groupBox33.TabIndex = 97;
            this.groupBox33.TabStop = false;
            this.groupBox33.Text = "VIA 10";
            // 
            // rtb_IDBM_LIVE10
            // 
            this.rtb_IDBM_LIVE10.Location = new System.Drawing.Point(31, 45);
            this.rtb_IDBM_LIVE10.Name = "rtb_IDBM_LIVE10";
            this.rtb_IDBM_LIVE10.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_LIVE10.TabIndex = 81;
            this.rtb_IDBM_LIVE10.Text = "";
            // 
            // label363
            // 
            this.label363.AutoSize = true;
            this.label363.Location = new System.Drawing.Point(219, 164);
            this.label363.Name = "label363";
            this.label363.Size = new System.Drawing.Size(72, 15);
            this.label363.TabIndex = 89;
            this.label363.Text = "AC CLOSE:";
            // 
            // label364
            // 
            this.label364.AutoSize = true;
            this.label364.Location = new System.Drawing.Point(64, 27);
            this.label364.Name = "label364";
            this.label364.Size = new System.Drawing.Size(72, 15);
            this.label364.TabIndex = 82;
            this.label364.Text = "IDBM LIVE:";
            // 
            // label365
            // 
            this.label365.AutoSize = true;
            this.label365.Location = new System.Drawing.Point(64, 164);
            this.label365.Name = "label365";
            this.label365.Size = new System.Drawing.Size(57, 15);
            this.label365.TabIndex = 88;
            this.label365.Text = "AC LIVE:";
            // 
            // label366
            // 
            this.label366.AutoSize = true;
            this.label366.Location = new System.Drawing.Point(219, 27);
            this.label366.Name = "label366";
            this.label366.Size = new System.Drawing.Size(87, 15);
            this.label366.TabIndex = 84;
            this.label366.Text = "IDBM CLOSE:";
            // 
            // rtb_AC_CLOSE10
            // 
            this.rtb_AC_CLOSE10.Location = new System.Drawing.Point(182, 183);
            this.rtb_AC_CLOSE10.Name = "rtb_AC_CLOSE10";
            this.rtb_AC_CLOSE10.Size = new System.Drawing.Size(145, 116);
            this.rtb_AC_CLOSE10.TabIndex = 87;
            this.rtb_AC_CLOSE10.Text = "";
            // 
            // rtb_IDBM_CLOSECL10
            // 
            this.rtb_IDBM_CLOSECL10.Location = new System.Drawing.Point(182, 45);
            this.rtb_IDBM_CLOSECL10.Name = "rtb_IDBM_CLOSECL10";
            this.rtb_IDBM_CLOSECL10.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_CLOSECL10.TabIndex = 85;
            this.rtb_IDBM_CLOSECL10.Text = "";
            // 
            // rtb_ACLIVE10
            // 
            this.rtb_ACLIVE10.Location = new System.Drawing.Point(31, 183);
            this.rtb_ACLIVE10.Name = "rtb_ACLIVE10";
            this.rtb_ACLIVE10.Size = new System.Drawing.Size(145, 116);
            this.rtb_ACLIVE10.TabIndex = 86;
            this.rtb_ACLIVE10.Text = "";
            // 
            // groupBox34
            // 
            this.groupBox34.Controls.Add(this.rtb_IDBM_LIVE9);
            this.groupBox34.Controls.Add(this.label367);
            this.groupBox34.Controls.Add(this.label368);
            this.groupBox34.Controls.Add(this.label369);
            this.groupBox34.Controls.Add(this.label370);
            this.groupBox34.Controls.Add(this.rtb_AC_CLOSE9);
            this.groupBox34.Controls.Add(this.rtb_IDBM_CLOSECL9);
            this.groupBox34.Controls.Add(this.rtb_ACLIVE9);
            this.groupBox34.Location = new System.Drawing.Point(6, 6);
            this.groupBox34.Name = "groupBox34";
            this.groupBox34.Size = new System.Drawing.Size(352, 320);
            this.groupBox34.TabIndex = 96;
            this.groupBox34.TabStop = false;
            this.groupBox34.Text = "VIA 9";
            // 
            // rtb_IDBM_LIVE9
            // 
            this.rtb_IDBM_LIVE9.Location = new System.Drawing.Point(31, 45);
            this.rtb_IDBM_LIVE9.Name = "rtb_IDBM_LIVE9";
            this.rtb_IDBM_LIVE9.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_LIVE9.TabIndex = 81;
            this.rtb_IDBM_LIVE9.Text = "";
            // 
            // label367
            // 
            this.label367.AutoSize = true;
            this.label367.Location = new System.Drawing.Point(219, 164);
            this.label367.Name = "label367";
            this.label367.Size = new System.Drawing.Size(72, 15);
            this.label367.TabIndex = 89;
            this.label367.Text = "AC CLOSE:";
            // 
            // label368
            // 
            this.label368.AutoSize = true;
            this.label368.Location = new System.Drawing.Point(64, 27);
            this.label368.Name = "label368";
            this.label368.Size = new System.Drawing.Size(72, 15);
            this.label368.TabIndex = 82;
            this.label368.Text = "IDBM LIVE:";
            // 
            // label369
            // 
            this.label369.AutoSize = true;
            this.label369.Location = new System.Drawing.Point(64, 164);
            this.label369.Name = "label369";
            this.label369.Size = new System.Drawing.Size(57, 15);
            this.label369.TabIndex = 88;
            this.label369.Text = "AC LIVE:";
            // 
            // label370
            // 
            this.label370.AutoSize = true;
            this.label370.Location = new System.Drawing.Point(219, 27);
            this.label370.Name = "label370";
            this.label370.Size = new System.Drawing.Size(87, 15);
            this.label370.TabIndex = 84;
            this.label370.Text = "IDBM CLOSE:";
            // 
            // rtb_AC_CLOSE9
            // 
            this.rtb_AC_CLOSE9.Location = new System.Drawing.Point(182, 183);
            this.rtb_AC_CLOSE9.Name = "rtb_AC_CLOSE9";
            this.rtb_AC_CLOSE9.Size = new System.Drawing.Size(145, 116);
            this.rtb_AC_CLOSE9.TabIndex = 87;
            this.rtb_AC_CLOSE9.Text = "";
            // 
            // rtb_IDBM_CLOSECL9
            // 
            this.rtb_IDBM_CLOSECL9.Location = new System.Drawing.Point(182, 45);
            this.rtb_IDBM_CLOSECL9.Name = "rtb_IDBM_CLOSECL9";
            this.rtb_IDBM_CLOSECL9.Size = new System.Drawing.Size(145, 116);
            this.rtb_IDBM_CLOSECL9.TabIndex = 85;
            this.rtb_IDBM_CLOSECL9.Text = "";
            // 
            // rtb_ACLIVE9
            // 
            this.rtb_ACLIVE9.Location = new System.Drawing.Point(31, 183);
            this.rtb_ACLIVE9.Name = "rtb_ACLIVE9";
            this.rtb_ACLIVE9.Size = new System.Drawing.Size(145, 116);
            this.rtb_ACLIVE9.TabIndex = 86;
            this.rtb_ACLIVE9.Text = "";
            // 
            // tabPage30
            // 
            this.tabPage30.BackColor = System.Drawing.Color.DimGray;
            this.tabPage30.Controls.Add(this.number_delay_nhand2);
            this.tabPage30.Controls.Add(this.label338);
            this.tabPage30.Controls.Add(this.tabControl9);
            this.tabPage30.Controls.Add(this.button9);
            this.tabPage30.Controls.Add(this.cmb_stt_chuyen_123);
            this.tabPage30.Controls.Add(this.label309);
            this.tabPage30.Controls.Add(this.cmb_VIA1);
            this.tabPage30.Controls.Add(this.label308);
            this.tabPage30.Controls.Add(this.label301);
            this.tabPage30.Controls.Add(this.richTextBox2);
            this.tabPage30.Controls.Add(this.rtb_ID_AC_SELECT_FAIL);
            this.tabPage30.Controls.Add(this.button8);
            this.tabPage30.Controls.Add(this.label300);
            this.tabPage30.Controls.Add(this.rtb_ID_AC_DONE);
            this.tabPage30.Controls.Add(this.label299);
            this.tabPage30.Controls.Add(this.rtb_ID_AC_FAIL);
            this.tabPage30.Location = new System.Drawing.Point(4, 24);
            this.tabPage30.Name = "tabPage30";
            this.tabPage30.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage30.Size = new System.Drawing.Size(1763, 657);
            this.tabPage30.TabIndex = 2;
            this.tabPage30.Text = "VIA 1";
            // 
            // number_delay_nhand2
            // 
            this.number_delay_nhand2.Location = new System.Drawing.Point(528, 15);
            this.number_delay_nhand2.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.number_delay_nhand2.Name = "number_delay_nhand2";
            this.number_delay_nhand2.Size = new System.Drawing.Size(120, 21);
            this.number_delay_nhand2.TabIndex = 113;
            this.number_delay_nhand2.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // label338
            // 
            this.label338.AutoSize = true;
            this.label338.Location = new System.Drawing.Point(440, 17);
            this.label338.Name = "label338";
            this.label338.Size = new System.Drawing.Size(87, 15);
            this.label338.TabIndex = 112;
            this.label338.Text = "DELAY NHẬN:";
            // 
            // tabControl9
            // 
            this.tabControl9.Controls.Add(this.tabPage33);
            this.tabControl9.Controls.Add(this.tabPage34);
            this.tabControl9.Controls.Add(this.tabPage36);
            this.tabControl9.Controls.Add(this.tabPage37);
            this.tabControl9.Location = new System.Drawing.Point(22, 35);
            this.tabControl9.Name = "tabControl9";
            this.tabControl9.SelectedIndex = 0;
            this.tabControl9.Size = new System.Drawing.Size(1145, 616);
            this.tabControl9.TabIndex = 111;
            // 
            // tabPage33
            // 
            this.tabPage33.BackColor = System.Drawing.Color.DimGray;
            this.tabPage33.Controls.Add(this.groupBox23);
            this.tabPage33.Location = new System.Drawing.Point(4, 24);
            this.tabPage33.Name = "tabPage33";
            this.tabPage33.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage33.Size = new System.Drawing.Size(1137, 588);
            this.tabPage33.TabIndex = 0;
            this.tabPage33.Text = "1-6";
            // 
            // groupBox23
            // 
            this.groupBox23.Controls.Add(this.rtb_ACLIVE6_VIA1);
            this.groupBox23.Controls.Add(this.label310);
            this.groupBox23.Controls.Add(this.rtb_ACLIVE5_VIA1);
            this.groupBox23.Controls.Add(this.label311);
            this.groupBox23.Controls.Add(this.rtb_ACLIVE4_VIA1);
            this.groupBox23.Controls.Add(this.label312);
            this.groupBox23.Controls.Add(this.rtb_IDBMLIVE6_VIA1);
            this.groupBox23.Controls.Add(this.rtb_IDBMLIVE5_VIA1);
            this.groupBox23.Controls.Add(this.label313);
            this.groupBox23.Controls.Add(this.label314);
            this.groupBox23.Controls.Add(this.rtb_IDBMLIVE4_VIA1);
            this.groupBox23.Controls.Add(this.label315);
            this.groupBox23.Controls.Add(this.rtb_ACLIVE3_VIA1);
            this.groupBox23.Controls.Add(this.label307);
            this.groupBox23.Controls.Add(this.rtb_ACLIVE2_VIA1);
            this.groupBox23.Controls.Add(this.label302);
            this.groupBox23.Controls.Add(this.rtb_ACLIVE1_VIA1);
            this.groupBox23.Controls.Add(this.label304);
            this.groupBox23.Controls.Add(this.rtb_IDBMLIVE3_VIA1);
            this.groupBox23.Controls.Add(this.rtb_IDBMLIVE2_VIA1);
            this.groupBox23.Controls.Add(this.label305);
            this.groupBox23.Controls.Add(this.label306);
            this.groupBox23.Controls.Add(this.rtb_IDBMLIVE_VIA1);
            this.groupBox23.Controls.Add(this.label303);
            this.groupBox23.Location = new System.Drawing.Point(6, 3);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(1103, 579);
            this.groupBox23.TabIndex = 105;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "VIA 1";
            // 
            // rtb_ACLIVE6_VIA1
            // 
            this.rtb_ACLIVE6_VIA1.Location = new System.Drawing.Point(927, 305);
            this.rtb_ACLIVE6_VIA1.Name = "rtb_ACLIVE6_VIA1";
            this.rtb_ACLIVE6_VIA1.Size = new System.Drawing.Size(165, 241);
            this.rtb_ACLIVE6_VIA1.TabIndex = 112;
            this.rtb_ACLIVE6_VIA1.Text = "";
            // 
            // label310
            // 
            this.label310.AutoSize = true;
            this.label310.Location = new System.Drawing.Point(953, 284);
            this.label310.Name = "label310";
            this.label310.Size = new System.Drawing.Size(76, 15);
            this.label310.TabIndex = 111;
            this.label310.Text = "IDAC LIVE6:";
            // 
            // rtb_ACLIVE5_VIA1
            // 
            this.rtb_ACLIVE5_VIA1.Location = new System.Drawing.Point(743, 305);
            this.rtb_ACLIVE5_VIA1.Name = "rtb_ACLIVE5_VIA1";
            this.rtb_ACLIVE5_VIA1.Size = new System.Drawing.Size(165, 241);
            this.rtb_ACLIVE5_VIA1.TabIndex = 110;
            this.rtb_ACLIVE5_VIA1.Text = "";
            // 
            // label311
            // 
            this.label311.AutoSize = true;
            this.label311.Location = new System.Drawing.Point(769, 284);
            this.label311.Name = "label311";
            this.label311.Size = new System.Drawing.Size(76, 15);
            this.label311.TabIndex = 109;
            this.label311.Text = "IDAC LIVE5:";
            // 
            // rtb_ACLIVE4_VIA1
            // 
            this.rtb_ACLIVE4_VIA1.Location = new System.Drawing.Point(562, 305);
            this.rtb_ACLIVE4_VIA1.Name = "rtb_ACLIVE4_VIA1";
            this.rtb_ACLIVE4_VIA1.Size = new System.Drawing.Size(165, 241);
            this.rtb_ACLIVE4_VIA1.TabIndex = 107;
            this.rtb_ACLIVE4_VIA1.Text = "";
            // 
            // label312
            // 
            this.label312.AutoSize = true;
            this.label312.Location = new System.Drawing.Point(590, 284);
            this.label312.Name = "label312";
            this.label312.Size = new System.Drawing.Size(76, 15);
            this.label312.TabIndex = 108;
            this.label312.Text = "IDAC LIVE4:";
            // 
            // rtb_IDBMLIVE6_VIA1
            // 
            this.rtb_IDBMLIVE6_VIA1.Location = new System.Drawing.Point(914, 41);
            this.rtb_IDBMLIVE6_VIA1.Name = "rtb_IDBMLIVE6_VIA1";
            this.rtb_IDBMLIVE6_VIA1.Size = new System.Drawing.Size(176, 198);
            this.rtb_IDBMLIVE6_VIA1.TabIndex = 106;
            this.rtb_IDBMLIVE6_VIA1.Text = "";
            // 
            // rtb_IDBMLIVE5_VIA1
            // 
            this.rtb_IDBMLIVE5_VIA1.Location = new System.Drawing.Point(732, 41);
            this.rtb_IDBMLIVE5_VIA1.Name = "rtb_IDBMLIVE5_VIA1";
            this.rtb_IDBMLIVE5_VIA1.Size = new System.Drawing.Size(176, 198);
            this.rtb_IDBMLIVE5_VIA1.TabIndex = 105;
            this.rtb_IDBMLIVE5_VIA1.Text = "";
            // 
            // label313
            // 
            this.label313.AutoSize = true;
            this.label313.Location = new System.Drawing.Point(953, 20);
            this.label313.Name = "label313";
            this.label313.Size = new System.Drawing.Size(78, 15);
            this.label313.TabIndex = 104;
            this.label313.Text = "IDBM LIVE6:";
            // 
            // label314
            // 
            this.label314.AutoSize = true;
            this.label314.Location = new System.Drawing.Point(769, 20);
            this.label314.Name = "label314";
            this.label314.Size = new System.Drawing.Size(78, 15);
            this.label314.TabIndex = 103;
            this.label314.Text = "IDBM LIVE5:";
            // 
            // rtb_IDBMLIVE4_VIA1
            // 
            this.rtb_IDBMLIVE4_VIA1.Location = new System.Drawing.Point(551, 41);
            this.rtb_IDBMLIVE4_VIA1.Name = "rtb_IDBMLIVE4_VIA1";
            this.rtb_IDBMLIVE4_VIA1.Size = new System.Drawing.Size(176, 198);
            this.rtb_IDBMLIVE4_VIA1.TabIndex = 101;
            this.rtb_IDBMLIVE4_VIA1.Text = "";
            // 
            // label315
            // 
            this.label315.AutoSize = true;
            this.label315.Location = new System.Drawing.Point(590, 20);
            this.label315.Name = "label315";
            this.label315.Size = new System.Drawing.Size(78, 15);
            this.label315.TabIndex = 102;
            this.label315.Text = "IDBM LIVE4:";
            // 
            // rtb_ACLIVE3_VIA1
            // 
            this.rtb_ACLIVE3_VIA1.Location = new System.Drawing.Point(382, 305);
            this.rtb_ACLIVE3_VIA1.Name = "rtb_ACLIVE3_VIA1";
            this.rtb_ACLIVE3_VIA1.Size = new System.Drawing.Size(165, 241);
            this.rtb_ACLIVE3_VIA1.TabIndex = 100;
            this.rtb_ACLIVE3_VIA1.Text = "";
            // 
            // label307
            // 
            this.label307.AutoSize = true;
            this.label307.Location = new System.Drawing.Point(408, 284);
            this.label307.Name = "label307";
            this.label307.Size = new System.Drawing.Size(76, 15);
            this.label307.TabIndex = 99;
            this.label307.Text = "IDAC LIVE3:";
            // 
            // rtb_ACLIVE2_VIA1
            // 
            this.rtb_ACLIVE2_VIA1.Location = new System.Drawing.Point(198, 305);
            this.rtb_ACLIVE2_VIA1.Name = "rtb_ACLIVE2_VIA1";
            this.rtb_ACLIVE2_VIA1.Size = new System.Drawing.Size(165, 241);
            this.rtb_ACLIVE2_VIA1.TabIndex = 98;
            this.rtb_ACLIVE2_VIA1.Text = "";
            // 
            // label302
            // 
            this.label302.AutoSize = true;
            this.label302.Location = new System.Drawing.Point(224, 284);
            this.label302.Name = "label302";
            this.label302.Size = new System.Drawing.Size(76, 15);
            this.label302.TabIndex = 97;
            this.label302.Text = "IDAC LIVE2:";
            // 
            // rtb_ACLIVE1_VIA1
            // 
            this.rtb_ACLIVE1_VIA1.Location = new System.Drawing.Point(17, 305);
            this.rtb_ACLIVE1_VIA1.Name = "rtb_ACLIVE1_VIA1";
            this.rtb_ACLIVE1_VIA1.Size = new System.Drawing.Size(165, 241);
            this.rtb_ACLIVE1_VIA1.TabIndex = 95;
            this.rtb_ACLIVE1_VIA1.Text = "";
            // 
            // label304
            // 
            this.label304.AutoSize = true;
            this.label304.Location = new System.Drawing.Point(45, 284);
            this.label304.Name = "label304";
            this.label304.Size = new System.Drawing.Size(76, 15);
            this.label304.TabIndex = 96;
            this.label304.Text = "IDAC LIVE1:";
            // 
            // rtb_IDBMLIVE3_VIA1
            // 
            this.rtb_IDBMLIVE3_VIA1.Location = new System.Drawing.Point(369, 41);
            this.rtb_IDBMLIVE3_VIA1.Name = "rtb_IDBMLIVE3_VIA1";
            this.rtb_IDBMLIVE3_VIA1.Size = new System.Drawing.Size(176, 198);
            this.rtb_IDBMLIVE3_VIA1.TabIndex = 94;
            this.rtb_IDBMLIVE3_VIA1.Text = "";
            // 
            // rtb_IDBMLIVE2_VIA1
            // 
            this.rtb_IDBMLIVE2_VIA1.Location = new System.Drawing.Point(187, 41);
            this.rtb_IDBMLIVE2_VIA1.Name = "rtb_IDBMLIVE2_VIA1";
            this.rtb_IDBMLIVE2_VIA1.Size = new System.Drawing.Size(176, 198);
            this.rtb_IDBMLIVE2_VIA1.TabIndex = 93;
            this.rtb_IDBMLIVE2_VIA1.Text = "";
            // 
            // label305
            // 
            this.label305.AutoSize = true;
            this.label305.Location = new System.Drawing.Point(408, 20);
            this.label305.Name = "label305";
            this.label305.Size = new System.Drawing.Size(78, 15);
            this.label305.TabIndex = 92;
            this.label305.Text = "IDBM LIVE3:";
            // 
            // label306
            // 
            this.label306.AutoSize = true;
            this.label306.Location = new System.Drawing.Point(224, 20);
            this.label306.Name = "label306";
            this.label306.Size = new System.Drawing.Size(78, 15);
            this.label306.TabIndex = 90;
            this.label306.Text = "IDBM LIVE2:";
            // 
            // rtb_IDBMLIVE_VIA1
            // 
            this.rtb_IDBMLIVE_VIA1.Location = new System.Drawing.Point(6, 41);
            this.rtb_IDBMLIVE_VIA1.Name = "rtb_IDBMLIVE_VIA1";
            this.rtb_IDBMLIVE_VIA1.Size = new System.Drawing.Size(176, 198);
            this.rtb_IDBMLIVE_VIA1.TabIndex = 81;
            this.rtb_IDBMLIVE_VIA1.Text = "";
            // 
            // label303
            // 
            this.label303.AutoSize = true;
            this.label303.Location = new System.Drawing.Point(43, 20);
            this.label303.Name = "label303";
            this.label303.Size = new System.Drawing.Size(78, 15);
            this.label303.TabIndex = 82;
            this.label303.Text = "IDBM LIVE1:";
            // 
            // tabPage34
            // 
            this.tabPage34.BackColor = System.Drawing.Color.DimGray;
            this.tabPage34.Controls.Add(this.groupBox26);
            this.tabPage34.Location = new System.Drawing.Point(4, 24);
            this.tabPage34.Name = "tabPage34";
            this.tabPage34.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage34.Size = new System.Drawing.Size(1137, 588);
            this.tabPage34.TabIndex = 1;
            this.tabPage34.Text = "7-12";
            // 
            // groupBox26
            // 
            this.groupBox26.Controls.Add(this.rtb_ACLIVE12_VIA1);
            this.groupBox26.Controls.Add(this.label326);
            this.groupBox26.Controls.Add(this.rtb_ACLIVE11_VIA1);
            this.groupBox26.Controls.Add(this.label327);
            this.groupBox26.Controls.Add(this.rtb_ACLIVE10_VIA1);
            this.groupBox26.Controls.Add(this.label328);
            this.groupBox26.Controls.Add(this.rtb_IDBMLIVE12_VIA1);
            this.groupBox26.Controls.Add(this.rtb_IDBMLIVE11_VIA1);
            this.groupBox26.Controls.Add(this.label329);
            this.groupBox26.Controls.Add(this.label330);
            this.groupBox26.Controls.Add(this.rtb_IDBMLIVE10_VIA1);
            this.groupBox26.Controls.Add(this.label331);
            this.groupBox26.Controls.Add(this.rtb_ACLIVE9_VIA1);
            this.groupBox26.Controls.Add(this.label332);
            this.groupBox26.Controls.Add(this.rtb_ACLIVE8_VIA1);
            this.groupBox26.Controls.Add(this.label333);
            this.groupBox26.Controls.Add(this.rtb_ACLIVE7_VIA1);
            this.groupBox26.Controls.Add(this.label334);
            this.groupBox26.Controls.Add(this.rtb_IDBMLIVE9_VIA1);
            this.groupBox26.Controls.Add(this.rtb_IDBMLIVE8_VIA1);
            this.groupBox26.Controls.Add(this.label335);
            this.groupBox26.Controls.Add(this.label336);
            this.groupBox26.Controls.Add(this.rtb_IDBMLIVE7_VIA1);
            this.groupBox26.Controls.Add(this.label337);
            this.groupBox26.Location = new System.Drawing.Point(6, 13);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.Size = new System.Drawing.Size(1103, 579);
            this.groupBox26.TabIndex = 113;
            this.groupBox26.TabStop = false;
            this.groupBox26.Text = "VIA 1";
            // 
            // rtb_ACLIVE12_VIA1
            // 
            this.rtb_ACLIVE12_VIA1.Location = new System.Drawing.Point(927, 305);
            this.rtb_ACLIVE12_VIA1.Name = "rtb_ACLIVE12_VIA1";
            this.rtb_ACLIVE12_VIA1.Size = new System.Drawing.Size(165, 241);
            this.rtb_ACLIVE12_VIA1.TabIndex = 112;
            this.rtb_ACLIVE12_VIA1.Text = "";
            // 
            // label326
            // 
            this.label326.AutoSize = true;
            this.label326.Location = new System.Drawing.Point(953, 284);
            this.label326.Name = "label326";
            this.label326.Size = new System.Drawing.Size(82, 15);
            this.label326.TabIndex = 111;
            this.label326.Text = "IDAC LIVE12:";
            // 
            // rtb_ACLIVE11_VIA1
            // 
            this.rtb_ACLIVE11_VIA1.Location = new System.Drawing.Point(743, 305);
            this.rtb_ACLIVE11_VIA1.Name = "rtb_ACLIVE11_VIA1";
            this.rtb_ACLIVE11_VIA1.Size = new System.Drawing.Size(165, 241);
            this.rtb_ACLIVE11_VIA1.TabIndex = 110;
            this.rtb_ACLIVE11_VIA1.Text = "";
            // 
            // label327
            // 
            this.label327.AutoSize = true;
            this.label327.Location = new System.Drawing.Point(769, 284);
            this.label327.Name = "label327";
            this.label327.Size = new System.Drawing.Size(81, 15);
            this.label327.TabIndex = 109;
            this.label327.Text = "IDAC LIVE11:";
            // 
            // rtb_ACLIVE10_VIA1
            // 
            this.rtb_ACLIVE10_VIA1.Location = new System.Drawing.Point(562, 305);
            this.rtb_ACLIVE10_VIA1.Name = "rtb_ACLIVE10_VIA1";
            this.rtb_ACLIVE10_VIA1.Size = new System.Drawing.Size(165, 241);
            this.rtb_ACLIVE10_VIA1.TabIndex = 107;
            this.rtb_ACLIVE10_VIA1.Text = "";
            // 
            // label328
            // 
            this.label328.AutoSize = true;
            this.label328.Location = new System.Drawing.Point(590, 284);
            this.label328.Name = "label328";
            this.label328.Size = new System.Drawing.Size(82, 15);
            this.label328.TabIndex = 108;
            this.label328.Text = "IDAC LIVE10:";
            // 
            // rtb_IDBMLIVE12_VIA1
            // 
            this.rtb_IDBMLIVE12_VIA1.Location = new System.Drawing.Point(914, 41);
            this.rtb_IDBMLIVE12_VIA1.Name = "rtb_IDBMLIVE12_VIA1";
            this.rtb_IDBMLIVE12_VIA1.Size = new System.Drawing.Size(176, 198);
            this.rtb_IDBMLIVE12_VIA1.TabIndex = 106;
            this.rtb_IDBMLIVE12_VIA1.Text = "";
            // 
            // rtb_IDBMLIVE11_VIA1
            // 
            this.rtb_IDBMLIVE11_VIA1.Location = new System.Drawing.Point(732, 41);
            this.rtb_IDBMLIVE11_VIA1.Name = "rtb_IDBMLIVE11_VIA1";
            this.rtb_IDBMLIVE11_VIA1.Size = new System.Drawing.Size(176, 198);
            this.rtb_IDBMLIVE11_VIA1.TabIndex = 105;
            this.rtb_IDBMLIVE11_VIA1.Text = "";
            // 
            // label329
            // 
            this.label329.AutoSize = true;
            this.label329.Location = new System.Drawing.Point(953, 20);
            this.label329.Name = "label329";
            this.label329.Size = new System.Drawing.Size(84, 15);
            this.label329.TabIndex = 104;
            this.label329.Text = "IDBM LIVE12:";
            // 
            // label330
            // 
            this.label330.AutoSize = true;
            this.label330.Location = new System.Drawing.Point(769, 20);
            this.label330.Name = "label330";
            this.label330.Size = new System.Drawing.Size(83, 15);
            this.label330.TabIndex = 103;
            this.label330.Text = "IDBM LIVE11:";
            // 
            // rtb_IDBMLIVE10_VIA1
            // 
            this.rtb_IDBMLIVE10_VIA1.Location = new System.Drawing.Point(551, 41);
            this.rtb_IDBMLIVE10_VIA1.Name = "rtb_IDBMLIVE10_VIA1";
            this.rtb_IDBMLIVE10_VIA1.Size = new System.Drawing.Size(176, 198);
            this.rtb_IDBMLIVE10_VIA1.TabIndex = 101;
            this.rtb_IDBMLIVE10_VIA1.Text = "";
            // 
            // label331
            // 
            this.label331.AutoSize = true;
            this.label331.Location = new System.Drawing.Point(590, 20);
            this.label331.Name = "label331";
            this.label331.Size = new System.Drawing.Size(84, 15);
            this.label331.TabIndex = 102;
            this.label331.Text = "IDBM LIVE10:";
            // 
            // rtb_ACLIVE9_VIA1
            // 
            this.rtb_ACLIVE9_VIA1.Location = new System.Drawing.Point(382, 305);
            this.rtb_ACLIVE9_VIA1.Name = "rtb_ACLIVE9_VIA1";
            this.rtb_ACLIVE9_VIA1.Size = new System.Drawing.Size(165, 241);
            this.rtb_ACLIVE9_VIA1.TabIndex = 100;
            this.rtb_ACLIVE9_VIA1.Text = "";
            // 
            // label332
            // 
            this.label332.AutoSize = true;
            this.label332.Location = new System.Drawing.Point(408, 284);
            this.label332.Name = "label332";
            this.label332.Size = new System.Drawing.Size(76, 15);
            this.label332.TabIndex = 99;
            this.label332.Text = "IDAC LIVE9:";
            // 
            // rtb_ACLIVE8_VIA1
            // 
            this.rtb_ACLIVE8_VIA1.Location = new System.Drawing.Point(198, 305);
            this.rtb_ACLIVE8_VIA1.Name = "rtb_ACLIVE8_VIA1";
            this.rtb_ACLIVE8_VIA1.Size = new System.Drawing.Size(165, 241);
            this.rtb_ACLIVE8_VIA1.TabIndex = 98;
            this.rtb_ACLIVE8_VIA1.Text = "";
            // 
            // label333
            // 
            this.label333.AutoSize = true;
            this.label333.Location = new System.Drawing.Point(224, 284);
            this.label333.Name = "label333";
            this.label333.Size = new System.Drawing.Size(76, 15);
            this.label333.TabIndex = 97;
            this.label333.Text = "IDAC LIVE8:";
            // 
            // rtb_ACLIVE7_VIA1
            // 
            this.rtb_ACLIVE7_VIA1.Location = new System.Drawing.Point(17, 305);
            this.rtb_ACLIVE7_VIA1.Name = "rtb_ACLIVE7_VIA1";
            this.rtb_ACLIVE7_VIA1.Size = new System.Drawing.Size(165, 241);
            this.rtb_ACLIVE7_VIA1.TabIndex = 95;
            this.rtb_ACLIVE7_VIA1.Text = "";
            // 
            // label334
            // 
            this.label334.AutoSize = true;
            this.label334.Location = new System.Drawing.Point(45, 284);
            this.label334.Name = "label334";
            this.label334.Size = new System.Drawing.Size(76, 15);
            this.label334.TabIndex = 96;
            this.label334.Text = "IDAC LIVE7:";
            // 
            // rtb_IDBMLIVE9_VIA1
            // 
            this.rtb_IDBMLIVE9_VIA1.Location = new System.Drawing.Point(369, 41);
            this.rtb_IDBMLIVE9_VIA1.Name = "rtb_IDBMLIVE9_VIA1";
            this.rtb_IDBMLIVE9_VIA1.Size = new System.Drawing.Size(176, 198);
            this.rtb_IDBMLIVE9_VIA1.TabIndex = 94;
            this.rtb_IDBMLIVE9_VIA1.Text = "";
            // 
            // rtb_IDBMLIVE8_VIA1
            // 
            this.rtb_IDBMLIVE8_VIA1.Location = new System.Drawing.Point(187, 41);
            this.rtb_IDBMLIVE8_VIA1.Name = "rtb_IDBMLIVE8_VIA1";
            this.rtb_IDBMLIVE8_VIA1.Size = new System.Drawing.Size(176, 198);
            this.rtb_IDBMLIVE8_VIA1.TabIndex = 93;
            this.rtb_IDBMLIVE8_VIA1.Text = "";
            // 
            // label335
            // 
            this.label335.AutoSize = true;
            this.label335.Location = new System.Drawing.Point(408, 20);
            this.label335.Name = "label335";
            this.label335.Size = new System.Drawing.Size(78, 15);
            this.label335.TabIndex = 92;
            this.label335.Text = "IDBM LIVE9:";
            // 
            // label336
            // 
            this.label336.AutoSize = true;
            this.label336.Location = new System.Drawing.Point(224, 20);
            this.label336.Name = "label336";
            this.label336.Size = new System.Drawing.Size(78, 15);
            this.label336.TabIndex = 90;
            this.label336.Text = "IDBM LIVE8:";
            // 
            // rtb_IDBMLIVE7_VIA1
            // 
            this.rtb_IDBMLIVE7_VIA1.Location = new System.Drawing.Point(6, 41);
            this.rtb_IDBMLIVE7_VIA1.Name = "rtb_IDBMLIVE7_VIA1";
            this.rtb_IDBMLIVE7_VIA1.Size = new System.Drawing.Size(176, 198);
            this.rtb_IDBMLIVE7_VIA1.TabIndex = 81;
            this.rtb_IDBMLIVE7_VIA1.Text = "";
            // 
            // label337
            // 
            this.label337.AutoSize = true;
            this.label337.Location = new System.Drawing.Point(43, 20);
            this.label337.Name = "label337";
            this.label337.Size = new System.Drawing.Size(78, 15);
            this.label337.TabIndex = 82;
            this.label337.Text = "IDBM LIVE7:";
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button9.Location = new System.Drawing.Point(1564, 243);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(133, 49);
            this.button9.TabIndex = 110;
            this.button9.Text = "DELETE ID AC";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // cmb_stt_chuyen_123
            // 
            this.cmb_stt_chuyen_123.FormattingEnabled = true;
            this.cmb_stt_chuyen_123.Location = new System.Drawing.Point(293, 9);
            this.cmb_stt_chuyen_123.Name = "cmb_stt_chuyen_123";
            this.cmb_stt_chuyen_123.Size = new System.Drawing.Size(122, 23);
            this.cmb_stt_chuyen_123.TabIndex = 109;
            // 
            // label309
            // 
            this.label309.AutoSize = true;
            this.label309.Location = new System.Drawing.Point(230, 12);
            this.label309.Name = "label309";
            this.label309.Size = new System.Drawing.Size(37, 15);
            this.label309.TabIndex = 108;
            this.label309.Text = "1-2-3:";
            // 
            // cmb_VIA1
            // 
            this.cmb_VIA1.FormattingEnabled = true;
            this.cmb_VIA1.Location = new System.Drawing.Point(82, 6);
            this.cmb_VIA1.Name = "cmb_VIA1";
            this.cmb_VIA1.Size = new System.Drawing.Size(122, 23);
            this.cmb_VIA1.TabIndex = 107;
            // 
            // label308
            // 
            this.label308.AutoSize = true;
            this.label308.Location = new System.Drawing.Point(19, 9);
            this.label308.Name = "label308";
            this.label308.Size = new System.Drawing.Size(39, 15);
            this.label308.TabIndex = 106;
            this.label308.Text = "VIA 1:";
            // 
            // label301
            // 
            this.label301.AutoSize = true;
            this.label301.Location = new System.Drawing.Point(1561, 77);
            this.label301.Name = "label301";
            this.label301.Size = new System.Drawing.Size(91, 15);
            this.label301.TabIndex = 104;
            this.label301.Text = "ID AC SELECT:";
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(1218, 428);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(319, 101);
            this.richTextBox2.TabIndex = 103;
            this.richTextBox2.Text = "";
            // 
            // rtb_ID_AC_SELECT_FAIL
            // 
            this.rtb_ID_AC_SELECT_FAIL.Location = new System.Drawing.Point(1564, 95);
            this.rtb_ID_AC_SELECT_FAIL.Name = "rtb_ID_AC_SELECT_FAIL";
            this.rtb_ID_AC_SELECT_FAIL.Size = new System.Drawing.Size(172, 101);
            this.rtb_ID_AC_SELECT_FAIL.TabIndex = 102;
            this.rtb_ID_AC_SELECT_FAIL.Text = "";
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button8.Location = new System.Drawing.Point(1574, 25);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(133, 49);
            this.button8.TabIndex = 38;
            this.button8.Text = "Select ID AC FAIL";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // label300
            // 
            this.label300.AutoSize = true;
            this.label300.Location = new System.Drawing.Point(1341, 225);
            this.label300.Name = "label300";
            this.label300.Size = new System.Drawing.Size(81, 15);
            this.label300.TabIndex = 101;
            this.label300.Text = "ID AC DONE:";
            // 
            // rtb_ID_AC_DONE
            // 
            this.rtb_ID_AC_DONE.Location = new System.Drawing.Point(1218, 243);
            this.rtb_ID_AC_DONE.Name = "rtb_ID_AC_DONE";
            this.rtb_ID_AC_DONE.Size = new System.Drawing.Size(319, 157);
            this.rtb_ID_AC_DONE.TabIndex = 100;
            this.rtb_ID_AC_DONE.Text = "";
            // 
            // label299
            // 
            this.label299.AutoSize = true;
            this.label299.Location = new System.Drawing.Point(1341, 25);
            this.label299.Name = "label299";
            this.label299.Size = new System.Drawing.Size(71, 15);
            this.label299.TabIndex = 98;
            this.label299.Text = "ID AC FAIL:";
            // 
            // rtb_ID_AC_FAIL
            // 
            this.rtb_ID_AC_FAIL.Location = new System.Drawing.Point(1218, 43);
            this.rtb_ID_AC_FAIL.Name = "rtb_ID_AC_FAIL";
            this.rtb_ID_AC_FAIL.Size = new System.Drawing.Size(319, 169);
            this.rtb_ID_AC_FAIL.TabIndex = 99;
            this.rtb_ID_AC_FAIL.Text = "";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(306, 28);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown1.TabIndex = 4;
            // 
            // cmb_Chuc_Nang
            // 
            this.cmb_Chuc_Nang.FormattingEnabled = true;
            this.cmb_Chuc_Nang.Location = new System.Drawing.Point(305, 54);
            this.cmb_Chuc_Nang.Name = "cmb_Chuc_Nang";
            this.cmb_Chuc_Nang.Size = new System.Drawing.Size(121, 21);
            this.cmb_Chuc_Nang.TabIndex = 20;
            this.cmb_Chuc_Nang.SelectedIndexChanged += new System.EventHandler(this.cmb_Chuc_Nang_SelectedIndexChanged);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(226, 57);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(74, 13);
            this.label42.TabIndex = 21;
            this.label42.Text = "CHỨC NĂNG:";
            // 
            // tbsodu
            // 
            this.tbsodu.Location = new System.Drawing.Point(864, 27);
            this.tbsodu.Name = "tbsodu";
            this.tbsodu.Size = new System.Drawing.Size(125, 20);
            this.tbsodu.TabIndex = 24;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(776, 30);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(82, 13);
            this.label45.TabIndex = 25;
            this.label45.Text = "Số Dư captcha:";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(788, 62);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(70, 13);
            this.label46.TabIndex = 26;
            this.label46.Text = "Key captcha:";
            // 
            // cmbKeyCaptcha
            // 
            this.cmbKeyCaptcha.FormattingEnabled = true;
            this.cmbKeyCaptcha.Location = new System.Drawing.Point(864, 59);
            this.cmbKeyCaptcha.Name = "cmbKeyCaptcha";
            this.cmbKeyCaptcha.Size = new System.Drawing.Size(230, 21);
            this.cmbKeyCaptcha.TabIndex = 27;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(226, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 28;
            this.label1.Text = "Số Luồng:";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(490, 30);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(27, 13);
            this.label67.TabIndex = 29;
            this.label67.Text = "VIA:";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(489, 57);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(43, 13);
            this.label68.TabIndex = 30;
            this.label68.Text = "LOGIN:";
            // 
            // cmbVIA
            // 
            this.cmbVIA.FormattingEnabled = true;
            this.cmbVIA.Location = new System.Drawing.Point(538, 28);
            this.cmbVIA.Name = "cmbVIA";
            this.cmbVIA.Size = new System.Drawing.Size(121, 21);
            this.cmbVIA.TabIndex = 31;
            // 
            // cmbLogin
            // 
            this.cmbLogin.FormattingEnabled = true;
            this.cmbLogin.Location = new System.Drawing.Point(538, 53);
            this.cmbLogin.Name = "cmbLogin";
            this.cmbLogin.Size = new System.Drawing.Size(121, 21);
            this.cmbLogin.TabIndex = 32;
            // 
            // btn_Stop
            // 
            this.btn_Stop.BackColor = System.Drawing.Color.Red;
            this.btn_Stop.Location = new System.Drawing.Point(93, 13);
            this.btn_Stop.Name = "btn_Stop";
            this.btn_Stop.Size = new System.Drawing.Size(75, 49);
            this.btn_Stop.TabIndex = 33;
            this.btn_Stop.Text = "STOP";
            this.btn_Stop.UseVisualStyleBackColor = false;
            this.btn_Stop.Click += new System.EventHandler(this.btn_Stop_Click);
            // 
            // lbnew
            // 
            this.lbnew.AutoSize = true;
            this.lbnew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbnew.Location = new System.Drawing.Point(194, 85);
            this.lbnew.Name = "lbnew";
            this.lbnew.Size = new System.Drawing.Size(47, 13);
            this.lbnew.TabIndex = 5;
            this.lbnew.Text = "1.0.0.0";
            // 
            // labelnew
            // 
            this.labelnew.AutoSize = true;
            this.labelnew.Location = new System.Drawing.Point(115, 85);
            this.labelnew.Name = "labelnew";
            this.labelnew.Size = new System.Drawing.Size(73, 13);
            this.labelnew.TabIndex = 4;
            this.labelnew.Text = "New Version :";
            // 
            // btUpdate
            // 
            this.btUpdate.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btUpdate.Location = new System.Drawing.Point(12, 65);
            this.btUpdate.Name = "btUpdate";
            this.btUpdate.Size = new System.Drawing.Size(75, 49);
            this.btUpdate.TabIndex = 35;
            this.btUpdate.Text = "UPDATE";
            this.btUpdate.UseVisualStyleBackColor = false;
            // 
            // tb_LOAD_STT
            // 
            this.tb_LOAD_STT.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.tb_LOAD_STT.Location = new System.Drawing.Point(1167, 13);
            this.tb_LOAD_STT.Name = "tb_LOAD_STT";
            this.tb_LOAD_STT.Size = new System.Drawing.Size(75, 49);
            this.tb_LOAD_STT.TabIndex = 36;
            this.tb_LOAD_STT.Text = "LOAD STT";
            this.tb_LOAD_STT.UseVisualStyleBackColor = false;
            this.tb_LOAD_STT.Click += new System.EventHandler(this.tb_LOAD_STT_Click);
            // 
            // bt_file_VIA
            // 
            this.bt_file_VIA.BackColor = System.Drawing.Color.MediumOrchid;
            this.bt_file_VIA.Location = new System.Drawing.Point(1271, 13);
            this.bt_file_VIA.Name = "bt_file_VIA";
            this.bt_file_VIA.Size = new System.Drawing.Size(75, 49);
            this.bt_file_VIA.TabIndex = 37;
            this.bt_file_VIA.Text = "FILE VIA";
            this.bt_file_VIA.UseVisualStyleBackColor = false;
            this.bt_file_VIA.Click += new System.EventHandler(this.bt_file_VIA_Click);
            // 
            // tabPage36
            // 
            this.tabPage36.BackColor = System.Drawing.Color.DimGray;
            this.tabPage36.Controls.Add(this.groupBox37);
            this.tabPage36.Location = new System.Drawing.Point(4, 24);
            this.tabPage36.Name = "tabPage36";
            this.tabPage36.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage36.Size = new System.Drawing.Size(1137, 588);
            this.tabPage36.TabIndex = 2;
            this.tabPage36.Text = "13-18";
            // 
            // groupBox37
            // 
            this.groupBox37.Controls.Add(this.rtb_ACLIVE18_VIA1);
            this.groupBox37.Controls.Add(this.label379);
            this.groupBox37.Controls.Add(this.rtb_ACLIVE17_VIA1);
            this.groupBox37.Controls.Add(this.label380);
            this.groupBox37.Controls.Add(this.rtb_ACLIVE16_VIA1);
            this.groupBox37.Controls.Add(this.label381);
            this.groupBox37.Controls.Add(this.rtb_IDBMLIVE18_VIA1);
            this.groupBox37.Controls.Add(this.rtb_IDBMLIVE17_VIA1);
            this.groupBox37.Controls.Add(this.label382);
            this.groupBox37.Controls.Add(this.label383);
            this.groupBox37.Controls.Add(this.rtb_IDBMLIVE16_VIA1);
            this.groupBox37.Controls.Add(this.label384);
            this.groupBox37.Controls.Add(this.rtb_ACLIVE15_VIA1);
            this.groupBox37.Controls.Add(this.label385);
            this.groupBox37.Controls.Add(this.rtb_ACLIVE14_VIA1);
            this.groupBox37.Controls.Add(this.label386);
            this.groupBox37.Controls.Add(this.rtb_ACLIVE13_VIA1);
            this.groupBox37.Controls.Add(this.label387);
            this.groupBox37.Controls.Add(this.rtb_IDBMLIVE15_VIA1);
            this.groupBox37.Controls.Add(this.rtb_IDBMLIVE14_VIA1);
            this.groupBox37.Controls.Add(this.label388);
            this.groupBox37.Controls.Add(this.label389);
            this.groupBox37.Controls.Add(this.rtb_IDBMLIVE13_VIA1);
            this.groupBox37.Controls.Add(this.label390);
            this.groupBox37.Location = new System.Drawing.Point(15, 12);
            this.groupBox37.Name = "groupBox37";
            this.groupBox37.Size = new System.Drawing.Size(1103, 579);
            this.groupBox37.TabIndex = 114;
            this.groupBox37.TabStop = false;
            this.groupBox37.Text = "VIA 1";
            // 
            // rtb_ACLIVE18_VIA1
            // 
            this.rtb_ACLIVE18_VIA1.Location = new System.Drawing.Point(927, 305);
            this.rtb_ACLIVE18_VIA1.Name = "rtb_ACLIVE18_VIA1";
            this.rtb_ACLIVE18_VIA1.Size = new System.Drawing.Size(165, 241);
            this.rtb_ACLIVE18_VIA1.TabIndex = 112;
            this.rtb_ACLIVE18_VIA1.Text = "";
            // 
            // label379
            // 
            this.label379.AutoSize = true;
            this.label379.Location = new System.Drawing.Point(953, 284);
            this.label379.Name = "label379";
            this.label379.Size = new System.Drawing.Size(82, 15);
            this.label379.TabIndex = 111;
            this.label379.Text = "IDAC LIVE18:";
            // 
            // rtb_ACLIVE17_VIA1
            // 
            this.rtb_ACLIVE17_VIA1.Location = new System.Drawing.Point(743, 305);
            this.rtb_ACLIVE17_VIA1.Name = "rtb_ACLIVE17_VIA1";
            this.rtb_ACLIVE17_VIA1.Size = new System.Drawing.Size(165, 241);
            this.rtb_ACLIVE17_VIA1.TabIndex = 110;
            this.rtb_ACLIVE17_VIA1.Text = "";
            // 
            // label380
            // 
            this.label380.AutoSize = true;
            this.label380.Location = new System.Drawing.Point(769, 284);
            this.label380.Name = "label380";
            this.label380.Size = new System.Drawing.Size(82, 15);
            this.label380.TabIndex = 109;
            this.label380.Text = "IDAC LIVE17:";
            // 
            // rtb_ACLIVE16_VIA1
            // 
            this.rtb_ACLIVE16_VIA1.Location = new System.Drawing.Point(562, 305);
            this.rtb_ACLIVE16_VIA1.Name = "rtb_ACLIVE16_VIA1";
            this.rtb_ACLIVE16_VIA1.Size = new System.Drawing.Size(165, 241);
            this.rtb_ACLIVE16_VIA1.TabIndex = 107;
            this.rtb_ACLIVE16_VIA1.Text = "";
            // 
            // label381
            // 
            this.label381.AutoSize = true;
            this.label381.Location = new System.Drawing.Point(590, 284);
            this.label381.Name = "label381";
            this.label381.Size = new System.Drawing.Size(82, 15);
            this.label381.TabIndex = 108;
            this.label381.Text = "IDAC LIVE16:";
            // 
            // rtb_IDBMLIVE18_VIA1
            // 
            this.rtb_IDBMLIVE18_VIA1.Location = new System.Drawing.Point(914, 41);
            this.rtb_IDBMLIVE18_VIA1.Name = "rtb_IDBMLIVE18_VIA1";
            this.rtb_IDBMLIVE18_VIA1.Size = new System.Drawing.Size(176, 198);
            this.rtb_IDBMLIVE18_VIA1.TabIndex = 106;
            this.rtb_IDBMLIVE18_VIA1.Text = "";
            // 
            // rtb_IDBMLIVE17_VIA1
            // 
            this.rtb_IDBMLIVE17_VIA1.Location = new System.Drawing.Point(732, 41);
            this.rtb_IDBMLIVE17_VIA1.Name = "rtb_IDBMLIVE17_VIA1";
            this.rtb_IDBMLIVE17_VIA1.Size = new System.Drawing.Size(176, 198);
            this.rtb_IDBMLIVE17_VIA1.TabIndex = 105;
            this.rtb_IDBMLIVE17_VIA1.Text = "";
            // 
            // label382
            // 
            this.label382.AutoSize = true;
            this.label382.Location = new System.Drawing.Point(953, 20);
            this.label382.Name = "label382";
            this.label382.Size = new System.Drawing.Size(84, 15);
            this.label382.TabIndex = 104;
            this.label382.Text = "IDBM LIVE18:";
            // 
            // label383
            // 
            this.label383.AutoSize = true;
            this.label383.Location = new System.Drawing.Point(769, 20);
            this.label383.Name = "label383";
            this.label383.Size = new System.Drawing.Size(84, 15);
            this.label383.TabIndex = 103;
            this.label383.Text = "IDBM LIVE17:";
            // 
            // rtb_IDBMLIVE16_VIA1
            // 
            this.rtb_IDBMLIVE16_VIA1.Location = new System.Drawing.Point(551, 41);
            this.rtb_IDBMLIVE16_VIA1.Name = "rtb_IDBMLIVE16_VIA1";
            this.rtb_IDBMLIVE16_VIA1.Size = new System.Drawing.Size(176, 198);
            this.rtb_IDBMLIVE16_VIA1.TabIndex = 101;
            this.rtb_IDBMLIVE16_VIA1.Text = "";
            // 
            // label384
            // 
            this.label384.AutoSize = true;
            this.label384.Location = new System.Drawing.Point(590, 20);
            this.label384.Name = "label384";
            this.label384.Size = new System.Drawing.Size(84, 15);
            this.label384.TabIndex = 102;
            this.label384.Text = "IDBM LIVE16:";
            // 
            // rtb_ACLIVE15_VIA1
            // 
            this.rtb_ACLIVE15_VIA1.Location = new System.Drawing.Point(382, 305);
            this.rtb_ACLIVE15_VIA1.Name = "rtb_ACLIVE15_VIA1";
            this.rtb_ACLIVE15_VIA1.Size = new System.Drawing.Size(165, 241);
            this.rtb_ACLIVE15_VIA1.TabIndex = 100;
            this.rtb_ACLIVE15_VIA1.Text = "";
            // 
            // label385
            // 
            this.label385.AutoSize = true;
            this.label385.Location = new System.Drawing.Point(408, 284);
            this.label385.Name = "label385";
            this.label385.Size = new System.Drawing.Size(82, 15);
            this.label385.TabIndex = 99;
            this.label385.Text = "IDAC LIVE15:";
            // 
            // rtb_ACLIVE14_VIA1
            // 
            this.rtb_ACLIVE14_VIA1.Location = new System.Drawing.Point(198, 305);
            this.rtb_ACLIVE14_VIA1.Name = "rtb_ACLIVE14_VIA1";
            this.rtb_ACLIVE14_VIA1.Size = new System.Drawing.Size(165, 241);
            this.rtb_ACLIVE14_VIA1.TabIndex = 98;
            this.rtb_ACLIVE14_VIA1.Text = "";
            // 
            // label386
            // 
            this.label386.AutoSize = true;
            this.label386.Location = new System.Drawing.Point(224, 284);
            this.label386.Name = "label386";
            this.label386.Size = new System.Drawing.Size(82, 15);
            this.label386.TabIndex = 97;
            this.label386.Text = "IDAC LIVE14:";
            // 
            // rtb_ACLIVE13_VIA1
            // 
            this.rtb_ACLIVE13_VIA1.Location = new System.Drawing.Point(17, 305);
            this.rtb_ACLIVE13_VIA1.Name = "rtb_ACLIVE13_VIA1";
            this.rtb_ACLIVE13_VIA1.Size = new System.Drawing.Size(165, 241);
            this.rtb_ACLIVE13_VIA1.TabIndex = 95;
            this.rtb_ACLIVE13_VIA1.Text = "";
            // 
            // label387
            // 
            this.label387.AutoSize = true;
            this.label387.Location = new System.Drawing.Point(45, 284);
            this.label387.Name = "label387";
            this.label387.Size = new System.Drawing.Size(82, 15);
            this.label387.TabIndex = 96;
            this.label387.Text = "IDAC LIVE13:";
            // 
            // rtb_IDBMLIVE15_VIA1
            // 
            this.rtb_IDBMLIVE15_VIA1.Location = new System.Drawing.Point(369, 41);
            this.rtb_IDBMLIVE15_VIA1.Name = "rtb_IDBMLIVE15_VIA1";
            this.rtb_IDBMLIVE15_VIA1.Size = new System.Drawing.Size(176, 198);
            this.rtb_IDBMLIVE15_VIA1.TabIndex = 94;
            this.rtb_IDBMLIVE15_VIA1.Text = "";
            // 
            // rtb_IDBMLIVE14_VIA1
            // 
            this.rtb_IDBMLIVE14_VIA1.Location = new System.Drawing.Point(187, 41);
            this.rtb_IDBMLIVE14_VIA1.Name = "rtb_IDBMLIVE14_VIA1";
            this.rtb_IDBMLIVE14_VIA1.Size = new System.Drawing.Size(176, 198);
            this.rtb_IDBMLIVE14_VIA1.TabIndex = 93;
            this.rtb_IDBMLIVE14_VIA1.Text = "";
            // 
            // label388
            // 
            this.label388.AutoSize = true;
            this.label388.Location = new System.Drawing.Point(408, 20);
            this.label388.Name = "label388";
            this.label388.Size = new System.Drawing.Size(84, 15);
            this.label388.TabIndex = 92;
            this.label388.Text = "IDBM LIVE15:";
            // 
            // label389
            // 
            this.label389.AutoSize = true;
            this.label389.Location = new System.Drawing.Point(224, 20);
            this.label389.Name = "label389";
            this.label389.Size = new System.Drawing.Size(84, 15);
            this.label389.TabIndex = 90;
            this.label389.Text = "IDBM LIVE14:";
            // 
            // rtb_IDBMLIVE13_VIA1
            // 
            this.rtb_IDBMLIVE13_VIA1.Location = new System.Drawing.Point(6, 41);
            this.rtb_IDBMLIVE13_VIA1.Name = "rtb_IDBMLIVE13_VIA1";
            this.rtb_IDBMLIVE13_VIA1.Size = new System.Drawing.Size(176, 198);
            this.rtb_IDBMLIVE13_VIA1.TabIndex = 81;
            this.rtb_IDBMLIVE13_VIA1.Text = "";
            // 
            // label390
            // 
            this.label390.AutoSize = true;
            this.label390.Location = new System.Drawing.Point(43, 20);
            this.label390.Name = "label390";
            this.label390.Size = new System.Drawing.Size(84, 15);
            this.label390.TabIndex = 82;
            this.label390.Text = "IDBM LIVE13:";
            // 
            // tabPage37
            // 
            this.tabPage37.BackColor = System.Drawing.Color.DimGray;
            this.tabPage37.Controls.Add(this.groupBox38);
            this.tabPage37.Location = new System.Drawing.Point(4, 24);
            this.tabPage37.Name = "tabPage37";
            this.tabPage37.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage37.Size = new System.Drawing.Size(1137, 588);
            this.tabPage37.TabIndex = 3;
            this.tabPage37.Text = "18-23";
            // 
            // groupBox38
            // 
            this.groupBox38.Controls.Add(this.label399);
            this.groupBox38.Controls.Add(this.label402);
            this.groupBox38.Controls.Add(this.rtb_ACLIVE24_VIA1);
            this.groupBox38.Controls.Add(this.label391);
            this.groupBox38.Controls.Add(this.rtb_ACLIVE23_VIA1);
            this.groupBox38.Controls.Add(this.label392);
            this.groupBox38.Controls.Add(this.rtb_ACLIVE22_VIA1);
            this.groupBox38.Controls.Add(this.label393);
            this.groupBox38.Controls.Add(this.rtb_IDBMLIVE24_VIA1);
            this.groupBox38.Controls.Add(this.rtb_IDBMLIVE23_VIA1);
            this.groupBox38.Controls.Add(this.label394);
            this.groupBox38.Controls.Add(this.label395);
            this.groupBox38.Controls.Add(this.rtb_IDBMLIVE22_VIA1);
            this.groupBox38.Controls.Add(this.label396);
            this.groupBox38.Controls.Add(this.rtb_ACLIVE21_VIA1);
            this.groupBox38.Controls.Add(this.label397);
            this.groupBox38.Controls.Add(this.rtb_ACLIVE20_VIA1);
            this.groupBox38.Controls.Add(this.label398);
            this.groupBox38.Controls.Add(this.rtb_ACLIVE19_VIA1);
            this.groupBox38.Controls.Add(this.rtb_IDBMLIVE21_VIA1);
            this.groupBox38.Controls.Add(this.rtb_IDBMLIVE20_VIA1);
            this.groupBox38.Controls.Add(this.label400);
            this.groupBox38.Controls.Add(this.label401);
            this.groupBox38.Controls.Add(this.rtb_IDBMLIVE19_VIA1);
            this.groupBox38.Location = new System.Drawing.Point(17, 5);
            this.groupBox38.Name = "groupBox38";
            this.groupBox38.Size = new System.Drawing.Size(1103, 579);
            this.groupBox38.TabIndex = 115;
            this.groupBox38.TabStop = false;
            this.groupBox38.Text = "VIA 1";
            // 
            // rtb_ACLIVE24_VIA1
            // 
            this.rtb_ACLIVE24_VIA1.Location = new System.Drawing.Point(927, 305);
            this.rtb_ACLIVE24_VIA1.Name = "rtb_ACLIVE24_VIA1";
            this.rtb_ACLIVE24_VIA1.Size = new System.Drawing.Size(165, 241);
            this.rtb_ACLIVE24_VIA1.TabIndex = 112;
            this.rtb_ACLIVE24_VIA1.Text = "";
            // 
            // label391
            // 
            this.label391.AutoSize = true;
            this.label391.Location = new System.Drawing.Point(779, 287);
            this.label391.Name = "label391";
            this.label391.Size = new System.Drawing.Size(82, 15);
            this.label391.TabIndex = 111;
            this.label391.Text = "IDAC LIVE23:";
            // 
            // rtb_ACLIVE23_VIA1
            // 
            this.rtb_ACLIVE23_VIA1.Location = new System.Drawing.Point(743, 305);
            this.rtb_ACLIVE23_VIA1.Name = "rtb_ACLIVE23_VIA1";
            this.rtb_ACLIVE23_VIA1.Size = new System.Drawing.Size(165, 241);
            this.rtb_ACLIVE23_VIA1.TabIndex = 110;
            this.rtb_ACLIVE23_VIA1.Text = "";
            // 
            // label392
            // 
            this.label392.AutoSize = true;
            this.label392.Location = new System.Drawing.Point(595, 287);
            this.label392.Name = "label392";
            this.label392.Size = new System.Drawing.Size(82, 15);
            this.label392.TabIndex = 109;
            this.label392.Text = "IDAC LIVE22:";
            // 
            // rtb_ACLIVE22_VIA1
            // 
            this.rtb_ACLIVE22_VIA1.Location = new System.Drawing.Point(562, 305);
            this.rtb_ACLIVE22_VIA1.Name = "rtb_ACLIVE22_VIA1";
            this.rtb_ACLIVE22_VIA1.Size = new System.Drawing.Size(165, 241);
            this.rtb_ACLIVE22_VIA1.TabIndex = 107;
            this.rtb_ACLIVE22_VIA1.Text = "";
            // 
            // label393
            // 
            this.label393.AutoSize = true;
            this.label393.Location = new System.Drawing.Point(416, 287);
            this.label393.Name = "label393";
            this.label393.Size = new System.Drawing.Size(82, 15);
            this.label393.TabIndex = 108;
            this.label393.Text = "IDAC LIVE21:";
            // 
            // rtb_IDBMLIVE24_VIA1
            // 
            this.rtb_IDBMLIVE24_VIA1.Location = new System.Drawing.Point(914, 41);
            this.rtb_IDBMLIVE24_VIA1.Name = "rtb_IDBMLIVE24_VIA1";
            this.rtb_IDBMLIVE24_VIA1.Size = new System.Drawing.Size(176, 198);
            this.rtb_IDBMLIVE24_VIA1.TabIndex = 106;
            this.rtb_IDBMLIVE24_VIA1.Text = "";
            // 
            // rtb_IDBMLIVE23_VIA1
            // 
            this.rtb_IDBMLIVE23_VIA1.Location = new System.Drawing.Point(732, 41);
            this.rtb_IDBMLIVE23_VIA1.Name = "rtb_IDBMLIVE23_VIA1";
            this.rtb_IDBMLIVE23_VIA1.Size = new System.Drawing.Size(176, 198);
            this.rtb_IDBMLIVE23_VIA1.TabIndex = 105;
            this.rtb_IDBMLIVE23_VIA1.Text = "";
            // 
            // label394
            // 
            this.label394.AutoSize = true;
            this.label394.Location = new System.Drawing.Point(779, 23);
            this.label394.Name = "label394";
            this.label394.Size = new System.Drawing.Size(84, 15);
            this.label394.TabIndex = 104;
            this.label394.Text = "IDBM LIVE23:";
            // 
            // label395
            // 
            this.label395.AutoSize = true;
            this.label395.Location = new System.Drawing.Point(595, 23);
            this.label395.Name = "label395";
            this.label395.Size = new System.Drawing.Size(84, 15);
            this.label395.TabIndex = 103;
            this.label395.Text = "IDBM LIVE22:";
            // 
            // rtb_IDBMLIVE22_VIA1
            // 
            this.rtb_IDBMLIVE22_VIA1.Location = new System.Drawing.Point(551, 41);
            this.rtb_IDBMLIVE22_VIA1.Name = "rtb_IDBMLIVE22_VIA1";
            this.rtb_IDBMLIVE22_VIA1.Size = new System.Drawing.Size(176, 198);
            this.rtb_IDBMLIVE22_VIA1.TabIndex = 101;
            this.rtb_IDBMLIVE22_VIA1.Text = "";
            // 
            // label396
            // 
            this.label396.AutoSize = true;
            this.label396.Location = new System.Drawing.Point(416, 23);
            this.label396.Name = "label396";
            this.label396.Size = new System.Drawing.Size(84, 15);
            this.label396.TabIndex = 102;
            this.label396.Text = "IDBM LIVE21:";
            // 
            // rtb_ACLIVE21_VIA1
            // 
            this.rtb_ACLIVE21_VIA1.Location = new System.Drawing.Point(382, 305);
            this.rtb_ACLIVE21_VIA1.Name = "rtb_ACLIVE21_VIA1";
            this.rtb_ACLIVE21_VIA1.Size = new System.Drawing.Size(165, 241);
            this.rtb_ACLIVE21_VIA1.TabIndex = 100;
            this.rtb_ACLIVE21_VIA1.Text = "";
            // 
            // label397
            // 
            this.label397.AutoSize = true;
            this.label397.Location = new System.Drawing.Point(234, 287);
            this.label397.Name = "label397";
            this.label397.Size = new System.Drawing.Size(82, 15);
            this.label397.TabIndex = 99;
            this.label397.Text = "IDAC LIVE20:";
            // 
            // rtb_ACLIVE20_VIA1
            // 
            this.rtb_ACLIVE20_VIA1.Location = new System.Drawing.Point(198, 305);
            this.rtb_ACLIVE20_VIA1.Name = "rtb_ACLIVE20_VIA1";
            this.rtb_ACLIVE20_VIA1.Size = new System.Drawing.Size(165, 241);
            this.rtb_ACLIVE20_VIA1.TabIndex = 98;
            this.rtb_ACLIVE20_VIA1.Text = "";
            // 
            // label398
            // 
            this.label398.AutoSize = true;
            this.label398.Location = new System.Drawing.Point(50, 287);
            this.label398.Name = "label398";
            this.label398.Size = new System.Drawing.Size(82, 15);
            this.label398.TabIndex = 97;
            this.label398.Text = "IDAC LIVE19:";
            // 
            // rtb_ACLIVE19_VIA1
            // 
            this.rtb_ACLIVE19_VIA1.Location = new System.Drawing.Point(17, 305);
            this.rtb_ACLIVE19_VIA1.Name = "rtb_ACLIVE19_VIA1";
            this.rtb_ACLIVE19_VIA1.Size = new System.Drawing.Size(165, 241);
            this.rtb_ACLIVE19_VIA1.TabIndex = 95;
            this.rtb_ACLIVE19_VIA1.Text = "";
            // 
            // rtb_IDBMLIVE21_VIA1
            // 
            this.rtb_IDBMLIVE21_VIA1.Location = new System.Drawing.Point(369, 41);
            this.rtb_IDBMLIVE21_VIA1.Name = "rtb_IDBMLIVE21_VIA1";
            this.rtb_IDBMLIVE21_VIA1.Size = new System.Drawing.Size(176, 198);
            this.rtb_IDBMLIVE21_VIA1.TabIndex = 94;
            this.rtb_IDBMLIVE21_VIA1.Text = "";
            // 
            // rtb_IDBMLIVE20_VIA1
            // 
            this.rtb_IDBMLIVE20_VIA1.Location = new System.Drawing.Point(187, 41);
            this.rtb_IDBMLIVE20_VIA1.Name = "rtb_IDBMLIVE20_VIA1";
            this.rtb_IDBMLIVE20_VIA1.Size = new System.Drawing.Size(176, 198);
            this.rtb_IDBMLIVE20_VIA1.TabIndex = 93;
            this.rtb_IDBMLIVE20_VIA1.Text = "";
            // 
            // label400
            // 
            this.label400.AutoSize = true;
            this.label400.Location = new System.Drawing.Point(234, 23);
            this.label400.Name = "label400";
            this.label400.Size = new System.Drawing.Size(84, 15);
            this.label400.TabIndex = 92;
            this.label400.Text = "IDBM LIVE20:";
            // 
            // label401
            // 
            this.label401.AutoSize = true;
            this.label401.Location = new System.Drawing.Point(50, 23);
            this.label401.Name = "label401";
            this.label401.Size = new System.Drawing.Size(84, 15);
            this.label401.TabIndex = 90;
            this.label401.Text = "IDBM LIVE19:";
            // 
            // rtb_IDBMLIVE19_VIA1
            // 
            this.rtb_IDBMLIVE19_VIA1.Location = new System.Drawing.Point(6, 41);
            this.rtb_IDBMLIVE19_VIA1.Name = "rtb_IDBMLIVE19_VIA1";
            this.rtb_IDBMLIVE19_VIA1.Size = new System.Drawing.Size(176, 198);
            this.rtb_IDBMLIVE19_VIA1.TabIndex = 81;
            this.rtb_IDBMLIVE19_VIA1.Text = "";
            // 
            // label399
            // 
            this.label399.AutoSize = true;
            this.label399.Location = new System.Drawing.Point(956, 287);
            this.label399.Name = "label399";
            this.label399.Size = new System.Drawing.Size(82, 15);
            this.label399.TabIndex = 114;
            this.label399.Text = "IDAC LIVE24:";
            // 
            // label402
            // 
            this.label402.AutoSize = true;
            this.label402.Location = new System.Drawing.Point(956, 23);
            this.label402.Name = "label402";
            this.label402.Size = new System.Drawing.Size(84, 15);
            this.label402.TabIndex = 113;
            this.label402.Text = "IDBM LIVE24:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1776, 830);
            this.Controls.Add(this.bt_file_VIA);
            this.Controls.Add(this.tb_LOAD_STT);
            this.Controls.Add(this.btUpdate);
            this.Controls.Add(this.lbnew);
            this.Controls.Add(this.labelnew);
            this.Controls.Add(this.btn_Stop);
            this.Controls.Add(this.cmbLogin);
            this.Controls.Add(this.cmbVIA);
            this.Controls.Add(this.label68);
            this.Controls.Add(this.label67);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbKeyCaptcha);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.tbsodu);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.cmb_Chuc_Nang);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btn_RUN);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "FB";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed_1);
            this.Load += new System.EventHandler(this.Form1_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gioi_han_close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gioi_han_live)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gioi_han_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.delayshare)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sl_Nhan_BM_CLOSE1_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sl_Nhan_BM_PARTNER)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sl_nhan_Bm_BM_BACKUP)).EndInit();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.delay_reg_bm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.for_reg_bm)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.soluong_mua_Mail)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv2_IG)).EndInit();
            this.contextMenuStrip3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_mail)).EndInit();
            this.contextMenuStrip2.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabControl6.ResumeLayout(false);
            this.tabPage23.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage24.ResumeLayout(false);
            this.tabPage24.PerformLayout();
            this.tabPage25.ResumeLayout(false);
            this.tabPage25.PerformLayout();
            this.tabPage26.ResumeLayout(false);
            this.tabPage26.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5_delay_regbmig)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_tao_5bm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.delay_doc_hotmail_1)).EndInit();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.n_slink_share_them)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.delay_tatbatsangtao)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nam_rip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.thang_rip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngay_rip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5_slcheck_bm350)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.delay_check_admin)).EndInit();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ndelayloop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.delay_link_bm_backup)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            this.tabPage10.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage11.ResumeLayout(false);
            this.tabPage11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.delay_check_infor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sl_LOAD_TK_D2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_AC)).EndInit();
            this.contextMenuStrip5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.delay_LOAD_BM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SL_BM_LOAD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_BM)).EndInit();
            this.contextMenuStrip4.ResumeLayout(false);
            this.tabPage12.ResumeLayout(false);
            this.tabPage12.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.n_Delay_TTK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.delay_doc_link)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.so_link_backup)).EndInit();
            this.tabPage22.ResumeLayout(false);
            this.tabPage22.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sl_BM_kick3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.m_delay_ttk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.delay_kick_bm3)).EndInit();
            this.tabPage13.ResumeLayout(false);
            this.tabPage13.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.tabPage14.ResumeLayout(false);
            this.tabControl4.ResumeLayout(false);
            this.tabPage15.ResumeLayout(false);
            this.tabPage15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DELAY_DOC_MAIL)).EndInit();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_STT_NHAN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.number_nhan_fail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).EndInit();
            this.tabPage16.ResumeLayout(false);
            this.tabPage16.PerformLayout();
            this.tabPage17.ResumeLayout(false);
            this.tabPage17.PerformLayout();
            this.tabPage18.ResumeLayout(false);
            this.tabPage18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.delay_check_ig)).EndInit();
            this.tabPage19.ResumeLayout(false);
            this.tabControl5.ResumeLayout(false);
            this.tabPage20.ResumeLayout(false);
            this.tabPage20.PerformLayout();
            this.tabPage27.ResumeLayout(false);
            this.tabControl7.ResumeLayout(false);
            this.tabPage28.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.tabControl8.ResumeLayout(false);
            this.tabPage31.ResumeLayout(false);
            this.groupBox24.ResumeLayout(false);
            this.groupBox24.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown20)).EndInit();
            this.tabPage32.ResumeLayout(false);
            this.groupBox25.ResumeLayout(false);
            this.groupBox25.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown27)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown29)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.delay_regbm_cl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.number_REGBMCL)).EndInit();
            this.tabPage29.ResumeLayout(false);
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.tabPage35.ResumeLayout(false);
            this.groupBox35.ResumeLayout(false);
            this.groupBox35.PerformLayout();
            this.groupBox27.ResumeLayout(false);
            this.groupBox27.PerformLayout();
            this.groupBox36.ResumeLayout(false);
            this.groupBox36.PerformLayout();
            this.groupBox28.ResumeLayout(false);
            this.groupBox28.PerformLayout();
            this.groupBox29.ResumeLayout(false);
            this.groupBox29.PerformLayout();
            this.groupBox30.ResumeLayout(false);
            this.groupBox30.PerformLayout();
            this.groupBox31.ResumeLayout(false);
            this.groupBox31.PerformLayout();
            this.groupBox32.ResumeLayout(false);
            this.groupBox32.PerformLayout();
            this.groupBox33.ResumeLayout(false);
            this.groupBox33.PerformLayout();
            this.groupBox34.ResumeLayout(false);
            this.groupBox34.PerformLayout();
            this.tabPage30.ResumeLayout(false);
            this.tabPage30.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.number_delay_nhand2)).EndInit();
            this.tabControl9.ResumeLayout(false);
            this.tabPage33.ResumeLayout(false);
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            this.tabPage34.ResumeLayout(false);
            this.groupBox26.ResumeLayout(false);
            this.groupBox26.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.tabPage36.ResumeLayout(false);
            this.groupBox37.ResumeLayout(false);
            this.groupBox37.PerformLayout();
            this.tabPage37.ResumeLayout(false);
            this.groupBox38.ResumeLayout(false);
            this.groupBox38.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn_RUN;
        private System.Windows.Forms.DataGridView dgv1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridViewTextBoxColumn cStt;
        private System.Windows.Forms.DataGridViewTextBoxColumn cUID;
        private System.Windows.Forms.DataGridViewTextBoxColumn cPass;
        private System.Windows.Forms.DataGridViewTextBoxColumn c2FAvsCookie;
        private System.Windows.Forms.DataGridViewTextBoxColumn cMail;
        private System.Windows.Forms.DataGridViewTextBoxColumn cPassMail;
        private System.Windows.Forms.DataGridViewTextBoxColumn cMailKP;
        private System.Windows.Forms.DataGridViewTextBoxColumn cStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn cCheckBM;
        private System.Windows.Forms.DataGridViewCheckBoxColumn cSelect;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem chọnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bôiĐenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tấtCảToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bỏChọnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bôiĐenToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tấtCảToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem xóaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dòngĐãChọnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tấtCảToolStripMenuItem2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cmb_ID_MAIL;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox tb_so_du_DongVan;
        private System.Windows.Forms.TextBox Tx_Key_API_DongVan;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox tx_MK_Dong_Vanox2;
        private System.Windows.Forms.TextBox tx_TK_Dong_Van;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.NumericUpDown soluong_mua_Mail;
        private System.Windows.Forms.ComboBox cmb_Chuc_Nang;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox tbsodu;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.ComboBox cmbKeyCaptcha;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataGridView dgv_mail;
        private System.Windows.Forms.DataGridViewTextBoxColumn cStt1;
        private System.Windows.Forms.DataGridViewTextBoxColumn cMail1;
        private System.Windows.Forms.DataGridViewTextBoxColumn cPassMail1;
        private System.Windows.Forms.DataGridViewTextBoxColumn cToken;
        private System.Windows.Forms.DataGridViewTextBoxColumn cStatus1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn cSelect1;
        private System.Windows.Forms.DataGridView dgv2_IG;
        private System.Windows.Forms.DataGridViewTextBoxColumn cStt2;
        private System.Windows.Forms.DataGridViewTextBoxColumn cIG;
        private System.Windows.Forms.DataGridViewTextBoxColumn cStatus2;
        private System.Windows.Forms.DataGridViewCheckBoxColumn cSelect2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem chọnToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem bôiĐenToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem tấtCảToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem bỏChọnToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem bôiĐenToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem tấtCảToolStripMenuItem4;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip3;
        private System.Windows.Forms.ToolStripMenuItem chọnToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem bôiĐenToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem tấtCảToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem bỏChọnToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem bôiĐenToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem tấtCảToolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem xóaToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem bôiĐenToolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem tấtCảToolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem xóaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem dòngĐãChọnToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tấtCảToolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem aDDMAILKPToolStripMenuItem;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.ComboBox cmb_REGHOTMAIL;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.ComboBox cmb_VN_US;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.ComboBox cmb_LOGIN_IG;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TextBox tb_so_luong_BM_PARTNER;
        private System.Windows.Forms.TextBox tb_BM_Close_4;
        private System.Windows.Forms.TextBox tb_BM_Close_3;
        private System.Windows.Forms.TextBox tb_BM_Close_2;
        private System.Windows.Forms.TextBox tb_BM_Close1;
        private System.Windows.Forms.TextBox tb_BM_BACK_UP3;
        private System.Windows.Forms.TextBox tb_BM_BACK_UP2;
        private System.Windows.Forms.TextBox tb_BM_BACK_UP;
        private System.Windows.Forms.TextBox tb_BM;
        private System.Windows.Forms.RichTextBox rtb_IDBM_PARTNER;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSE_4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSE_3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSE_2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSE;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.RichTextBox rtb_ID_BM_Share_BACK_UP3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.RichTextBox rtb_ID_BM_Share_BACK_UP2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.RichTextBox rtb_ID_BM_Share_BACK_UP;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.RichTextBox rtb_ID_BM_Share;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tb_sl_282;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmb_CLOSE_SHARE;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmb_User_Agent;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.RichTextBox rtb_BM_CLOSE_4_THAY_THE;
        private System.Windows.Forms.RichTextBox rtb_BM_CLOSE_3_THAY_THE;
        private System.Windows.Forms.RichTextBox rtb_BM_CLOSE_2_THAY_THE;
        private System.Windows.Forms.RichTextBox rtb_BM_CLOSE_THAY_THE;
        private System.Windows.Forms.RichTextBox rtb_BM_BACKUP3_THAY_THE;
        private System.Windows.Forms.RichTextBox rtb_BM_BACKUP2_THAY_THE;
        private System.Windows.Forms.RichTextBox rtb_BM_BACKUP_THAY_THE;
        private System.Windows.Forms.RichTextBox rtb_BM_THAY_THE;
        private System.Windows.Forms.ComboBox cmb_ADD_Tra_Truoc;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.NumericUpDown gioi_han_close;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.NumericUpDown gioi_han_live;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.NumericUpDown gioi_han_1;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.NumericUpDown delayshare;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.RichTextBox rtb_BM_PARTNER_THAY_THE;
        private System.Windows.Forms.NumericUpDown sl_Nhan_BM_CLOSE1_2;
        private System.Windows.Forms.NumericUpDown sl_Nhan_BM_PARTNER;
        private System.Windows.Forms.NumericUpDown sl_nhan_Bm_BM_BACKUP;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox tx_So_Luong_Share_vao_bm;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.RichTextBox rtb_BMDIE;
        private System.Windows.Forms.RichTextBox rtb_BM_Nhan_Du;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.RichTextBox rtbdone;
        private System.Windows.Forms.RichTextBox rtbAC_FAIL;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.RichTextBox rtb_MAIL_SHARE_CLONE;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cmb_Share_BM_CLone;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.ComboBox cmb_Mui_Gio_TK_BM;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.ComboBox cmb_TEN_TK_BM;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.ComboBox cmb_Tien_Te_TK_BM;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.NumericUpDown delay_reg_bm;
        private System.Windows.Forms.NumericUpDown for_reg_bm;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmb_Tao_TK_BM;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmb_REG_BM_Clone_API;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox tb_so_luong_BM;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.ComboBox cmb_Share_DOI_TAC;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RichTextBox rtb_DONE1;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.ToolStripMenuItem nHẬNBMNEWToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.ComboBox cmbVIA;
        private System.Windows.Forms.ComboBox cmbLogin;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.ComboBox cmbonoffchrome;
        private System.Windows.Forms.ComboBox cmb_lay_Cookie;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Button btn_Stop;
        private System.Windows.Forms.RichTextBox rtb_FAIL3;
        private System.Windows.Forms.RichTextBox rtb_linkmail3_backup;
        private System.Windows.Forms.RichTextBox rtb_DONE3;
        private System.Windows.Forms.RichTextBox rtb_FAIL2;
        private System.Windows.Forms.RichTextBox rtb_linkmail2_backup;
        private System.Windows.Forms.RichTextBox rtb_DONE2;
        private System.Windows.Forms.RichTextBox rtb_FAIL1;
        private System.Windows.Forms.RichTextBox rtb_linkmail1_backup;
        private System.Windows.Forms.RichTextBox rtb_MAIL_DOCLINK_BACKUP;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.NumericUpDown delay_link_bm_backup;
        private System.Windows.Forms.ComboBox cmb_DUNG_DOC_LINK_BACKUP;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.NumericUpDown ndelayloop;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.ComboBox cmb_HOTMAIL_GMAIL;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.ComboBox cmb_ON_OFF_2FAIG;
        private System.Windows.Forms.ToolStripMenuItem tẮTBẬTSÁNGTẠOIGToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cHECKBMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sHAREBMIGToolStripMenuItem;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.RichTextBox rtb_Link_BM_IG;
        private System.Windows.Forms.ComboBox cmb_Admin_BM;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.RichTextBox rtb_hotmail;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.ComboBox cmb_MAIL_SHARE_BM_IG;
        private System.Windows.Forms.ToolStripMenuItem rEGBM12ToolStripMenuItem;
        private System.Windows.Forms.ComboBox cmb_TAT_BAT_SANG_TAO;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.ComboBox cmb_AN_CHROME;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.ToolStripMenuItem rEGBM2025ToolStripMenuItem;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.NumericUpDown delay_check_admin;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.RichTextBox rtb_Link_BM350_IG;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.ComboBox cmb_CHECK_ADMIN;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.RichTextBox rtb_BMIII;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.ComboBox cmb_DOC_LINK_MAX;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.DataGridView dgv_BM;
        private System.Windows.Forms.Button bt_filter;
        private System.Windows.Forms.RichTextBox rtb_IDBM_FILTER;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip4;
        private System.Windows.Forms.ToolStripMenuItem lOADALLBMVIAToolStripMenuItem;
        private System.Windows.Forms.NumericUpDown SL_BM_LOAD;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.NumericUpDown delay_LOAD_BM;
        private System.Windows.Forms.ToolStripMenuItem chọnToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem bôiĐenToolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem tấtCảToolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem bỏChọnToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem bôiĐenToolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem tấtCảToolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem xóaALLToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgv_AC;
        private System.Windows.Forms.DataGridViewTextBoxColumn cSttACBM;
        private System.Windows.Forms.DataGridViewTextBoxColumn cIDACBM;
        private System.Windows.Forms.DataGridViewTextBoxColumn cNAMEAC;
        private System.Windows.Forms.DataGridViewTextBoxColumn cStatusAC;
        private System.Windows.Forms.DataGridViewTextBoxColumn cLimit;
        private System.Windows.Forms.DataGridViewTextBoxColumn cTIENTE;
        private System.Windows.Forms.DataGridViewTextBoxColumn cNGAYTAOACBM;
        private System.Windows.Forms.DataGridViewCheckBoxColumn cSelectACBM;
        private System.Windows.Forms.ToolStripMenuItem lOADTKDONGToolStripMenuItem;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.NumericUpDown sl_LOAD_TK_D2;
        private System.Windows.Forms.ToolStripMenuItem bACKUPBMToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.NumericUpDown delay_doc_link;
        private System.Windows.Forms.NumericUpDown so_link_backup;
        private System.Windows.Forms.TextBox tb_hotmail_Share_bm;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.RichTextBox rtb_Link_BM;
        private System.Windows.Forms.ComboBox cmb_loai_mail;
        private System.Windows.Forms.ComboBox cmb_Admin_BM1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip5;
        private System.Windows.Forms.ToolStripMenuItem xÓAALLToolStripMenuItem1;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.ComboBox cmb_CACH_NHAN_LINK;
        private System.Windows.Forms.ComboBox cmbAPI_Auto_selenium_NhanBM;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.RichTextBox rtbLINK;
        private System.Windows.Forms.RichTextBox rtb_Link_FAIL;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_20;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_19;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_18;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_17;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_16;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_15;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_14;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_13;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_12;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_11;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_10;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_9;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_8;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_7;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_6;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_5;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_4;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_3;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_2;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_1;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.ToolStripMenuItem nHẬNBMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loginVIAToolStripMenuItem;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.ComboBox cmb_2FA_IG;
        private System.Windows.Forms.ToolStripMenuItem kILLChromeDriverToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lấyCookieVIAToolStripMenuItem;
        private System.Windows.Forms.ComboBox cmb_REG_BM_IG1;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.ComboBox cmb_TTKQC_BM_IG;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.NumericUpDown numericUpDown4;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.TabPage tabPage15;
        private System.Windows.Forms.TabPage tabPage16;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_19;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_20;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_20;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_19;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_15;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_16;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_16;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_15;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_11;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_12;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_12;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_11;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_7;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_8;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_8;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_7;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_3;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_4;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_4;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_3;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_17;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_18;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_18;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_17;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_13;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_14;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_14;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_13;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_9;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_10;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_10;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_9;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_5;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_6;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_6;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_5;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_1;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_2;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_2;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_1;
        private System.Windows.Forms.TabPage tabPage17;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_39;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_40;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_40;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_39;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_35;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_36;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_36;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_35;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_31;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_32;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_32;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_31;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_27;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_28;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_28;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_27;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_23;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_24;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_24;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_23;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_37;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_38;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_38;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_37;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_33;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_34;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_34;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_33;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_29;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_30;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_30;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_29;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_25;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_26;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_26;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_25;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_21;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_22;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_22;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_21;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.RichTextBox rtb_Link_BM50_IG_auto;
        private System.Windows.Forms.RichTextBox rtb_hotmail_BM350;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.RichTextBox rtb_mail_bm350_auto;
        private System.Windows.Forms.RichTextBox rtb_mail_bm50_auto;
        private System.Windows.Forms.RichTextBox rtb_BMIII_auto;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.RichTextBox rtb_Link_BM350_IG_auto;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.ToolStripMenuItem nHẬNBMAUTOToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.ComboBox cmbAPI_Auto_selenium_NhanBM_IG;
        private System.Windows.Forms.ComboBox cmb_STOP;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.TextBox tb_nhan19;
        private System.Windows.Forms.TextBox tb_19;
        private System.Windows.Forms.TextBox tb_nhan15;
        private System.Windows.Forms.TextBox tb_15;
        private System.Windows.Forms.TextBox tb_nhan11;
        private System.Windows.Forms.TextBox tb_11;
        private System.Windows.Forms.TextBox tb_nhan7;
        private System.Windows.Forms.TextBox tb_7;
        private System.Windows.Forms.TextBox tb_nhan3;
        private System.Windows.Forms.TextBox tb_3;
        private System.Windows.Forms.TextBox tb_nhan18;
        private System.Windows.Forms.TextBox tb_18;
        private System.Windows.Forms.TextBox tb_nhan14;
        private System.Windows.Forms.TextBox tb_14;
        private System.Windows.Forms.TextBox tb_nhan10;
        private System.Windows.Forms.TextBox tb_10;
        private System.Windows.Forms.TextBox tb_nhan6;
        private System.Windows.Forms.TextBox tb_6;
        private System.Windows.Forms.TextBox tb_nhan2;
        private System.Windows.Forms.TextBox tb_2;
        private System.Windows.Forms.TextBox tb_nhan17;
        private System.Windows.Forms.TextBox tb_17;
        private System.Windows.Forms.TextBox tb_nhan13;
        private System.Windows.Forms.TextBox tb_13;
        private System.Windows.Forms.TextBox tb_nhan9;
        private System.Windows.Forms.TextBox tb_9;
        private System.Windows.Forms.TextBox tb_nhan5;
        private System.Windows.Forms.TextBox tb_5;
        private System.Windows.Forms.TextBox tb_nhan1;
        private System.Windows.Forms.TextBox tb_1;
        private System.Windows.Forms.TextBox tb_nhan20;
        private System.Windows.Forms.TextBox tb_20;
        private System.Windows.Forms.TextBox tb_nhan16;
        private System.Windows.Forms.TextBox tb_16;
        private System.Windows.Forms.TextBox tb_nhan12;
        private System.Windows.Forms.TextBox tb_12;
        private System.Windows.Forms.TextBox tb_nhan8;
        private System.Windows.Forms.TextBox tb_8;
        private System.Windows.Forms.TextBox tb_nhan4;
        private System.Windows.Forms.TextBox tb_4;
        private System.Windows.Forms.TextBox tb_nhan40;
        private System.Windows.Forms.TextBox tb_40;
        private System.Windows.Forms.TextBox tb_nhan36;
        private System.Windows.Forms.TextBox tb_36;
        private System.Windows.Forms.TextBox tb_nhan32;
        private System.Windows.Forms.TextBox tb_32;
        private System.Windows.Forms.TextBox tb_nhan28;
        private System.Windows.Forms.TextBox tb_28;
        private System.Windows.Forms.TextBox tb_nhan24;
        private System.Windows.Forms.TextBox tb_24;
        private System.Windows.Forms.TextBox tb_nhan39;
        private System.Windows.Forms.TextBox tb_39;
        private System.Windows.Forms.TextBox tb_nhan35;
        private System.Windows.Forms.TextBox tb_35;
        private System.Windows.Forms.TextBox tb_nhan31;
        private System.Windows.Forms.TextBox tb_31;
        private System.Windows.Forms.TextBox tb_nhan27;
        private System.Windows.Forms.TextBox tb_27;
        private System.Windows.Forms.TextBox tb_nhan23;
        private System.Windows.Forms.TextBox tb_23;
        private System.Windows.Forms.TextBox tb_nhan38;
        private System.Windows.Forms.TextBox tb_38;
        private System.Windows.Forms.TextBox tb_nhan34;
        private System.Windows.Forms.TextBox tb_34;
        private System.Windows.Forms.TextBox tb_nhan30;
        private System.Windows.Forms.TextBox tb_30;
        private System.Windows.Forms.TextBox tb_nhan26;
        private System.Windows.Forms.TextBox tb_26;
        private System.Windows.Forms.TextBox tb_nhan22;
        private System.Windows.Forms.TextBox tb_22;
        private System.Windows.Forms.TextBox tb_nhan37;
        private System.Windows.Forms.TextBox tb_37;
        private System.Windows.Forms.TextBox tb_nhan33;
        private System.Windows.Forms.TextBox tb_33;
        private System.Windows.Forms.TextBox tb_nhan29;
        private System.Windows.Forms.TextBox tb_29;
        private System.Windows.Forms.TextBox tb_nhan25;
        private System.Windows.Forms.TextBox tb_25;
        private System.Windows.Forms.TextBox tb_nhan21;
        private System.Windows.Forms.TextBox tb_21;
        private System.Windows.Forms.ComboBox cmb_UP_WEB;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.TextBox tb_MK_NAM;
        private System.Windows.Forms.TextBox tb_TK_NAM;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.TextBox tb_ID_UP;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.ComboBox CMB_LOAI_BM_NHAN;
        private System.Windows.Forms.Label label142;
        private System.Windows.Forms.ComboBox cmb_LOAI_LINK;
        private System.Windows.Forms.ToolStripMenuItem bACKUPBMNHIEUVIAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lOGINGMAILCHROMEToolStripMenuItem;
        private System.Windows.Forms.TabPage tabPage18;
        private System.Windows.Forms.Label label144;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.RichTextBox rtb_282;
        private System.Windows.Forms.RichTextBox rtb_LIVE;
        private System.Windows.Forms.Label label145;
        private System.Windows.Forms.NumericUpDown delay_check_ig;
        private System.Windows.Forms.ToolStripMenuItem tESTWABMToolStripMenuItem;
        private System.Windows.Forms.Label lbnew;
        private System.Windows.Forms.Label labelnew;
        private System.Windows.Forms.Button btUpdate;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label146;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ComboBox cmb_FILE_OPEN;
        private System.Windows.Forms.Label label148;
        private System.Windows.Forms.Button bt_CLEAR_LINK;
        private System.Windows.Forms.Label label147;
        private System.Windows.Forms.Button bt_CLEAR_FAIL;
        private System.Windows.Forms.ComboBox cmb_Tao_5BM_IG;
        private System.Windows.Forms.Label label149;
        private System.Windows.Forms.Label label150;
        private System.Windows.Forms.NumericUpDown num_tao_5bm;
        private System.Windows.Forms.Label label151;
        private System.Windows.Forms.NumericUpDown numericUpDown5_delay_regbmig;
        private System.Windows.Forms.ComboBox cmb_chishare_bm350;
        private System.Windows.Forms.Label label152;
        private System.Windows.Forms.Label label153;
        private System.Windows.Forms.NumericUpDown numericUpDown5_slcheck_bm350;
        private System.Windows.Forms.ComboBox cmb_on_off_chrome;
        private System.Windows.Forms.Label label154;
        private System.Windows.Forms.Label label155;
        private System.Windows.Forms.ComboBox cmb_color350;
        private System.Windows.Forms.ComboBox cmb_BMT6;
        private System.Windows.Forms.Label label156;
        private System.Windows.Forms.ComboBox cmb_RIPIG;
        private System.Windows.Forms.Label label157;
        private System.Windows.Forms.Label label160;
        private System.Windows.Forms.Label label159;
        private System.Windows.Forms.Label label158;
        private System.Windows.Forms.NumericUpDown nam_rip;
        private System.Windows.Forms.NumericUpDown thang_rip;
        private System.Windows.Forms.NumericUpDown ngay_rip;
        private System.Windows.Forms.Label label161;
        private System.Windows.Forms.ComboBox cmb_sharebmt6_350;
        private System.Windows.Forms.ComboBox cmb_sharebmt6_50;
        private System.Windows.Forms.Label label162;
        private System.Windows.Forms.Label label163;
        private System.Windows.Forms.NumericUpDown delay_tatbatsangtao;
        private System.Windows.Forms.ToolStripMenuItem bACKUPBMTHEOIDToolStripMenuItem;
        private System.Windows.Forms.Label label164;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CAN_BACK_Up;
        private System.Windows.Forms.Label label165;
        private System.Windows.Forms.RichTextBox rtb_IDBM_Can_Tao_TK;
        private System.Windows.Forms.Label label166;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label167;
        private System.Windows.Forms.NumericUpDown n_slink_share_them;
        private System.Windows.Forms.Label label168;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.TabPage tabPage19;
        private System.Windows.Forms.TabControl tabControl5;
        private System.Windows.Forms.TabPage tabPage20;
        private System.Windows.Forms.TabPage tabPage21;
        private System.Windows.Forms.Label label170;
        private System.Windows.Forms.Label label169;
        private System.Windows.Forms.RichTextBox rtb_10_link_bm350;
        private System.Windows.Forms.RichTextBox rtb_10_link_bm50;
        private System.Windows.Forms.Label label171;
        private System.Windows.Forms.ComboBox cmb_loai_mail_nhan_bm_ig;
        private System.Windows.Forms.Button btn_update_mail;
        private System.Windows.Forms.Label label172;
        private System.Windows.Forms.RichTextBox rtb_ADMIN_BM_CHECK;
        private System.Windows.Forms.ToolStripMenuItem oUTBMTHEOIDToolStripMenuItem;
        private System.Windows.Forms.Label label173;
        private System.Windows.Forms.RichTextBox rtb_BM_OUT;
        private System.Windows.Forms.ToolStripMenuItem cHECKADMINBMTHEOIDToolStripMenuItem;
        private System.Windows.Forms.Button bt_doi_dinh_dang;
        private System.Windows.Forms.Label label174;
        private System.Windows.Forms.RichTextBox rtb_backup_fail;
        private System.Windows.Forms.Label label175;
        private System.Windows.Forms.ComboBox cmb_REG_BM_IG_API_CHROME;
        private System.Windows.Forms.ComboBox cmb_TTK_BM350;
        private System.Windows.Forms.ComboBox cmb_TTK_BM50;
        private System.Windows.Forms.Label label177;
        private System.Windows.Forms.Label label176;
        private System.Windows.Forms.Label label178;
        private System.Windows.Forms.NumericUpDown DELAY_DOC_MAIL;
        private System.Windows.Forms.Label label180;
        private System.Windows.Forms.Label label179;
        private System.Windows.Forms.RichTextBox rtb_mail_moakt_fail;
        private System.Windows.Forms.RichTextBox rtb_mail_moakt_done;
        private System.Windows.Forms.ComboBox cmb_doc_luon_link_mail_ao;
        private System.Windows.Forms.Label label181;
        private System.Windows.Forms.ToolStripMenuItem kICHWHATAPPToolStripMenuItem;
        private System.Windows.Forms.TabPage tabPage22;
        private System.Windows.Forms.Label label182;
        private System.Windows.Forms.TextBox tb_TokenEEAG;
        private System.Windows.Forms.Label label183;
        private System.Windows.Forms.RichTextBox rtb_IDBM_KICK_BM3;
        private System.Windows.Forms.Label label184;
        private System.Windows.Forms.RichTextBox rtb_status_kick;
        private System.Windows.Forms.NumericUpDown delay_kick_bm3;
        private System.Windows.Forms.Label label185;
        private System.Windows.Forms.TextBox tb_NAME_WHATAPP;
        private System.Windows.Forms.Label label186;
        private System.Windows.Forms.Label label187;
        private System.Windows.Forms.NumericUpDown numericUpDown5;
        private System.Windows.Forms.Button btdoidang;
        private System.Windows.Forms.ToolStripMenuItem cHECKINFORBMToolStripMenuItem;
        private System.Windows.Forms.Label label188;
        private System.Windows.Forms.NumericUpDown numericUpDown6;
        private System.Windows.Forms.TextBox tb_EEAG_LOAD_BM;
        private System.Windows.Forms.Label label189;
        private System.Windows.Forms.ComboBox cmb_chi_doc_link_mail_ao;
        private System.Windows.Forms.Label label190;
        private System.Windows.Forms.Label label191;
        private System.Windows.Forms.ComboBox cmb_TTKQCBM3;
        private System.Windows.Forms.Label label192;
        private System.Windows.Forms.Button bt_Tao_TK_BM;
        private System.Windows.Forms.Label label194;
        private System.Windows.Forms.NumericUpDown n_Delay_TTK;
        private System.Windows.Forms.Label label193;
        private System.Windows.Forms.NumericUpDown numericUpDown7;
        private System.Windows.Forms.TextBox tb_Token;
        private System.Windows.Forms.Label label195;
        private System.Windows.Forms.Label label196;
        private System.Windows.Forms.NumericUpDown numericUpDown9;
        private System.Windows.Forms.Label label197;
        private System.Windows.Forms.NumericUpDown m_delay_ttk;
        private System.Windows.Forms.Label label198;
        private System.Windows.Forms.ComboBox cmb_kick_BM3_IG;
        private System.Windows.Forms.Label label199;
        private System.Windows.Forms.ComboBox cmb_share_ban;
        private System.Windows.Forms.Label label200;
        private System.Windows.Forms.ComboBox cmb_bo_DIE;
        private System.Windows.Forms.ComboBox cmb_DIE_BM_CLEAR;
        private System.Windows.Forms.Label label201;
        private System.Windows.Forms.NumericUpDown number_nhan_fail;
        private System.Windows.Forms.Label label202;
        private System.Windows.Forms.Label label204;
        private System.Windows.Forms.Label label203;
        private System.Windows.Forms.RichTextBox rtb_BM1;
        private System.Windows.Forms.RichTextBox rtb_BM3;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.ComboBox cmb_Tao_1_5;
        private System.Windows.Forms.Label label205;
        private System.Windows.Forms.Label label206;
        private System.Windows.Forms.NumericUpDown sl_BM_kick3;
        private System.Windows.Forms.ToolStripMenuItem cHECKADMINIGToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uOTIGBMFBToolStripMenuItem;
        private System.Windows.Forms.Label label207;
        private System.Windows.Forms.ComboBox cmb_LOAD_API_CHROME;
        private System.Windows.Forms.DataGridViewTextBoxColumn cSTTBM;
        private System.Windows.Forms.DataGridViewTextBoxColumn cIDVIA;
        private System.Windows.Forms.DataGridViewTextBoxColumn cIDBM;
        private System.Windows.Forms.DataGridViewTextBoxColumn cNAMEBM;
        private System.Windows.Forms.DataGridViewTextBoxColumn cStatusBM;
        private System.Windows.Forms.DataGridViewTextBoxColumn cLOAIBM;
        private System.Windows.Forms.DataGridViewTextBoxColumn cinfor;
        private System.Windows.Forms.DataGridViewTextBoxColumn cNgayTao;
        private System.Windows.Forms.DataGridViewTextBoxColumn cADMIN;
        private System.Windows.Forms.DataGridViewTextBoxColumn cTKLIVEDIE;
        private System.Windows.Forms.DataGridViewCheckBoxColumn cSelectBM;
        private System.Windows.Forms.ComboBox cmb_API_CHROME_BACK_UP_BM_THEO_ID;
        private System.Windows.Forms.Label label208;
        private System.Windows.Forms.NumericUpDown delay_check_infor;
        private System.Windows.Forms.Label label209;
        private System.Windows.Forms.ComboBox cmb_Check_Infor_BM;
        private System.Windows.Forms.TextBox tb_IDBM_CHECK;
        private System.Windows.Forms.Label label210;
        private System.Windows.Forms.ComboBox cmb_bo_check1;
        private System.Windows.Forms.Label label211;
        private System.Windows.Forms.Label label212;
        private System.Windows.Forms.ComboBox cmb_ttk_5_1_WA;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ComboBox cmb_file_random;
        private System.Windows.Forms.ComboBox cmb_dinh_dang_ten;
        private System.Windows.Forms.Label label213;
        private System.Windows.Forms.TabControl tabControl6;
        private System.Windows.Forms.TabPage tabPage23;
        private System.Windows.Forms.TabPage tabPage24;
        private System.Windows.Forms.ComboBox cmb_Random4_17;
        private System.Windows.Forms.Label label214;
        private System.Windows.Forms.ComboBox cmb_NO_RANDOM;
        private System.Windows.Forms.Label label215;
        private System.Windows.Forms.Label label216;
        private System.Windows.Forms.RichTextBox rtb_codemail;
        private System.Windows.Forms.NumericUpDown num_STT_NHAN;
        private System.Windows.Forms.Label label217;
        private System.Windows.Forms.Button tb_LOAD_STT;
        private System.Windows.Forms.ComboBox cmb_VIA_NHAN_VERRY;
        private System.Windows.Forms.Label label218;
        private System.Windows.Forms.Label label220;
        private System.Windows.Forms.ComboBox cmb_new_create_WA;
        private System.Windows.Forms.Label label219;
        private System.Windows.Forms.ComboBox cmb_delete_WA;
        private System.Windows.Forms.ComboBox cmb_kologin_mail;
        private System.Windows.Forms.Label label221;
        private System.Windows.Forms.Button bt_file_VIA;
        private System.Windows.Forms.NumericUpDown delay_doc_hotmail_1;
        private System.Windows.Forms.Label label222;
        private System.Windows.Forms.NumericUpDown numericUpDown8;
        private System.Windows.Forms.Label label223;
        private System.Windows.Forms.TabPage tabPage25;
        private System.Windows.Forms.ComboBox cmn_doc_link_hotmail_vanha;
        private System.Windows.Forms.Label label224;
        private System.Windows.Forms.Label label225;
        private System.Windows.Forms.ComboBox cmb_ramdom_nuoc;
        private System.Windows.Forms.TabPage tabPage26;
        private System.Windows.Forms.Label label228;
        private System.Windows.Forms.ComboBox cmb_nameMACDINH;
        private System.Windows.Forms.ComboBox cmb_Domain_RANDOM;
        private System.Windows.Forms.Label label227;
        private System.Windows.Forms.Label label226;
        private System.Windows.Forms.ComboBox cmb_domain_moakt;
        private System.Windows.Forms.Label label229;
        private System.Windows.Forms.ComboBox cmb_ALL_FILE;
        private System.Windows.Forms.NumericUpDown numericUpDown10;
        private System.Windows.Forms.Label label230;
        private System.Windows.Forms.TabPage tabPage27;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.ComboBox cmb_DONG_VAN;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.ComboBox cmb_VN_US_INDIA;
        private System.Windows.Forms.Label label232;
        private System.Windows.Forms.Label label231;
        private System.Windows.Forms.ComboBox cmb_on2FAFB;
        private System.Windows.Forms.ComboBox cmb_noveri;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.ComboBox cmb_IP;
        private System.Windows.Forms.ComboBox cmb_radom_ncFB;
        private System.Windows.Forms.Label label233;
        private System.Windows.Forms.Label label235;
        private System.Windows.Forms.ComboBox cmb_REGBMVIA;
        private System.Windows.Forms.Label label234;
        private System.Windows.Forms.ComboBox cmb_share_D2VIA;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label236;
        private System.Windows.Forms.NumericUpDown delay_regbm_cl;
        private System.Windows.Forms.Label label237;
        private System.Windows.Forms.NumericUpDown number_REGBMCL;
        private System.Windows.Forms.Label label239;
        private System.Windows.Forms.RichTextBox rtb_BM350_CL;
        private System.Windows.Forms.Label label238;
        private System.Windows.Forms.RichTextBox rtb_BM50_CL;
        private System.Windows.Forms.ComboBox cmb_MUI_GIO_BMCL;
        private System.Windows.Forms.Label label240;
        private System.Windows.Forms.ComboBox cmb_TEN_TKBM_CL;
        private System.Windows.Forms.Label label241;
        private System.Windows.Forms.ComboBox cmb_TIENTE_BM_CL;
        private System.Windows.Forms.Label label242;
        private System.Windows.Forms.ComboBox cmb_TAOTK_CL;
        private System.Windows.Forms.Label label243;
        private System.Windows.Forms.Label label245;
        private System.Windows.Forms.RichTextBox rtb_AC_CLOSE;
        private System.Windows.Forms.Label label244;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE;
        private System.Windows.Forms.ToolStripMenuItem sHARED22025ToolStripMenuItem;
        private System.Windows.Forms.NumericUpDown numericUpDown11;
        private System.Windows.Forms.Label label246;
        private System.Windows.Forms.NumericUpDown numericUpDown12;
        private System.Windows.Forms.Label label249;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSECL;
        private System.Windows.Forms.Label label248;
        private System.Windows.Forms.RichTextBox rtb_IDBM_LIVE;
        private System.Windows.Forms.NumericUpDown numericUpDown13;
        private System.Windows.Forms.Label label247;
        private System.Windows.Forms.Label label251;
        private System.Windows.Forms.RichTextBox rtb_AC_DIE;
        private System.Windows.Forms.ToolStripMenuItem vIADToolStripMenuItem;
        private System.Windows.Forms.NumericUpDown numericUpDown14;
        private System.Windows.Forms.Label label252;
        private System.Windows.Forms.Label label250;
        private System.Windows.Forms.ComboBox cmb_chi_Share_LIVE;
        private System.Windows.Forms.Label label253;
        private System.Windows.Forms.ComboBox cmb_Logingmail_trc;
        private System.Windows.Forms.Label label254;
        private System.Windows.Forms.ComboBox cmb_NO_CLOSE_TK_D2;
        private System.Windows.Forms.Label label255;
        private System.Windows.Forms.TabControl tabControl7;
        private System.Windows.Forms.TabPage tabPage28;
        private System.Windows.Forms.TabPage tabPage29;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.RichTextBox rtb_IDBM_LIVE3;
        private System.Windows.Forms.Label label264;
        private System.Windows.Forms.Label label265;
        private System.Windows.Forms.Label label266;
        private System.Windows.Forms.Label label267;
        private System.Windows.Forms.RichTextBox rtb_AC_CLOSE3;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSECL3;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE3;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.RichTextBox rtb_IDBM_LIVE4;
        private System.Windows.Forms.Label label268;
        private System.Windows.Forms.Label label270;
        private System.Windows.Forms.Label label271;
        private System.Windows.Forms.RichTextBox rtb_AC_CLOSE4;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSECL4;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE4;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.RichTextBox rtb_IDBM_LIVE2;
        private System.Windows.Forms.Label label260;
        private System.Windows.Forms.Label label261;
        private System.Windows.Forms.Label label262;
        private System.Windows.Forms.Label label263;
        private System.Windows.Forms.RichTextBox rtb_AC_CLOSE2;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSECL2;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE2;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.RichTextBox rtb_IDBM_LIVE1;
        private System.Windows.Forms.Label label258;
        private System.Windows.Forms.Label label257;
        private System.Windows.Forms.Label label259;
        private System.Windows.Forms.Label label256;
        private System.Windows.Forms.RichTextBox rtb_AC_CLOSE1;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSECL1;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE1;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.RichTextBox rtb_IDBM_LIVE6;
        private System.Windows.Forms.Label label272;
        private System.Windows.Forms.Label label273;
        private System.Windows.Forms.Label label274;
        private System.Windows.Forms.Label label275;
        private System.Windows.Forms.RichTextBox rtb_AC_CLOSE6;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSECL6;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE6;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.RichTextBox rtb_IDBM_LIVE5;
        private System.Windows.Forms.Label label276;
        private System.Windows.Forms.Label label277;
        private System.Windows.Forms.Label label278;
        private System.Windows.Forms.Label label279;
        private System.Windows.Forms.RichTextBox rtb_AC_CLOSE5;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSECL5;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE5;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.RichTextBox rtb_IDBM_LIVE8;
        private System.Windows.Forms.Label label280;
        private System.Windows.Forms.Label label281;
        private System.Windows.Forms.Label label282;
        private System.Windows.Forms.Label label283;
        private System.Windows.Forms.RichTextBox rtb_AC_CLOSE8;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSECL8;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE8;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.RichTextBox rtb_IDBM_LIVE7;
        private System.Windows.Forms.Label label284;
        private System.Windows.Forms.Label label285;
        private System.Windows.Forms.Label label286;
        private System.Windows.Forms.Label label287;
        private System.Windows.Forms.RichTextBox rtb_AC_CLOSE7;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSECL7;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.ComboBox cmb_Doi_Ten_BM;
        private System.Windows.Forms.Label label288;
        private System.Windows.Forms.NumericUpDown numericUpDown15;
        private System.Windows.Forms.Label label289;
        private System.Windows.Forms.NumericUpDown numericUpDown20;
        private System.Windows.Forms.Label label294;
        private System.Windows.Forms.NumericUpDown numericUpDown17;
        private System.Windows.Forms.Label label291;
        private System.Windows.Forms.NumericUpDown numericUpDown18;
        private System.Windows.Forms.Label label292;
        private System.Windows.Forms.NumericUpDown numericUpDown16;
        private System.Windows.Forms.Label label290;
        private System.Windows.Forms.NumericUpDown numericUpDown19;
        private System.Windows.Forms.Label label293;
        private System.Windows.Forms.NumericUpDown numericUpDown21;
        private System.Windows.Forms.Label label295;
        private System.Windows.Forms.NumericUpDown numericUpDown22;
        private System.Windows.Forms.Label label296;
        private System.Windows.Forms.NumericUpDown numericUpDown23;
        private System.Windows.Forms.Label label297;
        private System.Windows.Forms.NumericUpDown numericUpDown24;
        private System.Windows.Forms.Label label298;
        private System.Windows.Forms.Label label269;
        private System.Windows.Forms.TabPage tabPage30;
        private System.Windows.Forms.RichTextBox rtb_ID_AC_SELECT_FAIL;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label300;
        private System.Windows.Forms.RichTextBox rtb_ID_AC_DONE;
        private System.Windows.Forms.Label label299;
        private System.Windows.Forms.RichTextBox rtb_ID_AC_FAIL;
        private System.Windows.Forms.Label label301;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.RichTextBox rtb_IDBMLIVE_VIA1;
        private System.Windows.Forms.Label label303;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE3_VIA1;
        private System.Windows.Forms.Label label307;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE2_VIA1;
        private System.Windows.Forms.Label label302;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE1_VIA1;
        private System.Windows.Forms.Label label304;
        private System.Windows.Forms.RichTextBox rtb_IDBMLIVE3_VIA1;
        private System.Windows.Forms.RichTextBox rtb_IDBMLIVE2_VIA1;
        private System.Windows.Forms.Label label305;
        private System.Windows.Forms.Label label306;
        private System.Windows.Forms.ComboBox cmb_stt_chuyen_123;
        private System.Windows.Forms.Label label309;
        private System.Windows.Forms.ComboBox cmb_VIA1;
        private System.Windows.Forms.Label label308;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE6_VIA1;
        private System.Windows.Forms.Label label310;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE5_VIA1;
        private System.Windows.Forms.Label label311;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE4_VIA1;
        private System.Windows.Forms.Label label312;
        private System.Windows.Forms.RichTextBox rtb_IDBMLIVE6_VIA1;
        private System.Windows.Forms.RichTextBox rtb_IDBMLIVE5_VIA1;
        private System.Windows.Forms.Label label313;
        private System.Windows.Forms.Label label314;
        private System.Windows.Forms.RichTextBox rtb_IDBMLIVE4_VIA1;
        private System.Windows.Forms.Label label315;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.TabControl tabControl8;
        private System.Windows.Forms.TabPage tabPage31;
        private System.Windows.Forms.TabPage tabPage32;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.Label label316;
        private System.Windows.Forms.NumericUpDown numericUpDown25;
        private System.Windows.Forms.NumericUpDown numericUpDown26;
        private System.Windows.Forms.Label label317;
        private System.Windows.Forms.Label label318;
        private System.Windows.Forms.NumericUpDown numericUpDown27;
        private System.Windows.Forms.NumericUpDown numericUpDown28;
        private System.Windows.Forms.Label label319;
        private System.Windows.Forms.Label label320;
        private System.Windows.Forms.NumericUpDown numericUpDown29;
        private System.Windows.Forms.NumericUpDown numericUpDown30;
        private System.Windows.Forms.Label label321;
        private System.Windows.Forms.Label label322;
        private System.Windows.Forms.NumericUpDown numericUpDown31;
        private System.Windows.Forms.NumericUpDown numericUpDown32;
        private System.Windows.Forms.Label label323;
        private System.Windows.Forms.Label label324;
        private System.Windows.Forms.NumericUpDown numericUpDown33;
        private System.Windows.Forms.NumericUpDown numericUpDown34;
        private System.Windows.Forms.Label label325;
        private System.Windows.Forms.TabControl tabControl9;
        private System.Windows.Forms.TabPage tabPage33;
        private System.Windows.Forms.TabPage tabPage34;
        private System.Windows.Forms.GroupBox groupBox26;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE12_VIA1;
        private System.Windows.Forms.Label label326;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE11_VIA1;
        private System.Windows.Forms.Label label327;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE10_VIA1;
        private System.Windows.Forms.Label label328;
        private System.Windows.Forms.RichTextBox rtb_IDBMLIVE12_VIA1;
        private System.Windows.Forms.RichTextBox rtb_IDBMLIVE11_VIA1;
        private System.Windows.Forms.Label label329;
        private System.Windows.Forms.Label label330;
        private System.Windows.Forms.RichTextBox rtb_IDBMLIVE10_VIA1;
        private System.Windows.Forms.Label label331;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE9_VIA1;
        private System.Windows.Forms.Label label332;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE8_VIA1;
        private System.Windows.Forms.Label label333;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE7_VIA1;
        private System.Windows.Forms.Label label334;
        private System.Windows.Forms.RichTextBox rtb_IDBMLIVE9_VIA1;
        private System.Windows.Forms.RichTextBox rtb_IDBMLIVE8_VIA1;
        private System.Windows.Forms.Label label335;
        private System.Windows.Forms.Label label336;
        private System.Windows.Forms.RichTextBox rtb_IDBMLIVE7_VIA1;
        private System.Windows.Forms.Label label337;
        private System.Windows.Forms.ToolStripMenuItem lOADACBMD2ToolStripMenuItem;
        private System.Windows.Forms.NumericUpDown number_delay_nhand2;
        private System.Windows.Forms.Label label338;
        private System.Windows.Forms.TabPage tabPage35;
        private System.Windows.Forms.GroupBox groupBox27;
        private System.Windows.Forms.RichTextBox rtb_IDBM_LIVE16;
        private System.Windows.Forms.Label label339;
        private System.Windows.Forms.Label label340;
        private System.Windows.Forms.Label label341;
        private System.Windows.Forms.Label label342;
        private System.Windows.Forms.RichTextBox rtb_AC_CLOSE16;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSECL16;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE16;
        private System.Windows.Forms.GroupBox groupBox28;
        private System.Windows.Forms.RichTextBox rtb_IDBM_LIVE14;
        private System.Windows.Forms.Label label343;
        private System.Windows.Forms.Label label344;
        private System.Windows.Forms.Label label345;
        private System.Windows.Forms.Label label346;
        private System.Windows.Forms.RichTextBox rtb_AC_CLOSE14;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSECL14;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE14;
        private System.Windows.Forms.GroupBox groupBox29;
        private System.Windows.Forms.RichTextBox rtb_IDBM_LIVE15;
        private System.Windows.Forms.Label label347;
        private System.Windows.Forms.Label label348;
        private System.Windows.Forms.Label label349;
        private System.Windows.Forms.Label label350;
        private System.Windows.Forms.RichTextBox rtb_AC_CLOSE15;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSECL15;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE15;
        private System.Windows.Forms.GroupBox groupBox30;
        private System.Windows.Forms.RichTextBox rtb_IDBM_LIVE11;
        private System.Windows.Forms.Label label351;
        private System.Windows.Forms.Label label352;
        private System.Windows.Forms.Label label353;
        private System.Windows.Forms.Label label354;
        private System.Windows.Forms.RichTextBox rtb_AC_CLOSE11;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSECL11;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE11;
        private System.Windows.Forms.GroupBox groupBox31;
        private System.Windows.Forms.RichTextBox rtb_IDBM_LIVE13;
        private System.Windows.Forms.Label label355;
        private System.Windows.Forms.Label label356;
        private System.Windows.Forms.Label label357;
        private System.Windows.Forms.Label label358;
        private System.Windows.Forms.RichTextBox rtb_AC_CLOSE13;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSECL13;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE13;
        private System.Windows.Forms.GroupBox groupBox32;
        private System.Windows.Forms.RichTextBox rtb_IDBM_LIVE12;
        private System.Windows.Forms.Label label359;
        private System.Windows.Forms.Label label360;
        private System.Windows.Forms.Label label361;
        private System.Windows.Forms.Label label362;
        private System.Windows.Forms.RichTextBox rtb_AC_CLOSE12;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSECL12;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE12;
        private System.Windows.Forms.GroupBox groupBox33;
        private System.Windows.Forms.RichTextBox rtb_IDBM_LIVE10;
        private System.Windows.Forms.Label label363;
        private System.Windows.Forms.Label label364;
        private System.Windows.Forms.Label label365;
        private System.Windows.Forms.Label label366;
        private System.Windows.Forms.RichTextBox rtb_AC_CLOSE10;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSECL10;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE10;
        private System.Windows.Forms.GroupBox groupBox34;
        private System.Windows.Forms.RichTextBox rtb_IDBM_LIVE9;
        private System.Windows.Forms.Label label367;
        private System.Windows.Forms.Label label368;
        private System.Windows.Forms.Label label369;
        private System.Windows.Forms.Label label370;
        private System.Windows.Forms.RichTextBox rtb_AC_CLOSE9;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSECL9;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE9;
        private System.Windows.Forms.GroupBox groupBox35;
        private System.Windows.Forms.RichTextBox rtb_IDBM_LIVE18;
        private System.Windows.Forms.Label label371;
        private System.Windows.Forms.Label label372;
        private System.Windows.Forms.Label label373;
        private System.Windows.Forms.Label label374;
        private System.Windows.Forms.RichTextBox rtb_AC_CLOSE18;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSECL18;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE18;
        private System.Windows.Forms.GroupBox groupBox36;
        private System.Windows.Forms.RichTextBox rtb_IDBM_LIVE17;
        private System.Windows.Forms.Label label375;
        private System.Windows.Forms.Label label376;
        private System.Windows.Forms.Label label377;
        private System.Windows.Forms.Label label378;
        private System.Windows.Forms.RichTextBox rtb_AC_CLOSE17;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSECL17;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE17;
        private System.Windows.Forms.TabPage tabPage36;
        private System.Windows.Forms.GroupBox groupBox37;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE18_VIA1;
        private System.Windows.Forms.Label label379;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE17_VIA1;
        private System.Windows.Forms.Label label380;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE16_VIA1;
        private System.Windows.Forms.Label label381;
        private System.Windows.Forms.RichTextBox rtb_IDBMLIVE18_VIA1;
        private System.Windows.Forms.RichTextBox rtb_IDBMLIVE17_VIA1;
        private System.Windows.Forms.Label label382;
        private System.Windows.Forms.Label label383;
        private System.Windows.Forms.RichTextBox rtb_IDBMLIVE16_VIA1;
        private System.Windows.Forms.Label label384;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE15_VIA1;
        private System.Windows.Forms.Label label385;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE14_VIA1;
        private System.Windows.Forms.Label label386;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE13_VIA1;
        private System.Windows.Forms.Label label387;
        private System.Windows.Forms.RichTextBox rtb_IDBMLIVE15_VIA1;
        private System.Windows.Forms.RichTextBox rtb_IDBMLIVE14_VIA1;
        private System.Windows.Forms.Label label388;
        private System.Windows.Forms.Label label389;
        private System.Windows.Forms.RichTextBox rtb_IDBMLIVE13_VIA1;
        private System.Windows.Forms.Label label390;
        private System.Windows.Forms.TabPage tabPage37;
        private System.Windows.Forms.GroupBox groupBox38;
        private System.Windows.Forms.Label label399;
        private System.Windows.Forms.Label label402;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE24_VIA1;
        private System.Windows.Forms.Label label391;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE23_VIA1;
        private System.Windows.Forms.Label label392;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE22_VIA1;
        private System.Windows.Forms.Label label393;
        private System.Windows.Forms.RichTextBox rtb_IDBMLIVE24_VIA1;
        private System.Windows.Forms.RichTextBox rtb_IDBMLIVE23_VIA1;
        private System.Windows.Forms.Label label394;
        private System.Windows.Forms.Label label395;
        private System.Windows.Forms.RichTextBox rtb_IDBMLIVE22_VIA1;
        private System.Windows.Forms.Label label396;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE21_VIA1;
        private System.Windows.Forms.Label label397;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE20_VIA1;
        private System.Windows.Forms.Label label398;
        private System.Windows.Forms.RichTextBox rtb_ACLIVE19_VIA1;
        private System.Windows.Forms.RichTextBox rtb_IDBMLIVE21_VIA1;
        private System.Windows.Forms.RichTextBox rtb_IDBMLIVE20_VIA1;
        private System.Windows.Forms.Label label400;
        private System.Windows.Forms.Label label401;
        private System.Windows.Forms.RichTextBox rtb_IDBMLIVE19_VIA1;
    }
}

