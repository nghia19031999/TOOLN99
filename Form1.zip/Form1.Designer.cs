﻿namespace BMD2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.btn_RUN = new System.Windows.Forms.Button();
            this.dgv1 = new System.Windows.Forms.DataGridView();
            this.cStt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cUID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cPass = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c2FAvsCookie = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cMail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cPassMail = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cMailKP = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cCheckBM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cSelect = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.chọnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bôiĐenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bỏChọnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bôiĐenToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.xóaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dòngĐãChọnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.aDDMAILKPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nHẬNBMNEWToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tẮTBẬTSÁNGTẠOIGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cHECKBMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sHAREBMIGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rEGBM12ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rEGBM2025ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lOADALLBMVIAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nHẬNBMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loginVIAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kILLChromeDriverToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lấyCookieVIAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nHẬNBMAUTOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lOGINGMAILCHROMEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tESTWABMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bACKUPBMTHEOIDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oUTBMTHEOIDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cHECKADMINBMTHEOIDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kICHWHATAPPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cHECKINFORBMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cHECKADMINIGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uOTIGBMFBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.label56 = new System.Windows.Forms.Label();
            this.tb_so_luong_BM = new System.Windows.Forms.TextBox();
            this.rtb_BMDIE = new System.Windows.Forms.RichTextBox();
            this.rtb_BM_Nhan_Du = new System.Windows.Forms.RichTextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.rtbdone = new System.Windows.Forms.RichTextBox();
            this.rtbAC_FAIL = new System.Windows.Forms.RichTextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.rtb_BM_CLOSE_4_THAY_THE = new System.Windows.Forms.RichTextBox();
            this.rtb_BM_CLOSE_3_THAY_THE = new System.Windows.Forms.RichTextBox();
            this.rtb_BM_CLOSE_2_THAY_THE = new System.Windows.Forms.RichTextBox();
            this.rtb_BM_CLOSE_THAY_THE = new System.Windows.Forms.RichTextBox();
            this.rtb_BM_BACKUP3_THAY_THE = new System.Windows.Forms.RichTextBox();
            this.rtb_BM_BACKUP2_THAY_THE = new System.Windows.Forms.RichTextBox();
            this.rtb_BM_BACKUP_THAY_THE = new System.Windows.Forms.RichTextBox();
            this.rtb_BM_THAY_THE = new System.Windows.Forms.RichTextBox();
            this.cmb_ADD_Tra_Truoc = new System.Windows.Forms.ComboBox();
            this.label34 = new System.Windows.Forms.Label();
            this.gioi_han_close = new System.Windows.Forms.NumericUpDown();
            this.label32 = new System.Windows.Forms.Label();
            this.gioi_han_live = new System.Windows.Forms.NumericUpDown();
            this.label31 = new System.Windows.Forms.Label();
            this.gioi_han_1 = new System.Windows.Forms.NumericUpDown();
            this.label30 = new System.Windows.Forms.Label();
            this.delayshare = new System.Windows.Forms.NumericUpDown();
            this.label29 = new System.Windows.Forms.Label();
            this.rtb_BM_PARTNER_THAY_THE = new System.Windows.Forms.RichTextBox();
            this.sl_Nhan_BM_CLOSE1_2 = new System.Windows.Forms.NumericUpDown();
            this.sl_Nhan_BM_PARTNER = new System.Windows.Forms.NumericUpDown();
            this.sl_nhan_Bm_BM_BACKUP = new System.Windows.Forms.NumericUpDown();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.tx_So_Luong_Share_vao_bm = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.tb_so_luong_BM_PARTNER = new System.Windows.Forms.TextBox();
            this.tb_BM_Close_4 = new System.Windows.Forms.TextBox();
            this.tb_BM_Close_3 = new System.Windows.Forms.TextBox();
            this.tb_BM_Close_2 = new System.Windows.Forms.TextBox();
            this.tb_BM_Close1 = new System.Windows.Forms.TextBox();
            this.tb_BM_BACK_UP3 = new System.Windows.Forms.TextBox();
            this.tb_BM_BACK_UP2 = new System.Windows.Forms.TextBox();
            this.tb_BM_BACK_UP = new System.Windows.Forms.TextBox();
            this.tb_BM = new System.Windows.Forms.TextBox();
            this.rtb_IDBM_PARTNER = new System.Windows.Forms.RichTextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.rtb_IDBM_CLOSE_4 = new System.Windows.Forms.RichTextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.rtb_IDBM_CLOSE_3 = new System.Windows.Forms.RichTextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.rtb_IDBM_CLOSE_2 = new System.Windows.Forms.RichTextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.rtb_IDBM_CLOSE = new System.Windows.Forms.RichTextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.rtb_ID_BM_Share_BACK_UP3 = new System.Windows.Forms.RichTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.rtb_ID_BM_Share_BACK_UP2 = new System.Windows.Forms.RichTextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.rtb_ID_BM_Share_BACK_UP = new System.Windows.Forms.RichTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.rtb_ID_BM_Share = new System.Windows.Forms.RichTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tb_sl_282 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cmb_CLOSE_SHARE = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cmb_User_Agent = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.label55 = new System.Windows.Forms.Label();
            this.rtb_MAIL_SHARE_CLONE = new System.Windows.Forms.RichTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmb_Share_DOI_TAC = new System.Windows.Forms.ComboBox();
            this.label57 = new System.Windows.Forms.Label();
            this.cmb_Share_BM_CLone = new System.Windows.Forms.ComboBox();
            this.label54 = new System.Windows.Forms.Label();
            this.cmb_Mui_Gio_TK_BM = new System.Windows.Forms.ComboBox();
            this.label53 = new System.Windows.Forms.Label();
            this.cmb_TEN_TK_BM = new System.Windows.Forms.ComboBox();
            this.label52 = new System.Windows.Forms.Label();
            this.cmb_Tien_Te_TK_BM = new System.Windows.Forms.ComboBox();
            this.label51 = new System.Windows.Forms.Label();
            this.delay_reg_bm = new System.Windows.Forms.NumericUpDown();
            this.for_reg_bm = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cmb_Tao_TK_BM = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cmb_REG_BM_Clone_API = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label44 = new System.Windows.Forms.Label();
            this.cmb_noveri = new System.Windows.Forms.ComboBox();
            this.label41 = new System.Windows.Forms.Label();
            this.cmb_DONG_VAN = new System.Windows.Forms.ComboBox();
            this.cmb_ID_MAIL = new System.Windows.Forms.ComboBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.soluong_mua_Mail = new System.Windows.Forms.NumericUpDown();
            this.label38 = new System.Windows.Forms.Label();
            this.tb_so_du_DongVan = new System.Windows.Forms.TextBox();
            this.Tx_Key_API_DongVan = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.tx_MK_Dong_Vanox2 = new System.Windows.Forms.TextBox();
            this.tx_TK_Dong_Van = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.dgv2_IG = new System.Windows.Forms.DataGridView();
            this.cStt2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cIG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cStatus2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cSelect2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.contextMenuStrip3 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.chọnToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.bôiĐenToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.bỏChọnToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.bôiĐenToolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảToolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.xóaToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.bôiĐenToolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảToolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.dgv_mail = new System.Windows.Forms.DataGridView();
            this.cStt1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cMail1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cPassMail1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cToken = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cStatus1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cSelect1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.chọnToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.bôiĐenToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.bỏChọnToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.bôiĐenToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảToolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.xóaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.dòngĐãChọnToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảToolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabControl6 = new System.Windows.Forms.TabControl();
            this.tabPage23 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label175 = new System.Windows.Forms.Label();
            this.cmb_REG_BM_IG_API_CHROME = new System.Windows.Forms.ComboBox();
            this.tb_ID_UP = new System.Windows.Forms.TextBox();
            this.label140 = new System.Windows.Forms.Label();
            this.label139 = new System.Windows.Forms.Label();
            this.label138 = new System.Windows.Forms.Label();
            this.tb_MK_NAM = new System.Windows.Forms.TextBox();
            this.tb_TK_NAM = new System.Windows.Forms.TextBox();
            this.cmb_UP_WEB = new System.Windows.Forms.ComboBox();
            this.label137 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.cmb_IP = new System.Windows.Forms.ComboBox();
            this.label48 = new System.Windows.Forms.Label();
            this.cmb_REGHOTMAIL = new System.Windows.Forms.ComboBox();
            this.cmb_VN_US = new System.Windows.Forms.ComboBox();
            this.tabPage24 = new System.Windows.Forms.TabPage();
            this.cmb_NO_RANDOM = new System.Windows.Forms.ComboBox();
            this.label215 = new System.Windows.Forms.Label();
            this.cmb_Random4_17 = new System.Windows.Forms.ComboBox();
            this.label214 = new System.Windows.Forms.Label();
            this.cmb_dinh_dang_ten = new System.Windows.Forms.ComboBox();
            this.label213 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label200 = new System.Windows.Forms.Label();
            this.cmb_bo_DIE = new System.Windows.Forms.ComboBox();
            this.cmb_TTK_BM350 = new System.Windows.Forms.ComboBox();
            this.cmb_TTK_BM50 = new System.Windows.Forms.ComboBox();
            this.label177 = new System.Windows.Forms.Label();
            this.label176 = new System.Windows.Forms.Label();
            this.label151 = new System.Windows.Forms.Label();
            this.numericUpDown5_delay_regbmig = new System.Windows.Forms.NumericUpDown();
            this.label150 = new System.Windows.Forms.Label();
            this.num_tao_5bm = new System.Windows.Forms.NumericUpDown();
            this.cmb_Tao_5BM_IG = new System.Windows.Forms.ComboBox();
            this.label149 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.cmb_TTKQC_BM_IG = new System.Windows.Forms.ComboBox();
            this.label110 = new System.Windows.Forms.Label();
            this.cmb_REG_BM_IG1 = new System.Windows.Forms.ComboBox();
            this.label109 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.cmb_2FA_IG = new System.Windows.Forms.ComboBox();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.cmb_ON_OFF_2FAIG = new System.Windows.Forms.ComboBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.delay_doc_hotmail_1 = new System.Windows.Forms.NumericUpDown();
            this.label222 = new System.Windows.Forms.Label();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.cmb_Tao_1_5 = new System.Windows.Forms.ComboBox();
            this.label205 = new System.Windows.Forms.Label();
            this.cmb_kick_BM3_IG = new System.Windows.Forms.ComboBox();
            this.label198 = new System.Windows.Forms.Label();
            this.cmb_doc_luon_link_mail_ao = new System.Windows.Forms.ComboBox();
            this.label181 = new System.Windows.Forms.Label();
            this.btn_update_mail = new System.Windows.Forms.Button();
            this.label168 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.label167 = new System.Windows.Forms.Label();
            this.n_slink_share_them = new System.Windows.Forms.NumericUpDown();
            this.label163 = new System.Windows.Forms.Label();
            this.delay_tatbatsangtao = new System.Windows.Forms.NumericUpDown();
            this.cmb_sharebmt6_50 = new System.Windows.Forms.ComboBox();
            this.label162 = new System.Windows.Forms.Label();
            this.label161 = new System.Windows.Forms.Label();
            this.cmb_sharebmt6_350 = new System.Windows.Forms.ComboBox();
            this.label160 = new System.Windows.Forms.Label();
            this.label159 = new System.Windows.Forms.Label();
            this.label158 = new System.Windows.Forms.Label();
            this.nam_rip = new System.Windows.Forms.NumericUpDown();
            this.thang_rip = new System.Windows.Forms.NumericUpDown();
            this.ngay_rip = new System.Windows.Forms.NumericUpDown();
            this.cmb_RIPIG = new System.Windows.Forms.ComboBox();
            this.label157 = new System.Windows.Forms.Label();
            this.cmb_BMT6 = new System.Windows.Forms.ComboBox();
            this.label156 = new System.Windows.Forms.Label();
            this.cmb_color350 = new System.Windows.Forms.ComboBox();
            this.label155 = new System.Windows.Forms.Label();
            this.cmb_on_off_chrome = new System.Windows.Forms.ComboBox();
            this.label154 = new System.Windows.Forms.Label();
            this.label153 = new System.Windows.Forms.Label();
            this.numericUpDown5_slcheck_bm350 = new System.Windows.Forms.NumericUpDown();
            this.cmb_chishare_bm350 = new System.Windows.Forms.ComboBox();
            this.label152 = new System.Windows.Forms.Label();
            this.cmb_LOAI_LINK = new System.Windows.Forms.ComboBox();
            this.label142 = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.rtb_hotmail_BM350 = new System.Windows.Forms.RichTextBox();
            this.label88 = new System.Windows.Forms.Label();
            this.cmb_DOC_LINK_MAX = new System.Windows.Forms.ComboBox();
            this.label87 = new System.Windows.Forms.Label();
            this.rtb_BMIII = new System.Windows.Forms.RichTextBox();
            this.label86 = new System.Windows.Forms.Label();
            this.cmb_CHECK_ADMIN = new System.Windows.Forms.ComboBox();
            this.label85 = new System.Windows.Forms.Label();
            this.delay_check_admin = new System.Windows.Forms.NumericUpDown();
            this.label84 = new System.Windows.Forms.Label();
            this.rtb_Link_BM350_IG = new System.Windows.Forms.RichTextBox();
            this.cmb_TAT_BAT_SANG_TAO = new System.Windows.Forms.ComboBox();
            this.label83 = new System.Windows.Forms.Label();
            this.cmb_AN_CHROME = new System.Windows.Forms.ComboBox();
            this.label82 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.cmb_MAIL_SHARE_BM_IG = new System.Windows.Forms.ComboBox();
            this.label80 = new System.Windows.Forms.Label();
            this.rtb_hotmail = new System.Windows.Forms.RichTextBox();
            this.cmb_Admin_BM = new System.Windows.Forms.ComboBox();
            this.label79 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.rtb_Link_BM_IG = new System.Windows.Forms.RichTextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.cmb_LOGIN_IG = new System.Windows.Forms.ComboBox();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.ndelayloop = new System.Windows.Forms.NumericUpDown();
            this.label74 = new System.Windows.Forms.Label();
            this.cmb_DUNG_DOC_LINK_BACKUP = new System.Windows.Forms.ComboBox();
            this.label73 = new System.Windows.Forms.Label();
            this.delay_link_bm_backup = new System.Windows.Forms.NumericUpDown();
            this.label72 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.rtb_MAIL_DOCLINK_BACKUP = new System.Windows.Forms.RichTextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.rtb_FAIL3 = new System.Windows.Forms.RichTextBox();
            this.rtb_linkmail3_backup = new System.Windows.Forms.RichTextBox();
            this.rtb_DONE3 = new System.Windows.Forms.RichTextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.rtb_FAIL2 = new System.Windows.Forms.RichTextBox();
            this.rtb_linkmail2_backup = new System.Windows.Forms.RichTextBox();
            this.rtb_DONE2 = new System.Windows.Forms.RichTextBox();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.rtb_FAIL1 = new System.Windows.Forms.RichTextBox();
            this.rtb_linkmail1_backup = new System.Windows.Forms.RichTextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.rtb_DONE1 = new System.Windows.Forms.RichTextBox();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.label75 = new System.Windows.Forms.Label();
            this.cmb_HOTMAIL_GMAIL = new System.Windows.Forms.ComboBox();
            this.cmbonoffchrome = new System.Windows.Forms.ComboBox();
            this.cmb_lay_Cookie = new System.Windows.Forms.ComboBox();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.tb_IDBM_CHECK = new System.Windows.Forms.TextBox();
            this.label210 = new System.Windows.Forms.Label();
            this.delay_check_infor = new System.Windows.Forms.NumericUpDown();
            this.label209 = new System.Windows.Forms.Label();
            this.cmb_Check_Infor_BM = new System.Windows.Forms.ComboBox();
            this.label207 = new System.Windows.Forms.Label();
            this.cmb_LOAD_API_CHROME = new System.Windows.Forms.ComboBox();
            this.label192 = new System.Windows.Forms.Label();
            this.tb_EEAG_LOAD_BM = new System.Windows.Forms.TextBox();
            this.label189 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.label92 = new System.Windows.Forms.Label();
            this.sl_LOAD_TK_D2 = new System.Windows.Forms.NumericUpDown();
            this.dgv_AC = new System.Windows.Forms.DataGridView();
            this.cSttACBM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cIDACBM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cNAMEAC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cStatusAC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cLimit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cTIENTE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cNGAYTAOACBM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cSelectACBM = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.contextMenuStrip5 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.xÓAALLToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.label90 = new System.Windows.Forms.Label();
            this.delay_LOAD_BM = new System.Windows.Forms.NumericUpDown();
            this.label89 = new System.Windows.Forms.Label();
            this.SL_BM_LOAD = new System.Windows.Forms.NumericUpDown();
            this.rtb_IDBM_FILTER = new System.Windows.Forms.RichTextBox();
            this.bt_filter = new System.Windows.Forms.Button();
            this.dgv_BM = new System.Windows.Forms.DataGridView();
            this.cSTTBM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cIDVIA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cIDBM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cNAMEBM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cStatusBM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cLOAIBM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cinfor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cNgayTao = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cADMIN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cTKLIVEDIE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cSelectBM = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.contextMenuStrip4 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.chọnToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.bôiĐenToolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảToolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.bỏChọnToolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.bôiĐenToolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.tấtCảToolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.xóaALLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lOADTKDONGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bACKUPBMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bACKUPBMNHIEUVIAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.tb_Token = new System.Windows.Forms.TextBox();
            this.label195 = new System.Windows.Forms.Label();
            this.label174 = new System.Windows.Forms.Label();
            this.rtb_backup_fail = new System.Windows.Forms.RichTextBox();
            this.bt_doi_dinh_dang = new System.Windows.Forms.Button();
            this.label173 = new System.Windows.Forms.Label();
            this.rtb_BM_OUT = new System.Windows.Forms.RichTextBox();
            this.label172 = new System.Windows.Forms.Label();
            this.rtb_ADMIN_BM_CHECK = new System.Windows.Forms.RichTextBox();
            this.label165 = new System.Windows.Forms.Label();
            this.rtb_IDBM_Can_Tao_TK = new System.Windows.Forms.RichTextBox();
            this.label164 = new System.Windows.Forms.Label();
            this.rtb_IDBM_CAN_BACK_Up = new System.Windows.Forms.RichTextBox();
            this.label99 = new System.Windows.Forms.Label();
            this.rtb_Link_BM = new System.Windows.Forms.RichTextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.cmb_API_CHROME_BACK_UP_BM_THEO_ID = new System.Windows.Forms.ComboBox();
            this.label208 = new System.Windows.Forms.Label();
            this.label199 = new System.Windows.Forms.Label();
            this.cmb_share_ban = new System.Windows.Forms.ComboBox();
            this.label194 = new System.Windows.Forms.Label();
            this.n_Delay_TTK = new System.Windows.Forms.NumericUpDown();
            this.label193 = new System.Windows.Forms.Label();
            this.bt_Tao_TK_BM = new System.Windows.Forms.Button();
            this.numericUpDown7 = new System.Windows.Forms.NumericUpDown();
            this.cmb_loai_mail = new System.Windows.Forms.ComboBox();
            this.cmb_Admin_BM1 = new System.Windows.Forms.ComboBox();
            this.delay_doc_link = new System.Windows.Forms.NumericUpDown();
            this.so_link_backup = new System.Windows.Forms.NumericUpDown();
            this.tb_hotmail_Share_bm = new System.Windows.Forms.TextBox();
            this.label98 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.tabPage22 = new System.Windows.Forms.TabPage();
            this.label220 = new System.Windows.Forms.Label();
            this.cmb_new_create_WA = new System.Windows.Forms.ComboBox();
            this.label219 = new System.Windows.Forms.Label();
            this.cmb_delete_WA = new System.Windows.Forms.ComboBox();
            this.label212 = new System.Windows.Forms.Label();
            this.cmb_ttk_5_1_WA = new System.Windows.Forms.ComboBox();
            this.cmb_bo_check1 = new System.Windows.Forms.ComboBox();
            this.label211 = new System.Windows.Forms.Label();
            this.label206 = new System.Windows.Forms.Label();
            this.sl_BM_kick3 = new System.Windows.Forms.NumericUpDown();
            this.label204 = new System.Windows.Forms.Label();
            this.label203 = new System.Windows.Forms.Label();
            this.rtb_BM1 = new System.Windows.Forms.RichTextBox();
            this.rtb_BM3 = new System.Windows.Forms.RichTextBox();
            this.label197 = new System.Windows.Forms.Label();
            this.m_delay_ttk = new System.Windows.Forms.NumericUpDown();
            this.label196 = new System.Windows.Forms.Label();
            this.numericUpDown9 = new System.Windows.Forms.NumericUpDown();
            this.label191 = new System.Windows.Forms.Label();
            this.cmb_TTKQCBM3 = new System.Windows.Forms.ComboBox();
            this.btdoidang = new System.Windows.Forms.Button();
            this.label187 = new System.Windows.Forms.Label();
            this.numericUpDown5 = new System.Windows.Forms.NumericUpDown();
            this.tb_NAME_WHATAPP = new System.Windows.Forms.TextBox();
            this.label186 = new System.Windows.Forms.Label();
            this.delay_kick_bm3 = new System.Windows.Forms.NumericUpDown();
            this.label185 = new System.Windows.Forms.Label();
            this.label184 = new System.Windows.Forms.Label();
            this.rtb_status_kick = new System.Windows.Forms.RichTextBox();
            this.label183 = new System.Windows.Forms.Label();
            this.rtb_IDBM_KICK_BM3 = new System.Windows.Forms.RichTextBox();
            this.tb_TokenEEAG = new System.Windows.Forms.TextBox();
            this.label182 = new System.Windows.Forms.Label();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.label148 = new System.Windows.Forms.Label();
            this.bt_CLEAR_LINK = new System.Windows.Forms.Button();
            this.label147 = new System.Windows.Forms.Label();
            this.bt_CLEAR_FAIL = new System.Windows.Forms.Button();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label107 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.rtb_LINKBM_20 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_19 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_18 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_17 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_16 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_15 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_14 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_13 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_12 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_11 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_10 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_9 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_8 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_7 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_6 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_5 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_4 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_3 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_2 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_1 = new System.Windows.Forms.RichTextBox();
            this.label105 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.rtbLINK = new System.Windows.Forms.RichTextBox();
            this.rtb_Link_FAIL = new System.Windows.Forms.RichTextBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label101 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.cmb_CACH_NHAN_LINK = new System.Windows.Forms.ComboBox();
            this.cmbAPI_Auto_selenium_NhanBM = new System.Windows.Forms.ComboBox();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.tabControl4 = new System.Windows.Forms.TabControl();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.label216 = new System.Windows.Forms.Label();
            this.rtb_codemail = new System.Windows.Forms.RichTextBox();
            this.cmb_file_random = new System.Windows.Forms.ComboBox();
            this.button5 = new System.Windows.Forms.Button();
            this.cmb_chi_doc_link_mail_ao = new System.Windows.Forms.ComboBox();
            this.label190 = new System.Windows.Forms.Label();
            this.label180 = new System.Windows.Forms.Label();
            this.label179 = new System.Windows.Forms.Label();
            this.rtb_mail_moakt_fail = new System.Windows.Forms.RichTextBox();
            this.rtb_mail_moakt_done = new System.Windows.Forms.RichTextBox();
            this.label178 = new System.Windows.Forms.Label();
            this.DELAY_DOC_MAIL = new System.Windows.Forms.NumericUpDown();
            this.label171 = new System.Windows.Forms.Label();
            this.cmb_loai_mail_nhan_bm_ig = new System.Windows.Forms.ComboBox();
            this.label166 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.cmb_FILE_OPEN = new System.Windows.Forms.ComboBox();
            this.button3 = new System.Windows.Forms.Button();
            this.label146 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.cmb_kologin_mail = new System.Windows.Forms.ComboBox();
            this.label221 = new System.Windows.Forms.Label();
            this.cmb_VIA_NHAN_VERRY = new System.Windows.Forms.ComboBox();
            this.label218 = new System.Windows.Forms.Label();
            this.num_STT_NHAN = new System.Windows.Forms.NumericUpDown();
            this.label217 = new System.Windows.Forms.Label();
            this.number_nhan_fail = new System.Windows.Forms.NumericUpDown();
            this.label202 = new System.Windows.Forms.Label();
            this.cmb_DIE_BM_CLEAR = new System.Windows.Forms.ComboBox();
            this.label201 = new System.Windows.Forms.Label();
            this.label188 = new System.Windows.Forms.Label();
            this.numericUpDown6 = new System.Windows.Forms.NumericUpDown();
            this.label141 = new System.Windows.Forms.Label();
            this.CMB_LOAI_BM_NHAN = new System.Windows.Forms.ComboBox();
            this.cmb_STOP = new System.Windows.Forms.ComboBox();
            this.label135 = new System.Windows.Forms.Label();
            this.label136 = new System.Windows.Forms.Label();
            this.cmbAPI_Auto_selenium_NhanBM_IG = new System.Windows.Forms.ComboBox();
            this.label134 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.rtb_mail_bm350_auto = new System.Windows.Forms.RichTextBox();
            this.rtb_mail_bm50_auto = new System.Windows.Forms.RichTextBox();
            this.rtb_BMIII_auto = new System.Windows.Forms.RichTextBox();
            this.label131 = new System.Windows.Forms.Label();
            this.rtb_Link_BM350_IG_auto = new System.Windows.Forms.RichTextBox();
            this.label130 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.rtb_Link_BM50_IG_auto = new System.Windows.Forms.RichTextBox();
            this.tabPage16 = new System.Windows.Forms.TabPage();
            this.tb_nhan20 = new System.Windows.Forms.TextBox();
            this.tb_20 = new System.Windows.Forms.TextBox();
            this.tb_nhan16 = new System.Windows.Forms.TextBox();
            this.tb_16 = new System.Windows.Forms.TextBox();
            this.tb_nhan12 = new System.Windows.Forms.TextBox();
            this.tb_12 = new System.Windows.Forms.TextBox();
            this.tb_nhan8 = new System.Windows.Forms.TextBox();
            this.tb_8 = new System.Windows.Forms.TextBox();
            this.tb_nhan4 = new System.Windows.Forms.TextBox();
            this.tb_4 = new System.Windows.Forms.TextBox();
            this.tb_nhan19 = new System.Windows.Forms.TextBox();
            this.tb_19 = new System.Windows.Forms.TextBox();
            this.tb_nhan15 = new System.Windows.Forms.TextBox();
            this.tb_15 = new System.Windows.Forms.TextBox();
            this.tb_nhan11 = new System.Windows.Forms.TextBox();
            this.tb_11 = new System.Windows.Forms.TextBox();
            this.tb_nhan7 = new System.Windows.Forms.TextBox();
            this.tb_7 = new System.Windows.Forms.TextBox();
            this.tb_nhan3 = new System.Windows.Forms.TextBox();
            this.tb_3 = new System.Windows.Forms.TextBox();
            this.tb_nhan18 = new System.Windows.Forms.TextBox();
            this.tb_18 = new System.Windows.Forms.TextBox();
            this.tb_nhan14 = new System.Windows.Forms.TextBox();
            this.tb_14 = new System.Windows.Forms.TextBox();
            this.tb_nhan10 = new System.Windows.Forms.TextBox();
            this.tb_10 = new System.Windows.Forms.TextBox();
            this.tb_nhan6 = new System.Windows.Forms.TextBox();
            this.tb_6 = new System.Windows.Forms.TextBox();
            this.tb_nhan2 = new System.Windows.Forms.TextBox();
            this.tb_2 = new System.Windows.Forms.TextBox();
            this.tb_nhan17 = new System.Windows.Forms.TextBox();
            this.tb_17 = new System.Windows.Forms.TextBox();
            this.tb_nhan13 = new System.Windows.Forms.TextBox();
            this.tb_13 = new System.Windows.Forms.TextBox();
            this.tb_nhan9 = new System.Windows.Forms.TextBox();
            this.tb_9 = new System.Windows.Forms.TextBox();
            this.tb_nhan5 = new System.Windows.Forms.TextBox();
            this.tb_5 = new System.Windows.Forms.TextBox();
            this.tb_nhan1 = new System.Windows.Forms.TextBox();
            this.tb_1 = new System.Windows.Forms.TextBox();
            this.label118 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.rtb_LINKBMFAIL_IG_19 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_20 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_20 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_19 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_15 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_16 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_16 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_15 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_11 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_12 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_12 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_11 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_7 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_8 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_8 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_7 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_3 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_4 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_4 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_3 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_17 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_18 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_18 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_17 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_13 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_14 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_14 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_13 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_9 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_10 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_10 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_9 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_5 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_6 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_6 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_5 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_1 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_2 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_2 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_1 = new System.Windows.Forms.RichTextBox();
            this.tabPage17 = new System.Windows.Forms.TabPage();
            this.tb_nhan40 = new System.Windows.Forms.TextBox();
            this.tb_40 = new System.Windows.Forms.TextBox();
            this.tb_nhan36 = new System.Windows.Forms.TextBox();
            this.tb_36 = new System.Windows.Forms.TextBox();
            this.tb_nhan32 = new System.Windows.Forms.TextBox();
            this.tb_32 = new System.Windows.Forms.TextBox();
            this.tb_nhan28 = new System.Windows.Forms.TextBox();
            this.tb_28 = new System.Windows.Forms.TextBox();
            this.tb_nhan24 = new System.Windows.Forms.TextBox();
            this.tb_24 = new System.Windows.Forms.TextBox();
            this.tb_nhan39 = new System.Windows.Forms.TextBox();
            this.tb_39 = new System.Windows.Forms.TextBox();
            this.tb_nhan35 = new System.Windows.Forms.TextBox();
            this.tb_35 = new System.Windows.Forms.TextBox();
            this.tb_nhan31 = new System.Windows.Forms.TextBox();
            this.tb_31 = new System.Windows.Forms.TextBox();
            this.tb_nhan27 = new System.Windows.Forms.TextBox();
            this.tb_27 = new System.Windows.Forms.TextBox();
            this.tb_nhan23 = new System.Windows.Forms.TextBox();
            this.tb_23 = new System.Windows.Forms.TextBox();
            this.tb_nhan38 = new System.Windows.Forms.TextBox();
            this.tb_38 = new System.Windows.Forms.TextBox();
            this.tb_nhan34 = new System.Windows.Forms.TextBox();
            this.tb_34 = new System.Windows.Forms.TextBox();
            this.tb_nhan30 = new System.Windows.Forms.TextBox();
            this.tb_30 = new System.Windows.Forms.TextBox();
            this.tb_nhan26 = new System.Windows.Forms.TextBox();
            this.tb_26 = new System.Windows.Forms.TextBox();
            this.tb_nhan22 = new System.Windows.Forms.TextBox();
            this.tb_22 = new System.Windows.Forms.TextBox();
            this.tb_nhan37 = new System.Windows.Forms.TextBox();
            this.tb_37 = new System.Windows.Forms.TextBox();
            this.tb_nhan33 = new System.Windows.Forms.TextBox();
            this.tb_33 = new System.Windows.Forms.TextBox();
            this.tb_nhan29 = new System.Windows.Forms.TextBox();
            this.tb_29 = new System.Windows.Forms.TextBox();
            this.tb_nhan25 = new System.Windows.Forms.TextBox();
            this.tb_25 = new System.Windows.Forms.TextBox();
            this.tb_nhan21 = new System.Windows.Forms.TextBox();
            this.tb_21 = new System.Windows.Forms.TextBox();
            this.label128 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.rtb_LINKBMFAIL_IG_39 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_40 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_40 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_39 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_35 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_36 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_36 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_35 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_31 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_32 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_32 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_31 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_27 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_28 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_28 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_27 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_23 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_24 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_24 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_23 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_37 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_38 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_38 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_37 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_33 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_34 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_34 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_33 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_29 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_30 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_30 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_29 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_25 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_26 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_26 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_25 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_21 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_22 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBMFAIL_IG_22 = new System.Windows.Forms.RichTextBox();
            this.rtb_LINKBM_IG_21 = new System.Windows.Forms.RichTextBox();
            this.tabPage18 = new System.Windows.Forms.TabPage();
            this.label145 = new System.Windows.Forms.Label();
            this.delay_check_ig = new System.Windows.Forms.NumericUpDown();
            this.label144 = new System.Windows.Forms.Label();
            this.label143 = new System.Windows.Forms.Label();
            this.rtb_282 = new System.Windows.Forms.RichTextBox();
            this.rtb_LIVE = new System.Windows.Forms.RichTextBox();
            this.tabPage19 = new System.Windows.Forms.TabPage();
            this.tabControl5 = new System.Windows.Forms.TabControl();
            this.tabPage20 = new System.Windows.Forms.TabPage();
            this.label170 = new System.Windows.Forms.Label();
            this.label169 = new System.Windows.Forms.Label();
            this.rtb_10_link_bm350 = new System.Windows.Forms.RichTextBox();
            this.rtb_10_link_bm50 = new System.Windows.Forms.RichTextBox();
            this.tabPage21 = new System.Windows.Forms.TabPage();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.cmb_Chuc_Nang = new System.Windows.Forms.ComboBox();
            this.label42 = new System.Windows.Forms.Label();
            this.tbsodu = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.cmbKeyCaptcha = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.cmbVIA = new System.Windows.Forms.ComboBox();
            this.cmbLogin = new System.Windows.Forms.ComboBox();
            this.btn_Stop = new System.Windows.Forms.Button();
            this.lbnew = new System.Windows.Forms.Label();
            this.labelnew = new System.Windows.Forms.Label();
            this.btUpdate = new System.Windows.Forms.Button();
            this.tb_LOAD_STT = new System.Windows.Forms.Button();
            this.bt_file_VIA = new System.Windows.Forms.Button();
            this.label223 = new System.Windows.Forms.Label();
            this.numericUpDown8 = new System.Windows.Forms.NumericUpDown();
            this.tabPage25 = new System.Windows.Forms.TabPage();
            this.label224 = new System.Windows.Forms.Label();
            this.cmn_doc_link_hotmail_vanha = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gioi_han_close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gioi_han_live)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gioi_han_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.delayshare)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sl_Nhan_BM_CLOSE1_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sl_Nhan_BM_PARTNER)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sl_nhan_Bm_BM_BACKUP)).BeginInit();
            this.tabPage7.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.delay_reg_bm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.for_reg_bm)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.soluong_mua_Mail)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv2_IG)).BeginInit();
            this.contextMenuStrip3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_mail)).BeginInit();
            this.contextMenuStrip2.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabControl6.SuspendLayout();
            this.tabPage23.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPage24.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5_delay_regbmig)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_tao_5bm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.delay_doc_hotmail_1)).BeginInit();
            this.groupBox14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.n_slink_share_them)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.delay_tatbatsangtao)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nam_rip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.thang_rip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngay_rip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5_slcheck_bm350)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.delay_check_admin)).BeginInit();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ndelayloop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.delay_link_bm_backup)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.delay_check_infor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sl_LOAD_TK_D2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_AC)).BeginInit();
            this.contextMenuStrip5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.delay_LOAD_BM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SL_BM_LOAD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_BM)).BeginInit();
            this.contextMenuStrip4.SuspendLayout();
            this.tabPage12.SuspendLayout();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.n_Delay_TTK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.delay_doc_link)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.so_link_backup)).BeginInit();
            this.tabPage22.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sl_BM_kick3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.m_delay_ttk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.delay_kick_bm3)).BeginInit();
            this.tabPage13.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.tabPage14.SuspendLayout();
            this.tabControl4.SuspendLayout();
            this.tabPage15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DELAY_DOC_MAIL)).BeginInit();
            this.groupBox12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_STT_NHAN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.number_nhan_fail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).BeginInit();
            this.tabPage16.SuspendLayout();
            this.tabPage17.SuspendLayout();
            this.tabPage18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.delay_check_ig)).BeginInit();
            this.tabPage19.SuspendLayout();
            this.tabControl5.SuspendLayout();
            this.tabPage20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).BeginInit();
            this.tabPage25.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(597, 137);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(8, 8);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btn_RUN
            // 
            this.btn_RUN.BackColor = System.Drawing.SystemColors.Highlight;
            this.btn_RUN.Location = new System.Drawing.Point(12, 12);
            this.btn_RUN.Name = "btn_RUN";
            this.btn_RUN.Size = new System.Drawing.Size(75, 49);
            this.btn_RUN.TabIndex = 1;
            this.btn_RUN.Text = "RUN";
            this.btn_RUN.UseVisualStyleBackColor = false;
            this.btn_RUN.Click += new System.EventHandler(this.btn_RUN_Click);
            // 
            // dgv1
            // 
            this.dgv1.AllowUserToAddRows = false;
            this.dgv1.AllowUserToDeleteRows = false;
            this.dgv1.AllowUserToResizeRows = false;
            this.dgv1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cStt,
            this.cUID,
            this.cPass,
            this.c2FAvsCookie,
            this.cMail,
            this.cPassMail,
            this.cMailKP,
            this.cStatus,
            this.cCheckBM,
            this.cSelect});
            this.dgv1.ContextMenuStrip = this.contextMenuStrip1;
            this.dgv1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv1.Location = new System.Drawing.Point(3, 3);
            this.dgv1.Name = "dgv1";
            this.dgv1.RowHeadersVisible = false;
            this.dgv1.Size = new System.Drawing.Size(1761, 682);
            this.dgv1.TabIndex = 2;
            this.dgv1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv1_CellContentClick);
            this.dgv1.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgv1_CellFormatting);
            this.dgv1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgv1_KeyDown);
            // 
            // cStt
            // 
            this.cStt.FillWeight = 30F;
            this.cStt.HeaderText = "STT";
            this.cStt.Name = "cStt";
            // 
            // cUID
            // 
            this.cUID.FillWeight = 50F;
            this.cUID.HeaderText = "UID";
            this.cUID.Name = "cUID";
            // 
            // cPass
            // 
            this.cPass.FillWeight = 50F;
            this.cPass.HeaderText = "PASS";
            this.cPass.Name = "cPass";
            // 
            // c2FAvsCookie
            // 
            this.c2FAvsCookie.FillWeight = 50F;
            this.c2FAvsCookie.HeaderText = "2FA || Cookie";
            this.c2FAvsCookie.Name = "c2FAvsCookie";
            // 
            // cMail
            // 
            this.cMail.FillWeight = 50F;
            this.cMail.HeaderText = "MAIL";
            this.cMail.Name = "cMail";
            // 
            // cPassMail
            // 
            this.cPassMail.FillWeight = 50F;
            this.cPassMail.HeaderText = "PASSMAIL";
            this.cPassMail.Name = "cPassMail";
            // 
            // cMailKP
            // 
            this.cMailKP.FillWeight = 50F;
            this.cMailKP.HeaderText = "MAILKP";
            this.cMailKP.Name = "cMailKP";
            // 
            // cStatus
            // 
            this.cStatus.FillWeight = 200F;
            this.cStatus.HeaderText = "STATUS";
            this.cStatus.Name = "cStatus";
            this.cStatus.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.cStatus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // cCheckBM
            // 
            this.cCheckBM.FillWeight = 200F;
            this.cCheckBM.HeaderText = "CheckBM";
            this.cCheckBM.Name = "cCheckBM";
            this.cCheckBM.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.cCheckBM.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // cSelect
            // 
            this.cSelect.FillWeight = 20F;
            this.cSelect.HeaderText = "";
            this.cSelect.Name = "cSelect";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chọnToolStripMenuItem,
            this.bỏChọnToolStripMenuItem,
            this.xóaToolStripMenuItem,
            this.aDDMAILKPToolStripMenuItem,
            this.nHẬNBMNEWToolStripMenuItem,
            this.tẮTBẬTSÁNGTẠOIGToolStripMenuItem,
            this.cHECKBMToolStripMenuItem,
            this.sHAREBMIGToolStripMenuItem,
            this.rEGBM12ToolStripMenuItem,
            this.rEGBM2025ToolStripMenuItem,
            this.lOADALLBMVIAToolStripMenuItem,
            this.nHẬNBMToolStripMenuItem,
            this.loginVIAToolStripMenuItem,
            this.kILLChromeDriverToolStripMenuItem,
            this.lấyCookieVIAToolStripMenuItem,
            this.nHẬNBMAUTOToolStripMenuItem,
            this.lOGINGMAILCHROMEToolStripMenuItem,
            this.tESTWABMToolStripMenuItem,
            this.bACKUPBMTHEOIDToolStripMenuItem,
            this.oUTBMTHEOIDToolStripMenuItem,
            this.cHECKADMINBMTHEOIDToolStripMenuItem,
            this.kICHWHATAPPToolStripMenuItem,
            this.cHECKINFORBMToolStripMenuItem,
            this.cHECKADMINIGToolStripMenuItem,
            this.uOTIGBMFBToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(227, 554);
            // 
            // chọnToolStripMenuItem
            // 
            this.chọnToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bôiĐenToolStripMenuItem,
            this.tấtCảToolStripMenuItem});
            this.chọnToolStripMenuItem.Name = "chọnToolStripMenuItem";
            this.chọnToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.chọnToolStripMenuItem.Text = "Chọn";
            // 
            // bôiĐenToolStripMenuItem
            // 
            this.bôiĐenToolStripMenuItem.Name = "bôiĐenToolStripMenuItem";
            this.bôiĐenToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.bôiĐenToolStripMenuItem.Text = "Bôi Đen";
            this.bôiĐenToolStripMenuItem.Click += new System.EventHandler(this.bôiĐenToolStripMenuItem_Click_1);
            // 
            // tấtCảToolStripMenuItem
            // 
            this.tấtCảToolStripMenuItem.Name = "tấtCảToolStripMenuItem";
            this.tấtCảToolStripMenuItem.Size = new System.Drawing.Size(115, 22);
            this.tấtCảToolStripMenuItem.Text = "Tất Cả";
            this.tấtCảToolStripMenuItem.Click += new System.EventHandler(this.tấtCảToolStripMenuItem_Click_1);
            // 
            // bỏChọnToolStripMenuItem
            // 
            this.bỏChọnToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bôiĐenToolStripMenuItem1,
            this.tấtCảToolStripMenuItem1});
            this.bỏChọnToolStripMenuItem.Name = "bỏChọnToolStripMenuItem";
            this.bỏChọnToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.bỏChọnToolStripMenuItem.Text = "Bỏ Chọn";
            // 
            // bôiĐenToolStripMenuItem1
            // 
            this.bôiĐenToolStripMenuItem1.Name = "bôiĐenToolStripMenuItem1";
            this.bôiĐenToolStripMenuItem1.Size = new System.Drawing.Size(115, 22);
            this.bôiĐenToolStripMenuItem1.Text = "Bôi Đen";
            this.bôiĐenToolStripMenuItem1.Click += new System.EventHandler(this.bôiĐenToolStripMenuItem1_Click_1);
            // 
            // tấtCảToolStripMenuItem1
            // 
            this.tấtCảToolStripMenuItem1.Name = "tấtCảToolStripMenuItem1";
            this.tấtCảToolStripMenuItem1.Size = new System.Drawing.Size(115, 22);
            this.tấtCảToolStripMenuItem1.Text = "Tất Cả";
            this.tấtCảToolStripMenuItem1.Click += new System.EventHandler(this.tấtCảToolStripMenuItem1_Click_1);
            // 
            // xóaToolStripMenuItem
            // 
            this.xóaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dòngĐãChọnToolStripMenuItem,
            this.tấtCảToolStripMenuItem2});
            this.xóaToolStripMenuItem.Name = "xóaToolStripMenuItem";
            this.xóaToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.xóaToolStripMenuItem.Text = "Xóa";
            // 
            // dòngĐãChọnToolStripMenuItem
            // 
            this.dòngĐãChọnToolStripMenuItem.Name = "dòngĐãChọnToolStripMenuItem";
            this.dòngĐãChọnToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.dòngĐãChọnToolStripMenuItem.Text = "Dòng Đã Chọn";
            this.dòngĐãChọnToolStripMenuItem.Click += new System.EventHandler(this.dòngĐãChọnToolStripMenuItem_Click_1);
            // 
            // tấtCảToolStripMenuItem2
            // 
            this.tấtCảToolStripMenuItem2.Name = "tấtCảToolStripMenuItem2";
            this.tấtCảToolStripMenuItem2.Size = new System.Drawing.Size(152, 22);
            this.tấtCảToolStripMenuItem2.Text = "Tất Cả";
            this.tấtCảToolStripMenuItem2.Click += new System.EventHandler(this.tấtCảToolStripMenuItem2_Click_1);
            // 
            // aDDMAILKPToolStripMenuItem
            // 
            this.aDDMAILKPToolStripMenuItem.Name = "aDDMAILKPToolStripMenuItem";
            this.aDDMAILKPToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.aDDMAILKPToolStripMenuItem.Text = "ADD MAIL KP";
            this.aDDMAILKPToolStripMenuItem.Click += new System.EventHandler(this.aDDMAILKPToolStripMenuItem_Click);
            // 
            // nHẬNBMNEWToolStripMenuItem
            // 
            this.nHẬNBMNEWToolStripMenuItem.Name = "nHẬNBMNEWToolStripMenuItem";
            this.nHẬNBMNEWToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.nHẬNBMNEWToolStripMenuItem.Text = "NHẬN BM NEW";
            this.nHẬNBMNEWToolStripMenuItem.Click += new System.EventHandler(this.nHẬNBMNEWToolStripMenuItem_Click);
            // 
            // tẮTBẬTSÁNGTẠOIGToolStripMenuItem
            // 
            this.tẮTBẬTSÁNGTẠOIGToolStripMenuItem.Name = "tẮTBẬTSÁNGTẠOIGToolStripMenuItem";
            this.tẮTBẬTSÁNGTẠOIGToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.tẮTBẬTSÁNGTẠOIGToolStripMenuItem.Text = "TẮT BẬT SÁNG TẠO IG";
            this.tẮTBẬTSÁNGTẠOIGToolStripMenuItem.Click += new System.EventHandler(this.tẮTBẬTSÁNGTẠOIGToolStripMenuItem_Click);
            // 
            // cHECKBMToolStripMenuItem
            // 
            this.cHECKBMToolStripMenuItem.Name = "cHECKBMToolStripMenuItem";
            this.cHECKBMToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.cHECKBMToolStripMenuItem.Text = "CHECK BM";
            this.cHECKBMToolStripMenuItem.Click += new System.EventHandler(this.cHECKBMToolStripMenuItem_Click);
            // 
            // sHAREBMIGToolStripMenuItem
            // 
            this.sHAREBMIGToolStripMenuItem.Name = "sHAREBMIGToolStripMenuItem";
            this.sHAREBMIGToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.sHAREBMIGToolStripMenuItem.Text = "SHARE_BM_IG";
            this.sHAREBMIGToolStripMenuItem.Click += new System.EventHandler(this.sHAREBMIGToolStripMenuItem_Click);
            // 
            // rEGBM12ToolStripMenuItem
            // 
            this.rEGBM12ToolStripMenuItem.Name = "rEGBM12ToolStripMenuItem";
            this.rEGBM12ToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.rEGBM12ToolStripMenuItem.Text = "REG_BM_1_2_3";
            this.rEGBM12ToolStripMenuItem.Click += new System.EventHandler(this.rEGBM12ToolStripMenuItem_Click);
            // 
            // rEGBM2025ToolStripMenuItem
            // 
            this.rEGBM2025ToolStripMenuItem.Name = "rEGBM2025ToolStripMenuItem";
            this.rEGBM2025ToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.rEGBM2025ToolStripMenuItem.Text = "REG_BM_2025";
            this.rEGBM2025ToolStripMenuItem.Click += new System.EventHandler(this.rEGBM2025ToolStripMenuItem_Click);
            // 
            // lOADALLBMVIAToolStripMenuItem
            // 
            this.lOADALLBMVIAToolStripMenuItem.Name = "lOADALLBMVIAToolStripMenuItem";
            this.lOADALLBMVIAToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.lOADALLBMVIAToolStripMenuItem.Text = "LOAD_ALL_BM_VIA";
            this.lOADALLBMVIAToolStripMenuItem.Click += new System.EventHandler(this.lOADALLBMVIAToolStripMenuItem_Click);
            // 
            // nHẬNBMToolStripMenuItem
            // 
            this.nHẬNBMToolStripMenuItem.Name = "nHẬNBMToolStripMenuItem";
            this.nHẬNBMToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.nHẬNBMToolStripMenuItem.Text = "NHẬN BM";
            this.nHẬNBMToolStripMenuItem.Click += new System.EventHandler(this.nHẬNBMToolStripMenuItem_Click_1);
            // 
            // loginVIAToolStripMenuItem
            // 
            this.loginVIAToolStripMenuItem.Name = "loginVIAToolStripMenuItem";
            this.loginVIAToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.loginVIAToolStripMenuItem.Text = "Login_VIA";
            this.loginVIAToolStripMenuItem.Click += new System.EventHandler(this.loginVIAToolStripMenuItem_Click);
            // 
            // kILLChromeDriverToolStripMenuItem
            // 
            this.kILLChromeDriverToolStripMenuItem.Name = "kILLChromeDriverToolStripMenuItem";
            this.kILLChromeDriverToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.kILLChromeDriverToolStripMenuItem.Text = "KILL_Chrome_Driver";
            this.kILLChromeDriverToolStripMenuItem.Click += new System.EventHandler(this.kILLChromeDriverToolStripMenuItem_Click);
            // 
            // lấyCookieVIAToolStripMenuItem
            // 
            this.lấyCookieVIAToolStripMenuItem.Name = "lấyCookieVIAToolStripMenuItem";
            this.lấyCookieVIAToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.lấyCookieVIAToolStripMenuItem.Text = "Lấy_Cookie_VIA";
            this.lấyCookieVIAToolStripMenuItem.Click += new System.EventHandler(this.lấyCookieVIAToolStripMenuItem_Click);
            // 
            // nHẬNBMAUTOToolStripMenuItem
            // 
            this.nHẬNBMAUTOToolStripMenuItem.Name = "nHẬNBMAUTOToolStripMenuItem";
            this.nHẬNBMAUTOToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.nHẬNBMAUTOToolStripMenuItem.Text = "NHẬN BM AUTO";
            this.nHẬNBMAUTOToolStripMenuItem.Click += new System.EventHandler(this.nHẬNBMAUTOToolStripMenuItem_Click);
            // 
            // lOGINGMAILCHROMEToolStripMenuItem
            // 
            this.lOGINGMAILCHROMEToolStripMenuItem.Name = "lOGINGMAILCHROMEToolStripMenuItem";
            this.lOGINGMAILCHROMEToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.lOGINGMAILCHROMEToolStripMenuItem.Text = "LOGIN_GMAIL_CHROME";
            this.lOGINGMAILCHROMEToolStripMenuItem.Click += new System.EventHandler(this.lOGINGMAILCHROMEToolStripMenuItem_Click);
            // 
            // tESTWABMToolStripMenuItem
            // 
            this.tESTWABMToolStripMenuItem.Name = "tESTWABMToolStripMenuItem";
            this.tESTWABMToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.tESTWABMToolStripMenuItem.Text = "TEST WA BM";
            this.tESTWABMToolStripMenuItem.Click += new System.EventHandler(this.tESTWABMToolStripMenuItem_Click);
            // 
            // bACKUPBMTHEOIDToolStripMenuItem
            // 
            this.bACKUPBMTHEOIDToolStripMenuItem.Name = "bACKUPBMTHEOIDToolStripMenuItem";
            this.bACKUPBMTHEOIDToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.bACKUPBMTHEOIDToolStripMenuItem.Text = "BACK_UP_BM_THEO_ID";
            this.bACKUPBMTHEOIDToolStripMenuItem.Click += new System.EventHandler(this.bACKUPBMTHEOIDToolStripMenuItem_Click);
            // 
            // oUTBMTHEOIDToolStripMenuItem
            // 
            this.oUTBMTHEOIDToolStripMenuItem.Name = "oUTBMTHEOIDToolStripMenuItem";
            this.oUTBMTHEOIDToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.oUTBMTHEOIDToolStripMenuItem.Text = "OUT_BM_THEO_ID";
            this.oUTBMTHEOIDToolStripMenuItem.Click += new System.EventHandler(this.oUTBMTHEOIDToolStripMenuItem_Click);
            // 
            // cHECKADMINBMTHEOIDToolStripMenuItem
            // 
            this.cHECKADMINBMTHEOIDToolStripMenuItem.Name = "cHECKADMINBMTHEOIDToolStripMenuItem";
            this.cHECKADMINBMTHEOIDToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.cHECKADMINBMTHEOIDToolStripMenuItem.Text = "CHECK_ADMINBM_THEO_ID";
            this.cHECKADMINBMTHEOIDToolStripMenuItem.Click += new System.EventHandler(this.cHECKADMINBMTHEOIDToolStripMenuItem_Click);
            // 
            // kICHWHATAPPToolStripMenuItem
            // 
            this.kICHWHATAPPToolStripMenuItem.Name = "kICHWHATAPPToolStripMenuItem";
            this.kICHWHATAPPToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.kICHWHATAPPToolStripMenuItem.Text = "KICH_WHATAPP";
            this.kICHWHATAPPToolStripMenuItem.Click += new System.EventHandler(this.kICHWHATAPPToolStripMenuItem_Click);
            // 
            // cHECKINFORBMToolStripMenuItem
            // 
            this.cHECKINFORBMToolStripMenuItem.Name = "cHECKINFORBMToolStripMenuItem";
            this.cHECKINFORBMToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.cHECKINFORBMToolStripMenuItem.Text = "CHECK_INFOR_BM";
            this.cHECKINFORBMToolStripMenuItem.Click += new System.EventHandler(this.cHECKINFORBMToolStripMenuItem_Click);
            // 
            // cHECKADMINIGToolStripMenuItem
            // 
            this.cHECKADMINIGToolStripMenuItem.Name = "cHECKADMINIGToolStripMenuItem";
            this.cHECKADMINIGToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.cHECKADMINIGToolStripMenuItem.Text = "CHECK_ADMIN_IG";
            this.cHECKADMINIGToolStripMenuItem.Click += new System.EventHandler(this.cHECKADMINIGToolStripMenuItem_Click);
            // 
            // uOTIGBMFBToolStripMenuItem
            // 
            this.uOTIGBMFBToolStripMenuItem.Name = "uOTIGBMFBToolStripMenuItem";
            this.uOTIGBMFBToolStripMenuItem.Size = new System.Drawing.Size(226, 22);
            this.uOTIGBMFBToolStripMenuItem.Text = "UOT_IG_BM_FB";
            this.uOTIGBMFBToolStripMenuItem.Click += new System.EventHandler(this.uOTIGBMFBToolStripMenuItem_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Controls.Add(this.tabPage9);
            this.tabControl1.Controls.Add(this.tabPage10);
            this.tabControl1.Controls.Add(this.tabPage13);
            this.tabControl1.Controls.Add(this.tabPage14);
            this.tabControl1.Controls.Add(this.tabPage18);
            this.tabControl1.Controls.Add(this.tabPage19);
            this.tabControl1.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(3, 117);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1775, 716);
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dgv1);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1767, 688);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Hiển Thị";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Silver;
            this.tabPage2.Controls.Add(this.tabControl2);
            this.tabPage2.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1767, 688);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "SHARE DONG 2";
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Location = new System.Drawing.Point(0, 0);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(1761, 695);
            this.tabControl2.TabIndex = 75;
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.tabPage6.Controls.Add(this.label56);
            this.tabPage6.Controls.Add(this.tb_so_luong_BM);
            this.tabPage6.Controls.Add(this.rtb_BMDIE);
            this.tabPage6.Controls.Add(this.rtb_BM_Nhan_Du);
            this.tabPage6.Controls.Add(this.label28);
            this.tabPage6.Controls.Add(this.label27);
            this.tabPage6.Controls.Add(this.label25);
            this.tabPage6.Controls.Add(this.label24);
            this.tabPage6.Controls.Add(this.rtbdone);
            this.tabPage6.Controls.Add(this.rtbAC_FAIL);
            this.tabPage6.Controls.Add(this.label26);
            this.tabPage6.Controls.Add(this.label19);
            this.tabPage6.Controls.Add(this.label18);
            this.tabPage6.Controls.Add(this.rtb_BM_CLOSE_4_THAY_THE);
            this.tabPage6.Controls.Add(this.rtb_BM_CLOSE_3_THAY_THE);
            this.tabPage6.Controls.Add(this.rtb_BM_CLOSE_2_THAY_THE);
            this.tabPage6.Controls.Add(this.rtb_BM_CLOSE_THAY_THE);
            this.tabPage6.Controls.Add(this.rtb_BM_BACKUP3_THAY_THE);
            this.tabPage6.Controls.Add(this.rtb_BM_BACKUP2_THAY_THE);
            this.tabPage6.Controls.Add(this.rtb_BM_BACKUP_THAY_THE);
            this.tabPage6.Controls.Add(this.rtb_BM_THAY_THE);
            this.tabPage6.Controls.Add(this.cmb_ADD_Tra_Truoc);
            this.tabPage6.Controls.Add(this.label34);
            this.tabPage6.Controls.Add(this.gioi_han_close);
            this.tabPage6.Controls.Add(this.label32);
            this.tabPage6.Controls.Add(this.gioi_han_live);
            this.tabPage6.Controls.Add(this.label31);
            this.tabPage6.Controls.Add(this.gioi_han_1);
            this.tabPage6.Controls.Add(this.label30);
            this.tabPage6.Controls.Add(this.delayshare);
            this.tabPage6.Controls.Add(this.label29);
            this.tabPage6.Controls.Add(this.rtb_BM_PARTNER_THAY_THE);
            this.tabPage6.Controls.Add(this.sl_Nhan_BM_CLOSE1_2);
            this.tabPage6.Controls.Add(this.sl_Nhan_BM_PARTNER);
            this.tabPage6.Controls.Add(this.sl_nhan_Bm_BM_BACKUP);
            this.tabPage6.Controls.Add(this.label22);
            this.tabPage6.Controls.Add(this.label21);
            this.tabPage6.Controls.Add(this.label20);
            this.tabPage6.Controls.Add(this.tx_So_Luong_Share_vao_bm);
            this.tabPage6.Controls.Add(this.label33);
            this.tabPage6.Controls.Add(this.tb_so_luong_BM_PARTNER);
            this.tabPage6.Controls.Add(this.tb_BM_Close_4);
            this.tabPage6.Controls.Add(this.tb_BM_Close_3);
            this.tabPage6.Controls.Add(this.tb_BM_Close_2);
            this.tabPage6.Controls.Add(this.tb_BM_Close1);
            this.tabPage6.Controls.Add(this.tb_BM_BACK_UP3);
            this.tabPage6.Controls.Add(this.tb_BM_BACK_UP2);
            this.tabPage6.Controls.Add(this.tb_BM_BACK_UP);
            this.tabPage6.Controls.Add(this.tb_BM);
            this.tabPage6.Controls.Add(this.rtb_IDBM_PARTNER);
            this.tabPage6.Controls.Add(this.label23);
            this.tabPage6.Controls.Add(this.label17);
            this.tabPage6.Controls.Add(this.rtb_IDBM_CLOSE_4);
            this.tabPage6.Controls.Add(this.label13);
            this.tabPage6.Controls.Add(this.rtb_IDBM_CLOSE_3);
            this.tabPage6.Controls.Add(this.label14);
            this.tabPage6.Controls.Add(this.rtb_IDBM_CLOSE_2);
            this.tabPage6.Controls.Add(this.label15);
            this.tabPage6.Controls.Add(this.rtb_IDBM_CLOSE);
            this.tabPage6.Controls.Add(this.label16);
            this.tabPage6.Controls.Add(this.rtb_ID_BM_Share_BACK_UP3);
            this.tabPage6.Controls.Add(this.label11);
            this.tabPage6.Controls.Add(this.rtb_ID_BM_Share_BACK_UP2);
            this.tabPage6.Controls.Add(this.label12);
            this.tabPage6.Controls.Add(this.rtb_ID_BM_Share_BACK_UP);
            this.tabPage6.Controls.Add(this.label10);
            this.tabPage6.Controls.Add(this.rtb_ID_BM_Share);
            this.tabPage6.Controls.Add(this.label9);
            this.tabPage6.Controls.Add(this.tb_sl_282);
            this.tabPage6.Controls.Add(this.label8);
            this.tabPage6.Controls.Add(this.cmb_CLOSE_SHARE);
            this.tabPage6.Controls.Add(this.label3);
            this.tabPage6.Controls.Add(this.cmb_User_Agent);
            this.tabPage6.Controls.Add(this.label2);
            this.tabPage6.Location = new System.Drawing.Point(4, 24);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1753, 667);
            this.tabPage6.TabIndex = 0;
            this.tabPage6.Text = "SHARE";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(1122, 31);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(126, 15);
            this.label56.TabIndex = 123;
            this.label56.Text = "SỐ LƯỢNG BM REG:";
            // 
            // tb_so_luong_BM
            // 
            this.tb_so_luong_BM.Location = new System.Drawing.Point(1254, 28);
            this.tb_so_luong_BM.Name = "tb_so_luong_BM";
            this.tb_so_luong_BM.Size = new System.Drawing.Size(100, 21);
            this.tb_so_luong_BM.TabIndex = 122;
            // 
            // rtb_BMDIE
            // 
            this.rtb_BMDIE.Location = new System.Drawing.Point(775, 412);
            this.rtb_BMDIE.Name = "rtb_BMDIE";
            this.rtb_BMDIE.Size = new System.Drawing.Size(302, 166);
            this.rtb_BMDIE.TabIndex = 117;
            this.rtb_BMDIE.Text = "";
            // 
            // rtb_BM_Nhan_Du
            // 
            this.rtb_BM_Nhan_Du.Location = new System.Drawing.Point(775, 215);
            this.rtb_BM_Nhan_Du.Name = "rtb_BM_Nhan_Du";
            this.rtb_BM_Nhan_Du.Size = new System.Drawing.Size(302, 166);
            this.rtb_BM_Nhan_Du.TabIndex = 116;
            this.rtb_BM_Nhan_Du.Text = "";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(828, 6);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(36, 15);
            this.label28.TabIndex = 121;
            this.label28.Text = "FAIL:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(969, 6);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(46, 15);
            this.label27.TabIndex = 120;
            this.label27.Text = "DONE:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(894, 388);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(53, 15);
            this.label25.TabIndex = 119;
            this.label25.Text = "BM DIE:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(875, 196);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(88, 15);
            this.label24.TabIndex = 118;
            this.label24.Text = "BM NHẬN ĐỦ:";
            // 
            // rtbdone
            // 
            this.rtbdone.Location = new System.Drawing.Point(945, 27);
            this.rtbdone.Name = "rtbdone";
            this.rtbdone.Size = new System.Drawing.Size(148, 166);
            this.rtbdone.TabIndex = 115;
            this.rtbdone.Text = "";
            // 
            // rtbAC_FAIL
            // 
            this.rtbAC_FAIL.Location = new System.Drawing.Point(775, 27);
            this.rtbAC_FAIL.Name = "rtbAC_FAIL";
            this.rtbAC_FAIL.Size = new System.Drawing.Size(148, 166);
            this.rtbAC_FAIL.TabIndex = 114;
            this.rtbAC_FAIL.Text = "";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(445, 401);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(100, 15);
            this.label26.TabIndex = 103;
            this.label26.Text = "IDBM PARTNER:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(613, 7);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(65, 15);
            this.label19.TabIndex = 95;
            this.label19.Text = "IDCLOSE:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(467, 7);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(43, 15);
            this.label18.TabIndex = 94;
            this.label18.Text = "IDBM:";
            // 
            // rtb_BM_CLOSE_4_THAY_THE
            // 
            this.rtb_BM_CLOSE_4_THAY_THE.Location = new System.Drawing.Point(577, 236);
            this.rtb_BM_CLOSE_4_THAY_THE.Name = "rtb_BM_CLOSE_4_THAY_THE";
            this.rtb_BM_CLOSE_4_THAY_THE.Size = new System.Drawing.Size(148, 64);
            this.rtb_BM_CLOSE_4_THAY_THE.TabIndex = 93;
            this.rtb_BM_CLOSE_4_THAY_THE.Text = "";
            // 
            // rtb_BM_CLOSE_3_THAY_THE
            // 
            this.rtb_BM_CLOSE_3_THAY_THE.Location = new System.Drawing.Point(577, 167);
            this.rtb_BM_CLOSE_3_THAY_THE.Name = "rtb_BM_CLOSE_3_THAY_THE";
            this.rtb_BM_CLOSE_3_THAY_THE.Size = new System.Drawing.Size(148, 64);
            this.rtb_BM_CLOSE_3_THAY_THE.TabIndex = 92;
            this.rtb_BM_CLOSE_3_THAY_THE.Text = "";
            // 
            // rtb_BM_CLOSE_2_THAY_THE
            // 
            this.rtb_BM_CLOSE_2_THAY_THE.Location = new System.Drawing.Point(577, 97);
            this.rtb_BM_CLOSE_2_THAY_THE.Name = "rtb_BM_CLOSE_2_THAY_THE";
            this.rtb_BM_CLOSE_2_THAY_THE.Size = new System.Drawing.Size(148, 64);
            this.rtb_BM_CLOSE_2_THAY_THE.TabIndex = 91;
            this.rtb_BM_CLOSE_2_THAY_THE.Text = "";
            // 
            // rtb_BM_CLOSE_THAY_THE
            // 
            this.rtb_BM_CLOSE_THAY_THE.Location = new System.Drawing.Point(577, 28);
            this.rtb_BM_CLOSE_THAY_THE.Name = "rtb_BM_CLOSE_THAY_THE";
            this.rtb_BM_CLOSE_THAY_THE.Size = new System.Drawing.Size(148, 64);
            this.rtb_BM_CLOSE_THAY_THE.TabIndex = 90;
            this.rtb_BM_CLOSE_THAY_THE.Text = "";
            // 
            // rtb_BM_BACKUP3_THAY_THE
            // 
            this.rtb_BM_BACKUP3_THAY_THE.Location = new System.Drawing.Point(416, 236);
            this.rtb_BM_BACKUP3_THAY_THE.Name = "rtb_BM_BACKUP3_THAY_THE";
            this.rtb_BM_BACKUP3_THAY_THE.Size = new System.Drawing.Size(148, 64);
            this.rtb_BM_BACKUP3_THAY_THE.TabIndex = 89;
            this.rtb_BM_BACKUP3_THAY_THE.Text = "";
            // 
            // rtb_BM_BACKUP2_THAY_THE
            // 
            this.rtb_BM_BACKUP2_THAY_THE.Location = new System.Drawing.Point(416, 167);
            this.rtb_BM_BACKUP2_THAY_THE.Name = "rtb_BM_BACKUP2_THAY_THE";
            this.rtb_BM_BACKUP2_THAY_THE.Size = new System.Drawing.Size(148, 64);
            this.rtb_BM_BACKUP2_THAY_THE.TabIndex = 88;
            this.rtb_BM_BACKUP2_THAY_THE.Text = "";
            // 
            // rtb_BM_BACKUP_THAY_THE
            // 
            this.rtb_BM_BACKUP_THAY_THE.Location = new System.Drawing.Point(416, 97);
            this.rtb_BM_BACKUP_THAY_THE.Name = "rtb_BM_BACKUP_THAY_THE";
            this.rtb_BM_BACKUP_THAY_THE.Size = new System.Drawing.Size(148, 64);
            this.rtb_BM_BACKUP_THAY_THE.TabIndex = 87;
            this.rtb_BM_BACKUP_THAY_THE.Text = "";
            // 
            // rtb_BM_THAY_THE
            // 
            this.rtb_BM_THAY_THE.Location = new System.Drawing.Point(416, 28);
            this.rtb_BM_THAY_THE.Name = "rtb_BM_THAY_THE";
            this.rtb_BM_THAY_THE.Size = new System.Drawing.Size(148, 64);
            this.rtb_BM_THAY_THE.TabIndex = 86;
            this.rtb_BM_THAY_THE.Text = "";
            // 
            // cmb_ADD_Tra_Truoc
            // 
            this.cmb_ADD_Tra_Truoc.FormattingEnabled = true;
            this.cmb_ADD_Tra_Truoc.Location = new System.Drawing.Point(688, 432);
            this.cmb_ADD_Tra_Truoc.Name = "cmb_ADD_Tra_Truoc";
            this.cmb_ADD_Tra_Truoc.Size = new System.Drawing.Size(77, 23);
            this.cmb_ADD_Tra_Truoc.TabIndex = 113;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(570, 438);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(112, 15);
            this.label34.TabIndex = 112;
            this.label34.Text = "ADD TRẢ TRƯỚC:";
            // 
            // gioi_han_close
            // 
            this.gioi_han_close.Location = new System.Drawing.Point(665, 503);
            this.gioi_han_close.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.gioi_han_close.Name = "gioi_han_close";
            this.gioi_han_close.Size = new System.Drawing.Size(85, 21);
            this.gioi_han_close.TabIndex = 111;
            this.gioi_han_close.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(574, 505);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(93, 15);
            this.label32.TabIndex = 110;
            this.label32.Text = "Giới Hạn Close:";
            // 
            // gioi_han_live
            // 
            this.gioi_han_live.Location = new System.Drawing.Point(479, 562);
            this.gioi_han_live.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.gioi_han_live.Name = "gioi_han_live";
            this.gioi_han_live.Size = new System.Drawing.Size(85, 21);
            this.gioi_han_live.TabIndex = 109;
            this.gioi_han_live.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(396, 564);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(85, 15);
            this.label31.TabIndex = 108;
            this.label31.Text = "Giới Hạn Live:";
            // 
            // gioi_han_1
            // 
            this.gioi_han_1.Location = new System.Drawing.Point(479, 533);
            this.gioi_han_1.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.gioi_han_1.Name = "gioi_han_1";
            this.gioi_han_1.Size = new System.Drawing.Size(85, 21);
            this.gioi_han_1.TabIndex = 107;
            this.gioi_han_1.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(406, 539);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(67, 15);
            this.label30.TabIndex = 106;
            this.label30.Text = "Giới hạn 1:";
            // 
            // delayshare
            // 
            this.delayshare.Location = new System.Drawing.Point(479, 503);
            this.delayshare.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.delayshare.Name = "delayshare";
            this.delayshare.Size = new System.Drawing.Size(85, 21);
            this.delayshare.TabIndex = 105;
            this.delayshare.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(396, 505);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(77, 15);
            this.label29.TabIndex = 104;
            this.label29.Text = "Delay Share:";
            // 
            // rtb_BM_PARTNER_THAY_THE
            // 
            this.rtb_BM_PARTNER_THAY_THE.Location = new System.Drawing.Point(416, 419);
            this.rtb_BM_PARTNER_THAY_THE.Name = "rtb_BM_PARTNER_THAY_THE";
            this.rtb_BM_PARTNER_THAY_THE.Size = new System.Drawing.Size(148, 64);
            this.rtb_BM_PARTNER_THAY_THE.TabIndex = 102;
            this.rtb_BM_PARTNER_THAY_THE.Text = "";
            // 
            // sl_Nhan_BM_CLOSE1_2
            // 
            this.sl_Nhan_BM_CLOSE1_2.Location = new System.Drawing.Point(607, 341);
            this.sl_Nhan_BM_CLOSE1_2.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.sl_Nhan_BM_CLOSE1_2.Name = "sl_Nhan_BM_CLOSE1_2";
            this.sl_Nhan_BM_CLOSE1_2.Size = new System.Drawing.Size(120, 21);
            this.sl_Nhan_BM_CLOSE1_2.TabIndex = 101;
            this.sl_Nhan_BM_CLOSE1_2.Value = new decimal(new int[] {
            3000,
            0,
            0,
            0});
            // 
            // sl_Nhan_BM_PARTNER
            // 
            this.sl_Nhan_BM_PARTNER.Location = new System.Drawing.Point(607, 368);
            this.sl_Nhan_BM_PARTNER.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.sl_Nhan_BM_PARTNER.Name = "sl_Nhan_BM_PARTNER";
            this.sl_Nhan_BM_PARTNER.Size = new System.Drawing.Size(120, 21);
            this.sl_Nhan_BM_PARTNER.TabIndex = 100;
            this.sl_Nhan_BM_PARTNER.Value = new decimal(new int[] {
            1500,
            0,
            0,
            0});
            // 
            // sl_nhan_Bm_BM_BACKUP
            // 
            this.sl_nhan_Bm_BM_BACKUP.Location = new System.Drawing.Point(607, 314);
            this.sl_nhan_Bm_BM_BACKUP.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.sl_nhan_Bm_BM_BACKUP.Name = "sl_nhan_Bm_BM_BACKUP";
            this.sl_nhan_Bm_BM_BACKUP.Size = new System.Drawing.Size(120, 21);
            this.sl_nhan_Bm_BM_BACKUP.TabIndex = 99;
            this.sl_nhan_Bm_BM_BACKUP.Value = new decimal(new int[] {
            1500,
            0,
            0,
            0});
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(396, 376);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(196, 15);
            this.label22.TabIndex = 98;
            this.label22.Text = "Số Lượng Nhận Vào BM PARTNER:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(396, 348);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(183, 15);
            this.label21.TabIndex = 97;
            this.label21.Text = "Số Lượng Nhận Vào BM CLOSE:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(396, 320);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(139, 15);
            this.label20.TabIndex = 96;
            this.label20.Text = "Số Lượng Nhận Vào BM:";
            // 
            // tx_So_Luong_Share_vao_bm
            // 
            this.tx_So_Luong_Share_vao_bm.Location = new System.Drawing.Point(227, 549);
            this.tx_So_Luong_Share_vao_bm.Name = "tx_So_Luong_Share_vao_bm";
            this.tx_So_Luong_Share_vao_bm.Size = new System.Drawing.Size(92, 21);
            this.tx_So_Luong_Share_vao_bm.TabIndex = 84;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(140, 552);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(81, 15);
            this.label33.TabIndex = 85;
            this.label33.Text = "Share DONE:";
            // 
            // tb_so_luong_BM_PARTNER
            // 
            this.tb_so_luong_BM_PARTNER.Location = new System.Drawing.Point(271, 405);
            this.tb_so_luong_BM_PARTNER.Name = "tb_so_luong_BM_PARTNER";
            this.tb_so_luong_BM_PARTNER.Size = new System.Drawing.Size(100, 21);
            this.tb_so_luong_BM_PARTNER.TabIndex = 83;
            // 
            // tb_BM_Close_4
            // 
            this.tb_BM_Close_4.Location = new System.Drawing.Point(271, 356);
            this.tb_BM_Close_4.Name = "tb_BM_Close_4";
            this.tb_BM_Close_4.Size = new System.Drawing.Size(100, 21);
            this.tb_BM_Close_4.TabIndex = 82;
            // 
            // tb_BM_Close_3
            // 
            this.tb_BM_Close_3.Location = new System.Drawing.Point(271, 306);
            this.tb_BM_Close_3.Name = "tb_BM_Close_3";
            this.tb_BM_Close_3.Size = new System.Drawing.Size(100, 21);
            this.tb_BM_Close_3.TabIndex = 81;
            // 
            // tb_BM_Close_2
            // 
            this.tb_BM_Close_2.Location = new System.Drawing.Point(271, 258);
            this.tb_BM_Close_2.Name = "tb_BM_Close_2";
            this.tb_BM_Close_2.Size = new System.Drawing.Size(100, 21);
            this.tb_BM_Close_2.TabIndex = 80;
            // 
            // tb_BM_Close1
            // 
            this.tb_BM_Close1.Location = new System.Drawing.Point(271, 208);
            this.tb_BM_Close1.Name = "tb_BM_Close1";
            this.tb_BM_Close1.Size = new System.Drawing.Size(100, 21);
            this.tb_BM_Close1.TabIndex = 79;
            // 
            // tb_BM_BACK_UP3
            // 
            this.tb_BM_BACK_UP3.Location = new System.Drawing.Point(271, 159);
            this.tb_BM_BACK_UP3.Name = "tb_BM_BACK_UP3";
            this.tb_BM_BACK_UP3.Size = new System.Drawing.Size(100, 21);
            this.tb_BM_BACK_UP3.TabIndex = 78;
            // 
            // tb_BM_BACK_UP2
            // 
            this.tb_BM_BACK_UP2.Location = new System.Drawing.Point(271, 109);
            this.tb_BM_BACK_UP2.Name = "tb_BM_BACK_UP2";
            this.tb_BM_BACK_UP2.Size = new System.Drawing.Size(100, 21);
            this.tb_BM_BACK_UP2.TabIndex = 77;
            // 
            // tb_BM_BACK_UP
            // 
            this.tb_BM_BACK_UP.Location = new System.Drawing.Point(271, 61);
            this.tb_BM_BACK_UP.Name = "tb_BM_BACK_UP";
            this.tb_BM_BACK_UP.Size = new System.Drawing.Size(100, 21);
            this.tb_BM_BACK_UP.TabIndex = 76;
            // 
            // tb_BM
            // 
            this.tb_BM.Location = new System.Drawing.Point(271, 11);
            this.tb_BM.Name = "tb_BM";
            this.tb_BM.Size = new System.Drawing.Size(100, 21);
            this.tb_BM.TabIndex = 75;
            // 
            // rtb_IDBM_PARTNER
            // 
            this.rtb_IDBM_PARTNER.Location = new System.Drawing.Point(81, 396);
            this.rtb_IDBM_PARTNER.Name = "rtb_IDBM_PARTNER";
            this.rtb_IDBM_PARTNER.Size = new System.Drawing.Size(140, 40);
            this.rtb_IDBM_PARTNER.TabIndex = 74;
            this.rtb_IDBM_PARTNER.Text = "";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(7, 408);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(78, 15);
            this.label23.TabIndex = 73;
            this.label23.Text = "IDPARTNER:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(227, 14);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(36, 15);
            this.label17.TabIndex = 72;
            this.label17.Text = "STK:";
            // 
            // rtb_IDBM_CLOSE_4
            // 
            this.rtb_IDBM_CLOSE_4.Location = new System.Drawing.Point(81, 347);
            this.rtb_IDBM_CLOSE_4.Name = "rtb_IDBM_CLOSE_4";
            this.rtb_IDBM_CLOSE_4.Size = new System.Drawing.Size(140, 40);
            this.rtb_IDBM_CLOSE_4.TabIndex = 71;
            this.rtb_IDBM_CLOSE_4.Text = "";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(7, 359);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(71, 15);
            this.label13.TabIndex = 70;
            this.label13.Text = "IDCLOSE4:";
            // 
            // rtb_IDBM_CLOSE_3
            // 
            this.rtb_IDBM_CLOSE_3.Location = new System.Drawing.Point(81, 297);
            this.rtb_IDBM_CLOSE_3.Name = "rtb_IDBM_CLOSE_3";
            this.rtb_IDBM_CLOSE_3.Size = new System.Drawing.Size(140, 40);
            this.rtb_IDBM_CLOSE_3.TabIndex = 69;
            this.rtb_IDBM_CLOSE_3.Text = "";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(7, 309);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(71, 15);
            this.label14.TabIndex = 68;
            this.label14.Text = "IDCLOSE3:";
            // 
            // rtb_IDBM_CLOSE_2
            // 
            this.rtb_IDBM_CLOSE_2.Location = new System.Drawing.Point(81, 249);
            this.rtb_IDBM_CLOSE_2.Name = "rtb_IDBM_CLOSE_2";
            this.rtb_IDBM_CLOSE_2.Size = new System.Drawing.Size(140, 40);
            this.rtb_IDBM_CLOSE_2.TabIndex = 67;
            this.rtb_IDBM_CLOSE_2.Text = "";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(7, 261);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(71, 15);
            this.label15.TabIndex = 66;
            this.label15.Text = "IDCLOSE2:";
            // 
            // rtb_IDBM_CLOSE
            // 
            this.rtb_IDBM_CLOSE.Location = new System.Drawing.Point(81, 199);
            this.rtb_IDBM_CLOSE.Name = "rtb_IDBM_CLOSE";
            this.rtb_IDBM_CLOSE.Size = new System.Drawing.Size(140, 40);
            this.rtb_IDBM_CLOSE.TabIndex = 65;
            this.rtb_IDBM_CLOSE.Text = "";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(7, 211);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(71, 15);
            this.label16.TabIndex = 64;
            this.label16.Text = "IDCLOSE1:";
            // 
            // rtb_ID_BM_Share_BACK_UP3
            // 
            this.rtb_ID_BM_Share_BACK_UP3.Location = new System.Drawing.Point(81, 150);
            this.rtb_ID_BM_Share_BACK_UP3.Name = "rtb_ID_BM_Share_BACK_UP3";
            this.rtb_ID_BM_Share_BACK_UP3.Size = new System.Drawing.Size(140, 40);
            this.rtb_ID_BM_Share_BACK_UP3.TabIndex = 63;
            this.rtb_ID_BM_Share_BACK_UP3.Text = "";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(7, 162);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 15);
            this.label11.TabIndex = 62;
            this.label11.Text = "IDBM4:";
            // 
            // rtb_ID_BM_Share_BACK_UP2
            // 
            this.rtb_ID_BM_Share_BACK_UP2.Location = new System.Drawing.Point(81, 100);
            this.rtb_ID_BM_Share_BACK_UP2.Name = "rtb_ID_BM_Share_BACK_UP2";
            this.rtb_ID_BM_Share_BACK_UP2.Size = new System.Drawing.Size(140, 40);
            this.rtb_ID_BM_Share_BACK_UP2.TabIndex = 61;
            this.rtb_ID_BM_Share_BACK_UP2.Text = "";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(7, 112);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(49, 15);
            this.label12.TabIndex = 60;
            this.label12.Text = "IDBM3:";
            // 
            // rtb_ID_BM_Share_BACK_UP
            // 
            this.rtb_ID_BM_Share_BACK_UP.Location = new System.Drawing.Point(81, 52);
            this.rtb_ID_BM_Share_BACK_UP.Name = "rtb_ID_BM_Share_BACK_UP";
            this.rtb_ID_BM_Share_BACK_UP.Size = new System.Drawing.Size(140, 40);
            this.rtb_ID_BM_Share_BACK_UP.TabIndex = 59;
            this.rtb_ID_BM_Share_BACK_UP.Text = "";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 64);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(49, 15);
            this.label10.TabIndex = 58;
            this.label10.Text = "IDBM2:";
            // 
            // rtb_ID_BM_Share
            // 
            this.rtb_ID_BM_Share.Location = new System.Drawing.Point(81, 2);
            this.rtb_ID_BM_Share.Name = "rtb_ID_BM_Share";
            this.rtb_ID_BM_Share.Size = new System.Drawing.Size(140, 40);
            this.rtb_ID_BM_Share.TabIndex = 57;
            this.rtb_ID_BM_Share.Text = "";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 14);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 15);
            this.label9.TabIndex = 56;
            this.label9.Text = "IDBM1:";
            // 
            // tb_sl_282
            // 
            this.tb_sl_282.Location = new System.Drawing.Point(42, 550);
            this.tb_sl_282.Name = "tb_sl_282";
            this.tb_sl_282.Size = new System.Drawing.Size(92, 21);
            this.tb_sl_282.TabIndex = 55;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(7, 553);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 15);
            this.label8.TabIndex = 54;
            this.label8.Text = "282:";
            // 
            // cmb_CLOSE_SHARE
            // 
            this.cmb_CLOSE_SHARE.FormattingEnabled = true;
            this.cmb_CLOSE_SHARE.Location = new System.Drawing.Point(101, 515);
            this.cmb_CLOSE_SHARE.Name = "cmb_CLOSE_SHARE";
            this.cmb_CLOSE_SHARE.Size = new System.Drawing.Size(92, 23);
            this.cmb_CLOSE_SHARE.TabIndex = 53;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 518);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 15);
            this.label3.TabIndex = 52;
            this.label3.Text = "Share CLONE:";
            // 
            // cmb_User_Agent
            // 
            this.cmb_User_Agent.FormattingEnabled = true;
            this.cmb_User_Agent.Location = new System.Drawing.Point(101, 478);
            this.cmb_User_Agent.Name = "cmb_User_Agent";
            this.cmb_User_Agent.Size = new System.Drawing.Size(274, 23);
            this.cmb_User_Agent.TabIndex = 51;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(7, 481);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 15);
            this.label2.TabIndex = 50;
            this.label2.Text = "User_Agent:";
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.tabPage7.Controls.Add(this.label55);
            this.tabPage7.Controls.Add(this.rtb_MAIL_SHARE_CLONE);
            this.tabPage7.Controls.Add(this.groupBox1);
            this.tabPage7.Location = new System.Drawing.Point(4, 24);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(1753, 667);
            this.tabPage7.TabIndex = 1;
            this.tabPage7.Text = "BM";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(318, 18);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(105, 15);
            this.label55.TabIndex = 76;
            this.label55.Text = "MAIL SHARE BM:";
            // 
            // rtb_MAIL_SHARE_CLONE
            // 
            this.rtb_MAIL_SHARE_CLONE.Location = new System.Drawing.Point(321, 36);
            this.rtb_MAIL_SHARE_CLONE.Name = "rtb_MAIL_SHARE_CLONE";
            this.rtb_MAIL_SHARE_CLONE.Size = new System.Drawing.Size(302, 166);
            this.rtb_MAIL_SHARE_CLONE.TabIndex = 75;
            this.rtb_MAIL_SHARE_CLONE.Text = "";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmb_Share_DOI_TAC);
            this.groupBox1.Controls.Add(this.label57);
            this.groupBox1.Controls.Add(this.cmb_Share_BM_CLone);
            this.groupBox1.Controls.Add(this.label54);
            this.groupBox1.Controls.Add(this.cmb_Mui_Gio_TK_BM);
            this.groupBox1.Controls.Add(this.label53);
            this.groupBox1.Controls.Add(this.cmb_TEN_TK_BM);
            this.groupBox1.Controls.Add(this.label52);
            this.groupBox1.Controls.Add(this.cmb_Tien_Te_TK_BM);
            this.groupBox1.Controls.Add(this.label51);
            this.groupBox1.Controls.Add(this.delay_reg_bm);
            this.groupBox1.Controls.Add(this.for_reg_bm);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.cmb_Tao_TK_BM);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.cmb_REG_BM_Clone_API);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new System.Drawing.Point(28, 32);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(264, 512);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "REG BM";
            // 
            // cmb_Share_DOI_TAC
            // 
            this.cmb_Share_DOI_TAC.FormattingEnabled = true;
            this.cmb_Share_DOI_TAC.Location = new System.Drawing.Point(120, 330);
            this.cmb_Share_DOI_TAC.Name = "cmb_Share_DOI_TAC";
            this.cmb_Share_DOI_TAC.Size = new System.Drawing.Size(122, 23);
            this.cmb_Share_DOI_TAC.TabIndex = 22;
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(6, 333);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(108, 15);
            this.label57.TabIndex = 21;
            this.label57.Text = "SHARE PARTNER:";
            // 
            // cmb_Share_BM_CLone
            // 
            this.cmb_Share_BM_CLone.FormattingEnabled = true;
            this.cmb_Share_BM_CLone.Location = new System.Drawing.Point(86, 301);
            this.cmb_Share_BM_CLone.Name = "cmb_Share_BM_CLone";
            this.cmb_Share_BM_CLone.Size = new System.Drawing.Size(122, 23);
            this.cmb_Share_BM_CLone.TabIndex = 20;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(7, 307);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(73, 15);
            this.label54.TabIndex = 19;
            this.label54.Text = "SHARE BM:";
            // 
            // cmb_Mui_Gio_TK_BM
            // 
            this.cmb_Mui_Gio_TK_BM.FormattingEnabled = true;
            this.cmb_Mui_Gio_TK_BM.Location = new System.Drawing.Point(86, 270);
            this.cmb_Mui_Gio_TK_BM.Name = "cmb_Mui_Gio_TK_BM";
            this.cmb_Mui_Gio_TK_BM.Size = new System.Drawing.Size(122, 23);
            this.cmb_Mui_Gio_TK_BM.TabIndex = 18;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(22, 272);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(56, 15);
            this.label53.TabIndex = 17;
            this.label53.Text = "Múi Giờ:";
            // 
            // cmb_TEN_TK_BM
            // 
            this.cmb_TEN_TK_BM.FormattingEnabled = true;
            this.cmb_TEN_TK_BM.Location = new System.Drawing.Point(86, 238);
            this.cmb_TEN_TK_BM.Name = "cmb_TEN_TK_BM";
            this.cmb_TEN_TK_BM.Size = new System.Drawing.Size(122, 23);
            this.cmb_TEN_TK_BM.TabIndex = 16;
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(6, 241);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(74, 15);
            this.label52.TabIndex = 15;
            this.label52.Text = "Tên TK BM:";
            // 
            // cmb_Tien_Te_TK_BM
            // 
            this.cmb_Tien_Te_TK_BM.FormattingEnabled = true;
            this.cmb_Tien_Te_TK_BM.Location = new System.Drawing.Point(86, 203);
            this.cmb_Tien_Te_TK_BM.Name = "cmb_Tien_Te_TK_BM";
            this.cmb_Tien_Te_TK_BM.Size = new System.Drawing.Size(122, 23);
            this.cmb_Tien_Te_TK_BM.TabIndex = 14;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(21, 209);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(53, 15);
            this.label51.TabIndex = 13;
            this.label51.Text = "Tiền Tệ:";
            // 
            // delay_reg_bm
            // 
            this.delay_reg_bm.Location = new System.Drawing.Point(86, 161);
            this.delay_reg_bm.Name = "delay_reg_bm";
            this.delay_reg_bm.Size = new System.Drawing.Size(120, 21);
            this.delay_reg_bm.TabIndex = 12;
            // 
            // for_reg_bm
            // 
            this.for_reg_bm.Location = new System.Drawing.Point(86, 123);
            this.for_reg_bm.Name = "for_reg_bm";
            this.for_reg_bm.Size = new System.Drawing.Size(120, 21);
            this.for_reg_bm.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(21, 165);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 15);
            this.label7.TabIndex = 10;
            this.label7.Text = "Delay:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(21, 126);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(29, 15);
            this.label6.TabIndex = 8;
            this.label6.Text = "For:";
            // 
            // cmb_Tao_TK_BM
            // 
            this.cmb_Tao_TK_BM.FormattingEnabled = true;
            this.cmb_Tao_TK_BM.Location = new System.Drawing.Point(84, 83);
            this.cmb_Tao_TK_BM.Name = "cmb_Tao_TK_BM";
            this.cmb_Tao_TK_BM.Size = new System.Drawing.Size(122, 23);
            this.cmb_Tao_TK_BM.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(21, 86);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 15);
            this.label5.TabIndex = 6;
            this.label5.Text = "Tạo TK:";
            // 
            // cmb_REG_BM_Clone_API
            // 
            this.cmb_REG_BM_Clone_API.FormattingEnabled = true;
            this.cmb_REG_BM_Clone_API.Location = new System.Drawing.Point(84, 36);
            this.cmb_REG_BM_Clone_API.Name = "cmb_REG_BM_Clone_API";
            this.cmb_REG_BM_Clone_API.Size = new System.Drawing.Size(122, 23);
            this.cmb_REG_BM_Clone_API.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 15);
            this.label4.TabIndex = 4;
            this.label4.Text = "ON/OFF:";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Silver;
            this.tabPage3.Controls.Add(this.groupBox2);
            this.tabPage3.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage3.Location = new System.Drawing.Point(4, 24);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1767, 688);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "DongVan.Net";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label44);
            this.groupBox2.Controls.Add(this.cmb_noveri);
            this.groupBox2.Controls.Add(this.label41);
            this.groupBox2.Controls.Add(this.cmb_DONG_VAN);
            this.groupBox2.Controls.Add(this.cmb_ID_MAIL);
            this.groupBox2.Controls.Add(this.label40);
            this.groupBox2.Controls.Add(this.label39);
            this.groupBox2.Controls.Add(this.soluong_mua_Mail);
            this.groupBox2.Controls.Add(this.label38);
            this.groupBox2.Controls.Add(this.tb_so_du_DongVan);
            this.groupBox2.Controls.Add(this.Tx_Key_API_DongVan);
            this.groupBox2.Controls.Add(this.label37);
            this.groupBox2.Controls.Add(this.tx_MK_Dong_Vanox2);
            this.groupBox2.Controls.Add(this.tx_TK_Dong_Van);
            this.groupBox2.Controls.Add(this.label36);
            this.groupBox2.Controls.Add(this.label35);
            this.groupBox2.Location = new System.Drawing.Point(35, 65);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(505, 229);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(288, 144);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(63, 15);
            this.label44.TabIndex = 23;
            this.label44.Text = "NO VERI :";
            // 
            // cmb_noveri
            // 
            this.cmb_noveri.FormattingEnabled = true;
            this.cmb_noveri.Location = new System.Drawing.Point(356, 141);
            this.cmb_noveri.Name = "cmb_noveri";
            this.cmb_noveri.Size = new System.Drawing.Size(121, 23);
            this.cmb_noveri.TabIndex = 22;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(300, 106);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(50, 15);
            this.label41.TabIndex = 21;
            this.label41.Text = "ON/FF :";
            // 
            // cmb_DONG_VAN
            // 
            this.cmb_DONG_VAN.FormattingEnabled = true;
            this.cmb_DONG_VAN.Location = new System.Drawing.Point(356, 103);
            this.cmb_DONG_VAN.Name = "cmb_DONG_VAN";
            this.cmb_DONG_VAN.Size = new System.Drawing.Size(121, 23);
            this.cmb_DONG_VAN.TabIndex = 20;
            // 
            // cmb_ID_MAIL
            // 
            this.cmb_ID_MAIL.FormattingEnabled = true;
            this.cmb_ID_MAIL.Location = new System.Drawing.Point(356, 74);
            this.cmb_ID_MAIL.Name = "cmb_ID_MAIL";
            this.cmb_ID_MAIL.Size = new System.Drawing.Size(121, 23);
            this.cmb_ID_MAIL.TabIndex = 19;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(327, 78);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(24, 15);
            this.label40.TabIndex = 18;
            this.label40.Text = "ID:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(262, 50);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(89, 15);
            this.label39.TabIndex = 17;
            this.label39.Text = "Số Lượng Mua:";
            // 
            // soluong_mua_Mail
            // 
            this.soluong_mua_Mail.Location = new System.Drawing.Point(357, 48);
            this.soluong_mua_Mail.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.soluong_mua_Mail.Name = "soluong_mua_Mail";
            this.soluong_mua_Mail.Size = new System.Drawing.Size(120, 21);
            this.soluong_mua_Mail.TabIndex = 16;
            this.soluong_mua_Mail.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(8, 134);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(44, 15);
            this.label38.TabIndex = 15;
            this.label38.Text = "Số Dư:";
            // 
            // tb_so_du_DongVan
            // 
            this.tb_so_du_DongVan.Location = new System.Drawing.Point(78, 131);
            this.tb_so_du_DongVan.Name = "tb_so_du_DongVan";
            this.tb_so_du_DongVan.Size = new System.Drawing.Size(149, 21);
            this.tb_so_du_DongVan.TabIndex = 14;
            // 
            // Tx_Key_API_DongVan
            // 
            this.Tx_Key_API_DongVan.Location = new System.Drawing.Point(78, 103);
            this.Tx_Key_API_DongVan.Name = "Tx_Key_API_DongVan";
            this.Tx_Key_API_DongVan.Size = new System.Drawing.Size(149, 21);
            this.Tx_Key_API_DongVan.TabIndex = 13;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(11, 109);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(53, 15);
            this.label37.TabIndex = 12;
            this.label37.Text = "Key API:";
            // 
            // tx_MK_Dong_Vanox2
            // 
            this.tx_MK_Dong_Vanox2.Location = new System.Drawing.Point(78, 74);
            this.tx_MK_Dong_Vanox2.Name = "tx_MK_Dong_Vanox2";
            this.tx_MK_Dong_Vanox2.Size = new System.Drawing.Size(149, 21);
            this.tx_MK_Dong_Vanox2.TabIndex = 11;
            // 
            // tx_TK_Dong_Van
            // 
            this.tx_TK_Dong_Van.Location = new System.Drawing.Point(78, 47);
            this.tx_TK_Dong_Van.Name = "tx_TK_Dong_Van";
            this.tx_TK_Dong_Van.Size = new System.Drawing.Size(149, 21);
            this.tx_TK_Dong_Van.TabIndex = 10;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(35, 74);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(29, 15);
            this.label36.TabIndex = 9;
            this.label36.Text = "Mk:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(35, 50);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(26, 15);
            this.label35.TabIndex = 8;
            this.label35.Text = "Tk:";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.DimGray;
            this.tabPage4.Controls.Add(this.dgv2_IG);
            this.tabPage4.Controls.Add(this.dgv_mail);
            this.tabPage4.Location = new System.Drawing.Point(4, 24);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1767, 688);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "IG_99";
            // 
            // dgv2_IG
            // 
            this.dgv2_IG.AllowUserToAddRows = false;
            this.dgv2_IG.AllowUserToDeleteRows = false;
            this.dgv2_IG.AllowUserToResizeRows = false;
            this.dgv2_IG.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv2_IG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv2_IG.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cStt2,
            this.cIG,
            this.cStatus2,
            this.cSelect2});
            this.dgv2_IG.ContextMenuStrip = this.contextMenuStrip3;
            this.dgv2_IG.Location = new System.Drawing.Point(758, 6);
            this.dgv2_IG.Name = "dgv2_IG";
            this.dgv2_IG.RowHeadersVisible = false;
            this.dgv2_IG.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgv2_IG.Size = new System.Drawing.Size(767, 596);
            this.dgv2_IG.TabIndex = 1;
            this.dgv2_IG.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgv2_IG_CellFormatting);
            // 
            // cStt2
            // 
            this.cStt2.FillWeight = 30F;
            this.cStt2.HeaderText = "STT";
            this.cStt2.Name = "cStt2";
            // 
            // cIG
            // 
            this.cIG.FillWeight = 200F;
            this.cIG.HeaderText = "IG";
            this.cIG.Name = "cIG";
            // 
            // cStatus2
            // 
            this.cStatus2.FillWeight = 200F;
            this.cStatus2.HeaderText = "STATUS";
            this.cStatus2.Name = "cStatus2";
            // 
            // cSelect2
            // 
            this.cSelect2.FillWeight = 20F;
            this.cSelect2.HeaderText = "";
            this.cSelect2.Name = "cSelect2";
            // 
            // contextMenuStrip3
            // 
            this.contextMenuStrip3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chọnToolStripMenuItem2,
            this.bỏChọnToolStripMenuItem2,
            this.xóaToolStripMenuItem2});
            this.contextMenuStrip3.Name = "contextMenuStrip3";
            this.contextMenuStrip3.Size = new System.Drawing.Size(121, 70);
            // 
            // chọnToolStripMenuItem2
            // 
            this.chọnToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bôiĐenToolStripMenuItem4,
            this.tấtCảToolStripMenuItem5});
            this.chọnToolStripMenuItem2.Name = "chọnToolStripMenuItem2";
            this.chọnToolStripMenuItem2.Size = new System.Drawing.Size(120, 22);
            this.chọnToolStripMenuItem2.Text = "Chọn";
            // 
            // bôiĐenToolStripMenuItem4
            // 
            this.bôiĐenToolStripMenuItem4.Name = "bôiĐenToolStripMenuItem4";
            this.bôiĐenToolStripMenuItem4.Size = new System.Drawing.Size(114, 22);
            this.bôiĐenToolStripMenuItem4.Text = "Bôi đen";
            this.bôiĐenToolStripMenuItem4.Click += new System.EventHandler(this.bôiĐenToolStripMenuItem4_Click);
            // 
            // tấtCảToolStripMenuItem5
            // 
            this.tấtCảToolStripMenuItem5.Name = "tấtCảToolStripMenuItem5";
            this.tấtCảToolStripMenuItem5.Size = new System.Drawing.Size(114, 22);
            this.tấtCảToolStripMenuItem5.Text = "Tất Cả";
            this.tấtCảToolStripMenuItem5.Click += new System.EventHandler(this.tấtCảToolStripMenuItem5_Click);
            // 
            // bỏChọnToolStripMenuItem2
            // 
            this.bỏChọnToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bôiĐenToolStripMenuItem5,
            this.tấtCảToolStripMenuItem6});
            this.bỏChọnToolStripMenuItem2.Name = "bỏChọnToolStripMenuItem2";
            this.bỏChọnToolStripMenuItem2.Size = new System.Drawing.Size(120, 22);
            this.bỏChọnToolStripMenuItem2.Text = "Bỏ Chọn";
            // 
            // bôiĐenToolStripMenuItem5
            // 
            this.bôiĐenToolStripMenuItem5.Name = "bôiĐenToolStripMenuItem5";
            this.bôiĐenToolStripMenuItem5.Size = new System.Drawing.Size(115, 22);
            this.bôiĐenToolStripMenuItem5.Text = "Bôi Đen";
            this.bôiĐenToolStripMenuItem5.Click += new System.EventHandler(this.bôiĐenToolStripMenuItem5_Click);
            // 
            // tấtCảToolStripMenuItem6
            // 
            this.tấtCảToolStripMenuItem6.Name = "tấtCảToolStripMenuItem6";
            this.tấtCảToolStripMenuItem6.Size = new System.Drawing.Size(115, 22);
            this.tấtCảToolStripMenuItem6.Text = "Tất Cả";
            this.tấtCảToolStripMenuItem6.Click += new System.EventHandler(this.tấtCảToolStripMenuItem6_Click);
            // 
            // xóaToolStripMenuItem2
            // 
            this.xóaToolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bôiĐenToolStripMenuItem6,
            this.tấtCảToolStripMenuItem7});
            this.xóaToolStripMenuItem2.Name = "xóaToolStripMenuItem2";
            this.xóaToolStripMenuItem2.Size = new System.Drawing.Size(120, 22);
            this.xóaToolStripMenuItem2.Text = "Xóa";
            // 
            // bôiĐenToolStripMenuItem6
            // 
            this.bôiĐenToolStripMenuItem6.Name = "bôiĐenToolStripMenuItem6";
            this.bôiĐenToolStripMenuItem6.Size = new System.Drawing.Size(152, 22);
            this.bôiĐenToolStripMenuItem6.Text = "Dòng Đã Chọn";
            this.bôiĐenToolStripMenuItem6.Click += new System.EventHandler(this.bôiĐenToolStripMenuItem6_Click);
            // 
            // tấtCảToolStripMenuItem7
            // 
            this.tấtCảToolStripMenuItem7.Name = "tấtCảToolStripMenuItem7";
            this.tấtCảToolStripMenuItem7.Size = new System.Drawing.Size(152, 22);
            this.tấtCảToolStripMenuItem7.Text = "Tất Cả";
            this.tấtCảToolStripMenuItem7.Click += new System.EventHandler(this.tấtCảToolStripMenuItem7_Click);
            // 
            // dgv_mail
            // 
            this.dgv_mail.AllowUserToAddRows = false;
            this.dgv_mail.AllowUserToDeleteRows = false;
            this.dgv_mail.AllowUserToResizeRows = false;
            this.dgv_mail.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_mail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_mail.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cStt1,
            this.cMail1,
            this.cPassMail1,
            this.cToken,
            this.cStatus1,
            this.cSelect1});
            this.dgv_mail.ContextMenuStrip = this.contextMenuStrip2;
            this.dgv_mail.Location = new System.Drawing.Point(6, 6);
            this.dgv_mail.Name = "dgv_mail";
            this.dgv_mail.RowHeadersVisible = false;
            this.dgv_mail.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dgv_mail.Size = new System.Drawing.Size(746, 596);
            this.dgv_mail.TabIndex = 0;
            this.dgv_mail.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_mail_CellContentClick);
            this.dgv_mail.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgv_mail_CellFormatting);
            this.dgv_mail.KeyDown += new System.Windows.Forms.KeyEventHandler(this.dgv_mail_KeyDown);
            // 
            // cStt1
            // 
            this.cStt1.FillWeight = 30F;
            this.cStt1.HeaderText = "STT";
            this.cStt1.Name = "cStt1";
            // 
            // cMail1
            // 
            this.cMail1.HeaderText = "MAIL";
            this.cMail1.Name = "cMail1";
            // 
            // cPassMail1
            // 
            this.cPassMail1.HeaderText = "PASSMAIL";
            this.cPassMail1.Name = "cPassMail1";
            // 
            // cToken
            // 
            this.cToken.HeaderText = "Token";
            this.cToken.Name = "cToken";
            // 
            // cStatus1
            // 
            this.cStatus1.FillWeight = 200F;
            this.cStatus1.HeaderText = "STATUS";
            this.cStatus1.Name = "cStatus1";
            // 
            // cSelect1
            // 
            this.cSelect1.FillWeight = 20F;
            this.cSelect1.HeaderText = "";
            this.cSelect1.Name = "cSelect1";
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chọnToolStripMenuItem1,
            this.bỏChọnToolStripMenuItem1,
            this.xóaToolStripMenuItem1});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(121, 70);
            // 
            // chọnToolStripMenuItem1
            // 
            this.chọnToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bôiĐenToolStripMenuItem2,
            this.tấtCảToolStripMenuItem3});
            this.chọnToolStripMenuItem1.Name = "chọnToolStripMenuItem1";
            this.chọnToolStripMenuItem1.Size = new System.Drawing.Size(120, 22);
            this.chọnToolStripMenuItem1.Text = "Chọn";
            // 
            // bôiĐenToolStripMenuItem2
            // 
            this.bôiĐenToolStripMenuItem2.Name = "bôiĐenToolStripMenuItem2";
            this.bôiĐenToolStripMenuItem2.Size = new System.Drawing.Size(115, 22);
            this.bôiĐenToolStripMenuItem2.Text = "Bôi Đen";
            this.bôiĐenToolStripMenuItem2.Click += new System.EventHandler(this.bôiĐenToolStripMenuItem2_Click);
            // 
            // tấtCảToolStripMenuItem3
            // 
            this.tấtCảToolStripMenuItem3.Name = "tấtCảToolStripMenuItem3";
            this.tấtCảToolStripMenuItem3.Size = new System.Drawing.Size(115, 22);
            this.tấtCảToolStripMenuItem3.Text = "Tất Cả";
            this.tấtCảToolStripMenuItem3.Click += new System.EventHandler(this.tấtCảToolStripMenuItem3_Click);
            // 
            // bỏChọnToolStripMenuItem1
            // 
            this.bỏChọnToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bôiĐenToolStripMenuItem3,
            this.tấtCảToolStripMenuItem4});
            this.bỏChọnToolStripMenuItem1.Name = "bỏChọnToolStripMenuItem1";
            this.bỏChọnToolStripMenuItem1.Size = new System.Drawing.Size(120, 22);
            this.bỏChọnToolStripMenuItem1.Text = "Bỏ Chọn";
            // 
            // bôiĐenToolStripMenuItem3
            // 
            this.bôiĐenToolStripMenuItem3.Name = "bôiĐenToolStripMenuItem3";
            this.bôiĐenToolStripMenuItem3.Size = new System.Drawing.Size(114, 22);
            this.bôiĐenToolStripMenuItem3.Text = "Bôi đen";
            this.bôiĐenToolStripMenuItem3.Click += new System.EventHandler(this.bôiĐenToolStripMenuItem3_Click);
            // 
            // tấtCảToolStripMenuItem4
            // 
            this.tấtCảToolStripMenuItem4.Name = "tấtCảToolStripMenuItem4";
            this.tấtCảToolStripMenuItem4.Size = new System.Drawing.Size(114, 22);
            this.tấtCảToolStripMenuItem4.Text = "Tất Cả";
            this.tấtCảToolStripMenuItem4.Click += new System.EventHandler(this.tấtCảToolStripMenuItem4_Click);
            // 
            // xóaToolStripMenuItem1
            // 
            this.xóaToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dòngĐãChọnToolStripMenuItem1,
            this.tấtCảToolStripMenuItem8});
            this.xóaToolStripMenuItem1.Name = "xóaToolStripMenuItem1";
            this.xóaToolStripMenuItem1.Size = new System.Drawing.Size(120, 22);
            this.xóaToolStripMenuItem1.Text = "Xóa";
            // 
            // dòngĐãChọnToolStripMenuItem1
            // 
            this.dòngĐãChọnToolStripMenuItem1.Name = "dòngĐãChọnToolStripMenuItem1";
            this.dòngĐãChọnToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.dòngĐãChọnToolStripMenuItem1.Text = "Dòng Đã Chọn";
            this.dòngĐãChọnToolStripMenuItem1.Click += new System.EventHandler(this.dòngĐãChọnToolStripMenuItem1_Click);
            // 
            // tấtCảToolStripMenuItem8
            // 
            this.tấtCảToolStripMenuItem8.Name = "tấtCảToolStripMenuItem8";
            this.tấtCảToolStripMenuItem8.Size = new System.Drawing.Size(152, 22);
            this.tấtCảToolStripMenuItem8.Text = "Tất Cả";
            this.tấtCảToolStripMenuItem8.Click += new System.EventHandler(this.tấtCảToolStripMenuItem8_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.Gray;
            this.tabPage5.Controls.Add(this.tabControl6);
            this.tabPage5.Controls.Add(this.groupBox8);
            this.tabPage5.Controls.Add(this.groupBox4);
            this.tabPage5.Location = new System.Drawing.Point(4, 24);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1767, 688);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Cài Đặt IG";
            // 
            // tabControl6
            // 
            this.tabControl6.Controls.Add(this.tabPage23);
            this.tabControl6.Controls.Add(this.tabPage24);
            this.tabControl6.Controls.Add(this.tabPage25);
            this.tabControl6.Location = new System.Drawing.Point(6, 6);
            this.tabControl6.Name = "tabControl6";
            this.tabControl6.SelectedIndex = 0;
            this.tabControl6.Size = new System.Drawing.Size(456, 330);
            this.tabControl6.TabIndex = 30;
            // 
            // tabPage23
            // 
            this.tabPage23.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage23.Controls.Add(this.groupBox3);
            this.tabPage23.Location = new System.Drawing.Point(4, 24);
            this.tabPage23.Name = "tabPage23";
            this.tabPage23.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage23.Size = new System.Drawing.Size(448, 302);
            this.tabPage23.TabIndex = 0;
            this.tabPage23.Text = "REGIG";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label175);
            this.groupBox3.Controls.Add(this.cmb_REG_BM_IG_API_CHROME);
            this.groupBox3.Controls.Add(this.tb_ID_UP);
            this.groupBox3.Controls.Add(this.label140);
            this.groupBox3.Controls.Add(this.label139);
            this.groupBox3.Controls.Add(this.label138);
            this.groupBox3.Controls.Add(this.tb_MK_NAM);
            this.groupBox3.Controls.Add(this.tb_TK_NAM);
            this.groupBox3.Controls.Add(this.cmb_UP_WEB);
            this.groupBox3.Controls.Add(this.label137);
            this.groupBox3.Controls.Add(this.label43);
            this.groupBox3.Controls.Add(this.label47);
            this.groupBox3.Controls.Add(this.cmb_IP);
            this.groupBox3.Controls.Add(this.label48);
            this.groupBox3.Controls.Add(this.cmb_REGHOTMAIL);
            this.groupBox3.Controls.Add(this.cmb_VN_US);
            this.groupBox3.Location = new System.Drawing.Point(2, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(440, 290);
            this.groupBox3.TabIndex = 27;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "REGIG";
            // 
            // label175
            // 
            this.label175.AutoSize = true;
            this.label175.Location = new System.Drawing.Point(70, 29);
            this.label175.Name = "label175";
            this.label175.Size = new System.Drawing.Size(87, 15);
            this.label175.TabIndex = 40;
            this.label175.Text = "API/CHROME:";
            // 
            // cmb_REG_BM_IG_API_CHROME
            // 
            this.cmb_REG_BM_IG_API_CHROME.FormattingEnabled = true;
            this.cmb_REG_BM_IG_API_CHROME.Location = new System.Drawing.Point(161, 26);
            this.cmb_REG_BM_IG_API_CHROME.Name = "cmb_REG_BM_IG_API_CHROME";
            this.cmb_REG_BM_IG_API_CHROME.Size = new System.Drawing.Size(141, 23);
            this.cmb_REG_BM_IG_API_CHROME.TabIndex = 39;
            // 
            // tb_ID_UP
            // 
            this.tb_ID_UP.Location = new System.Drawing.Point(165, 263);
            this.tb_ID_UP.Name = "tb_ID_UP";
            this.tb_ID_UP.Size = new System.Drawing.Size(121, 21);
            this.tb_ID_UP.TabIndex = 38;
            // 
            // label140
            // 
            this.label140.AutoSize = true;
            this.label140.Location = new System.Drawing.Point(119, 263);
            this.label140.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label140.Name = "label140";
            this.label140.Size = new System.Drawing.Size(42, 15);
            this.label140.TabIndex = 37;
            this.label140.Text = "ID UP:";
            // 
            // label139
            // 
            this.label139.AutoSize = true;
            this.label139.Location = new System.Drawing.Point(130, 239);
            this.label139.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label139.Name = "label139";
            this.label139.Size = new System.Drawing.Size(31, 15);
            this.label139.TabIndex = 36;
            this.label139.Text = "MK:";
            // 
            // label138
            // 
            this.label138.AutoSize = true;
            this.label138.Location = new System.Drawing.Point(130, 212);
            this.label138.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label138.Name = "label138";
            this.label138.Size = new System.Drawing.Size(28, 15);
            this.label138.TabIndex = 35;
            this.label138.Text = "TK:";
            // 
            // tb_MK_NAM
            // 
            this.tb_MK_NAM.Location = new System.Drawing.Point(165, 236);
            this.tb_MK_NAM.Name = "tb_MK_NAM";
            this.tb_MK_NAM.Size = new System.Drawing.Size(121, 21);
            this.tb_MK_NAM.TabIndex = 34;
            // 
            // tb_TK_NAM
            // 
            this.tb_TK_NAM.Location = new System.Drawing.Point(165, 209);
            this.tb_TK_NAM.Name = "tb_TK_NAM";
            this.tb_TK_NAM.Size = new System.Drawing.Size(121, 21);
            this.tb_TK_NAM.TabIndex = 30;
            // 
            // cmb_UP_WEB
            // 
            this.cmb_UP_WEB.FormattingEnabled = true;
            this.cmb_UP_WEB.Location = new System.Drawing.Point(165, 171);
            this.cmb_UP_WEB.Name = "cmb_UP_WEB";
            this.cmb_UP_WEB.Size = new System.Drawing.Size(121, 23);
            this.cmb_UP_WEB.TabIndex = 32;
            // 
            // label137
            // 
            this.label137.AutoSize = true;
            this.label137.Location = new System.Drawing.Point(104, 174);
            this.label137.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(54, 15);
            this.label137.TabIndex = 31;
            this.label137.Text = "UP WEB:";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(136, 134);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(22, 15);
            this.label43.TabIndex = 30;
            this.label43.Text = "IP:";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(1, 58);
            this.label47.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(158, 15);
            this.label47.TabIndex = 24;
            this.label47.Text = "REG_HOTMAIL_CHROME:";
            // 
            // cmb_IP
            // 
            this.cmb_IP.FormattingEnabled = true;
            this.cmb_IP.Location = new System.Drawing.Point(165, 131);
            this.cmb_IP.Name = "cmb_IP";
            this.cmb_IP.Size = new System.Drawing.Size(121, 23);
            this.cmb_IP.TabIndex = 29;
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(110, 96);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(47, 15);
            this.label48.TabIndex = 26;
            this.label48.Text = "VN/US:";
            // 
            // cmb_REGHOTMAIL
            // 
            this.cmb_REGHOTMAIL.FormattingEnabled = true;
            this.cmb_REGHOTMAIL.Location = new System.Drawing.Point(161, 55);
            this.cmb_REGHOTMAIL.Name = "cmb_REGHOTMAIL";
            this.cmb_REGHOTMAIL.Size = new System.Drawing.Size(141, 23);
            this.cmb_REGHOTMAIL.TabIndex = 23;
            // 
            // cmb_VN_US
            // 
            this.cmb_VN_US.FormattingEnabled = true;
            this.cmb_VN_US.Location = new System.Drawing.Point(161, 93);
            this.cmb_VN_US.Name = "cmb_VN_US";
            this.cmb_VN_US.Size = new System.Drawing.Size(141, 23);
            this.cmb_VN_US.TabIndex = 25;
            // 
            // tabPage24
            // 
            this.tabPage24.BackColor = System.Drawing.Color.Gray;
            this.tabPage24.Controls.Add(this.cmb_NO_RANDOM);
            this.tabPage24.Controls.Add(this.label215);
            this.tabPage24.Controls.Add(this.cmb_Random4_17);
            this.tabPage24.Controls.Add(this.label214);
            this.tabPage24.Controls.Add(this.cmb_dinh_dang_ten);
            this.tabPage24.Controls.Add(this.label213);
            this.tabPage24.Location = new System.Drawing.Point(4, 24);
            this.tabPage24.Name = "tabPage24";
            this.tabPage24.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage24.Size = new System.Drawing.Size(448, 302);
            this.tabPage24.TabIndex = 1;
            this.tabPage24.Text = "CÀI ĐẶT TÊN REG IG";
            // 
            // cmb_NO_RANDOM
            // 
            this.cmb_NO_RANDOM.FormattingEnabled = true;
            this.cmb_NO_RANDOM.Location = new System.Drawing.Point(169, 88);
            this.cmb_NO_RANDOM.Name = "cmb_NO_RANDOM";
            this.cmb_NO_RANDOM.Size = new System.Drawing.Size(104, 23);
            this.cmb_NO_RANDOM.TabIndex = 46;
            // 
            // label215
            // 
            this.label215.AutoSize = true;
            this.label215.Location = new System.Drawing.Point(169, 67);
            this.label215.Name = "label215";
            this.label215.Size = new System.Drawing.Size(91, 15);
            this.label215.TabIndex = 45;
            this.label215.Text = "NO_RANDOM:";
            // 
            // cmb_Random4_17
            // 
            this.cmb_Random4_17.FormattingEnabled = true;
            this.cmb_Random4_17.Location = new System.Drawing.Point(12, 88);
            this.cmb_Random4_17.Name = "cmb_Random4_17";
            this.cmb_Random4_17.Size = new System.Drawing.Size(104, 23);
            this.cmb_Random4_17.TabIndex = 44;
            // 
            // label214
            // 
            this.label214.AutoSize = true;
            this.label214.Location = new System.Drawing.Point(9, 67);
            this.label214.Name = "label214";
            this.label214.Size = new System.Drawing.Size(96, 15);
            this.label214.TabIndex = 43;
            this.label214.Text = "RANDOM_4_17:";
            // 
            // cmb_dinh_dang_ten
            // 
            this.cmb_dinh_dang_ten.FormattingEnabled = true;
            this.cmb_dinh_dang_ten.Location = new System.Drawing.Point(12, 32);
            this.cmb_dinh_dang_ten.Name = "cmb_dinh_dang_ten";
            this.cmb_dinh_dang_ten.Size = new System.Drawing.Size(427, 23);
            this.cmb_dinh_dang_ten.TabIndex = 42;
            // 
            // label213
            // 
            this.label213.AutoSize = true;
            this.label213.Location = new System.Drawing.Point(9, 14);
            this.label213.Name = "label213";
            this.label213.Size = new System.Drawing.Size(107, 15);
            this.label213.TabIndex = 41;
            this.label213.Text = "ĐỊNH DẠNG TÊN:";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label200);
            this.groupBox8.Controls.Add(this.cmb_bo_DIE);
            this.groupBox8.Controls.Add(this.cmb_TTK_BM350);
            this.groupBox8.Controls.Add(this.cmb_TTK_BM50);
            this.groupBox8.Controls.Add(this.label177);
            this.groupBox8.Controls.Add(this.label176);
            this.groupBox8.Controls.Add(this.label151);
            this.groupBox8.Controls.Add(this.numericUpDown5_delay_regbmig);
            this.groupBox8.Controls.Add(this.label150);
            this.groupBox8.Controls.Add(this.num_tao_5bm);
            this.groupBox8.Controls.Add(this.cmb_Tao_5BM_IG);
            this.groupBox8.Controls.Add(this.label149);
            this.groupBox8.Controls.Add(this.label120);
            this.groupBox8.Controls.Add(this.label119);
            this.groupBox8.Controls.Add(this.numericUpDown4);
            this.groupBox8.Controls.Add(this.numericUpDown3);
            this.groupBox8.Controls.Add(this.cmb_TTKQC_BM_IG);
            this.groupBox8.Controls.Add(this.label110);
            this.groupBox8.Controls.Add(this.cmb_REG_BM_IG1);
            this.groupBox8.Controls.Add(this.label109);
            this.groupBox8.Controls.Add(this.label108);
            this.groupBox8.Controls.Add(this.cmb_2FA_IG);
            this.groupBox8.Controls.Add(this.label76);
            this.groupBox8.Controls.Add(this.label77);
            this.groupBox8.Controls.Add(this.cmb_ON_OFF_2FAIG);
            this.groupBox8.Location = new System.Drawing.Point(22, 342);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(440, 340);
            this.groupBox8.TabIndex = 29;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "2FA IG";
            // 
            // label200
            // 
            this.label200.AutoSize = true;
            this.label200.Location = new System.Drawing.Point(326, 69);
            this.label200.Name = "label200";
            this.label200.Size = new System.Drawing.Size(88, 15);
            this.label200.TabIndex = 57;
            this.label200.Text = "REG 5 BỎ DIE:";
            // 
            // cmb_bo_DIE
            // 
            this.cmb_bo_DIE.FormattingEnabled = true;
            this.cmb_bo_DIE.Location = new System.Drawing.Point(329, 95);
            this.cmb_bo_DIE.Name = "cmb_bo_DIE";
            this.cmb_bo_DIE.Size = new System.Drawing.Size(104, 23);
            this.cmb_bo_DIE.TabIndex = 56;
            // 
            // cmb_TTK_BM350
            // 
            this.cmb_TTK_BM350.FormattingEnabled = true;
            this.cmb_TTK_BM350.Location = new System.Drawing.Point(352, 239);
            this.cmb_TTK_BM350.Name = "cmb_TTK_BM350";
            this.cmb_TTK_BM350.Size = new System.Drawing.Size(81, 23);
            this.cmb_TTK_BM350.TabIndex = 55;
            // 
            // cmb_TTK_BM50
            // 
            this.cmb_TTK_BM50.FormattingEnabled = true;
            this.cmb_TTK_BM50.Location = new System.Drawing.Point(352, 209);
            this.cmb_TTK_BM50.Name = "cmb_TTK_BM50";
            this.cmb_TTK_BM50.Size = new System.Drawing.Size(81, 23);
            this.cmb_TTK_BM50.TabIndex = 54;
            // 
            // label177
            // 
            this.label177.AutoSize = true;
            this.label177.Location = new System.Drawing.Point(237, 242);
            this.label177.Name = "label177";
            this.label177.Size = new System.Drawing.Size(97, 15);
            this.label177.TabIndex = 53;
            this.label177.Text = "TẠO TKQC 350:";
            // 
            // label176
            // 
            this.label176.AutoSize = true;
            this.label176.Location = new System.Drawing.Point(237, 217);
            this.label176.Name = "label176";
            this.label176.Size = new System.Drawing.Size(113, 15);
            this.label176.TabIndex = 52;
            this.label176.Text = "TẠO TKQC BM 50:";
            // 
            // label151
            // 
            this.label151.AutoSize = true;
            this.label151.Location = new System.Drawing.Point(19, 193);
            this.label151.Name = "label151";
            this.label151.Size = new System.Drawing.Size(69, 15);
            this.label151.TabIndex = 51;
            this.label151.Text = "Delay REG:";
            // 
            // numericUpDown5_delay_regbmig
            // 
            this.numericUpDown5_delay_regbmig.Location = new System.Drawing.Point(135, 193);
            this.numericUpDown5_delay_regbmig.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown5_delay_regbmig.Name = "numericUpDown5_delay_regbmig";
            this.numericUpDown5_delay_regbmig.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown5_delay_regbmig.TabIndex = 50;
            // 
            // label150
            // 
            this.label150.AutoSize = true;
            this.label150.Location = new System.Drawing.Point(19, 167);
            this.label150.Name = "label150";
            this.label150.Size = new System.Drawing.Size(48, 15);
            this.label150.TabIndex = 49;
            this.label150.Text = "for BM:";
            // 
            // num_tao_5bm
            // 
            this.num_tao_5bm.Location = new System.Drawing.Point(135, 161);
            this.num_tao_5bm.Name = "num_tao_5bm";
            this.num_tao_5bm.Size = new System.Drawing.Size(120, 21);
            this.num_tao_5bm.TabIndex = 48;
            this.num_tao_5bm.Value = new decimal(new int[] {
            4,
            0,
            0,
            0});
            // 
            // cmb_Tao_5BM_IG
            // 
            this.cmb_Tao_5BM_IG.FormattingEnabled = true;
            this.cmb_Tao_5BM_IG.Location = new System.Drawing.Point(131, 95);
            this.cmb_Tao_5BM_IG.Name = "cmb_Tao_5BM_IG";
            this.cmb_Tao_5BM_IG.Size = new System.Drawing.Size(141, 23);
            this.cmb_Tao_5BM_IG.TabIndex = 47;
            // 
            // label149
            // 
            this.label149.AutoSize = true;
            this.label149.Location = new System.Drawing.Point(15, 103);
            this.label149.Name = "label149";
            this.label149.Size = new System.Drawing.Size(84, 15);
            this.label149.TabIndex = 46;
            this.label149.Text = "REG BM 1/3/5:";
            // 
            // label120
            // 
            this.label120.AutoSize = true;
            this.label120.Location = new System.Drawing.Point(15, 302);
            this.label120.Name = "label120";
            this.label120.Size = new System.Drawing.Size(70, 15);
            this.label120.TabIndex = 45;
            this.label120.Text = "Delay TTK:";
            // 
            // label119
            // 
            this.label119.AutoSize = true;
            this.label119.Location = new System.Drawing.Point(15, 270);
            this.label119.Name = "label119";
            this.label119.Size = new System.Drawing.Size(46, 15);
            this.label119.TabIndex = 44;
            this.label119.Text = "for TK:";
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.Location = new System.Drawing.Point(131, 264);
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown4.TabIndex = 43;
            this.numericUpDown4.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Location = new System.Drawing.Point(131, 302);
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown3.TabIndex = 42;
            this.numericUpDown3.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // cmb_TTKQC_BM_IG
            // 
            this.cmb_TTKQC_BM_IG.FormattingEnabled = true;
            this.cmb_TTKQC_BM_IG.Location = new System.Drawing.Point(131, 226);
            this.cmb_TTKQC_BM_IG.Name = "cmb_TTKQC_BM_IG";
            this.cmb_TTKQC_BM_IG.Size = new System.Drawing.Size(81, 23);
            this.cmb_TTKQC_BM_IG.TabIndex = 32;
            // 
            // label110
            // 
            this.label110.AutoSize = true;
            this.label110.Location = new System.Drawing.Point(15, 234);
            this.label110.Name = "label110";
            this.label110.Size = new System.Drawing.Size(76, 15);
            this.label110.TabIndex = 31;
            this.label110.Text = "TẠO TKQC:";
            // 
            // cmb_REG_BM_IG1
            // 
            this.cmb_REG_BM_IG1.FormattingEnabled = true;
            this.cmb_REG_BM_IG1.Location = new System.Drawing.Point(131, 126);
            this.cmb_REG_BM_IG1.Name = "cmb_REG_BM_IG1";
            this.cmb_REG_BM_IG1.Size = new System.Drawing.Size(141, 23);
            this.cmb_REG_BM_IG1.TabIndex = 30;
            // 
            // label109
            // 
            this.label109.AutoSize = true;
            this.label109.Location = new System.Drawing.Point(15, 134);
            this.label109.Name = "label109";
            this.label109.Size = new System.Drawing.Size(57, 15);
            this.label109.TabIndex = 29;
            this.label109.Text = "REG BM:";
            // 
            // label108
            // 
            this.label108.AutoSize = true;
            this.label108.Location = new System.Drawing.Point(15, 64);
            this.label108.Name = "label108";
            this.label108.Size = new System.Drawing.Size(110, 15);
            this.label108.TabIndex = 28;
            this.label108.Text = "API/Auto selenium:";
            // 
            // cmb_2FA_IG
            // 
            this.cmb_2FA_IG.FormattingEnabled = true;
            this.cmb_2FA_IG.Location = new System.Drawing.Point(131, 61);
            this.cmb_2FA_IG.Name = "cmb_2FA_IG";
            this.cmb_2FA_IG.Size = new System.Drawing.Size(141, 23);
            this.cmb_2FA_IG.TabIndex = 27;
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Location = new System.Drawing.Point(15, 26);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(57, 15);
            this.label76.TabIndex = 24;
            this.label76.Text = "ON/OFF:";
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Location = new System.Drawing.Point(15, 85);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(0, 15);
            this.label77.TabIndex = 26;
            // 
            // cmb_ON_OFF_2FAIG
            // 
            this.cmb_ON_OFF_2FAIG.FormattingEnabled = true;
            this.cmb_ON_OFF_2FAIG.Location = new System.Drawing.Point(131, 23);
            this.cmb_ON_OFF_2FAIG.Name = "cmb_ON_OFF_2FAIG";
            this.cmb_ON_OFF_2FAIG.Size = new System.Drawing.Size(141, 23);
            this.cmb_ON_OFF_2FAIG.TabIndex = 23;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.delay_doc_hotmail_1);
            this.groupBox4.Controls.Add(this.label222);
            this.groupBox4.Controls.Add(this.groupBox14);
            this.groupBox4.Controls.Add(this.cmb_doc_luon_link_mail_ao);
            this.groupBox4.Controls.Add(this.label181);
            this.groupBox4.Controls.Add(this.btn_update_mail);
            this.groupBox4.Controls.Add(this.label168);
            this.groupBox4.Controls.Add(this.richTextBox1);
            this.groupBox4.Controls.Add(this.label167);
            this.groupBox4.Controls.Add(this.n_slink_share_them);
            this.groupBox4.Controls.Add(this.label163);
            this.groupBox4.Controls.Add(this.delay_tatbatsangtao);
            this.groupBox4.Controls.Add(this.cmb_sharebmt6_50);
            this.groupBox4.Controls.Add(this.label162);
            this.groupBox4.Controls.Add(this.label161);
            this.groupBox4.Controls.Add(this.cmb_sharebmt6_350);
            this.groupBox4.Controls.Add(this.label160);
            this.groupBox4.Controls.Add(this.label159);
            this.groupBox4.Controls.Add(this.label158);
            this.groupBox4.Controls.Add(this.nam_rip);
            this.groupBox4.Controls.Add(this.thang_rip);
            this.groupBox4.Controls.Add(this.ngay_rip);
            this.groupBox4.Controls.Add(this.cmb_RIPIG);
            this.groupBox4.Controls.Add(this.label157);
            this.groupBox4.Controls.Add(this.cmb_BMT6);
            this.groupBox4.Controls.Add(this.label156);
            this.groupBox4.Controls.Add(this.cmb_color350);
            this.groupBox4.Controls.Add(this.label155);
            this.groupBox4.Controls.Add(this.cmb_on_off_chrome);
            this.groupBox4.Controls.Add(this.label154);
            this.groupBox4.Controls.Add(this.label153);
            this.groupBox4.Controls.Add(this.numericUpDown5_slcheck_bm350);
            this.groupBox4.Controls.Add(this.cmb_chishare_bm350);
            this.groupBox4.Controls.Add(this.label152);
            this.groupBox4.Controls.Add(this.cmb_LOAI_LINK);
            this.groupBox4.Controls.Add(this.label142);
            this.groupBox4.Controls.Add(this.label133);
            this.groupBox4.Controls.Add(this.rtb_hotmail_BM350);
            this.groupBox4.Controls.Add(this.label88);
            this.groupBox4.Controls.Add(this.cmb_DOC_LINK_MAX);
            this.groupBox4.Controls.Add(this.label87);
            this.groupBox4.Controls.Add(this.rtb_BMIII);
            this.groupBox4.Controls.Add(this.label86);
            this.groupBox4.Controls.Add(this.cmb_CHECK_ADMIN);
            this.groupBox4.Controls.Add(this.label85);
            this.groupBox4.Controls.Add(this.delay_check_admin);
            this.groupBox4.Controls.Add(this.label84);
            this.groupBox4.Controls.Add(this.rtb_Link_BM350_IG);
            this.groupBox4.Controls.Add(this.cmb_TAT_BAT_SANG_TAO);
            this.groupBox4.Controls.Add(this.label83);
            this.groupBox4.Controls.Add(this.cmb_AN_CHROME);
            this.groupBox4.Controls.Add(this.label82);
            this.groupBox4.Controls.Add(this.label81);
            this.groupBox4.Controls.Add(this.cmb_MAIL_SHARE_BM_IG);
            this.groupBox4.Controls.Add(this.label80);
            this.groupBox4.Controls.Add(this.rtb_hotmail);
            this.groupBox4.Controls.Add(this.cmb_Admin_BM);
            this.groupBox4.Controls.Add(this.label79);
            this.groupBox4.Controls.Add(this.label78);
            this.groupBox4.Controls.Add(this.rtb_Link_BM_IG);
            this.groupBox4.Controls.Add(this.label49);
            this.groupBox4.Controls.Add(this.label50);
            this.groupBox4.Controls.Add(this.cmb_LOGIN_IG);
            this.groupBox4.Location = new System.Drawing.Point(481, 35);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1280, 630);
            this.groupBox4.TabIndex = 28;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "v";
            // 
            // delay_doc_hotmail_1
            // 
            this.delay_doc_hotmail_1.Location = new System.Drawing.Point(829, 205);
            this.delay_doc_hotmail_1.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.delay_doc_hotmail_1.Name = "delay_doc_hotmail_1";
            this.delay_doc_hotmail_1.Size = new System.Drawing.Size(120, 21);
            this.delay_doc_hotmail_1.TabIndex = 88;
            this.delay_doc_hotmail_1.Value = new decimal(new int[] {
            90,
            0,
            0,
            0});
            // 
            // label222
            // 
            this.label222.AutoSize = true;
            this.label222.Location = new System.Drawing.Point(716, 208);
            this.label222.Name = "label222";
            this.label222.Size = new System.Drawing.Size(109, 15);
            this.label222.TabIndex = 87;
            this.label222.Text = "delay_doc_hotmail:";
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.cmb_Tao_1_5);
            this.groupBox14.Controls.Add(this.label205);
            this.groupBox14.Controls.Add(this.cmb_kick_BM3_IG);
            this.groupBox14.Controls.Add(this.label198);
            this.groupBox14.Location = new System.Drawing.Point(1061, 376);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(200, 193);
            this.groupBox14.TabIndex = 86;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "BM3";
            // 
            // cmb_Tao_1_5
            // 
            this.cmb_Tao_1_5.FormattingEnabled = true;
            this.cmb_Tao_1_5.Location = new System.Drawing.Point(53, 83);
            this.cmb_Tao_1_5.Name = "cmb_Tao_1_5";
            this.cmb_Tao_1_5.Size = new System.Drawing.Size(141, 23);
            this.cmb_Tao_1_5.TabIndex = 87;
            // 
            // label205
            // 
            this.label205.AutoSize = true;
            this.label205.Location = new System.Drawing.Point(6, 65);
            this.label205.Name = "label205";
            this.label205.Size = new System.Drawing.Size(92, 15);
            this.label205.TabIndex = 86;
            this.label205.Text = "KICK 3 TẠO 1 :";
            // 
            // cmb_kick_BM3_IG
            // 
            this.cmb_kick_BM3_IG.FormattingEnabled = true;
            this.cmb_kick_BM3_IG.Location = new System.Drawing.Point(51, 26);
            this.cmb_kick_BM3_IG.Name = "cmb_kick_BM3_IG";
            this.cmb_kick_BM3_IG.Size = new System.Drawing.Size(141, 23);
            this.cmb_kick_BM3_IG.TabIndex = 84;
            // 
            // label198
            // 
            this.label198.AutoSize = true;
            this.label198.Location = new System.Drawing.Point(6, 29);
            this.label198.Name = "label198";
            this.label198.Size = new System.Drawing.Size(42, 15);
            this.label198.TabIndex = 85;
            this.label198.Text = "BM 3 :";
            // 
            // cmb_doc_luon_link_mail_ao
            // 
            this.cmb_doc_luon_link_mail_ao.FormattingEnabled = true;
            this.cmb_doc_luon_link_mail_ao.Location = new System.Drawing.Point(540, 205);
            this.cmb_doc_luon_link_mail_ao.Name = "cmb_doc_luon_link_mail_ao";
            this.cmb_doc_luon_link_mail_ao.Size = new System.Drawing.Size(141, 23);
            this.cmb_doc_luon_link_mail_ao.TabIndex = 83;
            // 
            // label181
            // 
            this.label181.AutoSize = true;
            this.label181.Location = new System.Drawing.Point(373, 208);
            this.label181.Name = "label181";
            this.label181.Size = new System.Drawing.Size(161, 15);
            this.label181.TabIndex = 82;
            this.label181.Text = "ĐỌC LUÔN LINK MAIL ẢO:";
            // 
            // btn_update_mail
            // 
            this.btn_update_mail.BackColor = System.Drawing.SystemColors.Highlight;
            this.btn_update_mail.Location = new System.Drawing.Point(260, 90);
            this.btn_update_mail.Name = "btn_update_mail";
            this.btn_update_mail.Size = new System.Drawing.Size(75, 28);
            this.btn_update_mail.TabIndex = 81;
            this.btn_update_mail.Text = "UPMAIL";
            this.btn_update_mail.UseVisualStyleBackColor = false;
            this.btn_update_mail.Click += new System.EventHandler(this.btn_update_mail_Click);
            // 
            // label168
            // 
            this.label168.AutoSize = true;
            this.label168.Location = new System.Drawing.Point(755, 244);
            this.label168.Name = "label168";
            this.label168.Size = new System.Drawing.Size(117, 15);
            this.label168.TabIndex = 80;
            this.label168.Text = "HOTMAIL 10 LINK :";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(758, 263);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(305, 57);
            this.richTextBox1.TabIndex = 79;
            this.richTextBox1.Text = "";
            // 
            // label167
            // 
            this.label167.AutoSize = true;
            this.label167.Location = new System.Drawing.Point(6, 120);
            this.label167.Name = "label167";
            this.label167.Size = new System.Drawing.Size(113, 15);
            this.label167.TabIndex = 78;
            this.label167.Text = "Số Link Cần Share:";
            // 
            // n_slink_share_them
            // 
            this.n_slink_share_them.Location = new System.Drawing.Point(125, 118);
            this.n_slink_share_them.Name = "n_slink_share_them";
            this.n_slink_share_them.Size = new System.Drawing.Size(120, 21);
            this.n_slink_share_them.TabIndex = 77;
            this.n_slink_share_them.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label163
            // 
            this.label163.AutoSize = true;
            this.label163.Location = new System.Drawing.Point(895, 189);
            this.label163.Name = "label163";
            this.label163.Size = new System.Drawing.Size(168, 15);
            this.label163.TabIndex = 76;
            this.label163.Text = "DELAY TAT BAT SANG TAO :";
            // 
            // delay_tatbatsangtao
            // 
            this.delay_tatbatsangtao.Location = new System.Drawing.Point(1067, 187);
            this.delay_tatbatsangtao.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.delay_tatbatsangtao.Name = "delay_tatbatsangtao";
            this.delay_tatbatsangtao.Size = new System.Drawing.Size(63, 21);
            this.delay_tatbatsangtao.TabIndex = 75;
            this.delay_tatbatsangtao.Value = new decimal(new int[] {
            300,
            0,
            0,
            0});
            // 
            // cmb_sharebmt6_50
            // 
            this.cmb_sharebmt6_50.FormattingEnabled = true;
            this.cmb_sharebmt6_50.Location = new System.Drawing.Point(1067, 156);
            this.cmb_sharebmt6_50.Name = "cmb_sharebmt6_50";
            this.cmb_sharebmt6_50.Size = new System.Drawing.Size(141, 23);
            this.cmb_sharebmt6_50.TabIndex = 74;
            // 
            // label162
            // 
            this.label162.AutoSize = true;
            this.label162.Location = new System.Drawing.Point(961, 160);
            this.label162.Name = "label162";
            this.label162.Size = new System.Drawing.Size(102, 15);
            this.label162.TabIndex = 73;
            this.label162.Text = "SHARET6/BM50 :";
            // 
            // label161
            // 
            this.label161.AutoSize = true;
            this.label161.Location = new System.Drawing.Point(955, 130);
            this.label161.Name = "label161";
            this.label161.Size = new System.Drawing.Size(108, 15);
            this.label161.TabIndex = 72;
            this.label161.Text = "SHARET6/BM350 :";
            // 
            // cmb_sharebmt6_350
            // 
            this.cmb_sharebmt6_350.FormattingEnabled = true;
            this.cmb_sharebmt6_350.Location = new System.Drawing.Point(1067, 127);
            this.cmb_sharebmt6_350.Name = "cmb_sharebmt6_350";
            this.cmb_sharebmt6_350.Size = new System.Drawing.Size(141, 23);
            this.cmb_sharebmt6_350.TabIndex = 71;
            // 
            // label160
            // 
            this.label160.AutoSize = true;
            this.label160.Location = new System.Drawing.Point(1142, 87);
            this.label160.Name = "label160";
            this.label160.Size = new System.Drawing.Size(20, 15);
            this.label160.TabIndex = 70;
            this.label160.Text = "N:";
            // 
            // label159
            // 
            this.label159.AutoSize = true;
            this.label159.Location = new System.Drawing.Point(1058, 87);
            this.label159.Name = "label159";
            this.label159.Size = new System.Drawing.Size(28, 15);
            this.label159.TabIndex = 69;
            this.label159.Text = "TH:";
            // 
            // label158
            // 
            this.label158.AutoSize = true;
            this.label158.Location = new System.Drawing.Point(979, 88);
            this.label158.Name = "label158";
            this.label158.Size = new System.Drawing.Size(29, 15);
            this.label158.TabIndex = 68;
            this.label158.Text = "NG:";
            // 
            // nam_rip
            // 
            this.nam_rip.Location = new System.Drawing.Point(1163, 84);
            this.nam_rip.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nam_rip.Name = "nam_rip";
            this.nam_rip.Size = new System.Drawing.Size(54, 21);
            this.nam_rip.TabIndex = 67;
            this.nam_rip.Value = new decimal(new int[] {
            2017,
            0,
            0,
            0});
            // 
            // thang_rip
            // 
            this.thang_rip.Location = new System.Drawing.Point(1092, 84);
            this.thang_rip.Name = "thang_rip";
            this.thang_rip.Size = new System.Drawing.Size(38, 21);
            this.thang_rip.TabIndex = 66;
            this.thang_rip.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // ngay_rip
            // 
            this.ngay_rip.Location = new System.Drawing.Point(1014, 84);
            this.ngay_rip.Name = "ngay_rip";
            this.ngay_rip.Size = new System.Drawing.Size(38, 21);
            this.ngay_rip.TabIndex = 65;
            this.ngay_rip.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // cmb_RIPIG
            // 
            this.cmb_RIPIG.FormattingEnabled = true;
            this.cmb_RIPIG.Location = new System.Drawing.Point(1067, 51);
            this.cmb_RIPIG.Name = "cmb_RIPIG";
            this.cmb_RIPIG.Size = new System.Drawing.Size(141, 23);
            this.cmb_RIPIG.TabIndex = 64;
            // 
            // label157
            // 
            this.label157.AutoSize = true;
            this.label157.Location = new System.Drawing.Point(989, 49);
            this.label157.Name = "label157";
            this.label157.Size = new System.Drawing.Size(43, 15);
            this.label157.TabIndex = 63;
            this.label157.Text = "RIPIG:";
            // 
            // cmb_BMT6
            // 
            this.cmb_BMT6.FormattingEnabled = true;
            this.cmb_BMT6.Location = new System.Drawing.Point(1067, 20);
            this.cmb_BMT6.Name = "cmb_BMT6";
            this.cmb_BMT6.Size = new System.Drawing.Size(141, 23);
            this.cmb_BMT6.TabIndex = 62;
            // 
            // label156
            // 
            this.label156.AutoSize = true;
            this.label156.Location = new System.Drawing.Point(989, 23);
            this.label156.Name = "label156";
            this.label156.Size = new System.Drawing.Size(44, 15);
            this.label156.TabIndex = 61;
            this.label156.Text = "BMT6:";
            // 
            // cmb_color350
            // 
            this.cmb_color350.FormattingEnabled = true;
            this.cmb_color350.Location = new System.Drawing.Point(808, 127);
            this.cmb_color350.Name = "cmb_color350";
            this.cmb_color350.Size = new System.Drawing.Size(141, 23);
            this.cmb_color350.TabIndex = 60;
            // 
            // label155
            // 
            this.label155.AutoSize = true;
            this.label155.Location = new System.Drawing.Point(653, 127);
            this.label155.Name = "label155";
            this.label155.Size = new System.Drawing.Size(62, 15);
            this.label155.TabIndex = 59;
            this.label155.Text = "Color 350:";
            // 
            // cmb_on_off_chrome
            // 
            this.cmb_on_off_chrome.FormattingEnabled = true;
            this.cmb_on_off_chrome.Location = new System.Drawing.Point(808, 90);
            this.cmb_on_off_chrome.Name = "cmb_on_off_chrome";
            this.cmb_on_off_chrome.Size = new System.Drawing.Size(141, 23);
            this.cmb_on_off_chrome.TabIndex = 58;
            // 
            // label154
            // 
            this.label154.AutoSize = true;
            this.label154.Location = new System.Drawing.Point(653, 93);
            this.label154.Name = "label154";
            this.label154.Size = new System.Drawing.Size(114, 15);
            this.label154.TabIndex = 57;
            this.label154.Text = "ON/OFF CHROME:";
            // 
            // label153
            // 
            this.label153.AutoSize = true;
            this.label153.Location = new System.Drawing.Point(653, 55);
            this.label153.Name = "label153";
            this.label153.Size = new System.Drawing.Size(149, 15);
            this.label153.TabIndex = 56;
            this.label153.Text = "SLCHECK ADMINBM350:";
            // 
            // numericUpDown5_slcheck_bm350
            // 
            this.numericUpDown5_slcheck_bm350.Location = new System.Drawing.Point(808, 53);
            this.numericUpDown5_slcheck_bm350.Maximum = new decimal(new int[] {
            10000000,
            0,
            0,
            0});
            this.numericUpDown5_slcheck_bm350.Name = "numericUpDown5_slcheck_bm350";
            this.numericUpDown5_slcheck_bm350.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown5_slcheck_bm350.TabIndex = 55;
            this.numericUpDown5_slcheck_bm350.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // cmb_chishare_bm350
            // 
            this.cmb_chishare_bm350.FormattingEnabled = true;
            this.cmb_chishare_bm350.Location = new System.Drawing.Point(756, 20);
            this.cmb_chishare_bm350.Name = "cmb_chishare_bm350";
            this.cmb_chishare_bm350.Size = new System.Drawing.Size(141, 23);
            this.cmb_chishare_bm350.TabIndex = 54;
            // 
            // label152
            // 
            this.label152.AutoSize = true;
            this.label152.Location = new System.Drawing.Point(653, 23);
            this.label152.Name = "label152";
            this.label152.Size = new System.Drawing.Size(72, 15);
            this.label152.TabIndex = 53;
            this.label152.Text = "SHARE350 :";
            // 
            // cmb_LOAI_LINK
            // 
            this.cmb_LOAI_LINK.FormattingEnabled = true;
            this.cmb_LOAI_LINK.Location = new System.Drawing.Point(468, 167);
            this.cmb_LOAI_LINK.Name = "cmb_LOAI_LINK";
            this.cmb_LOAI_LINK.Size = new System.Drawing.Size(359, 23);
            this.cmb_LOAI_LINK.TabIndex = 52;
            // 
            // label142
            // 
            this.label142.AutoSize = true;
            this.label142.Location = new System.Drawing.Point(390, 167);
            this.label142.Name = "label142";
            this.label142.Size = new System.Drawing.Size(72, 15);
            this.label142.TabIndex = 51;
            this.label142.Text = "LOẠI LINK:";
            // 
            // label133
            // 
            this.label133.AutoSize = true;
            this.label133.Location = new System.Drawing.Point(413, 244);
            this.label133.Name = "label133";
            this.label133.Size = new System.Drawing.Size(110, 15);
            this.label133.TabIndex = 50;
            this.label133.Text = "HOTMAIL BM350 :";
            // 
            // rtb_hotmail_BM350
            // 
            this.rtb_hotmail_BM350.Location = new System.Drawing.Point(417, 263);
            this.rtb_hotmail_BM350.Name = "rtb_hotmail_BM350";
            this.rtb_hotmail_BM350.Size = new System.Drawing.Size(305, 57);
            this.rtb_hotmail_BM350.TabIndex = 49;
            this.rtb_hotmail_BM350.Text = "";
            // 
            // label88
            // 
            this.label88.AutoSize = true;
            this.label88.Location = new System.Drawing.Point(365, 133);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(101, 15);
            this.label88.TabIndex = 48;
            this.label88.Text = "ĐỌC LINK MAX:";
            // 
            // cmb_DOC_LINK_MAX
            // 
            this.cmb_DOC_LINK_MAX.FormattingEnabled = true;
            this.cmb_DOC_LINK_MAX.Location = new System.Drawing.Point(468, 130);
            this.cmb_DOC_LINK_MAX.Name = "cmb_DOC_LINK_MAX";
            this.cmb_DOC_LINK_MAX.Size = new System.Drawing.Size(141, 23);
            this.cmb_DOC_LINK_MAX.TabIndex = 47;
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Location = new System.Drawing.Point(716, 344);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(101, 15);
            this.label87.TabIndex = 46;
            this.label87.Text = "LINK BM THỨ 3:";
            // 
            // rtb_BMIII
            // 
            this.rtb_BMIII.Location = new System.Drawing.Point(719, 371);
            this.rtb_BMIII.Name = "rtb_BMIII";
            this.rtb_BMIII.Size = new System.Drawing.Size(305, 195);
            this.rtb_BMIII.TabIndex = 45;
            this.rtb_BMIII.Text = "";
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Location = new System.Drawing.Point(365, 87);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(97, 15);
            this.label86.TabIndex = 44;
            this.label86.Text = "CHECK ADMIN:";
            // 
            // cmb_CHECK_ADMIN
            // 
            this.cmb_CHECK_ADMIN.FormattingEnabled = true;
            this.cmb_CHECK_ADMIN.Location = new System.Drawing.Point(468, 85);
            this.cmb_CHECK_ADMIN.Name = "cmb_CHECK_ADMIN";
            this.cmb_CHECK_ADMIN.Size = new System.Drawing.Size(141, 23);
            this.cmb_CHECK_ADMIN.TabIndex = 43;
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Location = new System.Drawing.Point(394, 23);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(157, 15);
            this.label85.TabIndex = 42;
            this.label85.Text = "Delay Check ADMIN BM(s):";
            // 
            // delay_check_admin
            // 
            this.delay_check_admin.Location = new System.Drawing.Point(468, 41);
            this.delay_check_admin.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.delay_check_admin.Name = "delay_check_admin";
            this.delay_check_admin.Size = new System.Drawing.Size(120, 21);
            this.delay_check_admin.TabIndex = 41;
            this.delay_check_admin.Value = new decimal(new int[] {
            40,
            0,
            0,
            0});
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Location = new System.Drawing.Point(394, 344);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(80, 15);
            this.label84.TabIndex = 40;
            this.label84.Text = "LINK BM350:";
            // 
            // rtb_Link_BM350_IG
            // 
            this.rtb_Link_BM350_IG.Location = new System.Drawing.Point(397, 371);
            this.rtb_Link_BM350_IG.Name = "rtb_Link_BM350_IG";
            this.rtb_Link_BM350_IG.Size = new System.Drawing.Size(305, 195);
            this.rtb_Link_BM350_IG.TabIndex = 39;
            this.rtb_Link_BM350_IG.Text = "";
            // 
            // cmb_TAT_BAT_SANG_TAO
            // 
            this.cmb_TAT_BAT_SANG_TAO.FormattingEnabled = true;
            this.cmb_TAT_BAT_SANG_TAO.Location = new System.Drawing.Point(93, 205);
            this.cmb_TAT_BAT_SANG_TAO.Name = "cmb_TAT_BAT_SANG_TAO";
            this.cmb_TAT_BAT_SANG_TAO.Size = new System.Drawing.Size(141, 23);
            this.cmb_TAT_BAT_SANG_TAO.TabIndex = 38;
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Location = new System.Drawing.Point(6, 187);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(189, 15);
            this.label83.TabIndex = 37;
            this.label83.Text = "TẮT BẬT SÁNG TẠO TỰ ĐỘNG:";
            // 
            // cmb_AN_CHROME
            // 
            this.cmb_AN_CHROME.FormattingEnabled = true;
            this.cmb_AN_CHROME.Location = new System.Drawing.Point(93, 145);
            this.cmb_AN_CHROME.Name = "cmb_AN_CHROME";
            this.cmb_AN_CHROME.Size = new System.Drawing.Size(141, 23);
            this.cmb_AN_CHROME.TabIndex = 36;
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Location = new System.Drawing.Point(6, 148);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(85, 15);
            this.label82.TabIndex = 35;
            this.label82.Text = "ẨN CHROME:";
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Location = new System.Drawing.Point(6, 95);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(81, 15);
            this.label81.TabIndex = 34;
            this.label81.Text = "CHỌN MAIL:";
            // 
            // cmb_MAIL_SHARE_BM_IG
            // 
            this.cmb_MAIL_SHARE_BM_IG.FormattingEnabled = true;
            this.cmb_MAIL_SHARE_BM_IG.Location = new System.Drawing.Point(93, 92);
            this.cmb_MAIL_SHARE_BM_IG.Name = "cmb_MAIL_SHARE_BM_IG";
            this.cmb_MAIL_SHARE_BM_IG.Size = new System.Drawing.Size(141, 23);
            this.cmb_MAIL_SHARE_BM_IG.TabIndex = 33;
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Location = new System.Drawing.Point(2, 245);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(163, 15);
            this.label80.TabIndex = 32;
            this.label80.Text = "HOTMAIL BM50-BM THỨ 3:";
            // 
            // rtb_hotmail
            // 
            this.rtb_hotmail.Location = new System.Drawing.Point(69, 263);
            this.rtb_hotmail.Name = "rtb_hotmail";
            this.rtb_hotmail.Size = new System.Drawing.Size(305, 57);
            this.rtb_hotmail.TabIndex = 31;
            this.rtb_hotmail.Text = "";
            // 
            // cmb_Admin_BM
            // 
            this.cmb_Admin_BM.FormattingEnabled = true;
            this.cmb_Admin_BM.Location = new System.Drawing.Point(64, 59);
            this.cmb_Admin_BM.Name = "cmb_Admin_BM";
            this.cmb_Admin_BM.Size = new System.Drawing.Size(141, 23);
            this.cmb_Admin_BM.TabIndex = 30;
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Location = new System.Drawing.Point(15, 62);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(53, 15);
            this.label79.TabIndex = 29;
            this.label79.Text = "QUYỀN:";
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Location = new System.Drawing.Point(8, 353);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(74, 15);
            this.label78.TabIndex = 28;
            this.label78.Text = "LINK BM50:";
            // 
            // rtb_Link_BM_IG
            // 
            this.rtb_Link_BM_IG.Location = new System.Drawing.Point(69, 371);
            this.rtb_Link_BM_IG.Name = "rtb_Link_BM_IG";
            this.rtb_Link_BM_IG.Size = new System.Drawing.Size(305, 195);
            this.rtb_Link_BM_IG.TabIndex = 27;
            this.rtb_Link_BM_IG.Text = "";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(15, 27);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(50, 15);
            this.label49.TabIndex = 24;
            this.label49.Text = "LOGIN:";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(15, 85);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(0, 15);
            this.label50.TabIndex = 26;
            // 
            // cmb_LOGIN_IG
            // 
            this.cmb_LOGIN_IG.FormattingEnabled = true;
            this.cmb_LOGIN_IG.Location = new System.Drawing.Point(64, 24);
            this.cmb_LOGIN_IG.Name = "cmb_LOGIN_IG";
            this.cmb_LOGIN_IG.Size = new System.Drawing.Size(141, 23);
            this.cmb_LOGIN_IG.TabIndex = 23;
            // 
            // tabPage8
            // 
            this.tabPage8.BackColor = System.Drawing.Color.Gray;
            this.tabPage8.Controls.Add(this.ndelayloop);
            this.tabPage8.Controls.Add(this.label74);
            this.tabPage8.Controls.Add(this.cmb_DUNG_DOC_LINK_BACKUP);
            this.tabPage8.Controls.Add(this.label73);
            this.tabPage8.Controls.Add(this.delay_link_bm_backup);
            this.tabPage8.Controls.Add(this.label72);
            this.tabPage8.Controls.Add(this.label71);
            this.tabPage8.Controls.Add(this.rtb_MAIL_DOCLINK_BACKUP);
            this.tabPage8.Controls.Add(this.groupBox7);
            this.tabPage8.Controls.Add(this.groupBox6);
            this.tabPage8.Controls.Add(this.groupBox5);
            this.tabPage8.Location = new System.Drawing.Point(4, 24);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(1767, 688);
            this.tabPage8.TabIndex = 5;
            this.tabPage8.Text = "NHẬN BM NEW";
            // 
            // ndelayloop
            // 
            this.ndelayloop.Location = new System.Drawing.Point(576, 92);
            this.ndelayloop.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.ndelayloop.Name = "ndelayloop";
            this.ndelayloop.Size = new System.Drawing.Size(120, 21);
            this.ndelayloop.TabIndex = 36;
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Location = new System.Drawing.Point(435, 94);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(128, 15);
            this.label74.TabIndex = 35;
            this.label74.Text = "Delay Đọc Link (phút):";
            // 
            // cmb_DUNG_DOC_LINK_BACKUP
            // 
            this.cmb_DUNG_DOC_LINK_BACKUP.FormattingEnabled = true;
            this.cmb_DUNG_DOC_LINK_BACKUP.Location = new System.Drawing.Point(576, 60);
            this.cmb_DUNG_DOC_LINK_BACKUP.Name = "cmb_DUNG_DOC_LINK_BACKUP";
            this.cmb_DUNG_DOC_LINK_BACKUP.Size = new System.Drawing.Size(121, 23);
            this.cmb_DUNG_DOC_LINK_BACKUP.TabIndex = 34;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(452, 60);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(111, 15);
            this.label73.TabIndex = 33;
            this.label73.Text = "DỪNG ĐỌC LINK:";
            // 
            // delay_link_bm_backup
            // 
            this.delay_link_bm_backup.Location = new System.Drawing.Point(577, 27);
            this.delay_link_bm_backup.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.delay_link_bm_backup.Name = "delay_link_bm_backup";
            this.delay_link_bm_backup.Size = new System.Drawing.Size(120, 21);
            this.delay_link_bm_backup.TabIndex = 32;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(476, 27);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(87, 15);
            this.label72.TabIndex = 31;
            this.label72.Text = "Delay Nhận(s):";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(14, 3);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(74, 15);
            this.label71.TabIndex = 30;
            this.label71.Text = "MAIL|PASS:";
            // 
            // rtb_MAIL_DOCLINK_BACKUP
            // 
            this.rtb_MAIL_DOCLINK_BACKUP.Location = new System.Drawing.Point(17, 24);
            this.rtb_MAIL_DOCLINK_BACKUP.Name = "rtb_MAIL_DOCLINK_BACKUP";
            this.rtb_MAIL_DOCLINK_BACKUP.Size = new System.Drawing.Size(375, 139);
            this.rtb_MAIL_DOCLINK_BACKUP.TabIndex = 29;
            this.rtb_MAIL_DOCLINK_BACKUP.Text = "";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.rtb_FAIL3);
            this.groupBox7.Controls.Add(this.rtb_linkmail3_backup);
            this.groupBox7.Controls.Add(this.rtb_DONE3);
            this.groupBox7.Controls.Add(this.label64);
            this.groupBox7.Controls.Add(this.label65);
            this.groupBox7.Controls.Add(this.label66);
            this.groupBox7.Location = new System.Drawing.Point(1144, 178);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(557, 435);
            this.groupBox7.TabIndex = 28;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "MAIL3";
            // 
            // rtb_FAIL3
            // 
            this.rtb_FAIL3.Location = new System.Drawing.Point(364, 44);
            this.rtb_FAIL3.Name = "rtb_FAIL3";
            this.rtb_FAIL3.Size = new System.Drawing.Size(173, 385);
            this.rtb_FAIL3.TabIndex = 32;
            this.rtb_FAIL3.Text = "";
            // 
            // rtb_linkmail3_backup
            // 
            this.rtb_linkmail3_backup.Location = new System.Drawing.Point(185, 44);
            this.rtb_linkmail3_backup.Name = "rtb_linkmail3_backup";
            this.rtb_linkmail3_backup.Size = new System.Drawing.Size(173, 385);
            this.rtb_linkmail3_backup.TabIndex = 31;
            this.rtb_linkmail3_backup.Text = "";
            // 
            // rtb_DONE3
            // 
            this.rtb_DONE3.Location = new System.Drawing.Point(6, 44);
            this.rtb_DONE3.Name = "rtb_DONE3";
            this.rtb_DONE3.Size = new System.Drawing.Size(173, 385);
            this.rtb_DONE3.TabIndex = 30;
            this.rtb_DONE3.Text = "";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(421, 26);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(74, 15);
            this.label64.TabIndex = 26;
            this.label64.Text = "LINK3 FAIL:";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(236, 26);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(79, 15);
            this.label65.TabIndex = 27;
            this.label65.Text = "LINK MAIL3:";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(68, 26);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(84, 15);
            this.label66.TabIndex = 25;
            this.label66.Text = "LINK3 DONE:";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.rtb_FAIL2);
            this.groupBox6.Controls.Add(this.rtb_linkmail2_backup);
            this.groupBox6.Controls.Add(this.rtb_DONE2);
            this.groupBox6.Controls.Add(this.label61);
            this.groupBox6.Controls.Add(this.label62);
            this.groupBox6.Controls.Add(this.label63);
            this.groupBox6.Location = new System.Drawing.Point(581, 178);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(557, 435);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "MAIL2";
            // 
            // rtb_FAIL2
            // 
            this.rtb_FAIL2.Location = new System.Drawing.Point(373, 44);
            this.rtb_FAIL2.Name = "rtb_FAIL2";
            this.rtb_FAIL2.Size = new System.Drawing.Size(173, 385);
            this.rtb_FAIL2.TabIndex = 32;
            this.rtb_FAIL2.Text = "";
            // 
            // rtb_linkmail2_backup
            // 
            this.rtb_linkmail2_backup.Location = new System.Drawing.Point(194, 44);
            this.rtb_linkmail2_backup.Name = "rtb_linkmail2_backup";
            this.rtb_linkmail2_backup.Size = new System.Drawing.Size(173, 385);
            this.rtb_linkmail2_backup.TabIndex = 31;
            this.rtb_linkmail2_backup.Text = "";
            // 
            // rtb_DONE2
            // 
            this.rtb_DONE2.Location = new System.Drawing.Point(15, 44);
            this.rtb_DONE2.Name = "rtb_DONE2";
            this.rtb_DONE2.Size = new System.Drawing.Size(173, 385);
            this.rtb_DONE2.TabIndex = 30;
            this.rtb_DONE2.Text = "";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(421, 26);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(74, 15);
            this.label61.TabIndex = 26;
            this.label61.Text = "LINK2 FAIL:";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(236, 26);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(79, 15);
            this.label62.TabIndex = 27;
            this.label62.Text = "LINK MAIL2:";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(68, 26);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(84, 15);
            this.label63.TabIndex = 25;
            this.label63.Text = "LINK2 DONE:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.rtb_FAIL1);
            this.groupBox5.Controls.Add(this.rtb_linkmail1_backup);
            this.groupBox5.Controls.Add(this.label59);
            this.groupBox5.Controls.Add(this.label60);
            this.groupBox5.Controls.Add(this.label58);
            this.groupBox5.Controls.Add(this.rtb_DONE1);
            this.groupBox5.Location = new System.Drawing.Point(17, 178);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(557, 435);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "MAIL1";
            // 
            // rtb_FAIL1
            // 
            this.rtb_FAIL1.Location = new System.Drawing.Point(373, 44);
            this.rtb_FAIL1.Name = "rtb_FAIL1";
            this.rtb_FAIL1.Size = new System.Drawing.Size(173, 385);
            this.rtb_FAIL1.TabIndex = 29;
            this.rtb_FAIL1.Text = "";
            // 
            // rtb_linkmail1_backup
            // 
            this.rtb_linkmail1_backup.Location = new System.Drawing.Point(194, 44);
            this.rtb_linkmail1_backup.Name = "rtb_linkmail1_backup";
            this.rtb_linkmail1_backup.Size = new System.Drawing.Size(173, 385);
            this.rtb_linkmail1_backup.TabIndex = 28;
            this.rtb_linkmail1_backup.Text = "";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(421, 26);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(74, 15);
            this.label59.TabIndex = 26;
            this.label59.Text = "LINK1 FAIL:";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(236, 26);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(79, 15);
            this.label60.TabIndex = 27;
            this.label60.Text = "LINK MAIL1:";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(68, 26);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(84, 15);
            this.label58.TabIndex = 25;
            this.label58.Text = "LINK1 DONE:";
            // 
            // rtb_DONE1
            // 
            this.rtb_DONE1.Location = new System.Drawing.Point(15, 44);
            this.rtb_DONE1.Name = "rtb_DONE1";
            this.rtb_DONE1.Size = new System.Drawing.Size(173, 385);
            this.rtb_DONE1.TabIndex = 0;
            this.rtb_DONE1.Text = "";
            // 
            // tabPage9
            // 
            this.tabPage9.BackColor = System.Drawing.Color.Gray;
            this.tabPage9.Controls.Add(this.label75);
            this.tabPage9.Controls.Add(this.cmb_HOTMAIL_GMAIL);
            this.tabPage9.Controls.Add(this.cmbonoffchrome);
            this.tabPage9.Controls.Add(this.cmb_lay_Cookie);
            this.tabPage9.Controls.Add(this.label69);
            this.tabPage9.Controls.Add(this.label70);
            this.tabPage9.Location = new System.Drawing.Point(4, 24);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(1767, 688);
            this.tabPage9.TabIndex = 6;
            this.tabPage9.Text = "CÀI ĐẶT CHUNG";
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Location = new System.Drawing.Point(376, 43);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(110, 15);
            this.label75.TabIndex = 38;
            this.label75.Text = "HOTMAIL/GMAIL:";
            // 
            // cmb_HOTMAIL_GMAIL
            // 
            this.cmb_HOTMAIL_GMAIL.FormattingEnabled = true;
            this.cmb_HOTMAIL_GMAIL.Location = new System.Drawing.Point(492, 37);
            this.cmb_HOTMAIL_GMAIL.Name = "cmb_HOTMAIL_GMAIL";
            this.cmb_HOTMAIL_GMAIL.Size = new System.Drawing.Size(121, 23);
            this.cmb_HOTMAIL_GMAIL.TabIndex = 37;
            // 
            // cmbonoffchrome
            // 
            this.cmbonoffchrome.FormattingEnabled = true;
            this.cmbonoffchrome.Location = new System.Drawing.Point(129, 68);
            this.cmbonoffchrome.Name = "cmbonoffchrome";
            this.cmbonoffchrome.Size = new System.Drawing.Size(121, 23);
            this.cmbonoffchrome.TabIndex = 36;
            // 
            // cmb_lay_Cookie
            // 
            this.cmb_lay_Cookie.FormattingEnabled = true;
            this.cmb_lay_Cookie.Location = new System.Drawing.Point(129, 43);
            this.cmb_lay_Cookie.Name = "cmb_lay_Cookie";
            this.cmb_lay_Cookie.Size = new System.Drawing.Size(121, 23);
            this.cmb_lay_Cookie.TabIndex = 35;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(14, 72);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(114, 15);
            this.label69.TabIndex = 34;
            this.label69.Text = "ON/OFF CHROME:";
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(40, 45);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(86, 15);
            this.label70.TabIndex = 33;
            this.label70.Text = "LẤY COOKIE:";
            // 
            // tabPage10
            // 
            this.tabPage10.BackColor = System.Drawing.Color.Gray;
            this.tabPage10.Controls.Add(this.tabControl3);
            this.tabPage10.Location = new System.Drawing.Point(4, 24);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage10.Size = new System.Drawing.Size(1767, 688);
            this.tabPage10.TabIndex = 7;
            this.tabPage10.Text = "LOAD BM";
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage11);
            this.tabControl3.Controls.Add(this.tabPage12);
            this.tabControl3.Controls.Add(this.tabPage22);
            this.tabControl3.Location = new System.Drawing.Point(0, 0);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(1748, 684);
            this.tabControl3.TabIndex = 0;
            // 
            // tabPage11
            // 
            this.tabPage11.BackColor = System.Drawing.Color.Gray;
            this.tabPage11.Controls.Add(this.tb_IDBM_CHECK);
            this.tabPage11.Controls.Add(this.label210);
            this.tabPage11.Controls.Add(this.delay_check_infor);
            this.tabPage11.Controls.Add(this.label209);
            this.tabPage11.Controls.Add(this.cmb_Check_Infor_BM);
            this.tabPage11.Controls.Add(this.label207);
            this.tabPage11.Controls.Add(this.cmb_LOAD_API_CHROME);
            this.tabPage11.Controls.Add(this.label192);
            this.tabPage11.Controls.Add(this.tb_EEAG_LOAD_BM);
            this.tabPage11.Controls.Add(this.label189);
            this.tabPage11.Controls.Add(this.label91);
            this.tabPage11.Controls.Add(this.numericUpDown2);
            this.tabPage11.Controls.Add(this.label92);
            this.tabPage11.Controls.Add(this.sl_LOAD_TK_D2);
            this.tabPage11.Controls.Add(this.dgv_AC);
            this.tabPage11.Controls.Add(this.label90);
            this.tabPage11.Controls.Add(this.delay_LOAD_BM);
            this.tabPage11.Controls.Add(this.label89);
            this.tabPage11.Controls.Add(this.SL_BM_LOAD);
            this.tabPage11.Controls.Add(this.rtb_IDBM_FILTER);
            this.tabPage11.Controls.Add(this.bt_filter);
            this.tabPage11.Controls.Add(this.dgv_BM);
            this.tabPage11.Location = new System.Drawing.Point(4, 24);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(1740, 656);
            this.tabPage11.TabIndex = 0;
            this.tabPage11.Text = "HIỂN THỊ";
            // 
            // tb_IDBM_CHECK
            // 
            this.tb_IDBM_CHECK.Location = new System.Drawing.Point(1314, 54);
            this.tb_IDBM_CHECK.Name = "tb_IDBM_CHECK";
            this.tb_IDBM_CHECK.Size = new System.Drawing.Size(317, 21);
            this.tb_IDBM_CHECK.TabIndex = 51;
            // 
            // label210
            // 
            this.label210.AutoSize = true;
            this.label210.Location = new System.Drawing.Point(1208, 54);
            this.label210.Name = "label210";
            this.label210.Size = new System.Drawing.Size(92, 15);
            this.label210.TabIndex = 50;
            this.label210.Text = "IDBM_CHECK:";
            // 
            // delay_check_infor
            // 
            this.delay_check_infor.Location = new System.Drawing.Point(814, 30);
            this.delay_check_infor.Name = "delay_check_infor";
            this.delay_check_infor.Size = new System.Drawing.Size(120, 21);
            this.delay_check_infor.TabIndex = 49;
            this.delay_check_infor.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label209
            // 
            this.label209.AutoSize = true;
            this.label209.Location = new System.Drawing.Point(571, 41);
            this.label209.Name = "label209";
            this.label209.Size = new System.Drawing.Size(114, 15);
            this.label209.TabIndex = 48;
            this.label209.Text = "Check_INFOR_BM:";
            // 
            // cmb_Check_Infor_BM
            // 
            this.cmb_Check_Infor_BM.FormattingEnabled = true;
            this.cmb_Check_Infor_BM.Location = new System.Drawing.Point(693, 38);
            this.cmb_Check_Infor_BM.Name = "cmb_Check_Infor_BM";
            this.cmb_Check_Infor_BM.Size = new System.Drawing.Size(91, 23);
            this.cmb_Check_Infor_BM.TabIndex = 47;
            // 
            // label207
            // 
            this.label207.AutoSize = true;
            this.label207.Location = new System.Drawing.Point(571, 12);
            this.label207.Name = "label207";
            this.label207.Size = new System.Drawing.Size(123, 15);
            this.label207.TabIndex = 36;
            this.label207.Text = "CHỨC NĂNG LOAD:";
            // 
            // cmb_LOAD_API_CHROME
            // 
            this.cmb_LOAD_API_CHROME.FormattingEnabled = true;
            this.cmb_LOAD_API_CHROME.Location = new System.Drawing.Point(693, 9);
            this.cmb_LOAD_API_CHROME.Name = "cmb_LOAD_API_CHROME";
            this.cmb_LOAD_API_CHROME.Size = new System.Drawing.Size(91, 23);
            this.cmb_LOAD_API_CHROME.TabIndex = 46;
            // 
            // label192
            // 
            this.label192.AutoSize = true;
            this.label192.Location = new System.Drawing.Point(811, 12);
            this.label192.Name = "label192";
            this.label192.Size = new System.Drawing.Size(120, 15);
            this.label192.TabIndex = 45;
            this.label192.Text = "Delay LOAD INFOR:";
            // 
            // tb_EEAG_LOAD_BM
            // 
            this.tb_EEAG_LOAD_BM.Location = new System.Drawing.Point(1314, 26);
            this.tb_EEAG_LOAD_BM.Name = "tb_EEAG_LOAD_BM";
            this.tb_EEAG_LOAD_BM.Size = new System.Drawing.Size(317, 21);
            this.tb_EEAG_LOAD_BM.TabIndex = 43;
            // 
            // label189
            // 
            this.label189.AutoSize = true;
            this.label189.Location = new System.Drawing.Point(1208, 29);
            this.label189.Name = "label189";
            this.label189.Size = new System.Drawing.Size(81, 15);
            this.label189.TabIndex = 42;
            this.label189.Text = "Token_EEAG:";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(907, 54);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(151, 15);
            this.label91.TabIndex = 37;
            this.label91.Text = "Delay LOAD TK DÒNG 2 :";
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(1064, 54);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown2.TabIndex = 36;
            this.numericUpDown2.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(993, 9);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(170, 15);
            this.label92.TabIndex = 35;
            this.label92.Text = "SỐ LƯỢNG TK LOAD/1 LẦN:";
            // 
            // sl_LOAD_TK_D2
            // 
            this.sl_LOAD_TK_D2.Location = new System.Drawing.Point(1064, 27);
            this.sl_LOAD_TK_D2.Name = "sl_LOAD_TK_D2";
            this.sl_LOAD_TK_D2.Size = new System.Drawing.Size(120, 21);
            this.sl_LOAD_TK_D2.TabIndex = 34;
            this.sl_LOAD_TK_D2.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // dgv_AC
            // 
            this.dgv_AC.AllowUserToAddRows = false;
            this.dgv_AC.AllowUserToDeleteRows = false;
            this.dgv_AC.AllowUserToResizeRows = false;
            this.dgv_AC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_AC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_AC.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cSttACBM,
            this.cIDACBM,
            this.cNAMEAC,
            this.cStatusAC,
            this.cLimit,
            this.cTIENTE,
            this.cNGAYTAOACBM,
            this.cSelectACBM});
            this.dgv_AC.ContextMenuStrip = this.contextMenuStrip5;
            this.dgv_AC.Location = new System.Drawing.Point(969, 81);
            this.dgv_AC.Name = "dgv_AC";
            this.dgv_AC.RowHeadersVisible = false;
            this.dgv_AC.Size = new System.Drawing.Size(765, 569);
            this.dgv_AC.TabIndex = 33;
            this.dgv_AC.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgv_AC_CellFormatting);
            // 
            // cSttACBM
            // 
            this.cSttACBM.FillWeight = 30F;
            this.cSttACBM.HeaderText = "STT";
            this.cSttACBM.Name = "cSttACBM";
            // 
            // cIDACBM
            // 
            this.cIDACBM.HeaderText = "ID AC";
            this.cIDACBM.Name = "cIDACBM";
            // 
            // cNAMEAC
            // 
            this.cNAMEAC.HeaderText = "NAME AC";
            this.cNAMEAC.Name = "cNAMEAC";
            // 
            // cStatusAC
            // 
            this.cStatusAC.FillWeight = 50F;
            this.cStatusAC.HeaderText = "STATUS";
            this.cStatusAC.Name = "cStatusAC";
            // 
            // cLimit
            // 
            this.cLimit.FillWeight = 50F;
            this.cLimit.HeaderText = "Limit";
            this.cLimit.Name = "cLimit";
            // 
            // cTIENTE
            // 
            this.cTIENTE.FillWeight = 50F;
            this.cTIENTE.HeaderText = "Tiền Tệ";
            this.cTIENTE.Name = "cTIENTE";
            this.cTIENTE.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.cTIENTE.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // cNGAYTAOACBM
            // 
            this.cNGAYTAOACBM.HeaderText = "Ngày Tạo";
            this.cNGAYTAOACBM.Name = "cNGAYTAOACBM";
            // 
            // cSelectACBM
            // 
            this.cSelectACBM.FillWeight = 20F;
            this.cSelectACBM.HeaderText = "";
            this.cSelectACBM.Name = "cSelectACBM";
            // 
            // contextMenuStrip5
            // 
            this.contextMenuStrip5.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.xÓAALLToolStripMenuItem1});
            this.contextMenuStrip5.Name = "contextMenuStrip5";
            this.contextMenuStrip5.Size = new System.Drawing.Size(122, 26);
            // 
            // xÓAALLToolStripMenuItem1
            // 
            this.xÓAALLToolStripMenuItem1.Name = "xÓAALLToolStripMenuItem1";
            this.xÓAALLToolStripMenuItem1.Size = new System.Drawing.Size(121, 22);
            this.xÓAALLToolStripMenuItem1.Text = "XÓA ALL";
            this.xÓAALLToolStripMenuItem1.Click += new System.EventHandler(this.xÓAALLToolStripMenuItem1_Click);
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Location = new System.Drawing.Point(332, 56);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(101, 15);
            this.label90.TabIndex = 32;
            this.label90.Text = "Delay LOAD BM:";
            // 
            // delay_LOAD_BM
            // 
            this.delay_LOAD_BM.Location = new System.Drawing.Point(436, 54);
            this.delay_LOAD_BM.Name = "delay_LOAD_BM";
            this.delay_LOAD_BM.Size = new System.Drawing.Size(120, 21);
            this.delay_LOAD_BM.TabIndex = 31;
            this.delay_LOAD_BM.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Location = new System.Drawing.Point(365, 9);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(172, 15);
            this.label89.TabIndex = 30;
            this.label89.Text = "SỐ LƯỢNG BM LOAD/1 LẦN:";
            // 
            // SL_BM_LOAD
            // 
            this.SL_BM_LOAD.Location = new System.Drawing.Point(436, 27);
            this.SL_BM_LOAD.Name = "SL_BM_LOAD";
            this.SL_BM_LOAD.Size = new System.Drawing.Size(120, 21);
            this.SL_BM_LOAD.TabIndex = 6;
            this.SL_BM_LOAD.Value = new decimal(new int[] {
            40,
            0,
            0,
            0});
            // 
            // rtb_IDBM_FILTER
            // 
            this.rtb_IDBM_FILTER.Location = new System.Drawing.Point(152, 9);
            this.rtb_IDBM_FILTER.Name = "rtb_IDBM_FILTER";
            this.rtb_IDBM_FILTER.Size = new System.Drawing.Size(162, 60);
            this.rtb_IDBM_FILTER.TabIndex = 5;
            this.rtb_IDBM_FILTER.Text = "";
            // 
            // bt_filter
            // 
            this.bt_filter.Location = new System.Drawing.Point(16, 23);
            this.bt_filter.Name = "bt_filter";
            this.bt_filter.Size = new System.Drawing.Size(130, 31);
            this.bt_filter.TabIndex = 4;
            this.bt_filter.Text = "FILTER";
            this.bt_filter.UseVisualStyleBackColor = true;
            this.bt_filter.Click += new System.EventHandler(this.bt_filter_Click);
            // 
            // dgv_BM
            // 
            this.dgv_BM.AllowUserToAddRows = false;
            this.dgv_BM.AllowUserToDeleteRows = false;
            this.dgv_BM.AllowUserToResizeRows = false;
            this.dgv_BM.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_BM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_BM.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cSTTBM,
            this.cIDVIA,
            this.cIDBM,
            this.cNAMEBM,
            this.cStatusBM,
            this.cLOAIBM,
            this.cinfor,
            this.cNgayTao,
            this.cADMIN,
            this.cTKLIVEDIE,
            this.cSelectBM});
            this.dgv_BM.ContextMenuStrip = this.contextMenuStrip4;
            this.dgv_BM.Location = new System.Drawing.Point(1, 81);
            this.dgv_BM.Name = "dgv_BM";
            this.dgv_BM.RowHeadersVisible = false;
            this.dgv_BM.Size = new System.Drawing.Size(962, 569);
            this.dgv_BM.TabIndex = 3;
            this.dgv_BM.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_BM_CellContentClick);
            this.dgv_BM.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgv_BM_CellFormatting);
            // 
            // cSTTBM
            // 
            this.cSTTBM.FillWeight = 25.93909F;
            this.cSTTBM.HeaderText = "STT";
            this.cSTTBM.Name = "cSTTBM";
            // 
            // cIDVIA
            // 
            this.cIDVIA.FillWeight = 86.46362F;
            this.cIDVIA.HeaderText = "ID VIA";
            this.cIDVIA.Name = "cIDVIA";
            // 
            // cIDBM
            // 
            this.cIDBM.FillWeight = 86.46362F;
            this.cIDBM.HeaderText = "ID BM";
            this.cIDBM.Name = "cIDBM";
            // 
            // cNAMEBM
            // 
            this.cNAMEBM.FillWeight = 43.23181F;
            this.cNAMEBM.HeaderText = "NAMEBM";
            this.cNAMEBM.Name = "cNAMEBM";
            // 
            // cStatusBM
            // 
            this.cStatusBM.FillWeight = 43.23181F;
            this.cStatusBM.HeaderText = "STATUS";
            this.cStatusBM.Name = "cStatusBM";
            // 
            // cLOAIBM
            // 
            this.cLOAIBM.FillWeight = 43.23181F;
            this.cLOAIBM.HeaderText = "Loại BM";
            this.cLOAIBM.Name = "cLOAIBM";
            // 
            // cinfor
            // 
            this.cinfor.FillWeight = 30F;
            this.cinfor.HeaderText = "Business_Info";
            this.cinfor.Name = "cinfor";
            // 
            // cNgayTao
            // 
            this.cNgayTao.FillWeight = 86.46362F;
            this.cNgayTao.HeaderText = "Ngày Tạo";
            this.cNgayTao.Name = "cNgayTao";
            // 
            // cADMIN
            // 
            this.cADMIN.FillWeight = 25.93909F;
            this.cADMIN.HeaderText = "ADMIN";
            this.cADMIN.Name = "cADMIN";
            this.cADMIN.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.cADMIN.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // cTKLIVEDIE
            // 
            this.cTKLIVEDIE.FillWeight = 86.46362F;
            this.cTKLIVEDIE.HeaderText = "TKLIVE || TKDIE";
            this.cTKLIVEDIE.Name = "cTKLIVEDIE";
            this.cTKLIVEDIE.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.cTKLIVEDIE.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // cSelectBM
            // 
            this.cSelectBM.FillWeight = 17.29272F;
            this.cSelectBM.HeaderText = "";
            this.cSelectBM.Name = "cSelectBM";
            // 
            // contextMenuStrip4
            // 
            this.contextMenuStrip4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chọnToolStripMenuItem3,
            this.bỏChọnToolStripMenuItem3,
            this.xóaALLToolStripMenuItem,
            this.lOADTKDONGToolStripMenuItem,
            this.bACKUPBMToolStripMenuItem,
            this.bACKUPBMNHIEUVIAToolStripMenuItem});
            this.contextMenuStrip4.Name = "contextMenuStrip4";
            this.contextMenuStrip4.Size = new System.Drawing.Size(203, 136);
            // 
            // chọnToolStripMenuItem3
            // 
            this.chọnToolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bôiĐenToolStripMenuItem7,
            this.tấtCảToolStripMenuItem9});
            this.chọnToolStripMenuItem3.Name = "chọnToolStripMenuItem3";
            this.chọnToolStripMenuItem3.Size = new System.Drawing.Size(202, 22);
            this.chọnToolStripMenuItem3.Text = "Chọn";
            // 
            // bôiĐenToolStripMenuItem7
            // 
            this.bôiĐenToolStripMenuItem7.Name = "bôiĐenToolStripMenuItem7";
            this.bôiĐenToolStripMenuItem7.Size = new System.Drawing.Size(115, 22);
            this.bôiĐenToolStripMenuItem7.Text = "Bôi Đen";
            this.bôiĐenToolStripMenuItem7.Click += new System.EventHandler(this.bôiĐenToolStripMenuItem7_Click);
            // 
            // tấtCảToolStripMenuItem9
            // 
            this.tấtCảToolStripMenuItem9.Name = "tấtCảToolStripMenuItem9";
            this.tấtCảToolStripMenuItem9.Size = new System.Drawing.Size(115, 22);
            this.tấtCảToolStripMenuItem9.Text = "Tất Cả";
            this.tấtCảToolStripMenuItem9.Click += new System.EventHandler(this.tấtCảToolStripMenuItem9_Click);
            // 
            // bỏChọnToolStripMenuItem3
            // 
            this.bỏChọnToolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bôiĐenToolStripMenuItem8,
            this.tấtCảToolStripMenuItem10});
            this.bỏChọnToolStripMenuItem3.Name = "bỏChọnToolStripMenuItem3";
            this.bỏChọnToolStripMenuItem3.Size = new System.Drawing.Size(202, 22);
            this.bỏChọnToolStripMenuItem3.Text = "Bỏ Chọn";
            // 
            // bôiĐenToolStripMenuItem8
            // 
            this.bôiĐenToolStripMenuItem8.Name = "bôiĐenToolStripMenuItem8";
            this.bôiĐenToolStripMenuItem8.Size = new System.Drawing.Size(115, 22);
            this.bôiĐenToolStripMenuItem8.Text = "Bôi Đen";
            this.bôiĐenToolStripMenuItem8.Click += new System.EventHandler(this.bôiĐenToolStripMenuItem8_Click);
            // 
            // tấtCảToolStripMenuItem10
            // 
            this.tấtCảToolStripMenuItem10.Name = "tấtCảToolStripMenuItem10";
            this.tấtCảToolStripMenuItem10.Size = new System.Drawing.Size(115, 22);
            this.tấtCảToolStripMenuItem10.Text = "Tất Cả";
            this.tấtCảToolStripMenuItem10.Click += new System.EventHandler(this.tấtCảToolStripMenuItem10_Click);
            // 
            // xóaALLToolStripMenuItem
            // 
            this.xóaALLToolStripMenuItem.Name = "xóaALLToolStripMenuItem";
            this.xóaALLToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.xóaALLToolStripMenuItem.Text = "Xóa ALL";
            this.xóaALLToolStripMenuItem.Click += new System.EventHandler(this.xóaALLToolStripMenuItem_Click);
            // 
            // lOADTKDONGToolStripMenuItem
            // 
            this.lOADTKDONGToolStripMenuItem.Name = "lOADTKDONGToolStripMenuItem";
            this.lOADTKDONGToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.lOADTKDONGToolStripMenuItem.Text = "LOAD TK DONG 2 BM";
            this.lOADTKDONGToolStripMenuItem.Click += new System.EventHandler(this.lOADTKDONGToolStripMenuItem_Click);
            // 
            // bACKUPBMToolStripMenuItem
            // 
            this.bACKUPBMToolStripMenuItem.Name = "bACKUPBMToolStripMenuItem";
            this.bACKUPBMToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.bACKUPBMToolStripMenuItem.Text = "BACK UP BM";
            this.bACKUPBMToolStripMenuItem.Click += new System.EventHandler(this.bACKUPBMToolStripMenuItem_Click);
            // 
            // bACKUPBMNHIEUVIAToolStripMenuItem
            // 
            this.bACKUPBMNHIEUVIAToolStripMenuItem.Name = "bACKUPBMNHIEUVIAToolStripMenuItem";
            this.bACKUPBMNHIEUVIAToolStripMenuItem.Size = new System.Drawing.Size(202, 22);
            this.bACKUPBMNHIEUVIAToolStripMenuItem.Text = "BACK UP BM NHIEU VIA";
            this.bACKUPBMNHIEUVIAToolStripMenuItem.Click += new System.EventHandler(this.bACKUPBMNHIEUVIAToolStripMenuItem_Click);
            // 
            // tabPage12
            // 
            this.tabPage12.BackColor = System.Drawing.Color.Gray;
            this.tabPage12.Controls.Add(this.tb_Token);
            this.tabPage12.Controls.Add(this.label195);
            this.tabPage12.Controls.Add(this.label174);
            this.tabPage12.Controls.Add(this.rtb_backup_fail);
            this.tabPage12.Controls.Add(this.bt_doi_dinh_dang);
            this.tabPage12.Controls.Add(this.label173);
            this.tabPage12.Controls.Add(this.rtb_BM_OUT);
            this.tabPage12.Controls.Add(this.label172);
            this.tabPage12.Controls.Add(this.rtb_ADMIN_BM_CHECK);
            this.tabPage12.Controls.Add(this.label165);
            this.tabPage12.Controls.Add(this.rtb_IDBM_Can_Tao_TK);
            this.tabPage12.Controls.Add(this.label164);
            this.tabPage12.Controls.Add(this.rtb_IDBM_CAN_BACK_Up);
            this.tabPage12.Controls.Add(this.label99);
            this.tabPage12.Controls.Add(this.rtb_Link_BM);
            this.tabPage12.Controls.Add(this.groupBox9);
            this.tabPage12.Location = new System.Drawing.Point(4, 24);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage12.Size = new System.Drawing.Size(1740, 656);
            this.tabPage12.TabIndex = 1;
            this.tabPage12.Text = "CÀI ĐẶT LINK BM";
            // 
            // tb_Token
            // 
            this.tb_Token.Location = new System.Drawing.Point(204, 398);
            this.tb_Token.Name = "tb_Token";
            this.tb_Token.Size = new System.Drawing.Size(317, 21);
            this.tb_Token.TabIndex = 52;
            // 
            // label195
            // 
            this.label195.AutoSize = true;
            this.label195.Location = new System.Drawing.Point(98, 401);
            this.label195.Name = "label195";
            this.label195.Size = new System.Drawing.Size(81, 15);
            this.label195.TabIndex = 51;
            this.label195.Text = "Token_EEAG:";
            // 
            // label174
            // 
            this.label174.AutoSize = true;
            this.label174.Location = new System.Drawing.Point(1003, 355);
            this.label174.Name = "label174";
            this.label174.Size = new System.Drawing.Size(268, 15);
            this.label174.TabIndex = 50;
            this.label174.Text = "IDBM Cần Back Up/OUT/CHECK_ADMIN FAIL!:";
            // 
            // rtb_backup_fail
            // 
            this.rtb_backup_fail.Location = new System.Drawing.Point(1006, 373);
            this.rtb_backup_fail.Name = "rtb_backup_fail";
            this.rtb_backup_fail.Size = new System.Drawing.Size(212, 266);
            this.rtb_backup_fail.TabIndex = 49;
            this.rtb_backup_fail.Text = "";
            // 
            // bt_doi_dinh_dang
            // 
            this.bt_doi_dinh_dang.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.bt_doi_dinh_dang.Location = new System.Drawing.Point(978, 6);
            this.bt_doi_dinh_dang.Name = "bt_doi_dinh_dang";
            this.bt_doi_dinh_dang.Size = new System.Drawing.Size(135, 35);
            this.bt_doi_dinh_dang.TabIndex = 48;
            this.bt_doi_dinh_dang.Text = "ĐỔI ĐỊNH DẠNG";
            this.bt_doi_dinh_dang.UseVisualStyleBackColor = false;
            this.bt_doi_dinh_dang.Click += new System.EventHandler(this.bt_doi_dinh_dang_Click);
            // 
            // label173
            // 
            this.label173.AutoSize = true;
            this.label173.Location = new System.Drawing.Point(1514, 355);
            this.label173.Name = "label173";
            this.label173.Size = new System.Drawing.Size(133, 15);
            this.label173.TabIndex = 47;
            this.label173.Text = "CHECK BM CẦN OUT:";
            // 
            // rtb_BM_OUT
            // 
            this.rtb_BM_OUT.Location = new System.Drawing.Point(1476, 373);
            this.rtb_BM_OUT.Name = "rtb_BM_OUT";
            this.rtb_BM_OUT.Size = new System.Drawing.Size(212, 266);
            this.rtb_BM_OUT.TabIndex = 46;
            this.rtb_BM_OUT.Text = "";
            // 
            // label172
            // 
            this.label172.AutoSize = true;
            this.label172.Location = new System.Drawing.Point(1473, 57);
            this.label172.Name = "label172";
            this.label172.Size = new System.Drawing.Size(207, 15);
            this.label172.TabIndex = 45;
            this.label172.Text = "CHECK ADMIN IDBM CẦN CHECK:";
            // 
            // rtb_ADMIN_BM_CHECK
            // 
            this.rtb_ADMIN_BM_CHECK.Location = new System.Drawing.Point(1476, 75);
            this.rtb_ADMIN_BM_CHECK.Name = "rtb_ADMIN_BM_CHECK";
            this.rtb_ADMIN_BM_CHECK.Size = new System.Drawing.Size(212, 266);
            this.rtb_ADMIN_BM_CHECK.TabIndex = 44;
            this.rtb_ADMIN_BM_CHECK.Text = "";
            // 
            // label165
            // 
            this.label165.AutoSize = true;
            this.label165.Location = new System.Drawing.Point(1288, 57);
            this.label165.Name = "label165";
            this.label165.Size = new System.Drawing.Size(111, 15);
            this.label165.TabIndex = 43;
            this.label165.Text = "IDBM Cần Tạo TK:";
            // 
            // rtb_IDBM_Can_Tao_TK
            // 
            this.rtb_IDBM_Can_Tao_TK.Location = new System.Drawing.Point(1243, 75);
            this.rtb_IDBM_Can_Tao_TK.Name = "rtb_IDBM_Can_Tao_TK";
            this.rtb_IDBM_Can_Tao_TK.Size = new System.Drawing.Size(212, 266);
            this.rtb_IDBM_Can_Tao_TK.TabIndex = 42;
            this.rtb_IDBM_Can_Tao_TK.Text = "";
            // 
            // label164
            // 
            this.label164.AutoSize = true;
            this.label164.Location = new System.Drawing.Point(1003, 57);
            this.label164.Name = "label164";
            this.label164.Size = new System.Drawing.Size(236, 15);
            this.label164.TabIndex = 41;
            this.label164.Text = "IDBM Cần Back Up/OUT/CHECK_ADMIN:";
            // 
            // rtb_IDBM_CAN_BACK_Up
            // 
            this.rtb_IDBM_CAN_BACK_Up.Location = new System.Drawing.Point(1006, 75);
            this.rtb_IDBM_CAN_BACK_Up.Name = "rtb_IDBM_CAN_BACK_Up";
            this.rtb_IDBM_CAN_BACK_Up.Size = new System.Drawing.Size(212, 266);
            this.rtb_IDBM_CAN_BACK_Up.TabIndex = 40;
            this.rtb_IDBM_CAN_BACK_Up.Text = "";
            // 
            // label99
            // 
            this.label99.AutoSize = true;
            this.label99.Location = new System.Drawing.Point(583, 57);
            this.label99.Name = "label99";
            this.label99.Size = new System.Drawing.Size(86, 15);
            this.label99.TabIndex = 39;
            this.label99.Text = "LINK SHARE :";
            // 
            // rtb_Link_BM
            // 
            this.rtb_Link_BM.Location = new System.Drawing.Point(586, 75);
            this.rtb_Link_BM.Name = "rtb_Link_BM";
            this.rtb_Link_BM.Size = new System.Drawing.Size(358, 266);
            this.rtb_Link_BM.TabIndex = 1;
            this.rtb_Link_BM.Text = "";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.cmb_API_CHROME_BACK_UP_BM_THEO_ID);
            this.groupBox9.Controls.Add(this.label208);
            this.groupBox9.Controls.Add(this.label199);
            this.groupBox9.Controls.Add(this.cmb_share_ban);
            this.groupBox9.Controls.Add(this.label194);
            this.groupBox9.Controls.Add(this.n_Delay_TTK);
            this.groupBox9.Controls.Add(this.label193);
            this.groupBox9.Controls.Add(this.bt_Tao_TK_BM);
            this.groupBox9.Controls.Add(this.numericUpDown7);
            this.groupBox9.Controls.Add(this.cmb_loai_mail);
            this.groupBox9.Controls.Add(this.cmb_Admin_BM1);
            this.groupBox9.Controls.Add(this.delay_doc_link);
            this.groupBox9.Controls.Add(this.so_link_backup);
            this.groupBox9.Controls.Add(this.tb_hotmail_Share_bm);
            this.groupBox9.Controls.Add(this.label98);
            this.groupBox9.Controls.Add(this.label97);
            this.groupBox9.Controls.Add(this.label95);
            this.groupBox9.Controls.Add(this.label96);
            this.groupBox9.Controls.Add(this.label94);
            this.groupBox9.Controls.Add(this.label93);
            this.groupBox9.Location = new System.Drawing.Point(82, 63);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(464, 435);
            this.groupBox9.TabIndex = 0;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "SHARE BM";
            // 
            // cmb_API_CHROME_BACK_UP_BM_THEO_ID
            // 
            this.cmb_API_CHROME_BACK_UP_BM_THEO_ID.FormattingEnabled = true;
            this.cmb_API_CHROME_BACK_UP_BM_THEO_ID.Location = new System.Drawing.Point(122, 386);
            this.cmb_API_CHROME_BACK_UP_BM_THEO_ID.Name = "cmb_API_CHROME_BACK_UP_BM_THEO_ID";
            this.cmb_API_CHROME_BACK_UP_BM_THEO_ID.Size = new System.Drawing.Size(107, 23);
            this.cmb_API_CHROME_BACK_UP_BM_THEO_ID.TabIndex = 56;
            // 
            // label208
            // 
            this.label208.AutoSize = true;
            this.label208.Location = new System.Drawing.Point(16, 368);
            this.label208.Name = "label208";
            this.label208.Size = new System.Drawing.Size(273, 15);
            this.label208.TabIndex = 53;
            this.label208.Text = "API/CHROME OUT/CHECK/KICK3/BACKUP_ID:";
            // 
            // label199
            // 
            this.label199.AutoSize = true;
            this.label199.Location = new System.Drawing.Point(6, 217);
            this.label199.Name = "label199";
            this.label199.Size = new System.Drawing.Size(79, 15);
            this.label199.TabIndex = 55;
            this.label199.Text = "SHARE BÁN:";
            // 
            // cmb_share_ban
            // 
            this.cmb_share_ban.FormattingEnabled = true;
            this.cmb_share_ban.Location = new System.Drawing.Point(201, 209);
            this.cmb_share_ban.Name = "cmb_share_ban";
            this.cmb_share_ban.Size = new System.Drawing.Size(180, 23);
            this.cmb_share_ban.TabIndex = 53;
            // 
            // label194
            // 
            this.label194.AutoSize = true;
            this.label194.Location = new System.Drawing.Point(181, 276);
            this.label194.Name = "label194";
            this.label194.Size = new System.Drawing.Size(48, 15);
            this.label194.TabIndex = 54;
            this.label194.Text = "DELAY:";
            // 
            // n_Delay_TTK
            // 
            this.n_Delay_TTK.Location = new System.Drawing.Point(235, 274);
            this.n_Delay_TTK.Name = "n_Delay_TTK";
            this.n_Delay_TTK.Size = new System.Drawing.Size(120, 21);
            this.n_Delay_TTK.TabIndex = 53;
            // 
            // label193
            // 
            this.label193.AutoSize = true;
            this.label193.Location = new System.Drawing.Point(164, 249);
            this.label193.Name = "label193";
            this.label193.Size = new System.Drawing.Size(65, 15);
            this.label193.TabIndex = 52;
            this.label193.Text = "STK TẠO:";
            // 
            // bt_Tao_TK_BM
            // 
            this.bt_Tao_TK_BM.BackColor = System.Drawing.Color.LawnGreen;
            this.bt_Tao_TK_BM.Location = new System.Drawing.Point(9, 241);
            this.bt_Tao_TK_BM.Name = "bt_Tao_TK_BM";
            this.bt_Tao_TK_BM.Size = new System.Drawing.Size(130, 31);
            this.bt_Tao_TK_BM.TabIndex = 51;
            this.bt_Tao_TK_BM.Text = "TAO TK BM";
            this.bt_Tao_TK_BM.UseVisualStyleBackColor = false;
            this.bt_Tao_TK_BM.Click += new System.EventHandler(this.bt_Tao_TK_BM_Click_1);
            // 
            // numericUpDown7
            // 
            this.numericUpDown7.Location = new System.Drawing.Point(235, 247);
            this.numericUpDown7.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.numericUpDown7.Name = "numericUpDown7";
            this.numericUpDown7.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown7.TabIndex = 49;
            this.numericUpDown7.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // cmb_loai_mail
            // 
            this.cmb_loai_mail.FormattingEnabled = true;
            this.cmb_loai_mail.Location = new System.Drawing.Point(201, 149);
            this.cmb_loai_mail.Name = "cmb_loai_mail";
            this.cmb_loai_mail.Size = new System.Drawing.Size(180, 23);
            this.cmb_loai_mail.TabIndex = 48;
            // 
            // cmb_Admin_BM1
            // 
            this.cmb_Admin_BM1.FormattingEnabled = true;
            this.cmb_Admin_BM1.Location = new System.Drawing.Point(201, 116);
            this.cmb_Admin_BM1.Name = "cmb_Admin_BM1";
            this.cmb_Admin_BM1.Size = new System.Drawing.Size(180, 23);
            this.cmb_Admin_BM1.TabIndex = 47;
            // 
            // delay_doc_link
            // 
            this.delay_doc_link.Location = new System.Drawing.Point(201, 182);
            this.delay_doc_link.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.delay_doc_link.Name = "delay_doc_link";
            this.delay_doc_link.Size = new System.Drawing.Size(120, 21);
            this.delay_doc_link.TabIndex = 46;
            // 
            // so_link_backup
            // 
            this.so_link_backup.Location = new System.Drawing.Point(201, 87);
            this.so_link_backup.Name = "so_link_backup";
            this.so_link_backup.Size = new System.Drawing.Size(120, 21);
            this.so_link_backup.TabIndex = 45;
            // 
            // tb_hotmail_Share_bm
            // 
            this.tb_hotmail_Share_bm.Location = new System.Drawing.Point(201, 60);
            this.tb_hotmail_Share_bm.Name = "tb_hotmail_Share_bm";
            this.tb_hotmail_Share_bm.Size = new System.Drawing.Size(180, 21);
            this.tb_hotmail_Share_bm.TabIndex = 44;
            // 
            // label98
            // 
            this.label98.AutoSize = true;
            this.label98.Location = new System.Drawing.Point(220, 17);
            this.label98.Name = "label98";
            this.label98.Size = new System.Drawing.Size(74, 15);
            this.label98.TabIndex = 43;
            this.label98.Text = "MAIL|PASS:";
            // 
            // label97
            // 
            this.label97.AutoSize = true;
            this.label97.Location = new System.Drawing.Point(6, 188);
            this.label97.Name = "label97";
            this.label97.Size = new System.Drawing.Size(48, 15);
            this.label97.TabIndex = 42;
            this.label97.Text = "DELAY:";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(6, 161);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(73, 15);
            this.label95.TabIndex = 41;
            this.label95.Text = "LOẠI MAIL:";
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(6, 123);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(78, 15);
            this.label96.TabIndex = 40;
            this.label96.Text = "QUYỀN BM :";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(6, 95);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(133, 15);
            this.label94.TabIndex = 39;
            this.label94.Text = "SỐ LINK CẦN SHARE:";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(6, 66);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(113, 15);
            this.label93.TabIndex = 38;
            this.label93.Text = "HOTMAIL SHARE :";
            // 
            // tabPage22
            // 
            this.tabPage22.BackColor = System.Drawing.Color.Gray;
            this.tabPage22.Controls.Add(this.label220);
            this.tabPage22.Controls.Add(this.cmb_new_create_WA);
            this.tabPage22.Controls.Add(this.label219);
            this.tabPage22.Controls.Add(this.cmb_delete_WA);
            this.tabPage22.Controls.Add(this.label212);
            this.tabPage22.Controls.Add(this.cmb_ttk_5_1_WA);
            this.tabPage22.Controls.Add(this.cmb_bo_check1);
            this.tabPage22.Controls.Add(this.label211);
            this.tabPage22.Controls.Add(this.label206);
            this.tabPage22.Controls.Add(this.sl_BM_kick3);
            this.tabPage22.Controls.Add(this.label204);
            this.tabPage22.Controls.Add(this.label203);
            this.tabPage22.Controls.Add(this.rtb_BM1);
            this.tabPage22.Controls.Add(this.rtb_BM3);
            this.tabPage22.Controls.Add(this.label197);
            this.tabPage22.Controls.Add(this.m_delay_ttk);
            this.tabPage22.Controls.Add(this.label196);
            this.tabPage22.Controls.Add(this.numericUpDown9);
            this.tabPage22.Controls.Add(this.label191);
            this.tabPage22.Controls.Add(this.cmb_TTKQCBM3);
            this.tabPage22.Controls.Add(this.btdoidang);
            this.tabPage22.Controls.Add(this.label187);
            this.tabPage22.Controls.Add(this.numericUpDown5);
            this.tabPage22.Controls.Add(this.tb_NAME_WHATAPP);
            this.tabPage22.Controls.Add(this.label186);
            this.tabPage22.Controls.Add(this.delay_kick_bm3);
            this.tabPage22.Controls.Add(this.label185);
            this.tabPage22.Controls.Add(this.label184);
            this.tabPage22.Controls.Add(this.rtb_status_kick);
            this.tabPage22.Controls.Add(this.label183);
            this.tabPage22.Controls.Add(this.rtb_IDBM_KICK_BM3);
            this.tabPage22.Controls.Add(this.tb_TokenEEAG);
            this.tabPage22.Controls.Add(this.label182);
            this.tabPage22.Location = new System.Drawing.Point(4, 24);
            this.tabPage22.Name = "tabPage22";
            this.tabPage22.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage22.Size = new System.Drawing.Size(1740, 656);
            this.tabPage22.TabIndex = 2;
            this.tabPage22.Text = "KICK BM3";
            // 
            // label220
            // 
            this.label220.AutoSize = true;
            this.label220.Location = new System.Drawing.Point(771, 255);
            this.label220.Name = "label220";
            this.label220.Size = new System.Drawing.Size(96, 15);
            this.label220.TabIndex = 73;
            this.label220.Text = "TẠO WHATAPP:";
            // 
            // cmb_new_create_WA
            // 
            this.cmb_new_create_WA.FormattingEnabled = true;
            this.cmb_new_create_WA.Location = new System.Drawing.Point(821, 276);
            this.cmb_new_create_WA.Name = "cmb_new_create_WA";
            this.cmb_new_create_WA.Size = new System.Drawing.Size(121, 23);
            this.cmb_new_create_WA.TabIndex = 72;
            // 
            // label219
            // 
            this.label219.AutoSize = true;
            this.label219.Location = new System.Drawing.Point(771, 206);
            this.label219.Name = "label219";
            this.label219.Size = new System.Drawing.Size(115, 15);
            this.label219.TabIndex = 71;
            this.label219.Text = "DELETE WHATAPP:";
            // 
            // cmb_delete_WA
            // 
            this.cmb_delete_WA.FormattingEnabled = true;
            this.cmb_delete_WA.Location = new System.Drawing.Point(821, 229);
            this.cmb_delete_WA.Name = "cmb_delete_WA";
            this.cmb_delete_WA.Size = new System.Drawing.Size(121, 23);
            this.cmb_delete_WA.TabIndex = 70;
            // 
            // label212
            // 
            this.label212.AutoSize = true;
            this.label212.Location = new System.Drawing.Point(777, 162);
            this.label212.Name = "label212";
            this.label212.Size = new System.Drawing.Size(76, 15);
            this.label212.TabIndex = 69;
            this.label212.Text = "TẠO TK 5-1:";
            // 
            // cmb_ttk_5_1_WA
            // 
            this.cmb_ttk_5_1_WA.FormattingEnabled = true;
            this.cmb_ttk_5_1_WA.Location = new System.Drawing.Point(821, 180);
            this.cmb_ttk_5_1_WA.Name = "cmb_ttk_5_1_WA";
            this.cmb_ttk_5_1_WA.Size = new System.Drawing.Size(121, 23);
            this.cmb_ttk_5_1_WA.TabIndex = 68;
            // 
            // cmb_bo_check1
            // 
            this.cmb_bo_check1.FormattingEnabled = true;
            this.cmb_bo_check1.Location = new System.Drawing.Point(821, 127);
            this.cmb_bo_check1.Name = "cmb_bo_check1";
            this.cmb_bo_check1.Size = new System.Drawing.Size(121, 23);
            this.cmb_bo_check1.TabIndex = 67;
            // 
            // label211
            // 
            this.label211.AutoSize = true;
            this.label211.Location = new System.Drawing.Point(777, 109);
            this.label211.Name = "label211";
            this.label211.Size = new System.Drawing.Size(103, 15);
            this.label211.TabIndex = 66;
            this.label211.Text = "BỎ CHECK BM3:";
            // 
            // label206
            // 
            this.label206.AutoSize = true;
            this.label206.Location = new System.Drawing.Point(1060, 14);
            this.label206.Name = "label206";
            this.label206.Size = new System.Drawing.Size(133, 15);
            this.label206.TabIndex = 64;
            this.label206.Text = "SỐ LƯỢNG BM KICK:";
            // 
            // sl_BM_kick3
            // 
            this.sl_BM_kick3.Location = new System.Drawing.Point(1199, 11);
            this.sl_BM_kick3.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.sl_BM_kick3.Name = "sl_BM_kick3";
            this.sl_BM_kick3.Size = new System.Drawing.Size(120, 21);
            this.sl_BM_kick3.TabIndex = 63;
            this.sl_BM_kick3.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // label204
            // 
            this.label204.AutoSize = true;
            this.label204.Location = new System.Drawing.Point(1189, 91);
            this.label204.Name = "label204";
            this.label204.Size = new System.Drawing.Size(36, 15);
            this.label204.TabIndex = 62;
            this.label204.Text = "BM1:";
            // 
            // label203
            // 
            this.label203.AutoSize = true;
            this.label203.Location = new System.Drawing.Point(975, 91);
            this.label203.Name = "label203";
            this.label203.Size = new System.Drawing.Size(36, 15);
            this.label203.TabIndex = 61;
            this.label203.Text = "BM3:";
            // 
            // rtb_BM1
            // 
            this.rtb_BM1.Location = new System.Drawing.Point(1192, 112);
            this.rtb_BM1.Name = "rtb_BM1";
            this.rtb_BM1.Size = new System.Drawing.Size(195, 266);
            this.rtb_BM1.TabIndex = 60;
            this.rtb_BM1.Text = "";
            // 
            // rtb_BM3
            // 
            this.rtb_BM3.Location = new System.Drawing.Point(978, 112);
            this.rtb_BM3.Name = "rtb_BM3";
            this.rtb_BM3.Size = new System.Drawing.Size(195, 266);
            this.rtb_BM3.TabIndex = 59;
            this.rtb_BM3.Text = "";
            // 
            // label197
            // 
            this.label197.AutoSize = true;
            this.label197.Location = new System.Drawing.Point(775, 81);
            this.label197.Name = "label197";
            this.label197.Size = new System.Drawing.Size(42, 15);
            this.label197.TabIndex = 58;
            this.label197.Text = "Delay:";
            // 
            // m_delay_ttk
            // 
            this.m_delay_ttk.Location = new System.Drawing.Point(831, 76);
            this.m_delay_ttk.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.m_delay_ttk.Name = "m_delay_ttk";
            this.m_delay_ttk.Size = new System.Drawing.Size(120, 21);
            this.m_delay_ttk.TabIndex = 57;
            // 
            // label196
            // 
            this.label196.AutoSize = true;
            this.label196.Location = new System.Drawing.Point(777, 52);
            this.label196.Name = "label196";
            this.label196.Size = new System.Drawing.Size(36, 15);
            this.label196.TabIndex = 56;
            this.label196.Text = "STK:";
            // 
            // numericUpDown9
            // 
            this.numericUpDown9.Location = new System.Drawing.Point(831, 49);
            this.numericUpDown9.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.numericUpDown9.Name = "numericUpDown9";
            this.numericUpDown9.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown9.TabIndex = 55;
            this.numericUpDown9.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label191
            // 
            this.label191.AutoSize = true;
            this.label191.Location = new System.Drawing.Point(775, 17);
            this.label191.Name = "label191";
            this.label191.Size = new System.Drawing.Size(55, 15);
            this.label191.TabIndex = 54;
            this.label191.Text = "TTKQC:";
            // 
            // cmb_TTKQCBM3
            // 
            this.cmb_TTKQCBM3.FormattingEnabled = true;
            this.cmb_TTKQCBM3.Location = new System.Drawing.Point(831, 12);
            this.cmb_TTKQCBM3.Name = "cmb_TTKQCBM3";
            this.cmb_TTKQCBM3.Size = new System.Drawing.Size(121, 23);
            this.cmb_TTKQCBM3.TabIndex = 53;
            // 
            // btdoidang
            // 
            this.btdoidang.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btdoidang.Location = new System.Drawing.Point(164, 71);
            this.btdoidang.Name = "btdoidang";
            this.btdoidang.Size = new System.Drawing.Size(135, 35);
            this.btdoidang.TabIndex = 52;
            this.btdoidang.Text = "ĐỔI ĐỊNH DẠNG";
            this.btdoidang.UseVisualStyleBackColor = false;
            this.btdoidang.Click += new System.EventHandler(this.btdoidang_Click);
            // 
            // label187
            // 
            this.label187.AutoSize = true;
            this.label187.Location = new System.Drawing.Point(524, 20);
            this.label187.Name = "label187";
            this.label187.Size = new System.Drawing.Size(50, 15);
            this.label187.TabIndex = 51;
            this.label187.Text = "STLTK:";
            // 
            // numericUpDown5
            // 
            this.numericUpDown5.Location = new System.Drawing.Point(586, 14);
            this.numericUpDown5.Maximum = new decimal(new int[] {
            1000000000,
            0,
            0,
            0});
            this.numericUpDown5.Name = "numericUpDown5";
            this.numericUpDown5.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown5.TabIndex = 50;
            this.numericUpDown5.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // tb_NAME_WHATAPP
            // 
            this.tb_NAME_WHATAPP.Location = new System.Drawing.Point(164, 17);
            this.tb_NAME_WHATAPP.Name = "tb_NAME_WHATAPP";
            this.tb_NAME_WHATAPP.Size = new System.Drawing.Size(317, 21);
            this.tb_NAME_WHATAPP.TabIndex = 49;
            // 
            // label186
            // 
            this.label186.AutoSize = true;
            this.label186.Location = new System.Drawing.Point(57, 20);
            this.label186.Name = "label186";
            this.label186.Size = new System.Drawing.Size(105, 15);
            this.label186.TabIndex = 48;
            this.label186.Text = "NAME WHATAPP:";
            // 
            // delay_kick_bm3
            // 
            this.delay_kick_bm3.Location = new System.Drawing.Point(586, 47);
            this.delay_kick_bm3.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.delay_kick_bm3.Name = "delay_kick_bm3";
            this.delay_kick_bm3.Size = new System.Drawing.Size(120, 21);
            this.delay_kick_bm3.TabIndex = 47;
            this.delay_kick_bm3.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // label185
            // 
            this.label185.AutoSize = true;
            this.label185.Location = new System.Drawing.Point(524, 49);
            this.label185.Name = "label185";
            this.label185.Size = new System.Drawing.Size(42, 15);
            this.label185.TabIndex = 46;
            this.label185.Text = "Delay:";
            // 
            // label184
            // 
            this.label184.AutoSize = true;
            this.label184.Location = new System.Drawing.Point(391, 94);
            this.label184.Name = "label184";
            this.label184.Size = new System.Drawing.Size(94, 15);
            this.label184.TabIndex = 45;
            this.label184.Text = "STATUS_KICK:";
            // 
            // rtb_status_kick
            // 
            this.rtb_status_kick.Location = new System.Drawing.Point(394, 112);
            this.rtb_status_kick.Name = "rtb_status_kick";
            this.rtb_status_kick.Size = new System.Drawing.Size(363, 266);
            this.rtb_status_kick.TabIndex = 44;
            this.rtb_status_kick.Text = "";
            // 
            // label183
            // 
            this.label183.AutoSize = true;
            this.label183.Location = new System.Drawing.Point(58, 94);
            this.label183.Name = "label183";
            this.label183.Size = new System.Drawing.Size(80, 15);
            this.label183.TabIndex = 43;
            this.label183.Text = "IDBM_KICK:";
            // 
            // rtb_IDBM_KICK_BM3
            // 
            this.rtb_IDBM_KICK_BM3.Location = new System.Drawing.Point(164, 112);
            this.rtb_IDBM_KICK_BM3.Name = "rtb_IDBM_KICK_BM3";
            this.rtb_IDBM_KICK_BM3.Size = new System.Drawing.Size(200, 266);
            this.rtb_IDBM_KICK_BM3.TabIndex = 42;
            this.rtb_IDBM_KICK_BM3.Text = "";
            // 
            // tb_TokenEEAG
            // 
            this.tb_TokenEEAG.Location = new System.Drawing.Point(164, 46);
            this.tb_TokenEEAG.Name = "tb_TokenEEAG";
            this.tb_TokenEEAG.Size = new System.Drawing.Size(317, 21);
            this.tb_TokenEEAG.TabIndex = 41;
            // 
            // label182
            // 
            this.label182.AutoSize = true;
            this.label182.Location = new System.Drawing.Point(58, 49);
            this.label182.Name = "label182";
            this.label182.Size = new System.Drawing.Size(81, 15);
            this.label182.TabIndex = 40;
            this.label182.Text = "Token_EEAG:";
            // 
            // tabPage13
            // 
            this.tabPage13.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.tabPage13.Controls.Add(this.label148);
            this.tabPage13.Controls.Add(this.bt_CLEAR_LINK);
            this.tabPage13.Controls.Add(this.label147);
            this.tabPage13.Controls.Add(this.bt_CLEAR_FAIL);
            this.tabPage13.Controls.Add(this.groupBox11);
            this.tabPage13.Controls.Add(this.label103);
            this.tabPage13.Controls.Add(this.label102);
            this.tabPage13.Controls.Add(this.rtbLINK);
            this.tabPage13.Controls.Add(this.rtb_Link_FAIL);
            this.tabPage13.Controls.Add(this.groupBox10);
            this.tabPage13.Location = new System.Drawing.Point(4, 24);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage13.Size = new System.Drawing.Size(1767, 688);
            this.tabPage13.TabIndex = 8;
            this.tabPage13.Text = "NHẬN LINK BM";
            // 
            // label148
            // 
            this.label148.AutoSize = true;
            this.label148.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label148.Location = new System.Drawing.Point(155, 316);
            this.label148.Name = "label148";
            this.label148.Size = new System.Drawing.Size(132, 15);
            this.label148.TabIndex = 204;
            this.label148.Text = "XÓA HẾT LINK NHẬN ";
            // 
            // bt_CLEAR_LINK
            // 
            this.bt_CLEAR_LINK.BackColor = System.Drawing.Color.LimeGreen;
            this.bt_CLEAR_LINK.Location = new System.Drawing.Point(55, 299);
            this.bt_CLEAR_LINK.Name = "bt_CLEAR_LINK";
            this.bt_CLEAR_LINK.Size = new System.Drawing.Size(75, 49);
            this.bt_CLEAR_LINK.TabIndex = 203;
            this.bt_CLEAR_LINK.Text = "CLEAR";
            this.bt_CLEAR_LINK.UseVisualStyleBackColor = false;
            this.bt_CLEAR_LINK.Click += new System.EventHandler(this.bt_CLEAR_LINK_Click);
            // 
            // label147
            // 
            this.label147.AutoSize = true;
            this.label147.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label147.Location = new System.Drawing.Point(155, 261);
            this.label147.Name = "label147";
            this.label147.Size = new System.Drawing.Size(157, 15);
            this.label147.TabIndex = 202;
            this.label147.Text = "XÓA HẾT LINK NHẬN FAIL";
            // 
            // bt_CLEAR_FAIL
            // 
            this.bt_CLEAR_FAIL.BackColor = System.Drawing.Color.Red;
            this.bt_CLEAR_FAIL.Location = new System.Drawing.Point(55, 244);
            this.bt_CLEAR_FAIL.Name = "bt_CLEAR_FAIL";
            this.bt_CLEAR_FAIL.Size = new System.Drawing.Size(75, 49);
            this.bt_CLEAR_FAIL.TabIndex = 201;
            this.bt_CLEAR_FAIL.Text = "CLEAR";
            this.bt_CLEAR_FAIL.UseVisualStyleBackColor = false;
            this.bt_CLEAR_FAIL.Click += new System.EventHandler(this.bt_CLEAR_FAIL_Click);
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label107);
            this.groupBox11.Controls.Add(this.label106);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_20);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_19);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_18);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_17);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_16);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_15);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_14);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_13);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_12);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_11);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_10);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_9);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_8);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_7);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_6);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_5);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_4);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_3);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_2);
            this.groupBox11.Controls.Add(this.rtb_LINKBM_1);
            this.groupBox11.Controls.Add(this.label105);
            this.groupBox11.Controls.Add(this.label104);
            this.groupBox11.Location = new System.Drawing.Point(909, 23);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(822, 661);
            this.groupBox11.TabIndex = 43;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "1 VIA NHẬN NHIỀU LINK";
            // 
            // label107
            // 
            this.label107.AutoSize = true;
            this.label107.Location = new System.Drawing.Point(644, 31);
            this.label107.Name = "label107";
            this.label107.Size = new System.Drawing.Size(131, 15);
            this.label107.TabIndex = 66;
            this.label107.Text = "ACCOUNT 4,8,12,16,20";
            // 
            // label106
            // 
            this.label106.AutoSize = true;
            this.label106.Location = new System.Drawing.Point(454, 34);
            this.label106.Name = "label106";
            this.label106.Size = new System.Drawing.Size(130, 15);
            this.label106.TabIndex = 65;
            this.label106.Text = "ACCOUNT 3,7,11,15,19";
            // 
            // rtb_LINKBM_20
            // 
            this.rtb_LINKBM_20.Location = new System.Drawing.Point(616, 536);
            this.rtb_LINKBM_20.Name = "rtb_LINKBM_20";
            this.rtb_LINKBM_20.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_20.TabIndex = 64;
            this.rtb_LINKBM_20.Text = "";
            // 
            // rtb_LINKBM_19
            // 
            this.rtb_LINKBM_19.Location = new System.Drawing.Point(415, 536);
            this.rtb_LINKBM_19.Name = "rtb_LINKBM_19";
            this.rtb_LINKBM_19.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_19.TabIndex = 63;
            this.rtb_LINKBM_19.Text = "";
            // 
            // rtb_LINKBM_18
            // 
            this.rtb_LINKBM_18.Location = new System.Drawing.Point(214, 536);
            this.rtb_LINKBM_18.Name = "rtb_LINKBM_18";
            this.rtb_LINKBM_18.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_18.TabIndex = 62;
            this.rtb_LINKBM_18.Text = "";
            // 
            // rtb_LINKBM_17
            // 
            this.rtb_LINKBM_17.Location = new System.Drawing.Point(12, 536);
            this.rtb_LINKBM_17.Name = "rtb_LINKBM_17";
            this.rtb_LINKBM_17.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_17.TabIndex = 61;
            this.rtb_LINKBM_17.Text = "";
            // 
            // rtb_LINKBM_16
            // 
            this.rtb_LINKBM_16.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.rtb_LINKBM_16.Location = new System.Drawing.Point(616, 417);
            this.rtb_LINKBM_16.Name = "rtb_LINKBM_16";
            this.rtb_LINKBM_16.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_16.TabIndex = 60;
            this.rtb_LINKBM_16.Text = "";
            // 
            // rtb_LINKBM_15
            // 
            this.rtb_LINKBM_15.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.rtb_LINKBM_15.Location = new System.Drawing.Point(415, 417);
            this.rtb_LINKBM_15.Name = "rtb_LINKBM_15";
            this.rtb_LINKBM_15.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_15.TabIndex = 59;
            this.rtb_LINKBM_15.Text = "";
            // 
            // rtb_LINKBM_14
            // 
            this.rtb_LINKBM_14.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.rtb_LINKBM_14.Location = new System.Drawing.Point(214, 417);
            this.rtb_LINKBM_14.Name = "rtb_LINKBM_14";
            this.rtb_LINKBM_14.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_14.TabIndex = 58;
            this.rtb_LINKBM_14.Text = "";
            // 
            // rtb_LINKBM_13
            // 
            this.rtb_LINKBM_13.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.rtb_LINKBM_13.Location = new System.Drawing.Point(12, 417);
            this.rtb_LINKBM_13.Name = "rtb_LINKBM_13";
            this.rtb_LINKBM_13.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_13.TabIndex = 57;
            this.rtb_LINKBM_13.Text = "";
            // 
            // rtb_LINKBM_12
            // 
            this.rtb_LINKBM_12.Location = new System.Drawing.Point(616, 298);
            this.rtb_LINKBM_12.Name = "rtb_LINKBM_12";
            this.rtb_LINKBM_12.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_12.TabIndex = 56;
            this.rtb_LINKBM_12.Text = "";
            // 
            // rtb_LINKBM_11
            // 
            this.rtb_LINKBM_11.Location = new System.Drawing.Point(415, 298);
            this.rtb_LINKBM_11.Name = "rtb_LINKBM_11";
            this.rtb_LINKBM_11.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_11.TabIndex = 55;
            this.rtb_LINKBM_11.Text = "";
            // 
            // rtb_LINKBM_10
            // 
            this.rtb_LINKBM_10.Location = new System.Drawing.Point(214, 298);
            this.rtb_LINKBM_10.Name = "rtb_LINKBM_10";
            this.rtb_LINKBM_10.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_10.TabIndex = 54;
            this.rtb_LINKBM_10.Text = "";
            // 
            // rtb_LINKBM_9
            // 
            this.rtb_LINKBM_9.Location = new System.Drawing.Point(12, 298);
            this.rtb_LINKBM_9.Name = "rtb_LINKBM_9";
            this.rtb_LINKBM_9.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_9.TabIndex = 53;
            this.rtb_LINKBM_9.Text = "";
            // 
            // rtb_LINKBM_8
            // 
            this.rtb_LINKBM_8.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.rtb_LINKBM_8.Location = new System.Drawing.Point(616, 179);
            this.rtb_LINKBM_8.Name = "rtb_LINKBM_8";
            this.rtb_LINKBM_8.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_8.TabIndex = 52;
            this.rtb_LINKBM_8.Text = "";
            // 
            // rtb_LINKBM_7
            // 
            this.rtb_LINKBM_7.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.rtb_LINKBM_7.Location = new System.Drawing.Point(415, 179);
            this.rtb_LINKBM_7.Name = "rtb_LINKBM_7";
            this.rtb_LINKBM_7.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_7.TabIndex = 51;
            this.rtb_LINKBM_7.Text = "";
            // 
            // rtb_LINKBM_6
            // 
            this.rtb_LINKBM_6.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.rtb_LINKBM_6.Location = new System.Drawing.Point(214, 179);
            this.rtb_LINKBM_6.Name = "rtb_LINKBM_6";
            this.rtb_LINKBM_6.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_6.TabIndex = 50;
            this.rtb_LINKBM_6.Text = "";
            // 
            // rtb_LINKBM_5
            // 
            this.rtb_LINKBM_5.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.rtb_LINKBM_5.Location = new System.Drawing.Point(12, 179);
            this.rtb_LINKBM_5.Name = "rtb_LINKBM_5";
            this.rtb_LINKBM_5.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_5.TabIndex = 49;
            this.rtb_LINKBM_5.Text = "";
            // 
            // rtb_LINKBM_4
            // 
            this.rtb_LINKBM_4.Location = new System.Drawing.Point(616, 60);
            this.rtb_LINKBM_4.Name = "rtb_LINKBM_4";
            this.rtb_LINKBM_4.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_4.TabIndex = 48;
            this.rtb_LINKBM_4.Text = "";
            // 
            // rtb_LINKBM_3
            // 
            this.rtb_LINKBM_3.Location = new System.Drawing.Point(415, 60);
            this.rtb_LINKBM_3.Name = "rtb_LINKBM_3";
            this.rtb_LINKBM_3.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_3.TabIndex = 47;
            this.rtb_LINKBM_3.Text = "";
            // 
            // rtb_LINKBM_2
            // 
            this.rtb_LINKBM_2.Location = new System.Drawing.Point(214, 60);
            this.rtb_LINKBM_2.Name = "rtb_LINKBM_2";
            this.rtb_LINKBM_2.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_2.TabIndex = 46;
            this.rtb_LINKBM_2.Text = "";
            // 
            // rtb_LINKBM_1
            // 
            this.rtb_LINKBM_1.Location = new System.Drawing.Point(12, 60);
            this.rtb_LINKBM_1.Name = "rtb_LINKBM_1";
            this.rtb_LINKBM_1.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_1.TabIndex = 45;
            this.rtb_LINKBM_1.Text = "";
            // 
            // label105
            // 
            this.label105.AutoSize = true;
            this.label105.Location = new System.Drawing.Point(243, 31);
            this.label105.Name = "label105";
            this.label105.Size = new System.Drawing.Size(131, 15);
            this.label105.TabIndex = 43;
            this.label105.Text = "ACCOUNT 2,6,10,14,18";
            // 
            // label104
            // 
            this.label104.AutoSize = true;
            this.label104.Location = new System.Drawing.Point(40, 31);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(125, 15);
            this.label104.TabIndex = 42;
            this.label104.Text = "ACCOUNT 1,5,9,13,17";
            // 
            // label103
            // 
            this.label103.AutoSize = true;
            this.label103.Location = new System.Drawing.Point(666, 54);
            this.label103.Name = "label103";
            this.label103.Size = new System.Drawing.Size(105, 15);
            this.label103.TabIndex = 42;
            this.label103.Text = "LINK    UID|LINK:";
            // 
            // label102
            // 
            this.label102.AutoSize = true;
            this.label102.Location = new System.Drawing.Point(428, 54);
            this.label102.Name = "label102";
            this.label102.Size = new System.Drawing.Size(137, 15);
            this.label102.TabIndex = 41;
            this.label102.Text = "LINK    UID|LINK FAIL!:";
            // 
            // rtbLINK
            // 
            this.rtbLINK.Location = new System.Drawing.Point(621, 83);
            this.rtbLINK.Name = "rtbLINK";
            this.rtbLINK.Size = new System.Drawing.Size(227, 493);
            this.rtbLINK.TabIndex = 2;
            this.rtbLINK.Text = "";
            // 
            // rtb_Link_FAIL
            // 
            this.rtb_Link_FAIL.Location = new System.Drawing.Point(379, 83);
            this.rtb_Link_FAIL.Name = "rtb_Link_FAIL";
            this.rtb_Link_FAIL.Size = new System.Drawing.Size(227, 493);
            this.rtb_Link_FAIL.TabIndex = 1;
            this.rtb_Link_FAIL.Text = "";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label101);
            this.groupBox10.Controls.Add(this.label100);
            this.groupBox10.Controls.Add(this.cmb_CACH_NHAN_LINK);
            this.groupBox10.Controls.Add(this.cmbAPI_Auto_selenium_NhanBM);
            this.groupBox10.Location = new System.Drawing.Point(44, 23);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(307, 173);
            this.groupBox10.TabIndex = 0;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "NHẬN BM";
            // 
            // label101
            // 
            this.label101.AutoSize = true;
            this.label101.Location = new System.Drawing.Point(8, 63);
            this.label101.Name = "label101";
            this.label101.Size = new System.Drawing.Size(78, 15);
            this.label101.TabIndex = 40;
            this.label101.Text = "NHẬN LINK:";
            // 
            // label100
            // 
            this.label100.AutoSize = true;
            this.label100.Location = new System.Drawing.Point(8, 34);
            this.label100.Name = "label100";
            this.label100.Size = new System.Drawing.Size(110, 15);
            this.label100.TabIndex = 39;
            this.label100.Text = "API/Auto selenium:";
            // 
            // cmb_CACH_NHAN_LINK
            // 
            this.cmb_CACH_NHAN_LINK.FormattingEnabled = true;
            this.cmb_CACH_NHAN_LINK.Location = new System.Drawing.Point(141, 60);
            this.cmb_CACH_NHAN_LINK.Name = "cmb_CACH_NHAN_LINK";
            this.cmb_CACH_NHAN_LINK.Size = new System.Drawing.Size(139, 23);
            this.cmb_CACH_NHAN_LINK.TabIndex = 1;
            // 
            // cmbAPI_Auto_selenium_NhanBM
            // 
            this.cmbAPI_Auto_selenium_NhanBM.FormattingEnabled = true;
            this.cmbAPI_Auto_selenium_NhanBM.Location = new System.Drawing.Point(141, 31);
            this.cmbAPI_Auto_selenium_NhanBM.Name = "cmbAPI_Auto_selenium_NhanBM";
            this.cmbAPI_Auto_selenium_NhanBM.Size = new System.Drawing.Size(139, 23);
            this.cmbAPI_Auto_selenium_NhanBM.TabIndex = 0;
            // 
            // tabPage14
            // 
            this.tabPage14.BackColor = System.Drawing.Color.Gray;
            this.tabPage14.Controls.Add(this.tabControl4);
            this.tabPage14.Location = new System.Drawing.Point(4, 24);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage14.Size = new System.Drawing.Size(1767, 688);
            this.tabPage14.TabIndex = 9;
            this.tabPage14.Text = "NHẬN BM AUTO";
            // 
            // tabControl4
            // 
            this.tabControl4.Controls.Add(this.tabPage15);
            this.tabControl4.Controls.Add(this.tabPage16);
            this.tabControl4.Controls.Add(this.tabPage17);
            this.tabControl4.Location = new System.Drawing.Point(0, 3);
            this.tabControl4.Name = "tabControl4";
            this.tabControl4.SelectedIndex = 0;
            this.tabControl4.Size = new System.Drawing.Size(1764, 689);
            this.tabControl4.TabIndex = 99;
            // 
            // tabPage15
            // 
            this.tabPage15.BackColor = System.Drawing.Color.DarkGray;
            this.tabPage15.Controls.Add(this.label216);
            this.tabPage15.Controls.Add(this.rtb_codemail);
            this.tabPage15.Controls.Add(this.cmb_file_random);
            this.tabPage15.Controls.Add(this.button5);
            this.tabPage15.Controls.Add(this.cmb_chi_doc_link_mail_ao);
            this.tabPage15.Controls.Add(this.label190);
            this.tabPage15.Controls.Add(this.label180);
            this.tabPage15.Controls.Add(this.label179);
            this.tabPage15.Controls.Add(this.rtb_mail_moakt_fail);
            this.tabPage15.Controls.Add(this.rtb_mail_moakt_done);
            this.tabPage15.Controls.Add(this.label178);
            this.tabPage15.Controls.Add(this.DELAY_DOC_MAIL);
            this.tabPage15.Controls.Add(this.label171);
            this.tabPage15.Controls.Add(this.cmb_loai_mail_nhan_bm_ig);
            this.tabPage15.Controls.Add(this.label166);
            this.tabPage15.Controls.Add(this.button4);
            this.tabPage15.Controls.Add(this.cmb_FILE_OPEN);
            this.tabPage15.Controls.Add(this.button3);
            this.tabPage15.Controls.Add(this.label146);
            this.tabPage15.Controls.Add(this.button2);
            this.tabPage15.Controls.Add(this.groupBox12);
            this.tabPage15.Controls.Add(this.label134);
            this.tabPage15.Controls.Add(this.label132);
            this.tabPage15.Controls.Add(this.rtb_mail_bm350_auto);
            this.tabPage15.Controls.Add(this.rtb_mail_bm50_auto);
            this.tabPage15.Controls.Add(this.rtb_BMIII_auto);
            this.tabPage15.Controls.Add(this.label131);
            this.tabPage15.Controls.Add(this.rtb_Link_BM350_IG_auto);
            this.tabPage15.Controls.Add(this.label130);
            this.tabPage15.Controls.Add(this.label129);
            this.tabPage15.Controls.Add(this.rtb_Link_BM50_IG_auto);
            this.tabPage15.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tabPage15.Location = new System.Drawing.Point(4, 24);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage15.Size = new System.Drawing.Size(1756, 661);
            this.tabPage15.TabIndex = 0;
            this.tabPage15.Text = "Hiển Thị";
            // 
            // label216
            // 
            this.label216.AutoSize = true;
            this.label216.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label216.Location = new System.Drawing.Point(8, 417);
            this.label216.Name = "label216";
            this.label216.Size = new System.Drawing.Size(79, 15);
            this.label216.TabIndex = 218;
            this.label216.Text = "CODE MAIL:";
            // 
            // rtb_codemail
            // 
            this.rtb_codemail.Location = new System.Drawing.Point(11, 446);
            this.rtb_codemail.Name = "rtb_codemail";
            this.rtb_codemail.Size = new System.Drawing.Size(134, 177);
            this.rtb_codemail.TabIndex = 217;
            this.rtb_codemail.Text = "";
            // 
            // cmb_file_random
            // 
            this.cmb_file_random.FormattingEnabled = true;
            this.cmb_file_random.Location = new System.Drawing.Point(1453, 485);
            this.cmb_file_random.Name = "cmb_file_random";
            this.cmb_file_random.Size = new System.Drawing.Size(192, 23);
            this.cmb_file_random.TabIndex = 216;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Fuchsia;
            this.button5.Location = new System.Drawing.Point(1365, 471);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 49);
            this.button5.TabIndex = 215;
            this.button5.Text = "RANDOM";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // cmb_chi_doc_link_mail_ao
            // 
            this.cmb_chi_doc_link_mail_ao.FormattingEnabled = true;
            this.cmb_chi_doc_link_mail_ao.Location = new System.Drawing.Point(9, 374);
            this.cmb_chi_doc_link_mail_ao.Name = "cmb_chi_doc_link_mail_ao";
            this.cmb_chi_doc_link_mail_ao.Size = new System.Drawing.Size(136, 23);
            this.cmb_chi_doc_link_mail_ao.TabIndex = 214;
            // 
            // label190
            // 
            this.label190.AutoSize = true;
            this.label190.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label190.Location = new System.Drawing.Point(8, 356);
            this.label190.Name = "label190";
            this.label190.Size = new System.Drawing.Size(149, 15);
            this.label190.TabIndex = 213;
            this.label190.Text = "CHỉ ĐỌC LINK MAIL ẢO:";
            // 
            // label180
            // 
            this.label180.AutoSize = true;
            this.label180.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label180.Location = new System.Drawing.Point(6, 142);
            this.label180.Name = "label180";
            this.label180.Size = new System.Drawing.Size(107, 15);
            this.label180.TabIndex = 212;
            this.label180.Text = "mail đăng ký done:";
            // 
            // label179
            // 
            this.label179.AutoSize = true;
            this.label179.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label179.Location = new System.Drawing.Point(6, 248);
            this.label179.Name = "label179";
            this.label179.Size = new System.Drawing.Size(100, 15);
            this.label179.TabIndex = 211;
            this.label179.Text = "mail đăng ký fail:";
            // 
            // rtb_mail_moakt_fail
            // 
            this.rtb_mail_moakt_fail.Location = new System.Drawing.Point(9, 266);
            this.rtb_mail_moakt_fail.Name = "rtb_mail_moakt_fail";
            this.rtb_mail_moakt_fail.Size = new System.Drawing.Size(136, 72);
            this.rtb_mail_moakt_fail.TabIndex = 210;
            this.rtb_mail_moakt_fail.Text = "";
            // 
            // rtb_mail_moakt_done
            // 
            this.rtb_mail_moakt_done.Location = new System.Drawing.Point(6, 160);
            this.rtb_mail_moakt_done.Name = "rtb_mail_moakt_done";
            this.rtb_mail_moakt_done.Size = new System.Drawing.Size(139, 72);
            this.rtb_mail_moakt_done.TabIndex = 209;
            this.rtb_mail_moakt_done.Text = "";
            // 
            // label178
            // 
            this.label178.AutoSize = true;
            this.label178.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label178.Location = new System.Drawing.Point(6, 66);
            this.label178.Name = "label178";
            this.label178.Size = new System.Drawing.Size(119, 15);
            this.label178.TabIndex = 208;
            this.label178.Text = "DELAY_DOC_MAIL:";
            // 
            // DELAY_DOC_MAIL
            // 
            this.DELAY_DOC_MAIL.Location = new System.Drawing.Point(9, 85);
            this.DELAY_DOC_MAIL.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.DELAY_DOC_MAIL.Name = "DELAY_DOC_MAIL";
            this.DELAY_DOC_MAIL.Size = new System.Drawing.Size(107, 21);
            this.DELAY_DOC_MAIL.TabIndex = 207;
            this.DELAY_DOC_MAIL.Value = new decimal(new int[] {
            90,
            0,
            0,
            0});
            // 
            // label171
            // 
            this.label171.AutoSize = true;
            this.label171.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label171.Location = new System.Drawing.Point(6, 13);
            this.label171.Name = "label171";
            this.label171.Size = new System.Drawing.Size(73, 15);
            this.label171.TabIndex = 206;
            this.label171.Text = "LOẠI MAIL:";
            // 
            // cmb_loai_mail_nhan_bm_ig
            // 
            this.cmb_loai_mail_nhan_bm_ig.FormattingEnabled = true;
            this.cmb_loai_mail_nhan_bm_ig.Location = new System.Drawing.Point(6, 40);
            this.cmb_loai_mail_nhan_bm_ig.Name = "cmb_loai_mail_nhan_bm_ig";
            this.cmb_loai_mail_nhan_bm_ig.Size = new System.Drawing.Size(110, 23);
            this.cmb_loai_mail_nhan_bm_ig.TabIndex = 205;
            // 
            // label166
            // 
            this.label166.AutoSize = true;
            this.label166.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label166.Location = new System.Drawing.Point(1456, 418);
            this.label166.Name = "label166";
            this.label166.Size = new System.Drawing.Size(167, 15);
            this.label166.TabIndex = 204;
            this.label166.Text = "XÓA HẾT LINK ĐANG NHẬN";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.LimeGreen;
            this.button4.Location = new System.Drawing.Point(1365, 401);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 49);
            this.button4.TabIndex = 203;
            this.button4.Text = "CLEAR";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // cmb_FILE_OPEN
            // 
            this.cmb_FILE_OPEN.FormattingEnabled = true;
            this.cmb_FILE_OPEN.Location = new System.Drawing.Point(1050, 88);
            this.cmb_FILE_OPEN.Name = "cmb_FILE_OPEN";
            this.cmb_FILE_OPEN.Size = new System.Drawing.Size(192, 23);
            this.cmb_FILE_OPEN.TabIndex = 202;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.DarkTurquoise;
            this.button3.Location = new System.Drawing.Point(947, 74);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 49);
            this.button3.TabIndex = 201;
            this.button3.Text = "MỞ FILE";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label146
            // 
            this.label146.AutoSize = true;
            this.label146.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label146.Location = new System.Drawing.Point(1047, 41);
            this.label146.Name = "label146";
            this.label146.Size = new System.Drawing.Size(157, 15);
            this.label146.TabIndex = 200;
            this.label146.Text = "XÓA HẾT LINK NHẬN FAIL";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Red;
            this.button2.Location = new System.Drawing.Point(947, 24);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 49);
            this.button2.TabIndex = 199;
            this.button2.Text = "CLEAR";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.numericUpDown8);
            this.groupBox12.Controls.Add(this.label223);
            this.groupBox12.Controls.Add(this.cmb_kologin_mail);
            this.groupBox12.Controls.Add(this.label221);
            this.groupBox12.Controls.Add(this.cmb_VIA_NHAN_VERRY);
            this.groupBox12.Controls.Add(this.label218);
            this.groupBox12.Controls.Add(this.num_STT_NHAN);
            this.groupBox12.Controls.Add(this.label217);
            this.groupBox12.Controls.Add(this.number_nhan_fail);
            this.groupBox12.Controls.Add(this.label202);
            this.groupBox12.Controls.Add(this.cmb_DIE_BM_CLEAR);
            this.groupBox12.Controls.Add(this.label201);
            this.groupBox12.Controls.Add(this.label188);
            this.groupBox12.Controls.Add(this.numericUpDown6);
            this.groupBox12.Controls.Add(this.label141);
            this.groupBox12.Controls.Add(this.CMB_LOAI_BM_NHAN);
            this.groupBox12.Controls.Add(this.cmb_STOP);
            this.groupBox12.Controls.Add(this.label135);
            this.groupBox12.Controls.Add(this.label136);
            this.groupBox12.Controls.Add(this.cmbAPI_Auto_selenium_NhanBM_IG);
            this.groupBox12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox12.Location = new System.Drawing.Point(1365, 13);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(307, 384);
            this.groupBox12.TabIndex = 198;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "NHẬN BM";
            // 
            // cmb_kologin_mail
            // 
            this.cmb_kologin_mail.FormattingEnabled = true;
            this.cmb_kologin_mail.Location = new System.Drawing.Point(141, 289);
            this.cmb_kologin_mail.Name = "cmb_kologin_mail";
            this.cmb_kologin_mail.Size = new System.Drawing.Size(139, 23);
            this.cmb_kologin_mail.TabIndex = 224;
            // 
            // label221
            // 
            this.label221.AutoSize = true;
            this.label221.Location = new System.Drawing.Point(8, 296);
            this.label221.Name = "label221";
            this.label221.Size = new System.Drawing.Size(105, 15);
            this.label221.TabIndex = 223;
            this.label221.Text = "KO LOGIN MAIL:";
            // 
            // cmb_VIA_NHAN_VERRY
            // 
            this.cmb_VIA_NHAN_VERRY.FormattingEnabled = true;
            this.cmb_VIA_NHAN_VERRY.Location = new System.Drawing.Point(141, 260);
            this.cmb_VIA_NHAN_VERRY.Name = "cmb_VIA_NHAN_VERRY";
            this.cmb_VIA_NHAN_VERRY.Size = new System.Drawing.Size(139, 23);
            this.cmb_VIA_NHAN_VERRY.TabIndex = 222;
            // 
            // label218
            // 
            this.label218.AutoSize = true;
            this.label218.Location = new System.Drawing.Point(8, 267);
            this.label218.Name = "label218";
            this.label218.Size = new System.Drawing.Size(71, 15);
            this.label218.TabIndex = 221;
            this.label218.Text = "VIA VERRY:";
            // 
            // num_STT_NHAN
            // 
            this.num_STT_NHAN.Location = new System.Drawing.Point(141, 233);
            this.num_STT_NHAN.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.num_STT_NHAN.Name = "num_STT_NHAN";
            this.num_STT_NHAN.Size = new System.Drawing.Size(107, 21);
            this.num_STT_NHAN.TabIndex = 220;
            // 
            // label217
            // 
            this.label217.AutoSize = true;
            this.label217.Location = new System.Drawing.Point(8, 235);
            this.label217.Name = "label217";
            this.label217.Size = new System.Drawing.Size(69, 15);
            this.label217.TabIndex = 219;
            this.label217.Text = "STT NHẬN";
            // 
            // number_nhan_fail
            // 
            this.number_nhan_fail.Location = new System.Drawing.Point(141, 202);
            this.number_nhan_fail.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.number_nhan_fail.Name = "number_nhan_fail";
            this.number_nhan_fail.Size = new System.Drawing.Size(107, 21);
            this.number_nhan_fail.TabIndex = 218;
            this.number_nhan_fail.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label202
            // 
            this.label202.AutoSize = true;
            this.label202.Location = new System.Drawing.Point(8, 204);
            this.label202.Name = "label202";
            this.label202.Size = new System.Drawing.Size(133, 15);
            this.label202.TabIndex = 217;
            this.label202.Text = "GIỚI HẠN NHẬN FAIL:";
            // 
            // cmb_DIE_BM_CLEAR
            // 
            this.cmb_DIE_BM_CLEAR.FormattingEnabled = true;
            this.cmb_DIE_BM_CLEAR.Location = new System.Drawing.Point(141, 173);
            this.cmb_DIE_BM_CLEAR.Name = "cmb_DIE_BM_CLEAR";
            this.cmb_DIE_BM_CLEAR.Size = new System.Drawing.Size(139, 23);
            this.cmb_DIE_BM_CLEAR.TabIndex = 216;
            // 
            // label201
            // 
            this.label201.AutoSize = true;
            this.label201.Location = new System.Drawing.Point(8, 176);
            this.label201.Name = "label201";
            this.label201.Size = new System.Drawing.Size(95, 15);
            this.label201.TabIndex = 215;
            this.label201.Text = "BM DIE CLEAR:";
            // 
            // label188
            // 
            this.label188.AutoSize = true;
            this.label188.Location = new System.Drawing.Point(8, 145);
            this.label188.Name = "label188";
            this.label188.Size = new System.Drawing.Size(93, 15);
            this.label188.TabIndex = 213;
            this.label188.Text = "Delay nhan API:";
            // 
            // numericUpDown6
            // 
            this.numericUpDown6.Location = new System.Drawing.Point(141, 139);
            this.numericUpDown6.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.numericUpDown6.Name = "numericUpDown6";
            this.numericUpDown6.Size = new System.Drawing.Size(107, 21);
            this.numericUpDown6.TabIndex = 214;
            this.numericUpDown6.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label141
            // 
            this.label141.AutoSize = true;
            this.label141.Location = new System.Drawing.Point(8, 113);
            this.label141.Name = "label141";
            this.label141.Size = new System.Drawing.Size(100, 15);
            this.label141.TabIndex = 43;
            this.label141.Text = "LOẠI BM NHẬN:";
            // 
            // CMB_LOAI_BM_NHAN
            // 
            this.CMB_LOAI_BM_NHAN.FormattingEnabled = true;
            this.CMB_LOAI_BM_NHAN.Location = new System.Drawing.Point(141, 110);
            this.CMB_LOAI_BM_NHAN.Name = "CMB_LOAI_BM_NHAN";
            this.CMB_LOAI_BM_NHAN.Size = new System.Drawing.Size(139, 23);
            this.CMB_LOAI_BM_NHAN.TabIndex = 42;
            // 
            // cmb_STOP
            // 
            this.cmb_STOP.FormattingEnabled = true;
            this.cmb_STOP.Location = new System.Drawing.Point(141, 70);
            this.cmb_STOP.Name = "cmb_STOP";
            this.cmb_STOP.Size = new System.Drawing.Size(139, 23);
            this.cmb_STOP.TabIndex = 41;
            // 
            // label135
            // 
            this.label135.AutoSize = true;
            this.label135.Location = new System.Drawing.Point(8, 78);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(44, 15);
            this.label135.TabIndex = 40;
            this.label135.Text = "STOP:";
            // 
            // label136
            // 
            this.label136.AutoSize = true;
            this.label136.Location = new System.Drawing.Point(8, 34);
            this.label136.Name = "label136";
            this.label136.Size = new System.Drawing.Size(110, 15);
            this.label136.TabIndex = 39;
            this.label136.Text = "API/Auto selenium:";
            // 
            // cmbAPI_Auto_selenium_NhanBM_IG
            // 
            this.cmbAPI_Auto_selenium_NhanBM_IG.FormattingEnabled = true;
            this.cmbAPI_Auto_selenium_NhanBM_IG.Location = new System.Drawing.Point(141, 31);
            this.cmbAPI_Auto_selenium_NhanBM_IG.Name = "cmbAPI_Auto_selenium_NhanBM_IG";
            this.cmbAPI_Auto_selenium_NhanBM_IG.Size = new System.Drawing.Size(139, 23);
            this.cmbAPI_Auto_selenium_NhanBM_IG.TabIndex = 0;
            // 
            // label134
            // 
            this.label134.AutoSize = true;
            this.label134.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label134.Location = new System.Drawing.Point(520, 13);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(80, 15);
            this.label134.TabIndex = 197;
            this.label134.Text = "MAIL BM350:";
            // 
            // label132
            // 
            this.label132.AutoSize = true;
            this.label132.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label132.Location = new System.Drawing.Point(134, 13);
            this.label132.Name = "label132";
            this.label132.Size = new System.Drawing.Size(74, 15);
            this.label132.TabIndex = 195;
            this.label132.Text = "MAIL BM50:";
            // 
            // rtb_mail_bm350_auto
            // 
            this.rtb_mail_bm350_auto.Location = new System.Drawing.Point(586, 40);
            this.rtb_mail_bm350_auto.Name = "rtb_mail_bm350_auto";
            this.rtb_mail_bm350_auto.Size = new System.Drawing.Size(280, 72);
            this.rtb_mail_bm350_auto.TabIndex = 194;
            this.rtb_mail_bm350_auto.Text = "";
            // 
            // rtb_mail_bm50_auto
            // 
            this.rtb_mail_bm50_auto.Location = new System.Drawing.Point(170, 40);
            this.rtb_mail_bm50_auto.Name = "rtb_mail_bm50_auto";
            this.rtb_mail_bm50_auto.Size = new System.Drawing.Size(280, 72);
            this.rtb_mail_bm50_auto.TabIndex = 193;
            this.rtb_mail_bm50_auto.Text = "";
            // 
            // rtb_BMIII_auto
            // 
            this.rtb_BMIII_auto.Location = new System.Drawing.Point(1020, 160);
            this.rtb_BMIII_auto.Name = "rtb_BMIII_auto";
            this.rtb_BMIII_auto.Size = new System.Drawing.Size(280, 442);
            this.rtb_BMIII_auto.TabIndex = 192;
            this.rtb_BMIII_auto.Text = "";
            // 
            // label131
            // 
            this.label131.AutoSize = true;
            this.label131.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label131.Location = new System.Drawing.Point(954, 131);
            this.label131.Name = "label131";
            this.label131.Size = new System.Drawing.Size(79, 15);
            this.label131.TabIndex = 191;
            this.label131.Text = "LINK THỨ 3:";
            // 
            // rtb_Link_BM350_IG_auto
            // 
            this.rtb_Link_BM350_IG_auto.Location = new System.Drawing.Point(586, 160);
            this.rtb_Link_BM350_IG_auto.Name = "rtb_Link_BM350_IG_auto";
            this.rtb_Link_BM350_IG_auto.Size = new System.Drawing.Size(280, 442);
            this.rtb_Link_BM350_IG_auto.TabIndex = 190;
            this.rtb_Link_BM350_IG_auto.Text = "";
            // 
            // label130
            // 
            this.label130.AutoSize = true;
            this.label130.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label130.Location = new System.Drawing.Point(520, 131);
            this.label130.Name = "label130";
            this.label130.Size = new System.Drawing.Size(80, 15);
            this.label130.TabIndex = 189;
            this.label130.Text = "LINK BM350:";
            // 
            // label129
            // 
            this.label129.AutoSize = true;
            this.label129.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label129.Location = new System.Drawing.Point(134, 131);
            this.label129.Name = "label129";
            this.label129.Size = new System.Drawing.Size(74, 15);
            this.label129.TabIndex = 188;
            this.label129.Text = "LINK BM50:";
            // 
            // rtb_Link_BM50_IG_auto
            // 
            this.rtb_Link_BM50_IG_auto.Location = new System.Drawing.Point(170, 160);
            this.rtb_Link_BM50_IG_auto.Name = "rtb_Link_BM50_IG_auto";
            this.rtb_Link_BM50_IG_auto.Size = new System.Drawing.Size(280, 442);
            this.rtb_Link_BM50_IG_auto.TabIndex = 0;
            this.rtb_Link_BM50_IG_auto.Text = "";
            // 
            // tabPage16
            // 
            this.tabPage16.BackColor = System.Drawing.Color.Gray;
            this.tabPage16.Controls.Add(this.tb_nhan20);
            this.tabPage16.Controls.Add(this.tb_20);
            this.tabPage16.Controls.Add(this.tb_nhan16);
            this.tabPage16.Controls.Add(this.tb_16);
            this.tabPage16.Controls.Add(this.tb_nhan12);
            this.tabPage16.Controls.Add(this.tb_12);
            this.tabPage16.Controls.Add(this.tb_nhan8);
            this.tabPage16.Controls.Add(this.tb_8);
            this.tabPage16.Controls.Add(this.tb_nhan4);
            this.tabPage16.Controls.Add(this.tb_4);
            this.tabPage16.Controls.Add(this.tb_nhan19);
            this.tabPage16.Controls.Add(this.tb_19);
            this.tabPage16.Controls.Add(this.tb_nhan15);
            this.tabPage16.Controls.Add(this.tb_15);
            this.tabPage16.Controls.Add(this.tb_nhan11);
            this.tabPage16.Controls.Add(this.tb_11);
            this.tabPage16.Controls.Add(this.tb_nhan7);
            this.tabPage16.Controls.Add(this.tb_7);
            this.tabPage16.Controls.Add(this.tb_nhan3);
            this.tabPage16.Controls.Add(this.tb_3);
            this.tabPage16.Controls.Add(this.tb_nhan18);
            this.tabPage16.Controls.Add(this.tb_18);
            this.tabPage16.Controls.Add(this.tb_nhan14);
            this.tabPage16.Controls.Add(this.tb_14);
            this.tabPage16.Controls.Add(this.tb_nhan10);
            this.tabPage16.Controls.Add(this.tb_10);
            this.tabPage16.Controls.Add(this.tb_nhan6);
            this.tabPage16.Controls.Add(this.tb_6);
            this.tabPage16.Controls.Add(this.tb_nhan2);
            this.tabPage16.Controls.Add(this.tb_2);
            this.tabPage16.Controls.Add(this.tb_nhan17);
            this.tabPage16.Controls.Add(this.tb_17);
            this.tabPage16.Controls.Add(this.tb_nhan13);
            this.tabPage16.Controls.Add(this.tb_13);
            this.tabPage16.Controls.Add(this.tb_nhan9);
            this.tabPage16.Controls.Add(this.tb_9);
            this.tabPage16.Controls.Add(this.tb_nhan5);
            this.tabPage16.Controls.Add(this.tb_5);
            this.tabPage16.Controls.Add(this.tb_nhan1);
            this.tabPage16.Controls.Add(this.tb_1);
            this.tabPage16.Controls.Add(this.label118);
            this.tabPage16.Controls.Add(this.label117);
            this.tabPage16.Controls.Add(this.label116);
            this.tabPage16.Controls.Add(this.label115);
            this.tabPage16.Controls.Add(this.label114);
            this.tabPage16.Controls.Add(this.label113);
            this.tabPage16.Controls.Add(this.label112);
            this.tabPage16.Controls.Add(this.label111);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_19);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_20);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_20);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_19);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_15);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_16);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_16);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_15);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_11);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_12);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_12);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_11);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_7);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_8);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_8);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_7);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_3);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_4);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_4);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_3);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_17);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_18);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_18);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_17);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_13);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_14);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_14);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_13);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_9);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_10);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_10);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_9);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_5);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_6);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_6);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_5);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_1);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_2);
            this.tabPage16.Controls.Add(this.rtb_LINKBMFAIL_IG_2);
            this.tabPage16.Controls.Add(this.rtb_LINKBM_IG_1);
            this.tabPage16.Location = new System.Drawing.Point(4, 24);
            this.tabPage16.Name = "tabPage16";
            this.tabPage16.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage16.Size = new System.Drawing.Size(1756, 661);
            this.tabPage16.TabIndex = 1;
            this.tabPage16.Text = "VIA NHẬN BM 1-20";
            // 
            // tb_nhan20
            // 
            this.tb_nhan20.Location = new System.Drawing.Point(1314, 589);
            this.tb_nhan20.Name = "tb_nhan20";
            this.tb_nhan20.Size = new System.Drawing.Size(32, 21);
            this.tb_nhan20.TabIndex = 234;
            // 
            // tb_20
            // 
            this.tb_20.Location = new System.Drawing.Point(1315, 562);
            this.tb_20.Name = "tb_20";
            this.tb_20.Size = new System.Drawing.Size(31, 21);
            this.tb_20.TabIndex = 233;
            // 
            // tb_nhan16
            // 
            this.tb_nhan16.Location = new System.Drawing.Point(1315, 462);
            this.tb_nhan16.Name = "tb_nhan16";
            this.tb_nhan16.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan16.TabIndex = 232;
            // 
            // tb_16
            // 
            this.tb_16.Location = new System.Drawing.Point(1316, 435);
            this.tb_16.Name = "tb_16";
            this.tb_16.Size = new System.Drawing.Size(30, 21);
            this.tb_16.TabIndex = 231;
            // 
            // tb_nhan12
            // 
            this.tb_nhan12.Location = new System.Drawing.Point(1316, 347);
            this.tb_nhan12.Name = "tb_nhan12";
            this.tb_nhan12.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan12.TabIndex = 230;
            // 
            // tb_12
            // 
            this.tb_12.Location = new System.Drawing.Point(1317, 320);
            this.tb_12.Name = "tb_12";
            this.tb_12.Size = new System.Drawing.Size(30, 21);
            this.tb_12.TabIndex = 229;
            // 
            // tb_nhan8
            // 
            this.tb_nhan8.Location = new System.Drawing.Point(1316, 223);
            this.tb_nhan8.Name = "tb_nhan8";
            this.tb_nhan8.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan8.TabIndex = 228;
            // 
            // tb_8
            // 
            this.tb_8.Location = new System.Drawing.Point(1317, 196);
            this.tb_8.Name = "tb_8";
            this.tb_8.Size = new System.Drawing.Size(30, 21);
            this.tb_8.TabIndex = 227;
            // 
            // tb_nhan4
            // 
            this.tb_nhan4.Location = new System.Drawing.Point(1316, 89);
            this.tb_nhan4.Name = "tb_nhan4";
            this.tb_nhan4.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan4.TabIndex = 226;
            // 
            // tb_4
            // 
            this.tb_4.Location = new System.Drawing.Point(1317, 62);
            this.tb_4.Name = "tb_4";
            this.tb_4.Size = new System.Drawing.Size(30, 21);
            this.tb_4.TabIndex = 225;
            // 
            // tb_nhan19
            // 
            this.tb_nhan19.Location = new System.Drawing.Point(877, 589);
            this.tb_nhan19.Name = "tb_nhan19";
            this.tb_nhan19.Size = new System.Drawing.Size(32, 21);
            this.tb_nhan19.TabIndex = 224;
            // 
            // tb_19
            // 
            this.tb_19.Location = new System.Drawing.Point(878, 562);
            this.tb_19.Name = "tb_19";
            this.tb_19.Size = new System.Drawing.Size(31, 21);
            this.tb_19.TabIndex = 223;
            // 
            // tb_nhan15
            // 
            this.tb_nhan15.Location = new System.Drawing.Point(878, 462);
            this.tb_nhan15.Name = "tb_nhan15";
            this.tb_nhan15.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan15.TabIndex = 222;
            // 
            // tb_15
            // 
            this.tb_15.Location = new System.Drawing.Point(879, 435);
            this.tb_15.Name = "tb_15";
            this.tb_15.Size = new System.Drawing.Size(30, 21);
            this.tb_15.TabIndex = 221;
            // 
            // tb_nhan11
            // 
            this.tb_nhan11.Location = new System.Drawing.Point(879, 347);
            this.tb_nhan11.Name = "tb_nhan11";
            this.tb_nhan11.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan11.TabIndex = 220;
            // 
            // tb_11
            // 
            this.tb_11.Location = new System.Drawing.Point(880, 320);
            this.tb_11.Name = "tb_11";
            this.tb_11.Size = new System.Drawing.Size(30, 21);
            this.tb_11.TabIndex = 219;
            // 
            // tb_nhan7
            // 
            this.tb_nhan7.Location = new System.Drawing.Point(879, 223);
            this.tb_nhan7.Name = "tb_nhan7";
            this.tb_nhan7.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan7.TabIndex = 218;
            // 
            // tb_7
            // 
            this.tb_7.Location = new System.Drawing.Point(880, 196);
            this.tb_7.Name = "tb_7";
            this.tb_7.Size = new System.Drawing.Size(30, 21);
            this.tb_7.TabIndex = 217;
            // 
            // tb_nhan3
            // 
            this.tb_nhan3.Location = new System.Drawing.Point(879, 89);
            this.tb_nhan3.Name = "tb_nhan3";
            this.tb_nhan3.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan3.TabIndex = 216;
            // 
            // tb_3
            // 
            this.tb_3.Location = new System.Drawing.Point(880, 62);
            this.tb_3.Name = "tb_3";
            this.tb_3.Size = new System.Drawing.Size(30, 21);
            this.tb_3.TabIndex = 215;
            // 
            // tb_nhan18
            // 
            this.tb_nhan18.Location = new System.Drawing.Point(444, 589);
            this.tb_nhan18.Name = "tb_nhan18";
            this.tb_nhan18.Size = new System.Drawing.Size(32, 21);
            this.tb_nhan18.TabIndex = 214;
            // 
            // tb_18
            // 
            this.tb_18.Location = new System.Drawing.Point(445, 562);
            this.tb_18.Name = "tb_18";
            this.tb_18.Size = new System.Drawing.Size(31, 21);
            this.tb_18.TabIndex = 213;
            // 
            // tb_nhan14
            // 
            this.tb_nhan14.Location = new System.Drawing.Point(445, 462);
            this.tb_nhan14.Name = "tb_nhan14";
            this.tb_nhan14.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan14.TabIndex = 212;
            // 
            // tb_14
            // 
            this.tb_14.Location = new System.Drawing.Point(446, 435);
            this.tb_14.Name = "tb_14";
            this.tb_14.Size = new System.Drawing.Size(30, 21);
            this.tb_14.TabIndex = 211;
            // 
            // tb_nhan10
            // 
            this.tb_nhan10.Location = new System.Drawing.Point(446, 347);
            this.tb_nhan10.Name = "tb_nhan10";
            this.tb_nhan10.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan10.TabIndex = 210;
            // 
            // tb_10
            // 
            this.tb_10.Location = new System.Drawing.Point(447, 320);
            this.tb_10.Name = "tb_10";
            this.tb_10.Size = new System.Drawing.Size(30, 21);
            this.tb_10.TabIndex = 209;
            // 
            // tb_nhan6
            // 
            this.tb_nhan6.Location = new System.Drawing.Point(446, 223);
            this.tb_nhan6.Name = "tb_nhan6";
            this.tb_nhan6.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan6.TabIndex = 208;
            // 
            // tb_6
            // 
            this.tb_6.Location = new System.Drawing.Point(447, 196);
            this.tb_6.Name = "tb_6";
            this.tb_6.Size = new System.Drawing.Size(30, 21);
            this.tb_6.TabIndex = 207;
            // 
            // tb_nhan2
            // 
            this.tb_nhan2.Location = new System.Drawing.Point(446, 89);
            this.tb_nhan2.Name = "tb_nhan2";
            this.tb_nhan2.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan2.TabIndex = 206;
            // 
            // tb_2
            // 
            this.tb_2.Location = new System.Drawing.Point(447, 62);
            this.tb_2.Name = "tb_2";
            this.tb_2.Size = new System.Drawing.Size(30, 21);
            this.tb_2.TabIndex = 205;
            // 
            // tb_nhan17
            // 
            this.tb_nhan17.Location = new System.Drawing.Point(5, 589);
            this.tb_nhan17.Name = "tb_nhan17";
            this.tb_nhan17.Size = new System.Drawing.Size(32, 21);
            this.tb_nhan17.TabIndex = 204;
            // 
            // tb_17
            // 
            this.tb_17.Location = new System.Drawing.Point(6, 562);
            this.tb_17.Name = "tb_17";
            this.tb_17.Size = new System.Drawing.Size(31, 21);
            this.tb_17.TabIndex = 203;
            // 
            // tb_nhan13
            // 
            this.tb_nhan13.Location = new System.Drawing.Point(6, 462);
            this.tb_nhan13.Name = "tb_nhan13";
            this.tb_nhan13.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan13.TabIndex = 202;
            // 
            // tb_13
            // 
            this.tb_13.Location = new System.Drawing.Point(7, 435);
            this.tb_13.Name = "tb_13";
            this.tb_13.Size = new System.Drawing.Size(30, 21);
            this.tb_13.TabIndex = 201;
            // 
            // tb_nhan9
            // 
            this.tb_nhan9.Location = new System.Drawing.Point(7, 347);
            this.tb_nhan9.Name = "tb_nhan9";
            this.tb_nhan9.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan9.TabIndex = 200;
            // 
            // tb_9
            // 
            this.tb_9.Location = new System.Drawing.Point(8, 320);
            this.tb_9.Name = "tb_9";
            this.tb_9.Size = new System.Drawing.Size(30, 21);
            this.tb_9.TabIndex = 199;
            // 
            // tb_nhan5
            // 
            this.tb_nhan5.Location = new System.Drawing.Point(7, 223);
            this.tb_nhan5.Name = "tb_nhan5";
            this.tb_nhan5.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan5.TabIndex = 198;
            // 
            // tb_5
            // 
            this.tb_5.Location = new System.Drawing.Point(8, 196);
            this.tb_5.Name = "tb_5";
            this.tb_5.Size = new System.Drawing.Size(30, 21);
            this.tb_5.TabIndex = 197;
            // 
            // tb_nhan1
            // 
            this.tb_nhan1.Location = new System.Drawing.Point(7, 89);
            this.tb_nhan1.Name = "tb_nhan1";
            this.tb_nhan1.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan1.TabIndex = 196;
            // 
            // tb_1
            // 
            this.tb_1.Location = new System.Drawing.Point(8, 62);
            this.tb_1.Name = "tb_1";
            this.tb_1.Size = new System.Drawing.Size(30, 21);
            this.tb_1.TabIndex = 195;
            // 
            // label118
            // 
            this.label118.AutoSize = true;
            this.label118.Location = new System.Drawing.Point(1584, 20);
            this.label118.Name = "label118";
            this.label118.Size = new System.Drawing.Size(126, 15);
            this.label118.TabIndex = 194;
            this.label118.Text = "LINK FAIL 4,8,12,16,20";
            // 
            // label117
            // 
            this.label117.AutoSize = true;
            this.label117.Location = new System.Drawing.Point(1143, 20);
            this.label117.Name = "label117";
            this.label117.Size = new System.Drawing.Size(125, 15);
            this.label117.TabIndex = 193;
            this.label117.Text = "LINK FAIL 3,7,11,15,19";
            // 
            // label116
            // 
            this.label116.AutoSize = true;
            this.label116.Location = new System.Drawing.Point(710, 20);
            this.label116.Name = "label116";
            this.label116.Size = new System.Drawing.Size(126, 15);
            this.label116.TabIndex = 192;
            this.label116.Text = "LINK FAIL 2,6,10,14,18";
            // 
            // label115
            // 
            this.label115.AutoSize = true;
            this.label115.Location = new System.Drawing.Point(275, 20);
            this.label115.Name = "label115";
            this.label115.Size = new System.Drawing.Size(120, 15);
            this.label115.TabIndex = 191;
            this.label115.Text = "LINK FAIL 1,5,9,13,17";
            // 
            // label114
            // 
            this.label114.AutoSize = true;
            this.label114.Location = new System.Drawing.Point(1346, 20);
            this.label114.Name = "label114";
            this.label114.Size = new System.Drawing.Size(131, 15);
            this.label114.TabIndex = 190;
            this.label114.Text = "ACCOUNT 4,8,12,16,20";
            // 
            // label113
            // 
            this.label113.AutoSize = true;
            this.label113.Location = new System.Drawing.Point(912, 20);
            this.label113.Name = "label113";
            this.label113.Size = new System.Drawing.Size(130, 15);
            this.label113.TabIndex = 189;
            this.label113.Text = "ACCOUNT 3,7,11,15,19";
            // 
            // label112
            // 
            this.label112.AutoSize = true;
            this.label112.Location = new System.Drawing.Point(503, 20);
            this.label112.Name = "label112";
            this.label112.Size = new System.Drawing.Size(131, 15);
            this.label112.TabIndex = 188;
            this.label112.Text = "ACCOUNT 2,6,10,14,18";
            // 
            // label111
            // 
            this.label111.AutoSize = true;
            this.label111.Location = new System.Drawing.Point(64, 20);
            this.label111.Name = "label111";
            this.label111.Size = new System.Drawing.Size(125, 15);
            this.label111.TabIndex = 187;
            this.label111.Text = "ACCOUNT 1,5,9,13,17";
            // 
            // rtb_LINKBMFAIL_IG_19
            // 
            this.rtb_LINKBMFAIL_IG_19.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_19.Location = new System.Drawing.Point(1116, 527);
            this.rtb_LINKBMFAIL_IG_19.Name = "rtb_LINKBMFAIL_IG_19";
            this.rtb_LINKBMFAIL_IG_19.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_19.TabIndex = 186;
            this.rtb_LINKBMFAIL_IG_19.Text = "";
            // 
            // rtb_LINKBM_IG_20
            // 
            this.rtb_LINKBM_IG_20.Location = new System.Drawing.Point(1349, 527);
            this.rtb_LINKBM_IG_20.Name = "rtb_LINKBM_IG_20";
            this.rtb_LINKBM_IG_20.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_20.TabIndex = 185;
            this.rtb_LINKBM_IG_20.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_20
            // 
            this.rtb_LINKBMFAIL_IG_20.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_20.Location = new System.Drawing.Point(1553, 527);
            this.rtb_LINKBMFAIL_IG_20.Name = "rtb_LINKBMFAIL_IG_20";
            this.rtb_LINKBMFAIL_IG_20.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_20.TabIndex = 184;
            this.rtb_LINKBMFAIL_IG_20.Text = "";
            // 
            // rtb_LINKBM_IG_19
            // 
            this.rtb_LINKBM_IG_19.Location = new System.Drawing.Point(915, 527);
            this.rtb_LINKBM_IG_19.Name = "rtb_LINKBM_IG_19";
            this.rtb_LINKBM_IG_19.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_19.TabIndex = 183;
            this.rtb_LINKBM_IG_19.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_15
            // 
            this.rtb_LINKBMFAIL_IG_15.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_15.Location = new System.Drawing.Point(1116, 408);
            this.rtb_LINKBMFAIL_IG_15.Name = "rtb_LINKBMFAIL_IG_15";
            this.rtb_LINKBMFAIL_IG_15.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_15.TabIndex = 182;
            this.rtb_LINKBMFAIL_IG_15.Text = "";
            // 
            // rtb_LINKBM_IG_16
            // 
            this.rtb_LINKBM_IG_16.Location = new System.Drawing.Point(1349, 408);
            this.rtb_LINKBM_IG_16.Name = "rtb_LINKBM_IG_16";
            this.rtb_LINKBM_IG_16.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_16.TabIndex = 181;
            this.rtb_LINKBM_IG_16.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_16
            // 
            this.rtb_LINKBMFAIL_IG_16.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_16.Location = new System.Drawing.Point(1553, 408);
            this.rtb_LINKBMFAIL_IG_16.Name = "rtb_LINKBMFAIL_IG_16";
            this.rtb_LINKBMFAIL_IG_16.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_16.TabIndex = 180;
            this.rtb_LINKBMFAIL_IG_16.Text = "";
            // 
            // rtb_LINKBM_IG_15
            // 
            this.rtb_LINKBM_IG_15.Location = new System.Drawing.Point(915, 408);
            this.rtb_LINKBM_IG_15.Name = "rtb_LINKBM_IG_15";
            this.rtb_LINKBM_IG_15.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_15.TabIndex = 179;
            this.rtb_LINKBM_IG_15.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_11
            // 
            this.rtb_LINKBMFAIL_IG_11.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_11.Location = new System.Drawing.Point(1116, 289);
            this.rtb_LINKBMFAIL_IG_11.Name = "rtb_LINKBMFAIL_IG_11";
            this.rtb_LINKBMFAIL_IG_11.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_11.TabIndex = 178;
            this.rtb_LINKBMFAIL_IG_11.Text = "";
            // 
            // rtb_LINKBM_IG_12
            // 
            this.rtb_LINKBM_IG_12.Location = new System.Drawing.Point(1349, 289);
            this.rtb_LINKBM_IG_12.Name = "rtb_LINKBM_IG_12";
            this.rtb_LINKBM_IG_12.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_12.TabIndex = 177;
            this.rtb_LINKBM_IG_12.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_12
            // 
            this.rtb_LINKBMFAIL_IG_12.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_12.Location = new System.Drawing.Point(1553, 289);
            this.rtb_LINKBMFAIL_IG_12.Name = "rtb_LINKBMFAIL_IG_12";
            this.rtb_LINKBMFAIL_IG_12.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_12.TabIndex = 176;
            this.rtb_LINKBMFAIL_IG_12.Text = "";
            // 
            // rtb_LINKBM_IG_11
            // 
            this.rtb_LINKBM_IG_11.Location = new System.Drawing.Point(915, 289);
            this.rtb_LINKBM_IG_11.Name = "rtb_LINKBM_IG_11";
            this.rtb_LINKBM_IG_11.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_11.TabIndex = 175;
            this.rtb_LINKBM_IG_11.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_7
            // 
            this.rtb_LINKBMFAIL_IG_7.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_7.Location = new System.Drawing.Point(1116, 170);
            this.rtb_LINKBMFAIL_IG_7.Name = "rtb_LINKBMFAIL_IG_7";
            this.rtb_LINKBMFAIL_IG_7.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_7.TabIndex = 174;
            this.rtb_LINKBMFAIL_IG_7.Text = "";
            // 
            // rtb_LINKBM_IG_8
            // 
            this.rtb_LINKBM_IG_8.Location = new System.Drawing.Point(1349, 170);
            this.rtb_LINKBM_IG_8.Name = "rtb_LINKBM_IG_8";
            this.rtb_LINKBM_IG_8.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_8.TabIndex = 173;
            this.rtb_LINKBM_IG_8.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_8
            // 
            this.rtb_LINKBMFAIL_IG_8.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_8.Location = new System.Drawing.Point(1553, 170);
            this.rtb_LINKBMFAIL_IG_8.Name = "rtb_LINKBMFAIL_IG_8";
            this.rtb_LINKBMFAIL_IG_8.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_8.TabIndex = 172;
            this.rtb_LINKBMFAIL_IG_8.Text = "";
            // 
            // rtb_LINKBM_IG_7
            // 
            this.rtb_LINKBM_IG_7.Location = new System.Drawing.Point(915, 170);
            this.rtb_LINKBM_IG_7.Name = "rtb_LINKBM_IG_7";
            this.rtb_LINKBM_IG_7.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_7.TabIndex = 171;
            this.rtb_LINKBM_IG_7.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_3
            // 
            this.rtb_LINKBMFAIL_IG_3.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_3.Location = new System.Drawing.Point(1116, 51);
            this.rtb_LINKBMFAIL_IG_3.Name = "rtb_LINKBMFAIL_IG_3";
            this.rtb_LINKBMFAIL_IG_3.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_3.TabIndex = 170;
            this.rtb_LINKBMFAIL_IG_3.Text = "";
            // 
            // rtb_LINKBM_IG_4
            // 
            this.rtb_LINKBM_IG_4.Location = new System.Drawing.Point(1349, 51);
            this.rtb_LINKBM_IG_4.Name = "rtb_LINKBM_IG_4";
            this.rtb_LINKBM_IG_4.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_4.TabIndex = 169;
            this.rtb_LINKBM_IG_4.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_4
            // 
            this.rtb_LINKBMFAIL_IG_4.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_4.Location = new System.Drawing.Point(1553, 51);
            this.rtb_LINKBMFAIL_IG_4.Name = "rtb_LINKBMFAIL_IG_4";
            this.rtb_LINKBMFAIL_IG_4.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_4.TabIndex = 168;
            this.rtb_LINKBMFAIL_IG_4.Text = "";
            // 
            // rtb_LINKBM_IG_3
            // 
            this.rtb_LINKBM_IG_3.Location = new System.Drawing.Point(915, 51);
            this.rtb_LINKBM_IG_3.Name = "rtb_LINKBM_IG_3";
            this.rtb_LINKBM_IG_3.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_3.TabIndex = 167;
            this.rtb_LINKBM_IG_3.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_17
            // 
            this.rtb_LINKBMFAIL_IG_17.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_17.Location = new System.Drawing.Point(245, 527);
            this.rtb_LINKBMFAIL_IG_17.Name = "rtb_LINKBMFAIL_IG_17";
            this.rtb_LINKBMFAIL_IG_17.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_17.TabIndex = 166;
            this.rtb_LINKBMFAIL_IG_17.Text = "";
            // 
            // rtb_LINKBM_IG_18
            // 
            this.rtb_LINKBM_IG_18.Location = new System.Drawing.Point(478, 527);
            this.rtb_LINKBM_IG_18.Name = "rtb_LINKBM_IG_18";
            this.rtb_LINKBM_IG_18.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_18.TabIndex = 165;
            this.rtb_LINKBM_IG_18.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_18
            // 
            this.rtb_LINKBMFAIL_IG_18.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_18.Location = new System.Drawing.Point(679, 527);
            this.rtb_LINKBMFAIL_IG_18.Name = "rtb_LINKBMFAIL_IG_18";
            this.rtb_LINKBMFAIL_IG_18.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_18.TabIndex = 164;
            this.rtb_LINKBMFAIL_IG_18.Text = "";
            // 
            // rtb_LINKBM_IG_17
            // 
            this.rtb_LINKBM_IG_17.Location = new System.Drawing.Point(44, 527);
            this.rtb_LINKBM_IG_17.Name = "rtb_LINKBM_IG_17";
            this.rtb_LINKBM_IG_17.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_17.TabIndex = 163;
            this.rtb_LINKBM_IG_17.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_13
            // 
            this.rtb_LINKBMFAIL_IG_13.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_13.Location = new System.Drawing.Point(245, 408);
            this.rtb_LINKBMFAIL_IG_13.Name = "rtb_LINKBMFAIL_IG_13";
            this.rtb_LINKBMFAIL_IG_13.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_13.TabIndex = 162;
            this.rtb_LINKBMFAIL_IG_13.Text = "";
            // 
            // rtb_LINKBM_IG_14
            // 
            this.rtb_LINKBM_IG_14.Location = new System.Drawing.Point(478, 408);
            this.rtb_LINKBM_IG_14.Name = "rtb_LINKBM_IG_14";
            this.rtb_LINKBM_IG_14.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_14.TabIndex = 161;
            this.rtb_LINKBM_IG_14.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_14
            // 
            this.rtb_LINKBMFAIL_IG_14.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_14.Location = new System.Drawing.Point(679, 408);
            this.rtb_LINKBMFAIL_IG_14.Name = "rtb_LINKBMFAIL_IG_14";
            this.rtb_LINKBMFAIL_IG_14.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_14.TabIndex = 160;
            this.rtb_LINKBMFAIL_IG_14.Text = "";
            // 
            // rtb_LINKBM_IG_13
            // 
            this.rtb_LINKBM_IG_13.Location = new System.Drawing.Point(44, 408);
            this.rtb_LINKBM_IG_13.Name = "rtb_LINKBM_IG_13";
            this.rtb_LINKBM_IG_13.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_13.TabIndex = 159;
            this.rtb_LINKBM_IG_13.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_9
            // 
            this.rtb_LINKBMFAIL_IG_9.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_9.Location = new System.Drawing.Point(245, 289);
            this.rtb_LINKBMFAIL_IG_9.Name = "rtb_LINKBMFAIL_IG_9";
            this.rtb_LINKBMFAIL_IG_9.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_9.TabIndex = 158;
            this.rtb_LINKBMFAIL_IG_9.Text = "";
            // 
            // rtb_LINKBM_IG_10
            // 
            this.rtb_LINKBM_IG_10.Location = new System.Drawing.Point(478, 289);
            this.rtb_LINKBM_IG_10.Name = "rtb_LINKBM_IG_10";
            this.rtb_LINKBM_IG_10.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_10.TabIndex = 157;
            this.rtb_LINKBM_IG_10.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_10
            // 
            this.rtb_LINKBMFAIL_IG_10.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_10.Location = new System.Drawing.Point(679, 289);
            this.rtb_LINKBMFAIL_IG_10.Name = "rtb_LINKBMFAIL_IG_10";
            this.rtb_LINKBMFAIL_IG_10.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_10.TabIndex = 156;
            this.rtb_LINKBMFAIL_IG_10.Text = "";
            // 
            // rtb_LINKBM_IG_9
            // 
            this.rtb_LINKBM_IG_9.Location = new System.Drawing.Point(44, 289);
            this.rtb_LINKBM_IG_9.Name = "rtb_LINKBM_IG_9";
            this.rtb_LINKBM_IG_9.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_9.TabIndex = 155;
            this.rtb_LINKBM_IG_9.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_5
            // 
            this.rtb_LINKBMFAIL_IG_5.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_5.Location = new System.Drawing.Point(245, 170);
            this.rtb_LINKBMFAIL_IG_5.Name = "rtb_LINKBMFAIL_IG_5";
            this.rtb_LINKBMFAIL_IG_5.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_5.TabIndex = 154;
            this.rtb_LINKBMFAIL_IG_5.Text = "";
            // 
            // rtb_LINKBM_IG_6
            // 
            this.rtb_LINKBM_IG_6.Location = new System.Drawing.Point(478, 170);
            this.rtb_LINKBM_IG_6.Name = "rtb_LINKBM_IG_6";
            this.rtb_LINKBM_IG_6.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_6.TabIndex = 153;
            this.rtb_LINKBM_IG_6.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_6
            // 
            this.rtb_LINKBMFAIL_IG_6.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_6.Location = new System.Drawing.Point(679, 170);
            this.rtb_LINKBMFAIL_IG_6.Name = "rtb_LINKBMFAIL_IG_6";
            this.rtb_LINKBMFAIL_IG_6.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_6.TabIndex = 152;
            this.rtb_LINKBMFAIL_IG_6.Text = "";
            // 
            // rtb_LINKBM_IG_5
            // 
            this.rtb_LINKBM_IG_5.Location = new System.Drawing.Point(44, 170);
            this.rtb_LINKBM_IG_5.Name = "rtb_LINKBM_IG_5";
            this.rtb_LINKBM_IG_5.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_5.TabIndex = 151;
            this.rtb_LINKBM_IG_5.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_1
            // 
            this.rtb_LINKBMFAIL_IG_1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_1.Location = new System.Drawing.Point(245, 51);
            this.rtb_LINKBMFAIL_IG_1.Name = "rtb_LINKBMFAIL_IG_1";
            this.rtb_LINKBMFAIL_IG_1.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_1.TabIndex = 150;
            this.rtb_LINKBMFAIL_IG_1.Text = "";
            // 
            // rtb_LINKBM_IG_2
            // 
            this.rtb_LINKBM_IG_2.Location = new System.Drawing.Point(478, 51);
            this.rtb_LINKBM_IG_2.Name = "rtb_LINKBM_IG_2";
            this.rtb_LINKBM_IG_2.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_2.TabIndex = 149;
            this.rtb_LINKBM_IG_2.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_2
            // 
            this.rtb_LINKBMFAIL_IG_2.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_2.Location = new System.Drawing.Point(679, 51);
            this.rtb_LINKBMFAIL_IG_2.Name = "rtb_LINKBMFAIL_IG_2";
            this.rtb_LINKBMFAIL_IG_2.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_2.TabIndex = 148;
            this.rtb_LINKBMFAIL_IG_2.Text = "";
            // 
            // rtb_LINKBM_IG_1
            // 
            this.rtb_LINKBM_IG_1.Location = new System.Drawing.Point(44, 51);
            this.rtb_LINKBM_IG_1.Name = "rtb_LINKBM_IG_1";
            this.rtb_LINKBM_IG_1.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_1.TabIndex = 147;
            this.rtb_LINKBM_IG_1.Text = "";
            // 
            // tabPage17
            // 
            this.tabPage17.BackColor = System.Drawing.Color.Gray;
            this.tabPage17.Controls.Add(this.tb_nhan40);
            this.tabPage17.Controls.Add(this.tb_40);
            this.tabPage17.Controls.Add(this.tb_nhan36);
            this.tabPage17.Controls.Add(this.tb_36);
            this.tabPage17.Controls.Add(this.tb_nhan32);
            this.tabPage17.Controls.Add(this.tb_32);
            this.tabPage17.Controls.Add(this.tb_nhan28);
            this.tabPage17.Controls.Add(this.tb_28);
            this.tabPage17.Controls.Add(this.tb_nhan24);
            this.tabPage17.Controls.Add(this.tb_24);
            this.tabPage17.Controls.Add(this.tb_nhan39);
            this.tabPage17.Controls.Add(this.tb_39);
            this.tabPage17.Controls.Add(this.tb_nhan35);
            this.tabPage17.Controls.Add(this.tb_35);
            this.tabPage17.Controls.Add(this.tb_nhan31);
            this.tabPage17.Controls.Add(this.tb_31);
            this.tabPage17.Controls.Add(this.tb_nhan27);
            this.tabPage17.Controls.Add(this.tb_27);
            this.tabPage17.Controls.Add(this.tb_nhan23);
            this.tabPage17.Controls.Add(this.tb_23);
            this.tabPage17.Controls.Add(this.tb_nhan38);
            this.tabPage17.Controls.Add(this.tb_38);
            this.tabPage17.Controls.Add(this.tb_nhan34);
            this.tabPage17.Controls.Add(this.tb_34);
            this.tabPage17.Controls.Add(this.tb_nhan30);
            this.tabPage17.Controls.Add(this.tb_30);
            this.tabPage17.Controls.Add(this.tb_nhan26);
            this.tabPage17.Controls.Add(this.tb_26);
            this.tabPage17.Controls.Add(this.tb_nhan22);
            this.tabPage17.Controls.Add(this.tb_22);
            this.tabPage17.Controls.Add(this.tb_nhan37);
            this.tabPage17.Controls.Add(this.tb_37);
            this.tabPage17.Controls.Add(this.tb_nhan33);
            this.tabPage17.Controls.Add(this.tb_33);
            this.tabPage17.Controls.Add(this.tb_nhan29);
            this.tabPage17.Controls.Add(this.tb_29);
            this.tabPage17.Controls.Add(this.tb_nhan25);
            this.tabPage17.Controls.Add(this.tb_25);
            this.tabPage17.Controls.Add(this.tb_nhan21);
            this.tabPage17.Controls.Add(this.tb_21);
            this.tabPage17.Controls.Add(this.label128);
            this.tabPage17.Controls.Add(this.label121);
            this.tabPage17.Controls.Add(this.label122);
            this.tabPage17.Controls.Add(this.label123);
            this.tabPage17.Controls.Add(this.label124);
            this.tabPage17.Controls.Add(this.label125);
            this.tabPage17.Controls.Add(this.label126);
            this.tabPage17.Controls.Add(this.label127);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_39);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_40);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_40);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_39);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_35);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_36);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_36);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_35);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_31);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_32);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_32);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_31);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_27);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_28);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_28);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_27);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_23);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_24);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_24);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_23);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_37);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_38);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_38);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_37);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_33);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_34);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_34);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_33);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_29);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_30);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_30);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_29);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_25);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_26);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_26);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_25);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_21);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_22);
            this.tabPage17.Controls.Add(this.rtb_LINKBMFAIL_IG_22);
            this.tabPage17.Controls.Add(this.rtb_LINKBM_IG_21);
            this.tabPage17.Location = new System.Drawing.Point(4, 24);
            this.tabPage17.Name = "tabPage17";
            this.tabPage17.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage17.Size = new System.Drawing.Size(1756, 661);
            this.tabPage17.TabIndex = 2;
            this.tabPage17.Text = "VIA NHẬN BM 21-40";
            // 
            // tb_nhan40
            // 
            this.tb_nhan40.Location = new System.Drawing.Point(1312, 600);
            this.tb_nhan40.Name = "tb_nhan40";
            this.tb_nhan40.Size = new System.Drawing.Size(32, 21);
            this.tb_nhan40.TabIndex = 281;
            // 
            // tb_40
            // 
            this.tb_40.Location = new System.Drawing.Point(1313, 573);
            this.tb_40.Name = "tb_40";
            this.tb_40.Size = new System.Drawing.Size(31, 21);
            this.tb_40.TabIndex = 280;
            // 
            // tb_nhan36
            // 
            this.tb_nhan36.Location = new System.Drawing.Point(1313, 473);
            this.tb_nhan36.Name = "tb_nhan36";
            this.tb_nhan36.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan36.TabIndex = 279;
            // 
            // tb_36
            // 
            this.tb_36.Location = new System.Drawing.Point(1314, 446);
            this.tb_36.Name = "tb_36";
            this.tb_36.Size = new System.Drawing.Size(30, 21);
            this.tb_36.TabIndex = 278;
            // 
            // tb_nhan32
            // 
            this.tb_nhan32.Location = new System.Drawing.Point(1314, 358);
            this.tb_nhan32.Name = "tb_nhan32";
            this.tb_nhan32.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan32.TabIndex = 277;
            // 
            // tb_32
            // 
            this.tb_32.Location = new System.Drawing.Point(1315, 331);
            this.tb_32.Name = "tb_32";
            this.tb_32.Size = new System.Drawing.Size(30, 21);
            this.tb_32.TabIndex = 276;
            // 
            // tb_nhan28
            // 
            this.tb_nhan28.Location = new System.Drawing.Point(1314, 234);
            this.tb_nhan28.Name = "tb_nhan28";
            this.tb_nhan28.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan28.TabIndex = 275;
            // 
            // tb_28
            // 
            this.tb_28.Location = new System.Drawing.Point(1315, 207);
            this.tb_28.Name = "tb_28";
            this.tb_28.Size = new System.Drawing.Size(30, 21);
            this.tb_28.TabIndex = 274;
            // 
            // tb_nhan24
            // 
            this.tb_nhan24.Location = new System.Drawing.Point(1314, 100);
            this.tb_nhan24.Name = "tb_nhan24";
            this.tb_nhan24.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan24.TabIndex = 273;
            // 
            // tb_24
            // 
            this.tb_24.Location = new System.Drawing.Point(1315, 73);
            this.tb_24.Name = "tb_24";
            this.tb_24.Size = new System.Drawing.Size(30, 21);
            this.tb_24.TabIndex = 272;
            // 
            // tb_nhan39
            // 
            this.tb_nhan39.Location = new System.Drawing.Point(877, 600);
            this.tb_nhan39.Name = "tb_nhan39";
            this.tb_nhan39.Size = new System.Drawing.Size(32, 21);
            this.tb_nhan39.TabIndex = 271;
            // 
            // tb_39
            // 
            this.tb_39.Location = new System.Drawing.Point(878, 573);
            this.tb_39.Name = "tb_39";
            this.tb_39.Size = new System.Drawing.Size(31, 21);
            this.tb_39.TabIndex = 270;
            // 
            // tb_nhan35
            // 
            this.tb_nhan35.Location = new System.Drawing.Point(878, 473);
            this.tb_nhan35.Name = "tb_nhan35";
            this.tb_nhan35.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan35.TabIndex = 269;
            // 
            // tb_35
            // 
            this.tb_35.Location = new System.Drawing.Point(879, 446);
            this.tb_35.Name = "tb_35";
            this.tb_35.Size = new System.Drawing.Size(30, 21);
            this.tb_35.TabIndex = 268;
            // 
            // tb_nhan31
            // 
            this.tb_nhan31.Location = new System.Drawing.Point(879, 358);
            this.tb_nhan31.Name = "tb_nhan31";
            this.tb_nhan31.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan31.TabIndex = 267;
            // 
            // tb_31
            // 
            this.tb_31.Location = new System.Drawing.Point(880, 331);
            this.tb_31.Name = "tb_31";
            this.tb_31.Size = new System.Drawing.Size(30, 21);
            this.tb_31.TabIndex = 266;
            // 
            // tb_nhan27
            // 
            this.tb_nhan27.Location = new System.Drawing.Point(879, 234);
            this.tb_nhan27.Name = "tb_nhan27";
            this.tb_nhan27.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan27.TabIndex = 265;
            // 
            // tb_27
            // 
            this.tb_27.Location = new System.Drawing.Point(880, 207);
            this.tb_27.Name = "tb_27";
            this.tb_27.Size = new System.Drawing.Size(30, 21);
            this.tb_27.TabIndex = 264;
            // 
            // tb_nhan23
            // 
            this.tb_nhan23.Location = new System.Drawing.Point(879, 100);
            this.tb_nhan23.Name = "tb_nhan23";
            this.tb_nhan23.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan23.TabIndex = 263;
            // 
            // tb_23
            // 
            this.tb_23.Location = new System.Drawing.Point(880, 73);
            this.tb_23.Name = "tb_23";
            this.tb_23.Size = new System.Drawing.Size(30, 21);
            this.tb_23.TabIndex = 262;
            // 
            // tb_nhan38
            // 
            this.tb_nhan38.Location = new System.Drawing.Point(439, 600);
            this.tb_nhan38.Name = "tb_nhan38";
            this.tb_nhan38.Size = new System.Drawing.Size(32, 21);
            this.tb_nhan38.TabIndex = 261;
            // 
            // tb_38
            // 
            this.tb_38.Location = new System.Drawing.Point(440, 573);
            this.tb_38.Name = "tb_38";
            this.tb_38.Size = new System.Drawing.Size(31, 21);
            this.tb_38.TabIndex = 260;
            // 
            // tb_nhan34
            // 
            this.tb_nhan34.Location = new System.Drawing.Point(440, 473);
            this.tb_nhan34.Name = "tb_nhan34";
            this.tb_nhan34.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan34.TabIndex = 259;
            // 
            // tb_34
            // 
            this.tb_34.Location = new System.Drawing.Point(441, 446);
            this.tb_34.Name = "tb_34";
            this.tb_34.Size = new System.Drawing.Size(30, 21);
            this.tb_34.TabIndex = 258;
            // 
            // tb_nhan30
            // 
            this.tb_nhan30.Location = new System.Drawing.Point(441, 358);
            this.tb_nhan30.Name = "tb_nhan30";
            this.tb_nhan30.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan30.TabIndex = 257;
            // 
            // tb_30
            // 
            this.tb_30.Location = new System.Drawing.Point(442, 331);
            this.tb_30.Name = "tb_30";
            this.tb_30.Size = new System.Drawing.Size(30, 21);
            this.tb_30.TabIndex = 256;
            // 
            // tb_nhan26
            // 
            this.tb_nhan26.Location = new System.Drawing.Point(441, 234);
            this.tb_nhan26.Name = "tb_nhan26";
            this.tb_nhan26.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan26.TabIndex = 255;
            // 
            // tb_26
            // 
            this.tb_26.Location = new System.Drawing.Point(442, 207);
            this.tb_26.Name = "tb_26";
            this.tb_26.Size = new System.Drawing.Size(30, 21);
            this.tb_26.TabIndex = 254;
            // 
            // tb_nhan22
            // 
            this.tb_nhan22.Location = new System.Drawing.Point(441, 100);
            this.tb_nhan22.Name = "tb_nhan22";
            this.tb_nhan22.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan22.TabIndex = 253;
            // 
            // tb_22
            // 
            this.tb_22.Location = new System.Drawing.Point(442, 73);
            this.tb_22.Name = "tb_22";
            this.tb_22.Size = new System.Drawing.Size(30, 21);
            this.tb_22.TabIndex = 252;
            // 
            // tb_nhan37
            // 
            this.tb_nhan37.Location = new System.Drawing.Point(3, 600);
            this.tb_nhan37.Name = "tb_nhan37";
            this.tb_nhan37.Size = new System.Drawing.Size(32, 21);
            this.tb_nhan37.TabIndex = 251;
            // 
            // tb_37
            // 
            this.tb_37.Location = new System.Drawing.Point(4, 573);
            this.tb_37.Name = "tb_37";
            this.tb_37.Size = new System.Drawing.Size(31, 21);
            this.tb_37.TabIndex = 250;
            // 
            // tb_nhan33
            // 
            this.tb_nhan33.Location = new System.Drawing.Point(4, 473);
            this.tb_nhan33.Name = "tb_nhan33";
            this.tb_nhan33.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan33.TabIndex = 249;
            // 
            // tb_33
            // 
            this.tb_33.Location = new System.Drawing.Point(5, 446);
            this.tb_33.Name = "tb_33";
            this.tb_33.Size = new System.Drawing.Size(30, 21);
            this.tb_33.TabIndex = 248;
            // 
            // tb_nhan29
            // 
            this.tb_nhan29.Location = new System.Drawing.Point(5, 358);
            this.tb_nhan29.Name = "tb_nhan29";
            this.tb_nhan29.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan29.TabIndex = 247;
            // 
            // tb_29
            // 
            this.tb_29.Location = new System.Drawing.Point(6, 331);
            this.tb_29.Name = "tb_29";
            this.tb_29.Size = new System.Drawing.Size(30, 21);
            this.tb_29.TabIndex = 246;
            // 
            // tb_nhan25
            // 
            this.tb_nhan25.Location = new System.Drawing.Point(5, 234);
            this.tb_nhan25.Name = "tb_nhan25";
            this.tb_nhan25.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan25.TabIndex = 245;
            // 
            // tb_25
            // 
            this.tb_25.Location = new System.Drawing.Point(6, 207);
            this.tb_25.Name = "tb_25";
            this.tb_25.Size = new System.Drawing.Size(30, 21);
            this.tb_25.TabIndex = 244;
            // 
            // tb_nhan21
            // 
            this.tb_nhan21.Location = new System.Drawing.Point(5, 100);
            this.tb_nhan21.Name = "tb_nhan21";
            this.tb_nhan21.Size = new System.Drawing.Size(31, 21);
            this.tb_nhan21.TabIndex = 243;
            // 
            // tb_21
            // 
            this.tb_21.Location = new System.Drawing.Point(6, 73);
            this.tb_21.Name = "tb_21";
            this.tb_21.Size = new System.Drawing.Size(30, 21);
            this.tb_21.TabIndex = 242;
            // 
            // label128
            // 
            this.label128.AutoSize = true;
            this.label128.Location = new System.Drawing.Point(1581, 20);
            this.label128.Name = "label128";
            this.label128.Size = new System.Drawing.Size(138, 15);
            this.label128.TabIndex = 241;
            this.label128.Text = "LINK FAIL 24,28,32,36,40";
            // 
            // label121
            // 
            this.label121.AutoSize = true;
            this.label121.Location = new System.Drawing.Point(1141, 20);
            this.label121.Name = "label121";
            this.label121.Size = new System.Drawing.Size(138, 15);
            this.label121.TabIndex = 240;
            this.label121.Text = "LINK FAIL 23,27,31,35,39";
            // 
            // label122
            // 
            this.label122.AutoSize = true;
            this.label122.Location = new System.Drawing.Point(710, 20);
            this.label122.Name = "label122";
            this.label122.Size = new System.Drawing.Size(138, 15);
            this.label122.TabIndex = 239;
            this.label122.Text = "LINK FAIL 22,26,30,34,38";
            // 
            // label123
            // 
            this.label123.AutoSize = true;
            this.label123.Location = new System.Drawing.Point(271, 20);
            this.label123.Name = "label123";
            this.label123.Size = new System.Drawing.Size(138, 15);
            this.label123.TabIndex = 238;
            this.label123.Text = "LINK FAIL 21,25,29,33,37";
            // 
            // label124
            // 
            this.label124.AutoSize = true;
            this.label124.Location = new System.Drawing.Point(1377, 20);
            this.label124.Name = "label124";
            this.label124.Size = new System.Drawing.Size(143, 15);
            this.label124.TabIndex = 237;
            this.label124.Text = "ACCOUNT 24,28,32,36,40";
            // 
            // label125
            // 
            this.label125.AutoSize = true;
            this.label125.Location = new System.Drawing.Point(935, 20);
            this.label125.Name = "label125";
            this.label125.Size = new System.Drawing.Size(143, 15);
            this.label125.TabIndex = 236;
            this.label125.Text = "ACCOUNT 23,27,31,35,39";
            // 
            // label126
            // 
            this.label126.AutoSize = true;
            this.label126.Location = new System.Drawing.Point(506, 20);
            this.label126.Name = "label126";
            this.label126.Size = new System.Drawing.Size(143, 15);
            this.label126.TabIndex = 235;
            this.label126.Text = "ACCOUNT 22,26,30,34,38";
            // 
            // label127
            // 
            this.label127.AutoSize = true;
            this.label127.Location = new System.Drawing.Point(60, 20);
            this.label127.Name = "label127";
            this.label127.Size = new System.Drawing.Size(143, 15);
            this.label127.TabIndex = 234;
            this.label127.Text = "ACCOUNT 21,25,29,33,37";
            // 
            // rtb_LINKBMFAIL_IG_39
            // 
            this.rtb_LINKBMFAIL_IG_39.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_39.Location = new System.Drawing.Point(1114, 527);
            this.rtb_LINKBMFAIL_IG_39.Name = "rtb_LINKBMFAIL_IG_39";
            this.rtb_LINKBMFAIL_IG_39.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_39.TabIndex = 233;
            this.rtb_LINKBMFAIL_IG_39.Text = "";
            // 
            // rtb_LINKBM_IG_40
            // 
            this.rtb_LINKBM_IG_40.Location = new System.Drawing.Point(1349, 527);
            this.rtb_LINKBM_IG_40.Name = "rtb_LINKBM_IG_40";
            this.rtb_LINKBM_IG_40.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_40.TabIndex = 232;
            this.rtb_LINKBM_IG_40.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_40
            // 
            this.rtb_LINKBMFAIL_IG_40.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_40.Location = new System.Drawing.Point(1553, 527);
            this.rtb_LINKBMFAIL_IG_40.Name = "rtb_LINKBMFAIL_IG_40";
            this.rtb_LINKBMFAIL_IG_40.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_40.TabIndex = 231;
            this.rtb_LINKBMFAIL_IG_40.Text = "";
            // 
            // rtb_LINKBM_IG_39
            // 
            this.rtb_LINKBM_IG_39.Location = new System.Drawing.Point(913, 527);
            this.rtb_LINKBM_IG_39.Name = "rtb_LINKBM_IG_39";
            this.rtb_LINKBM_IG_39.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_39.TabIndex = 230;
            this.rtb_LINKBM_IG_39.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_35
            // 
            this.rtb_LINKBMFAIL_IG_35.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_35.Location = new System.Drawing.Point(1114, 408);
            this.rtb_LINKBMFAIL_IG_35.Name = "rtb_LINKBMFAIL_IG_35";
            this.rtb_LINKBMFAIL_IG_35.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_35.TabIndex = 229;
            this.rtb_LINKBMFAIL_IG_35.Text = "";
            // 
            // rtb_LINKBM_IG_36
            // 
            this.rtb_LINKBM_IG_36.Location = new System.Drawing.Point(1349, 408);
            this.rtb_LINKBM_IG_36.Name = "rtb_LINKBM_IG_36";
            this.rtb_LINKBM_IG_36.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_36.TabIndex = 228;
            this.rtb_LINKBM_IG_36.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_36
            // 
            this.rtb_LINKBMFAIL_IG_36.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_36.Location = new System.Drawing.Point(1553, 408);
            this.rtb_LINKBMFAIL_IG_36.Name = "rtb_LINKBMFAIL_IG_36";
            this.rtb_LINKBMFAIL_IG_36.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_36.TabIndex = 227;
            this.rtb_LINKBMFAIL_IG_36.Text = "";
            // 
            // rtb_LINKBM_IG_35
            // 
            this.rtb_LINKBM_IG_35.Location = new System.Drawing.Point(913, 408);
            this.rtb_LINKBM_IG_35.Name = "rtb_LINKBM_IG_35";
            this.rtb_LINKBM_IG_35.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_35.TabIndex = 226;
            this.rtb_LINKBM_IG_35.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_31
            // 
            this.rtb_LINKBMFAIL_IG_31.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_31.Location = new System.Drawing.Point(1114, 289);
            this.rtb_LINKBMFAIL_IG_31.Name = "rtb_LINKBMFAIL_IG_31";
            this.rtb_LINKBMFAIL_IG_31.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_31.TabIndex = 225;
            this.rtb_LINKBMFAIL_IG_31.Text = "";
            // 
            // rtb_LINKBM_IG_32
            // 
            this.rtb_LINKBM_IG_32.Location = new System.Drawing.Point(1349, 289);
            this.rtb_LINKBM_IG_32.Name = "rtb_LINKBM_IG_32";
            this.rtb_LINKBM_IG_32.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_32.TabIndex = 224;
            this.rtb_LINKBM_IG_32.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_32
            // 
            this.rtb_LINKBMFAIL_IG_32.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_32.Location = new System.Drawing.Point(1553, 289);
            this.rtb_LINKBMFAIL_IG_32.Name = "rtb_LINKBMFAIL_IG_32";
            this.rtb_LINKBMFAIL_IG_32.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_32.TabIndex = 223;
            this.rtb_LINKBMFAIL_IG_32.Text = "";
            // 
            // rtb_LINKBM_IG_31
            // 
            this.rtb_LINKBM_IG_31.Location = new System.Drawing.Point(913, 289);
            this.rtb_LINKBM_IG_31.Name = "rtb_LINKBM_IG_31";
            this.rtb_LINKBM_IG_31.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_31.TabIndex = 222;
            this.rtb_LINKBM_IG_31.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_27
            // 
            this.rtb_LINKBMFAIL_IG_27.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_27.Location = new System.Drawing.Point(1114, 170);
            this.rtb_LINKBMFAIL_IG_27.Name = "rtb_LINKBMFAIL_IG_27";
            this.rtb_LINKBMFAIL_IG_27.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_27.TabIndex = 221;
            this.rtb_LINKBMFAIL_IG_27.Text = "";
            // 
            // rtb_LINKBM_IG_28
            // 
            this.rtb_LINKBM_IG_28.Location = new System.Drawing.Point(1349, 170);
            this.rtb_LINKBM_IG_28.Name = "rtb_LINKBM_IG_28";
            this.rtb_LINKBM_IG_28.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_28.TabIndex = 220;
            this.rtb_LINKBM_IG_28.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_28
            // 
            this.rtb_LINKBMFAIL_IG_28.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_28.Location = new System.Drawing.Point(1553, 170);
            this.rtb_LINKBMFAIL_IG_28.Name = "rtb_LINKBMFAIL_IG_28";
            this.rtb_LINKBMFAIL_IG_28.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_28.TabIndex = 219;
            this.rtb_LINKBMFAIL_IG_28.Text = "";
            // 
            // rtb_LINKBM_IG_27
            // 
            this.rtb_LINKBM_IG_27.Location = new System.Drawing.Point(913, 170);
            this.rtb_LINKBM_IG_27.Name = "rtb_LINKBM_IG_27";
            this.rtb_LINKBM_IG_27.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_27.TabIndex = 218;
            this.rtb_LINKBM_IG_27.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_23
            // 
            this.rtb_LINKBMFAIL_IG_23.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_23.Location = new System.Drawing.Point(1114, 51);
            this.rtb_LINKBMFAIL_IG_23.Name = "rtb_LINKBMFAIL_IG_23";
            this.rtb_LINKBMFAIL_IG_23.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_23.TabIndex = 217;
            this.rtb_LINKBMFAIL_IG_23.Text = "";
            // 
            // rtb_LINKBM_IG_24
            // 
            this.rtb_LINKBM_IG_24.Location = new System.Drawing.Point(1349, 51);
            this.rtb_LINKBM_IG_24.Name = "rtb_LINKBM_IG_24";
            this.rtb_LINKBM_IG_24.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_24.TabIndex = 216;
            this.rtb_LINKBM_IG_24.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_24
            // 
            this.rtb_LINKBMFAIL_IG_24.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_24.Location = new System.Drawing.Point(1553, 51);
            this.rtb_LINKBMFAIL_IG_24.Name = "rtb_LINKBMFAIL_IG_24";
            this.rtb_LINKBMFAIL_IG_24.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_24.TabIndex = 215;
            this.rtb_LINKBMFAIL_IG_24.Text = "";
            // 
            // rtb_LINKBM_IG_23
            // 
            this.rtb_LINKBM_IG_23.Location = new System.Drawing.Point(913, 51);
            this.rtb_LINKBM_IG_23.Name = "rtb_LINKBM_IG_23";
            this.rtb_LINKBM_IG_23.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_23.TabIndex = 214;
            this.rtb_LINKBM_IG_23.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_37
            // 
            this.rtb_LINKBMFAIL_IG_37.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_37.Location = new System.Drawing.Point(241, 527);
            this.rtb_LINKBMFAIL_IG_37.Name = "rtb_LINKBMFAIL_IG_37";
            this.rtb_LINKBMFAIL_IG_37.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_37.TabIndex = 213;
            this.rtb_LINKBMFAIL_IG_37.Text = "";
            // 
            // rtb_LINKBM_IG_38
            // 
            this.rtb_LINKBM_IG_38.Location = new System.Drawing.Point(478, 527);
            this.rtb_LINKBM_IG_38.Name = "rtb_LINKBM_IG_38";
            this.rtb_LINKBM_IG_38.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_38.TabIndex = 212;
            this.rtb_LINKBM_IG_38.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_38
            // 
            this.rtb_LINKBMFAIL_IG_38.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_38.Location = new System.Drawing.Point(679, 527);
            this.rtb_LINKBMFAIL_IG_38.Name = "rtb_LINKBMFAIL_IG_38";
            this.rtb_LINKBMFAIL_IG_38.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_38.TabIndex = 211;
            this.rtb_LINKBMFAIL_IG_38.Text = "";
            // 
            // rtb_LINKBM_IG_37
            // 
            this.rtb_LINKBM_IG_37.Location = new System.Drawing.Point(40, 527);
            this.rtb_LINKBM_IG_37.Name = "rtb_LINKBM_IG_37";
            this.rtb_LINKBM_IG_37.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_37.TabIndex = 210;
            this.rtb_LINKBM_IG_37.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_33
            // 
            this.rtb_LINKBMFAIL_IG_33.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_33.Location = new System.Drawing.Point(241, 408);
            this.rtb_LINKBMFAIL_IG_33.Name = "rtb_LINKBMFAIL_IG_33";
            this.rtb_LINKBMFAIL_IG_33.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_33.TabIndex = 209;
            this.rtb_LINKBMFAIL_IG_33.Text = "";
            // 
            // rtb_LINKBM_IG_34
            // 
            this.rtb_LINKBM_IG_34.Location = new System.Drawing.Point(478, 408);
            this.rtb_LINKBM_IG_34.Name = "rtb_LINKBM_IG_34";
            this.rtb_LINKBM_IG_34.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_34.TabIndex = 208;
            this.rtb_LINKBM_IG_34.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_34
            // 
            this.rtb_LINKBMFAIL_IG_34.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_34.Location = new System.Drawing.Point(679, 408);
            this.rtb_LINKBMFAIL_IG_34.Name = "rtb_LINKBMFAIL_IG_34";
            this.rtb_LINKBMFAIL_IG_34.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_34.TabIndex = 207;
            this.rtb_LINKBMFAIL_IG_34.Text = "";
            // 
            // rtb_LINKBM_IG_33
            // 
            this.rtb_LINKBM_IG_33.Location = new System.Drawing.Point(40, 408);
            this.rtb_LINKBM_IG_33.Name = "rtb_LINKBM_IG_33";
            this.rtb_LINKBM_IG_33.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_33.TabIndex = 206;
            this.rtb_LINKBM_IG_33.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_29
            // 
            this.rtb_LINKBMFAIL_IG_29.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_29.Location = new System.Drawing.Point(241, 289);
            this.rtb_LINKBMFAIL_IG_29.Name = "rtb_LINKBMFAIL_IG_29";
            this.rtb_LINKBMFAIL_IG_29.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_29.TabIndex = 205;
            this.rtb_LINKBMFAIL_IG_29.Text = "";
            // 
            // rtb_LINKBM_IG_30
            // 
            this.rtb_LINKBM_IG_30.Location = new System.Drawing.Point(478, 289);
            this.rtb_LINKBM_IG_30.Name = "rtb_LINKBM_IG_30";
            this.rtb_LINKBM_IG_30.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_30.TabIndex = 204;
            this.rtb_LINKBM_IG_30.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_30
            // 
            this.rtb_LINKBMFAIL_IG_30.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_30.Location = new System.Drawing.Point(679, 289);
            this.rtb_LINKBMFAIL_IG_30.Name = "rtb_LINKBMFAIL_IG_30";
            this.rtb_LINKBMFAIL_IG_30.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_30.TabIndex = 203;
            this.rtb_LINKBMFAIL_IG_30.Text = "";
            // 
            // rtb_LINKBM_IG_29
            // 
            this.rtb_LINKBM_IG_29.Location = new System.Drawing.Point(40, 289);
            this.rtb_LINKBM_IG_29.Name = "rtb_LINKBM_IG_29";
            this.rtb_LINKBM_IG_29.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_29.TabIndex = 202;
            this.rtb_LINKBM_IG_29.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_25
            // 
            this.rtb_LINKBMFAIL_IG_25.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_25.Location = new System.Drawing.Point(241, 170);
            this.rtb_LINKBMFAIL_IG_25.Name = "rtb_LINKBMFAIL_IG_25";
            this.rtb_LINKBMFAIL_IG_25.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_25.TabIndex = 201;
            this.rtb_LINKBMFAIL_IG_25.Text = "";
            // 
            // rtb_LINKBM_IG_26
            // 
            this.rtb_LINKBM_IG_26.Location = new System.Drawing.Point(478, 170);
            this.rtb_LINKBM_IG_26.Name = "rtb_LINKBM_IG_26";
            this.rtb_LINKBM_IG_26.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_26.TabIndex = 200;
            this.rtb_LINKBM_IG_26.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_26
            // 
            this.rtb_LINKBMFAIL_IG_26.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_26.Location = new System.Drawing.Point(679, 170);
            this.rtb_LINKBMFAIL_IG_26.Name = "rtb_LINKBMFAIL_IG_26";
            this.rtb_LINKBMFAIL_IG_26.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_26.TabIndex = 199;
            this.rtb_LINKBMFAIL_IG_26.Text = "";
            // 
            // rtb_LINKBM_IG_25
            // 
            this.rtb_LINKBM_IG_25.Location = new System.Drawing.Point(40, 170);
            this.rtb_LINKBM_IG_25.Name = "rtb_LINKBM_IG_25";
            this.rtb_LINKBM_IG_25.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_25.TabIndex = 198;
            this.rtb_LINKBM_IG_25.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_21
            // 
            this.rtb_LINKBMFAIL_IG_21.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_21.Location = new System.Drawing.Point(241, 51);
            this.rtb_LINKBMFAIL_IG_21.Name = "rtb_LINKBMFAIL_IG_21";
            this.rtb_LINKBMFAIL_IG_21.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_21.TabIndex = 197;
            this.rtb_LINKBMFAIL_IG_21.Text = "";
            // 
            // rtb_LINKBM_IG_22
            // 
            this.rtb_LINKBM_IG_22.Location = new System.Drawing.Point(478, 51);
            this.rtb_LINKBM_IG_22.Name = "rtb_LINKBM_IG_22";
            this.rtb_LINKBM_IG_22.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_22.TabIndex = 196;
            this.rtb_LINKBM_IG_22.Text = "";
            // 
            // rtb_LINKBMFAIL_IG_22
            // 
            this.rtb_LINKBMFAIL_IG_22.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.rtb_LINKBMFAIL_IG_22.Location = new System.Drawing.Point(679, 51);
            this.rtb_LINKBMFAIL_IG_22.Name = "rtb_LINKBMFAIL_IG_22";
            this.rtb_LINKBMFAIL_IG_22.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBMFAIL_IG_22.TabIndex = 195;
            this.rtb_LINKBMFAIL_IG_22.Text = "";
            // 
            // rtb_LINKBM_IG_21
            // 
            this.rtb_LINKBM_IG_21.Location = new System.Drawing.Point(40, 51);
            this.rtb_LINKBM_IG_21.Name = "rtb_LINKBM_IG_21";
            this.rtb_LINKBM_IG_21.Size = new System.Drawing.Size(195, 113);
            this.rtb_LINKBM_IG_21.TabIndex = 194;
            this.rtb_LINKBM_IG_21.Text = "";
            // 
            // tabPage18
            // 
            this.tabPage18.BackColor = System.Drawing.Color.Gray;
            this.tabPage18.Controls.Add(this.label145);
            this.tabPage18.Controls.Add(this.delay_check_ig);
            this.tabPage18.Controls.Add(this.label144);
            this.tabPage18.Controls.Add(this.label143);
            this.tabPage18.Controls.Add(this.rtb_282);
            this.tabPage18.Controls.Add(this.rtb_LIVE);
            this.tabPage18.Location = new System.Drawing.Point(4, 24);
            this.tabPage18.Name = "tabPage18";
            this.tabPage18.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage18.Size = new System.Drawing.Size(1767, 688);
            this.tabPage18.TabIndex = 10;
            this.tabPage18.Text = "CHECK LIVE DIE";
            // 
            // label145
            // 
            this.label145.AutoSize = true;
            this.label145.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label145.Location = new System.Drawing.Point(32, 242);
            this.label145.Name = "label145";
            this.label145.Size = new System.Drawing.Size(48, 15);
            this.label145.TabIndex = 201;
            this.label145.Text = "DELAY:";
            // 
            // delay_check_ig
            // 
            this.delay_check_ig.Location = new System.Drawing.Point(35, 271);
            this.delay_check_ig.Name = "delay_check_ig";
            this.delay_check_ig.Size = new System.Drawing.Size(120, 21);
            this.delay_check_ig.TabIndex = 200;
            this.delay_check_ig.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label144
            // 
            this.label144.AutoSize = true;
            this.label144.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label144.Location = new System.Drawing.Point(32, 19);
            this.label144.Name = "label144";
            this.label144.Size = new System.Drawing.Size(37, 15);
            this.label144.TabIndex = 199;
            this.label144.Text = "LIVE:";
            // 
            // label143
            // 
            this.label143.AutoSize = true;
            this.label143.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label143.Location = new System.Drawing.Point(483, 19);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(29, 15);
            this.label143.TabIndex = 198;
            this.label143.Text = "282:";
            // 
            // rtb_282
            // 
            this.rtb_282.Location = new System.Drawing.Point(485, 53);
            this.rtb_282.Name = "rtb_282";
            this.rtb_282.Size = new System.Drawing.Size(391, 177);
            this.rtb_282.TabIndex = 2;
            this.rtb_282.Text = "";
            // 
            // rtb_LIVE
            // 
            this.rtb_LIVE.Location = new System.Drawing.Point(35, 53);
            this.rtb_LIVE.Name = "rtb_LIVE";
            this.rtb_LIVE.Size = new System.Drawing.Size(391, 177);
            this.rtb_LIVE.TabIndex = 1;
            this.rtb_LIVE.Text = "";
            // 
            // tabPage19
            // 
            this.tabPage19.BackColor = System.Drawing.Color.Gray;
            this.tabPage19.Controls.Add(this.tabControl5);
            this.tabPage19.Location = new System.Drawing.Point(4, 24);
            this.tabPage19.Name = "tabPage19";
            this.tabPage19.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage19.Size = new System.Drawing.Size(1767, 688);
            this.tabPage19.TabIndex = 11;
            this.tabPage19.Text = "IG NHAN BM";
            // 
            // tabControl5
            // 
            this.tabControl5.Controls.Add(this.tabPage20);
            this.tabControl5.Controls.Add(this.tabPage21);
            this.tabControl5.Location = new System.Drawing.Point(0, 6);
            this.tabControl5.Name = "tabControl5";
            this.tabControl5.SelectedIndex = 0;
            this.tabControl5.Size = new System.Drawing.Size(1764, 679);
            this.tabControl5.TabIndex = 0;
            // 
            // tabPage20
            // 
            this.tabPage20.BackColor = System.Drawing.Color.Gray;
            this.tabPage20.Controls.Add(this.label170);
            this.tabPage20.Controls.Add(this.label169);
            this.tabPage20.Controls.Add(this.rtb_10_link_bm350);
            this.tabPage20.Controls.Add(this.rtb_10_link_bm50);
            this.tabPage20.Location = new System.Drawing.Point(4, 24);
            this.tabPage20.Name = "tabPage20";
            this.tabPage20.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage20.Size = new System.Drawing.Size(1756, 651);
            this.tabPage20.TabIndex = 0;
            this.tabPage20.Text = "Cài Đặt";
            // 
            // label170
            // 
            this.label170.AutoSize = true;
            this.label170.Location = new System.Drawing.Point(334, 70);
            this.label170.Name = "label170";
            this.label170.Size = new System.Drawing.Size(48, 15);
            this.label170.TabIndex = 34;
            this.label170.Text = "BM350:";
            // 
            // label169
            // 
            this.label169.AutoSize = true;
            this.label169.Location = new System.Drawing.Point(31, 70);
            this.label169.Name = "label169";
            this.label169.Size = new System.Drawing.Size(42, 15);
            this.label169.TabIndex = 33;
            this.label169.Text = "BM50:";
            // 
            // rtb_10_link_bm350
            // 
            this.rtb_10_link_bm350.Location = new System.Drawing.Point(327, 102);
            this.rtb_10_link_bm350.Name = "rtb_10_link_bm350";
            this.rtb_10_link_bm350.Size = new System.Drawing.Size(267, 195);
            this.rtb_10_link_bm350.TabIndex = 29;
            this.rtb_10_link_bm350.Text = "";
            // 
            // rtb_10_link_bm50
            // 
            this.rtb_10_link_bm50.Location = new System.Drawing.Point(34, 102);
            this.rtb_10_link_bm50.Name = "rtb_10_link_bm50";
            this.rtb_10_link_bm50.Size = new System.Drawing.Size(267, 195);
            this.rtb_10_link_bm50.TabIndex = 28;
            this.rtb_10_link_bm50.Text = "";
            // 
            // tabPage21
            // 
            this.tabPage21.BackColor = System.Drawing.Color.Gray;
            this.tabPage21.Location = new System.Drawing.Point(4, 24);
            this.tabPage21.Name = "tabPage21";
            this.tabPage21.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage21.Size = new System.Drawing.Size(1756, 651);
            this.tabPage21.TabIndex = 1;
            this.tabPage21.Text = "NHẬN 1-10";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(306, 28);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown1.TabIndex = 4;
            // 
            // cmb_Chuc_Nang
            // 
            this.cmb_Chuc_Nang.FormattingEnabled = true;
            this.cmb_Chuc_Nang.Location = new System.Drawing.Point(305, 54);
            this.cmb_Chuc_Nang.Name = "cmb_Chuc_Nang";
            this.cmb_Chuc_Nang.Size = new System.Drawing.Size(121, 21);
            this.cmb_Chuc_Nang.TabIndex = 20;
            this.cmb_Chuc_Nang.SelectedIndexChanged += new System.EventHandler(this.cmb_Chuc_Nang_SelectedIndexChanged);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(226, 57);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(74, 13);
            this.label42.TabIndex = 21;
            this.label42.Text = "CHỨC NĂNG:";
            // 
            // tbsodu
            // 
            this.tbsodu.Location = new System.Drawing.Point(864, 27);
            this.tbsodu.Name = "tbsodu";
            this.tbsodu.Size = new System.Drawing.Size(125, 20);
            this.tbsodu.TabIndex = 24;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(776, 30);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(82, 13);
            this.label45.TabIndex = 25;
            this.label45.Text = "Số Dư captcha:";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(788, 62);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(70, 13);
            this.label46.TabIndex = 26;
            this.label46.Text = "Key captcha:";
            // 
            // cmbKeyCaptcha
            // 
            this.cmbKeyCaptcha.FormattingEnabled = true;
            this.cmbKeyCaptcha.Location = new System.Drawing.Point(864, 59);
            this.cmbKeyCaptcha.Name = "cmbKeyCaptcha";
            this.cmbKeyCaptcha.Size = new System.Drawing.Size(230, 21);
            this.cmbKeyCaptcha.TabIndex = 27;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(226, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 28;
            this.label1.Text = "Số Luồng:";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(490, 30);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(27, 13);
            this.label67.TabIndex = 29;
            this.label67.Text = "VIA:";
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(489, 57);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(43, 13);
            this.label68.TabIndex = 30;
            this.label68.Text = "LOGIN:";
            // 
            // cmbVIA
            // 
            this.cmbVIA.FormattingEnabled = true;
            this.cmbVIA.Location = new System.Drawing.Point(538, 28);
            this.cmbVIA.Name = "cmbVIA";
            this.cmbVIA.Size = new System.Drawing.Size(121, 21);
            this.cmbVIA.TabIndex = 31;
            // 
            // cmbLogin
            // 
            this.cmbLogin.FormattingEnabled = true;
            this.cmbLogin.Location = new System.Drawing.Point(538, 53);
            this.cmbLogin.Name = "cmbLogin";
            this.cmbLogin.Size = new System.Drawing.Size(121, 21);
            this.cmbLogin.TabIndex = 32;
            // 
            // btn_Stop
            // 
            this.btn_Stop.BackColor = System.Drawing.Color.Red;
            this.btn_Stop.Location = new System.Drawing.Point(93, 13);
            this.btn_Stop.Name = "btn_Stop";
            this.btn_Stop.Size = new System.Drawing.Size(75, 49);
            this.btn_Stop.TabIndex = 33;
            this.btn_Stop.Text = "STOP";
            this.btn_Stop.UseVisualStyleBackColor = false;
            this.btn_Stop.Click += new System.EventHandler(this.btn_Stop_Click);
            // 
            // lbnew
            // 
            this.lbnew.AutoSize = true;
            this.lbnew.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbnew.Location = new System.Drawing.Point(194, 85);
            this.lbnew.Name = "lbnew";
            this.lbnew.Size = new System.Drawing.Size(47, 13);
            this.lbnew.TabIndex = 5;
            this.lbnew.Text = "1.0.0.0";
            // 
            // labelnew
            // 
            this.labelnew.AutoSize = true;
            this.labelnew.Location = new System.Drawing.Point(115, 85);
            this.labelnew.Name = "labelnew";
            this.labelnew.Size = new System.Drawing.Size(73, 13);
            this.labelnew.TabIndex = 4;
            this.labelnew.Text = "New Version :";
            // 
            // btUpdate
            // 
            this.btUpdate.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btUpdate.Location = new System.Drawing.Point(12, 65);
            this.btUpdate.Name = "btUpdate";
            this.btUpdate.Size = new System.Drawing.Size(75, 49);
            this.btUpdate.TabIndex = 35;
            this.btUpdate.Text = "UPDATE";
            this.btUpdate.UseVisualStyleBackColor = false;
            // 
            // tb_LOAD_STT
            // 
            this.tb_LOAD_STT.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.tb_LOAD_STT.Location = new System.Drawing.Point(1167, 13);
            this.tb_LOAD_STT.Name = "tb_LOAD_STT";
            this.tb_LOAD_STT.Size = new System.Drawing.Size(75, 49);
            this.tb_LOAD_STT.TabIndex = 36;
            this.tb_LOAD_STT.Text = "LOAD STT";
            this.tb_LOAD_STT.UseVisualStyleBackColor = false;
            this.tb_LOAD_STT.Click += new System.EventHandler(this.tb_LOAD_STT_Click);
            // 
            // bt_file_VIA
            // 
            this.bt_file_VIA.BackColor = System.Drawing.Color.MediumOrchid;
            this.bt_file_VIA.Location = new System.Drawing.Point(1271, 13);
            this.bt_file_VIA.Name = "bt_file_VIA";
            this.bt_file_VIA.Size = new System.Drawing.Size(75, 49);
            this.bt_file_VIA.TabIndex = 37;
            this.bt_file_VIA.Text = "FILE VIA";
            this.bt_file_VIA.UseVisualStyleBackColor = false;
            this.bt_file_VIA.Click += new System.EventHandler(this.bt_file_VIA_Click);
            // 
            // label223
            // 
            this.label223.AutoSize = true;
            this.label223.Location = new System.Drawing.Point(8, 322);
            this.label223.Name = "label223";
            this.label223.Size = new System.Drawing.Size(114, 15);
            this.label223.TabIndex = 225;
            this.label223.Text = "delay_entercodefail:";
            // 
            // numericUpDown8
            // 
            this.numericUpDown8.Location = new System.Drawing.Point(141, 318);
            this.numericUpDown8.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.numericUpDown8.Name = "numericUpDown8";
            this.numericUpDown8.Size = new System.Drawing.Size(107, 21);
            this.numericUpDown8.TabIndex = 226;
            this.numericUpDown8.Value = new decimal(new int[] {
            20,
            0,
            0,
            0});
            // 
            // tabPage25
            // 
            this.tabPage25.BackColor = System.Drawing.Color.Gray;
            this.tabPage25.Controls.Add(this.cmn_doc_link_hotmail_vanha);
            this.tabPage25.Controls.Add(this.label224);
            this.tabPage25.Location = new System.Drawing.Point(4, 24);
            this.tabPage25.Name = "tabPage25";
            this.tabPage25.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage25.Size = new System.Drawing.Size(448, 302);
            this.tabPage25.TabIndex = 2;
            this.tabPage25.Text = "ĐỌC LINK ĐA LUỒNG";
            // 
            // label224
            // 
            this.label224.AutoSize = true;
            this.label224.Location = new System.Drawing.Point(17, 25);
            this.label224.Name = "label224";
            this.label224.Size = new System.Drawing.Size(154, 15);
            this.label224.TabIndex = 89;
            this.label224.Text = "ĐỌC LINK LẤY THEO VH:";
            // 
            // cmn_doc_link_hotmail_vanha
            // 
            this.cmn_doc_link_hotmail_vanha.FormattingEnabled = true;
            this.cmn_doc_link_hotmail_vanha.Location = new System.Drawing.Point(180, 17);
            this.cmn_doc_link_hotmail_vanha.Name = "cmn_doc_link_hotmail_vanha";
            this.cmn_doc_link_hotmail_vanha.Size = new System.Drawing.Size(141, 23);
            this.cmn_doc_link_hotmail_vanha.TabIndex = 89;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1776, 830);
            this.Controls.Add(this.bt_file_VIA);
            this.Controls.Add(this.tb_LOAD_STT);
            this.Controls.Add(this.btUpdate);
            this.Controls.Add(this.lbnew);
            this.Controls.Add(this.labelnew);
            this.Controls.Add(this.btn_Stop);
            this.Controls.Add(this.cmbLogin);
            this.Controls.Add(this.cmbVIA);
            this.Controls.Add(this.label68);
            this.Controls.Add(this.label67);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmbKeyCaptcha);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.label45);
            this.Controls.Add(this.tbsodu);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.cmb_Chuc_Nang);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btn_RUN);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "FB";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed_1);
            this.Load += new System.EventHandler(this.Form1_Load_1);
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gioi_han_close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gioi_han_live)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gioi_han_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.delayshare)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sl_Nhan_BM_CLOSE1_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sl_Nhan_BM_PARTNER)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sl_nhan_Bm_BM_BACKUP)).EndInit();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.delay_reg_bm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.for_reg_bm)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.soluong_mua_Mail)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv2_IG)).EndInit();
            this.contextMenuStrip3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_mail)).EndInit();
            this.contextMenuStrip2.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabControl6.ResumeLayout(false);
            this.tabPage23.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage24.ResumeLayout(false);
            this.tabPage24.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5_delay_regbmig)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.num_tao_5bm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.delay_doc_hotmail_1)).EndInit();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.n_slink_share_them)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.delay_tatbatsangtao)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nam_rip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.thang_rip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ngay_rip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5_slcheck_bm350)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.delay_check_admin)).EndInit();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ndelayloop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.delay_link_bm_backup)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            this.tabPage10.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage11.ResumeLayout(false);
            this.tabPage11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.delay_check_infor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sl_LOAD_TK_D2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_AC)).EndInit();
            this.contextMenuStrip5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.delay_LOAD_BM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SL_BM_LOAD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_BM)).EndInit();
            this.contextMenuStrip4.ResumeLayout(false);
            this.tabPage12.ResumeLayout(false);
            this.tabPage12.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.n_Delay_TTK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.delay_doc_link)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.so_link_backup)).EndInit();
            this.tabPage22.ResumeLayout(false);
            this.tabPage22.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sl_BM_kick3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.m_delay_ttk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.delay_kick_bm3)).EndInit();
            this.tabPage13.ResumeLayout(false);
            this.tabPage13.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.tabPage14.ResumeLayout(false);
            this.tabControl4.ResumeLayout(false);
            this.tabPage15.ResumeLayout(false);
            this.tabPage15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DELAY_DOC_MAIL)).EndInit();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.num_STT_NHAN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.number_nhan_fail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown6)).EndInit();
            this.tabPage16.ResumeLayout(false);
            this.tabPage16.PerformLayout();
            this.tabPage17.ResumeLayout(false);
            this.tabPage17.PerformLayout();
            this.tabPage18.ResumeLayout(false);
            this.tabPage18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.delay_check_ig)).EndInit();
            this.tabPage19.ResumeLayout(false);
            this.tabControl5.ResumeLayout(false);
            this.tabPage20.ResumeLayout(false);
            this.tabPage20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown8)).EndInit();
            this.tabPage25.ResumeLayout(false);
            this.tabPage25.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn_RUN;
        private System.Windows.Forms.DataGridView dgv1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridViewTextBoxColumn cStt;
        private System.Windows.Forms.DataGridViewTextBoxColumn cUID;
        private System.Windows.Forms.DataGridViewTextBoxColumn cPass;
        private System.Windows.Forms.DataGridViewTextBoxColumn c2FAvsCookie;
        private System.Windows.Forms.DataGridViewTextBoxColumn cMail;
        private System.Windows.Forms.DataGridViewTextBoxColumn cPassMail;
        private System.Windows.Forms.DataGridViewTextBoxColumn cMailKP;
        private System.Windows.Forms.DataGridViewTextBoxColumn cStatus;
        private System.Windows.Forms.DataGridViewTextBoxColumn cCheckBM;
        private System.Windows.Forms.DataGridViewCheckBoxColumn cSelect;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem chọnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bôiĐenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tấtCảToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bỏChọnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bôiĐenToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tấtCảToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem xóaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dòngĐãChọnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tấtCảToolStripMenuItem2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cmb_ID_MAIL;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox tb_so_du_DongVan;
        private System.Windows.Forms.TextBox Tx_Key_API_DongVan;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox tx_MK_Dong_Vanox2;
        private System.Windows.Forms.TextBox tx_TK_Dong_Van;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.NumericUpDown soluong_mua_Mail;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.ComboBox cmb_DONG_VAN;
        private System.Windows.Forms.ComboBox cmb_Chuc_Nang;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.ComboBox cmb_noveri;
        private System.Windows.Forms.TextBox tbsodu;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.ComboBox cmbKeyCaptcha;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataGridView dgv_mail;
        private System.Windows.Forms.DataGridViewTextBoxColumn cStt1;
        private System.Windows.Forms.DataGridViewTextBoxColumn cMail1;
        private System.Windows.Forms.DataGridViewTextBoxColumn cPassMail1;
        private System.Windows.Forms.DataGridViewTextBoxColumn cToken;
        private System.Windows.Forms.DataGridViewTextBoxColumn cStatus1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn cSelect1;
        private System.Windows.Forms.DataGridView dgv2_IG;
        private System.Windows.Forms.DataGridViewTextBoxColumn cStt2;
        private System.Windows.Forms.DataGridViewTextBoxColumn cIG;
        private System.Windows.Forms.DataGridViewTextBoxColumn cStatus2;
        private System.Windows.Forms.DataGridViewCheckBoxColumn cSelect2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem chọnToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem bôiĐenToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem tấtCảToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem bỏChọnToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem bôiĐenToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem tấtCảToolStripMenuItem4;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip3;
        private System.Windows.Forms.ToolStripMenuItem chọnToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem bôiĐenToolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem tấtCảToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem bỏChọnToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem bôiĐenToolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem tấtCảToolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem xóaToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem bôiĐenToolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem tấtCảToolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem xóaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem dòngĐãChọnToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tấtCảToolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem aDDMAILKPToolStripMenuItem;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.ComboBox cmb_REGHOTMAIL;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.ComboBox cmb_VN_US;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.ComboBox cmb_LOGIN_IG;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TextBox tb_so_luong_BM_PARTNER;
        private System.Windows.Forms.TextBox tb_BM_Close_4;
        private System.Windows.Forms.TextBox tb_BM_Close_3;
        private System.Windows.Forms.TextBox tb_BM_Close_2;
        private System.Windows.Forms.TextBox tb_BM_Close1;
        private System.Windows.Forms.TextBox tb_BM_BACK_UP3;
        private System.Windows.Forms.TextBox tb_BM_BACK_UP2;
        private System.Windows.Forms.TextBox tb_BM_BACK_UP;
        private System.Windows.Forms.TextBox tb_BM;
        private System.Windows.Forms.RichTextBox rtb_IDBM_PARTNER;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSE_4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSE_3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSE_2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CLOSE;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.RichTextBox rtb_ID_BM_Share_BACK_UP3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.RichTextBox rtb_ID_BM_Share_BACK_UP2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.RichTextBox rtb_ID_BM_Share_BACK_UP;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.RichTextBox rtb_ID_BM_Share;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tb_sl_282;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmb_CLOSE_SHARE;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmb_User_Agent;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.RichTextBox rtb_BM_CLOSE_4_THAY_THE;
        private System.Windows.Forms.RichTextBox rtb_BM_CLOSE_3_THAY_THE;
        private System.Windows.Forms.RichTextBox rtb_BM_CLOSE_2_THAY_THE;
        private System.Windows.Forms.RichTextBox rtb_BM_CLOSE_THAY_THE;
        private System.Windows.Forms.RichTextBox rtb_BM_BACKUP3_THAY_THE;
        private System.Windows.Forms.RichTextBox rtb_BM_BACKUP2_THAY_THE;
        private System.Windows.Forms.RichTextBox rtb_BM_BACKUP_THAY_THE;
        private System.Windows.Forms.RichTextBox rtb_BM_THAY_THE;
        private System.Windows.Forms.ComboBox cmb_ADD_Tra_Truoc;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.NumericUpDown gioi_han_close;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.NumericUpDown gioi_han_live;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.NumericUpDown gioi_han_1;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.NumericUpDown delayshare;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.RichTextBox rtb_BM_PARTNER_THAY_THE;
        private System.Windows.Forms.NumericUpDown sl_Nhan_BM_CLOSE1_2;
        private System.Windows.Forms.NumericUpDown sl_Nhan_BM_PARTNER;
        private System.Windows.Forms.NumericUpDown sl_nhan_Bm_BM_BACKUP;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox tx_So_Luong_Share_vao_bm;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.RichTextBox rtb_BMDIE;
        private System.Windows.Forms.RichTextBox rtb_BM_Nhan_Du;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.RichTextBox rtbdone;
        private System.Windows.Forms.RichTextBox rtbAC_FAIL;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.RichTextBox rtb_MAIL_SHARE_CLONE;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cmb_Share_BM_CLone;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.ComboBox cmb_Mui_Gio_TK_BM;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.ComboBox cmb_TEN_TK_BM;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.ComboBox cmb_Tien_Te_TK_BM;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.NumericUpDown delay_reg_bm;
        private System.Windows.Forms.NumericUpDown for_reg_bm;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmb_Tao_TK_BM;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmb_REG_BM_Clone_API;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.TextBox tb_so_luong_BM;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.ComboBox cmb_Share_DOI_TAC;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RichTextBox rtb_DONE1;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.ToolStripMenuItem nHẬNBMNEWToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.ComboBox cmb_IP;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.ComboBox cmbVIA;
        private System.Windows.Forms.ComboBox cmbLogin;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.ComboBox cmbonoffchrome;
        private System.Windows.Forms.ComboBox cmb_lay_Cookie;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Button btn_Stop;
        private System.Windows.Forms.RichTextBox rtb_FAIL3;
        private System.Windows.Forms.RichTextBox rtb_linkmail3_backup;
        private System.Windows.Forms.RichTextBox rtb_DONE3;
        private System.Windows.Forms.RichTextBox rtb_FAIL2;
        private System.Windows.Forms.RichTextBox rtb_linkmail2_backup;
        private System.Windows.Forms.RichTextBox rtb_DONE2;
        private System.Windows.Forms.RichTextBox rtb_FAIL1;
        private System.Windows.Forms.RichTextBox rtb_linkmail1_backup;
        private System.Windows.Forms.RichTextBox rtb_MAIL_DOCLINK_BACKUP;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.NumericUpDown delay_link_bm_backup;
        private System.Windows.Forms.ComboBox cmb_DUNG_DOC_LINK_BACKUP;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.NumericUpDown ndelayloop;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.ComboBox cmb_HOTMAIL_GMAIL;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.ComboBox cmb_ON_OFF_2FAIG;
        private System.Windows.Forms.ToolStripMenuItem tẮTBẬTSÁNGTẠOIGToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cHECKBMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sHAREBMIGToolStripMenuItem;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.RichTextBox rtb_Link_BM_IG;
        private System.Windows.Forms.ComboBox cmb_Admin_BM;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.RichTextBox rtb_hotmail;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.ComboBox cmb_MAIL_SHARE_BM_IG;
        private System.Windows.Forms.ToolStripMenuItem rEGBM12ToolStripMenuItem;
        private System.Windows.Forms.ComboBox cmb_TAT_BAT_SANG_TAO;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.ComboBox cmb_AN_CHROME;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.ToolStripMenuItem rEGBM2025ToolStripMenuItem;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.NumericUpDown delay_check_admin;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.RichTextBox rtb_Link_BM350_IG;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.ComboBox cmb_CHECK_ADMIN;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.RichTextBox rtb_BMIII;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.ComboBox cmb_DOC_LINK_MAX;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.DataGridView dgv_BM;
        private System.Windows.Forms.Button bt_filter;
        private System.Windows.Forms.RichTextBox rtb_IDBM_FILTER;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip4;
        private System.Windows.Forms.ToolStripMenuItem lOADALLBMVIAToolStripMenuItem;
        private System.Windows.Forms.NumericUpDown SL_BM_LOAD;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.NumericUpDown delay_LOAD_BM;
        private System.Windows.Forms.ToolStripMenuItem chọnToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem bôiĐenToolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem tấtCảToolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem bỏChọnToolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem bôiĐenToolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem tấtCảToolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem xóaALLToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgv_AC;
        private System.Windows.Forms.DataGridViewTextBoxColumn cSttACBM;
        private System.Windows.Forms.DataGridViewTextBoxColumn cIDACBM;
        private System.Windows.Forms.DataGridViewTextBoxColumn cNAMEAC;
        private System.Windows.Forms.DataGridViewTextBoxColumn cStatusAC;
        private System.Windows.Forms.DataGridViewTextBoxColumn cLimit;
        private System.Windows.Forms.DataGridViewTextBoxColumn cTIENTE;
        private System.Windows.Forms.DataGridViewTextBoxColumn cNGAYTAOACBM;
        private System.Windows.Forms.DataGridViewCheckBoxColumn cSelectACBM;
        private System.Windows.Forms.ToolStripMenuItem lOADTKDONGToolStripMenuItem;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.NumericUpDown sl_LOAD_TK_D2;
        private System.Windows.Forms.ToolStripMenuItem bACKUPBMToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.NumericUpDown delay_doc_link;
        private System.Windows.Forms.NumericUpDown so_link_backup;
        private System.Windows.Forms.TextBox tb_hotmail_Share_bm;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.RichTextBox rtb_Link_BM;
        private System.Windows.Forms.ComboBox cmb_loai_mail;
        private System.Windows.Forms.ComboBox cmb_Admin_BM1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip5;
        private System.Windows.Forms.ToolStripMenuItem xÓAALLToolStripMenuItem1;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.ComboBox cmb_CACH_NHAN_LINK;
        private System.Windows.Forms.ComboBox cmbAPI_Auto_selenium_NhanBM;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.RichTextBox rtbLINK;
        private System.Windows.Forms.RichTextBox rtb_Link_FAIL;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_20;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_19;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_18;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_17;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_16;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_15;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_14;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_13;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_12;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_11;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_10;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_9;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_8;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_7;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_6;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_5;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_4;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_3;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_2;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_1;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.ToolStripMenuItem nHẬNBMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loginVIAToolStripMenuItem;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.ComboBox cmb_2FA_IG;
        private System.Windows.Forms.ToolStripMenuItem kILLChromeDriverToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lấyCookieVIAToolStripMenuItem;
        private System.Windows.Forms.ComboBox cmb_REG_BM_IG1;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.ComboBox cmb_TTKQC_BM_IG;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.NumericUpDown numericUpDown4;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.TabPage tabPage15;
        private System.Windows.Forms.TabPage tabPage16;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_19;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_20;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_20;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_19;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_15;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_16;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_16;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_15;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_11;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_12;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_12;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_11;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_7;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_8;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_8;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_7;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_3;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_4;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_4;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_3;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_17;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_18;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_18;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_17;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_13;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_14;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_14;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_13;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_9;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_10;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_10;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_9;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_5;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_6;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_6;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_5;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_1;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_2;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_2;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_1;
        private System.Windows.Forms.TabPage tabPage17;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_39;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_40;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_40;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_39;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_35;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_36;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_36;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_35;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_31;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_32;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_32;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_31;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_27;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_28;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_28;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_27;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_23;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_24;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_24;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_23;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_37;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_38;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_38;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_37;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_33;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_34;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_34;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_33;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_29;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_30;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_30;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_29;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_25;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_26;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_26;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_25;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_21;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_22;
        private System.Windows.Forms.RichTextBox rtb_LINKBMFAIL_IG_22;
        private System.Windows.Forms.RichTextBox rtb_LINKBM_IG_21;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.RichTextBox rtb_Link_BM50_IG_auto;
        private System.Windows.Forms.RichTextBox rtb_hotmail_BM350;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.RichTextBox rtb_mail_bm350_auto;
        private System.Windows.Forms.RichTextBox rtb_mail_bm50_auto;
        private System.Windows.Forms.RichTextBox rtb_BMIII_auto;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.RichTextBox rtb_Link_BM350_IG_auto;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.ToolStripMenuItem nHẬNBMAUTOToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.ComboBox cmbAPI_Auto_selenium_NhanBM_IG;
        private System.Windows.Forms.ComboBox cmb_STOP;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.TextBox tb_nhan19;
        private System.Windows.Forms.TextBox tb_19;
        private System.Windows.Forms.TextBox tb_nhan15;
        private System.Windows.Forms.TextBox tb_15;
        private System.Windows.Forms.TextBox tb_nhan11;
        private System.Windows.Forms.TextBox tb_11;
        private System.Windows.Forms.TextBox tb_nhan7;
        private System.Windows.Forms.TextBox tb_7;
        private System.Windows.Forms.TextBox tb_nhan3;
        private System.Windows.Forms.TextBox tb_3;
        private System.Windows.Forms.TextBox tb_nhan18;
        private System.Windows.Forms.TextBox tb_18;
        private System.Windows.Forms.TextBox tb_nhan14;
        private System.Windows.Forms.TextBox tb_14;
        private System.Windows.Forms.TextBox tb_nhan10;
        private System.Windows.Forms.TextBox tb_10;
        private System.Windows.Forms.TextBox tb_nhan6;
        private System.Windows.Forms.TextBox tb_6;
        private System.Windows.Forms.TextBox tb_nhan2;
        private System.Windows.Forms.TextBox tb_2;
        private System.Windows.Forms.TextBox tb_nhan17;
        private System.Windows.Forms.TextBox tb_17;
        private System.Windows.Forms.TextBox tb_nhan13;
        private System.Windows.Forms.TextBox tb_13;
        private System.Windows.Forms.TextBox tb_nhan9;
        private System.Windows.Forms.TextBox tb_9;
        private System.Windows.Forms.TextBox tb_nhan5;
        private System.Windows.Forms.TextBox tb_5;
        private System.Windows.Forms.TextBox tb_nhan1;
        private System.Windows.Forms.TextBox tb_1;
        private System.Windows.Forms.TextBox tb_nhan20;
        private System.Windows.Forms.TextBox tb_20;
        private System.Windows.Forms.TextBox tb_nhan16;
        private System.Windows.Forms.TextBox tb_16;
        private System.Windows.Forms.TextBox tb_nhan12;
        private System.Windows.Forms.TextBox tb_12;
        private System.Windows.Forms.TextBox tb_nhan8;
        private System.Windows.Forms.TextBox tb_8;
        private System.Windows.Forms.TextBox tb_nhan4;
        private System.Windows.Forms.TextBox tb_4;
        private System.Windows.Forms.TextBox tb_nhan40;
        private System.Windows.Forms.TextBox tb_40;
        private System.Windows.Forms.TextBox tb_nhan36;
        private System.Windows.Forms.TextBox tb_36;
        private System.Windows.Forms.TextBox tb_nhan32;
        private System.Windows.Forms.TextBox tb_32;
        private System.Windows.Forms.TextBox tb_nhan28;
        private System.Windows.Forms.TextBox tb_28;
        private System.Windows.Forms.TextBox tb_nhan24;
        private System.Windows.Forms.TextBox tb_24;
        private System.Windows.Forms.TextBox tb_nhan39;
        private System.Windows.Forms.TextBox tb_39;
        private System.Windows.Forms.TextBox tb_nhan35;
        private System.Windows.Forms.TextBox tb_35;
        private System.Windows.Forms.TextBox tb_nhan31;
        private System.Windows.Forms.TextBox tb_31;
        private System.Windows.Forms.TextBox tb_nhan27;
        private System.Windows.Forms.TextBox tb_27;
        private System.Windows.Forms.TextBox tb_nhan23;
        private System.Windows.Forms.TextBox tb_23;
        private System.Windows.Forms.TextBox tb_nhan38;
        private System.Windows.Forms.TextBox tb_38;
        private System.Windows.Forms.TextBox tb_nhan34;
        private System.Windows.Forms.TextBox tb_34;
        private System.Windows.Forms.TextBox tb_nhan30;
        private System.Windows.Forms.TextBox tb_30;
        private System.Windows.Forms.TextBox tb_nhan26;
        private System.Windows.Forms.TextBox tb_26;
        private System.Windows.Forms.TextBox tb_nhan22;
        private System.Windows.Forms.TextBox tb_22;
        private System.Windows.Forms.TextBox tb_nhan37;
        private System.Windows.Forms.TextBox tb_37;
        private System.Windows.Forms.TextBox tb_nhan33;
        private System.Windows.Forms.TextBox tb_33;
        private System.Windows.Forms.TextBox tb_nhan29;
        private System.Windows.Forms.TextBox tb_29;
        private System.Windows.Forms.TextBox tb_nhan25;
        private System.Windows.Forms.TextBox tb_25;
        private System.Windows.Forms.TextBox tb_nhan21;
        private System.Windows.Forms.TextBox tb_21;
        private System.Windows.Forms.ComboBox cmb_UP_WEB;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.TextBox tb_MK_NAM;
        private System.Windows.Forms.TextBox tb_TK_NAM;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.TextBox tb_ID_UP;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.ComboBox CMB_LOAI_BM_NHAN;
        private System.Windows.Forms.Label label142;
        private System.Windows.Forms.ComboBox cmb_LOAI_LINK;
        private System.Windows.Forms.ToolStripMenuItem bACKUPBMNHIEUVIAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lOGINGMAILCHROMEToolStripMenuItem;
        private System.Windows.Forms.TabPage tabPage18;
        private System.Windows.Forms.Label label144;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.RichTextBox rtb_282;
        private System.Windows.Forms.RichTextBox rtb_LIVE;
        private System.Windows.Forms.Label label145;
        private System.Windows.Forms.NumericUpDown delay_check_ig;
        private System.Windows.Forms.ToolStripMenuItem tESTWABMToolStripMenuItem;
        private System.Windows.Forms.Label lbnew;
        private System.Windows.Forms.Label labelnew;
        private System.Windows.Forms.Button btUpdate;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label146;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ComboBox cmb_FILE_OPEN;
        private System.Windows.Forms.Label label148;
        private System.Windows.Forms.Button bt_CLEAR_LINK;
        private System.Windows.Forms.Label label147;
        private System.Windows.Forms.Button bt_CLEAR_FAIL;
        private System.Windows.Forms.ComboBox cmb_Tao_5BM_IG;
        private System.Windows.Forms.Label label149;
        private System.Windows.Forms.Label label150;
        private System.Windows.Forms.NumericUpDown num_tao_5bm;
        private System.Windows.Forms.Label label151;
        private System.Windows.Forms.NumericUpDown numericUpDown5_delay_regbmig;
        private System.Windows.Forms.ComboBox cmb_chishare_bm350;
        private System.Windows.Forms.Label label152;
        private System.Windows.Forms.Label label153;
        private System.Windows.Forms.NumericUpDown numericUpDown5_slcheck_bm350;
        private System.Windows.Forms.ComboBox cmb_on_off_chrome;
        private System.Windows.Forms.Label label154;
        private System.Windows.Forms.Label label155;
        private System.Windows.Forms.ComboBox cmb_color350;
        private System.Windows.Forms.ComboBox cmb_BMT6;
        private System.Windows.Forms.Label label156;
        private System.Windows.Forms.ComboBox cmb_RIPIG;
        private System.Windows.Forms.Label label157;
        private System.Windows.Forms.Label label160;
        private System.Windows.Forms.Label label159;
        private System.Windows.Forms.Label label158;
        private System.Windows.Forms.NumericUpDown nam_rip;
        private System.Windows.Forms.NumericUpDown thang_rip;
        private System.Windows.Forms.NumericUpDown ngay_rip;
        private System.Windows.Forms.Label label161;
        private System.Windows.Forms.ComboBox cmb_sharebmt6_350;
        private System.Windows.Forms.ComboBox cmb_sharebmt6_50;
        private System.Windows.Forms.Label label162;
        private System.Windows.Forms.Label label163;
        private System.Windows.Forms.NumericUpDown delay_tatbatsangtao;
        private System.Windows.Forms.ToolStripMenuItem bACKUPBMTHEOIDToolStripMenuItem;
        private System.Windows.Forms.Label label164;
        private System.Windows.Forms.RichTextBox rtb_IDBM_CAN_BACK_Up;
        private System.Windows.Forms.Label label165;
        private System.Windows.Forms.RichTextBox rtb_IDBM_Can_Tao_TK;
        private System.Windows.Forms.Label label166;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label167;
        private System.Windows.Forms.NumericUpDown n_slink_share_them;
        private System.Windows.Forms.Label label168;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.TabPage tabPage19;
        private System.Windows.Forms.TabControl tabControl5;
        private System.Windows.Forms.TabPage tabPage20;
        private System.Windows.Forms.TabPage tabPage21;
        private System.Windows.Forms.Label label170;
        private System.Windows.Forms.Label label169;
        private System.Windows.Forms.RichTextBox rtb_10_link_bm350;
        private System.Windows.Forms.RichTextBox rtb_10_link_bm50;
        private System.Windows.Forms.Label label171;
        private System.Windows.Forms.ComboBox cmb_loai_mail_nhan_bm_ig;
        private System.Windows.Forms.Button btn_update_mail;
        private System.Windows.Forms.Label label172;
        private System.Windows.Forms.RichTextBox rtb_ADMIN_BM_CHECK;
        private System.Windows.Forms.ToolStripMenuItem oUTBMTHEOIDToolStripMenuItem;
        private System.Windows.Forms.Label label173;
        private System.Windows.Forms.RichTextBox rtb_BM_OUT;
        private System.Windows.Forms.ToolStripMenuItem cHECKADMINBMTHEOIDToolStripMenuItem;
        private System.Windows.Forms.Button bt_doi_dinh_dang;
        private System.Windows.Forms.Label label174;
        private System.Windows.Forms.RichTextBox rtb_backup_fail;
        private System.Windows.Forms.Label label175;
        private System.Windows.Forms.ComboBox cmb_REG_BM_IG_API_CHROME;
        private System.Windows.Forms.ComboBox cmb_TTK_BM350;
        private System.Windows.Forms.ComboBox cmb_TTK_BM50;
        private System.Windows.Forms.Label label177;
        private System.Windows.Forms.Label label176;
        private System.Windows.Forms.Label label178;
        private System.Windows.Forms.NumericUpDown DELAY_DOC_MAIL;
        private System.Windows.Forms.Label label180;
        private System.Windows.Forms.Label label179;
        private System.Windows.Forms.RichTextBox rtb_mail_moakt_fail;
        private System.Windows.Forms.RichTextBox rtb_mail_moakt_done;
        private System.Windows.Forms.ComboBox cmb_doc_luon_link_mail_ao;
        private System.Windows.Forms.Label label181;
        private System.Windows.Forms.ToolStripMenuItem kICHWHATAPPToolStripMenuItem;
        private System.Windows.Forms.TabPage tabPage22;
        private System.Windows.Forms.Label label182;
        private System.Windows.Forms.TextBox tb_TokenEEAG;
        private System.Windows.Forms.Label label183;
        private System.Windows.Forms.RichTextBox rtb_IDBM_KICK_BM3;
        private System.Windows.Forms.Label label184;
        private System.Windows.Forms.RichTextBox rtb_status_kick;
        private System.Windows.Forms.NumericUpDown delay_kick_bm3;
        private System.Windows.Forms.Label label185;
        private System.Windows.Forms.TextBox tb_NAME_WHATAPP;
        private System.Windows.Forms.Label label186;
        private System.Windows.Forms.Label label187;
        private System.Windows.Forms.NumericUpDown numericUpDown5;
        private System.Windows.Forms.Button btdoidang;
        private System.Windows.Forms.ToolStripMenuItem cHECKINFORBMToolStripMenuItem;
        private System.Windows.Forms.Label label188;
        private System.Windows.Forms.NumericUpDown numericUpDown6;
        private System.Windows.Forms.TextBox tb_EEAG_LOAD_BM;
        private System.Windows.Forms.Label label189;
        private System.Windows.Forms.ComboBox cmb_chi_doc_link_mail_ao;
        private System.Windows.Forms.Label label190;
        private System.Windows.Forms.Label label191;
        private System.Windows.Forms.ComboBox cmb_TTKQCBM3;
        private System.Windows.Forms.Label label192;
        private System.Windows.Forms.Button bt_Tao_TK_BM;
        private System.Windows.Forms.Label label194;
        private System.Windows.Forms.NumericUpDown n_Delay_TTK;
        private System.Windows.Forms.Label label193;
        private System.Windows.Forms.NumericUpDown numericUpDown7;
        private System.Windows.Forms.TextBox tb_Token;
        private System.Windows.Forms.Label label195;
        private System.Windows.Forms.Label label196;
        private System.Windows.Forms.NumericUpDown numericUpDown9;
        private System.Windows.Forms.Label label197;
        private System.Windows.Forms.NumericUpDown m_delay_ttk;
        private System.Windows.Forms.Label label198;
        private System.Windows.Forms.ComboBox cmb_kick_BM3_IG;
        private System.Windows.Forms.Label label199;
        private System.Windows.Forms.ComboBox cmb_share_ban;
        private System.Windows.Forms.Label label200;
        private System.Windows.Forms.ComboBox cmb_bo_DIE;
        private System.Windows.Forms.ComboBox cmb_DIE_BM_CLEAR;
        private System.Windows.Forms.Label label201;
        private System.Windows.Forms.NumericUpDown number_nhan_fail;
        private System.Windows.Forms.Label label202;
        private System.Windows.Forms.Label label204;
        private System.Windows.Forms.Label label203;
        private System.Windows.Forms.RichTextBox rtb_BM1;
        private System.Windows.Forms.RichTextBox rtb_BM3;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.ComboBox cmb_Tao_1_5;
        private System.Windows.Forms.Label label205;
        private System.Windows.Forms.Label label206;
        private System.Windows.Forms.NumericUpDown sl_BM_kick3;
        private System.Windows.Forms.ToolStripMenuItem cHECKADMINIGToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uOTIGBMFBToolStripMenuItem;
        private System.Windows.Forms.Label label207;
        private System.Windows.Forms.ComboBox cmb_LOAD_API_CHROME;
        private System.Windows.Forms.DataGridViewTextBoxColumn cSTTBM;
        private System.Windows.Forms.DataGridViewTextBoxColumn cIDVIA;
        private System.Windows.Forms.DataGridViewTextBoxColumn cIDBM;
        private System.Windows.Forms.DataGridViewTextBoxColumn cNAMEBM;
        private System.Windows.Forms.DataGridViewTextBoxColumn cStatusBM;
        private System.Windows.Forms.DataGridViewTextBoxColumn cLOAIBM;
        private System.Windows.Forms.DataGridViewTextBoxColumn cinfor;
        private System.Windows.Forms.DataGridViewTextBoxColumn cNgayTao;
        private System.Windows.Forms.DataGridViewTextBoxColumn cADMIN;
        private System.Windows.Forms.DataGridViewTextBoxColumn cTKLIVEDIE;
        private System.Windows.Forms.DataGridViewCheckBoxColumn cSelectBM;
        private System.Windows.Forms.ComboBox cmb_API_CHROME_BACK_UP_BM_THEO_ID;
        private System.Windows.Forms.Label label208;
        private System.Windows.Forms.NumericUpDown delay_check_infor;
        private System.Windows.Forms.Label label209;
        private System.Windows.Forms.ComboBox cmb_Check_Infor_BM;
        private System.Windows.Forms.TextBox tb_IDBM_CHECK;
        private System.Windows.Forms.Label label210;
        private System.Windows.Forms.ComboBox cmb_bo_check1;
        private System.Windows.Forms.Label label211;
        private System.Windows.Forms.Label label212;
        private System.Windows.Forms.ComboBox cmb_ttk_5_1_WA;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ComboBox cmb_file_random;
        private System.Windows.Forms.ComboBox cmb_dinh_dang_ten;
        private System.Windows.Forms.Label label213;
        private System.Windows.Forms.TabControl tabControl6;
        private System.Windows.Forms.TabPage tabPage23;
        private System.Windows.Forms.TabPage tabPage24;
        private System.Windows.Forms.ComboBox cmb_Random4_17;
        private System.Windows.Forms.Label label214;
        private System.Windows.Forms.ComboBox cmb_NO_RANDOM;
        private System.Windows.Forms.Label label215;
        private System.Windows.Forms.Label label216;
        private System.Windows.Forms.RichTextBox rtb_codemail;
        private System.Windows.Forms.NumericUpDown num_STT_NHAN;
        private System.Windows.Forms.Label label217;
        private System.Windows.Forms.Button tb_LOAD_STT;
        private System.Windows.Forms.ComboBox cmb_VIA_NHAN_VERRY;
        private System.Windows.Forms.Label label218;
        private System.Windows.Forms.Label label220;
        private System.Windows.Forms.ComboBox cmb_new_create_WA;
        private System.Windows.Forms.Label label219;
        private System.Windows.Forms.ComboBox cmb_delete_WA;
        private System.Windows.Forms.ComboBox cmb_kologin_mail;
        private System.Windows.Forms.Label label221;
        private System.Windows.Forms.Button bt_file_VIA;
        private System.Windows.Forms.NumericUpDown delay_doc_hotmail_1;
        private System.Windows.Forms.Label label222;
        private System.Windows.Forms.NumericUpDown numericUpDown8;
        private System.Windows.Forms.Label label223;
        private System.Windows.Forms.TabPage tabPage25;
        private System.Windows.Forms.ComboBox cmn_doc_link_hotmail_vanha;
        private System.Windows.Forms.Label label224;
    }
}

