﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TrayNotify;

namespace BMD2
{
    public partial class MessageBoxMAIL: Form
    {
        public MessageBoxMAIL(string message, string title, Image icon = null, Image background = null)
        {
            InitializeComponent();
            this.Text = title;
            using (Bitmap bmp = new Bitmap("moakt.jpg"))
            {
                IntPtr hIcon = bmp.GetHicon();
                this.Icon = Icon.FromHandle(hIcon);
            }// 🔔 Thay icon ở đây
            lblMessage.Text = message;

            //if (icon != null)
            //    pictureBoxIcon.Image = icon;

            if (background != null)
            {
                this.BackgroundImage = background;
                this.BackgroundImageLayout = ImageLayout.Stretch;
            }
        }

        private void MessageBoxMAIL_Load(object sender, EventArgs e)
        {

        }

    
        public static void ShowMessageMAIL(string message, string title, string iconPath, string backgroundPath)
        {
            Image icon = File.Exists(iconPath) ? Image.FromFile(iconPath) : null;
            Image bg = File.Exists(backgroundPath) ? Image.FromFile(backgroundPath) : null;

            using (var box = new MessageBoxMAIL(message, title, icon, bg)) // ✅ Gọi đúng class
            {
                box.ShowDialog();
            }
        }
    }
}
