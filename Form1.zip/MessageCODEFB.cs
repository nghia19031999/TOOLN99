﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TrayNotify;

namespace BMD2
{
    public partial class MessageCODEFB: Form
    {
        public MessageCODEFB(string message, string title, Image icon = null, Image background = null)
        {
            InitializeComponent();
            this.Text = title;
            using (Bitmap bmp = new Bitmap("anhrong.jpg"))
            {
                IntPtr hIcon = bmp.GetHicon();
                this.Icon = Icon.FromHandle(hIcon);
            }// 🔔 Thay icon ở đây
            lblMessage.Text = message;

            //if (icon != null)
            //    pictureBoxIcon.Image = icon;

            if (background != null)
            {
                this.BackgroundImage = background;
                this.BackgroundImageLayout = ImageLayout.Stretch;
            }
        }
        public static void ShowMessage(string message, string title, string iconPath, string backgroundPath)
        {
            Image icon = File.Exists(iconPath) ? Image.FromFile(iconPath) : null;
            Image bg = File.Exists(backgroundPath) ? Image.FromFile(backgroundPath) : null;

            using (var box = new MessageCODEFB(message, title, icon, bg)) // ✅ Gọi đúng class
            {
                box.ShowDialog();
            }
        }



    }
}
