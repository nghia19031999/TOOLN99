
                    var config = {
                    mode: "fixed_servers",
                    rules: {
                    singleProxy: {
                    scheme: "http",
                    host: "pama02.quat.uk",
                    port: parseInt("51051")
                    },
                    bypassList: ["localhost"]
                    }
                    };
                    chrome.proxy.settings.set({value: config, scope: "regular"}, function(){});
                    function callbackFn(details) {
                    return {
                    authCredentials: {
                    username: "LhNXw4",
                    password: "7aV0Xf"
                    }
                    };
                    }
                    chrome.webRequest.onAuthRequired.addListener(
                    callbackFn,
                    {urls: ["<all_urls>"]},
                    ["blocking"]
                    );
                